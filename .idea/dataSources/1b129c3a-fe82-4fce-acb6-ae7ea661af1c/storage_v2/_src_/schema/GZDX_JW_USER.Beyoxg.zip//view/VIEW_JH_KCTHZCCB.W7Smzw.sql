create view VIEW_JH_KCTHZCCB as
  select kcthzccb_id,kcthz_id,kcthzz_id,ccgx,bz,tybj,jlsj,jlr,qtsj,qtr from JW_JH_KCTHZCCB
union
select kcthzccb_id,kcthzz_id||'A',kcthz_id||'A',ccgx,bz,tybj,jlsj,jlr,qtsj,qtr from JW_JH_KCTHZCCB where ccgx='='
/

