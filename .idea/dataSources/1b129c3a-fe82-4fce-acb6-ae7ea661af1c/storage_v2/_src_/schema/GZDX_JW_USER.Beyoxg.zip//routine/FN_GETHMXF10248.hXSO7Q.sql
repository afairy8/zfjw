create function FN_GETHMXF10248(v_xh_id varchar2,v_xfyqjd_id varchar2) return varchar2
/****查询节点总共的豁免学分 上海交通大学 只考虑 校外课程认定节点 ****/
as
   hmxf varchar2(20);
begin
        select
                (select nvl(sum(kcxx.xf),0)
                 from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b,jw_jh_xsjxzxjhkcxxb kcxx
                where b.xrdz_id = t.rdz_id
                  and b.rdlybj = '2'
                  and b.shjg='3'
                  and b.xh_id = v_xh_id
                  and b.xh_id  = kcxx.xh_id
		  and t.kch_id = kcxx.xfyqjd_id
		  and kcxx.xfyqjd_id = v_xfyqjd_id) into hmxf
           from dual;

    if hmxf is null then
       hmxf := 0;
    end if;
    return hmxf;
end FN_GETHMXF10248;

/

