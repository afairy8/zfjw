create function fn_fxxx(vXh_id varchar2, vFlag  varchar2) return  varchar2--返回辅修信息 （学号、标记）
as
  sFxxx varchar2(20);--辅修信息
  v_professional  varchar2(20);-- 专业
  v_college  varchar2(20);--学院
begin
  sFxxx :='';
  begin
       --获取专业名称
       if vFlag = 'zy' then

         select
           (select zymc from zftal_xtgl_zydmb where zyh_id = bmb.zyh_id) into v_professional
         from jw_fx_fxezybmb bmb
         where bmb.xh_id = vXh_id;

         --赋值
         sFxxx := v_professional;
       end if;

       --获取学院名称
       if vFlag = 'xy' then
         select
           ( select (select jgmc from zftal_xtgl_jgdmb where jg_id = zy.jg_id) jgmc from zftal_xtgl_zydmb zy where zy.zyh_id = bmb.zyh_id) into v_college
         from jw_fx_fxezybmb bmb
         where bmb.xh_id = vXh_id;

         --赋值
         sFxxx := v_college;
       end if;

  exception
    When others then
      sFxxx := '';
  end;

  if sFxxx is null then
   return '' ;
  else
   return sFxxx ;
  end if ;
end fn_fxxx;

/

