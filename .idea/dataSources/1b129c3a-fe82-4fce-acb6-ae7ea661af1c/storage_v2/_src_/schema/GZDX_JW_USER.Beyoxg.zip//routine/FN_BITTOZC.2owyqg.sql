create function FN_BITTOZC(int_ZC in int) return varchar2 is
  i       int;
  LoopCount int;
  returnstr varchar2(1000);
begin
   /**通过周次二进制计算出，周次明细**/
  if int_ZC = 0 then
    return '';
  end if;
  i := 0;
  returnstr:='';
  LoopCount:=round(log(2,int_ZC));
  while i <= LoopCount Loop
    if bitand (power(2,i),int_ZC)<>0 then
    if (returnstr = '') or (returnstr is null) then
     returnstr := to_char(i);
     else
     returnstr := returnstr||','||to_char(i);
     end if;
    End if;
    i := i + 1;
  End Loop;
  return(returnstr);
end FN_BITTOZC;


/

