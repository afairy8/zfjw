create view GZDXJCJK_ZYDMB as
  select a.zyh zydm,a.zymc,b.jg_id ssxydm,a.xz xz
from zftal_xtgl_zydmb a ,zftal_xtgl_jgdmb b
where a.jg_id=b.jg_id
union
select 'XXXX' zydm,'无专业','40' ssxydm,'4' xz from dual
/

