create function fn_jqzd(str_ysj in varchar2,   ---原数据
                                str_fgf in varchar2,      ---分格符
                                int_wz  in int) return varchar2 is  ---位数
  i       int;
  wz      int;
  int_zgs int;
  int_gs  int;
  str_zf  varchar2(4000);

begin
  i       := 1;
  wz      := 1;
  int_zgs := 0;
  int_gs  := 0;

  while i <= length(str_ysj) Loop
    If wz <= i Then
      If substr(str_ysj, i, length(str_fgf)) = str_fgf Then
        int_zgs := int_zgs + 1;
        wz      := i + length(str_fgf);
      End if;
    End if;
    i := i + 1;
  End Loop;

  If int_wz > int_zgs + 1 Then
    str_zf := '';
    return(str_zf);
  End if;

  wz := 1;
  i  := 1;

  while i <= length(str_ysj) Loop
    If wz <= i Then
      If substr(str_ysj, i, length(str_fgf)) = str_fgf Then
        int_gs := int_gs + 1;
        If int_wz < int_zgs + 1 Then
          If int_gs = int_wz Then
            str_zf := substr(str_ysj, wz, i - wz);
          end if;
        Else
          If (int_wz = int_zgs + 1) And (int_gs = int_zgs) Then
            str_zf := substr(str_ysj,
                             i + length(str_fgf),
                             length(str_ysj) - (i + length(str_fgf)) + 1);
          end if;
        End if;
        wz := i + length(str_fgf);
      End if;
    End if;

    i := i + 1;
  End loop;

  If int_zgs = 0 Then
    str_zf := str_ysj;
  end if;

  return(str_zf);
end fn_jqzd;

/

