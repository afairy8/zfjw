create function fn_cx_jfdj(
  vNjdm_id varchar2,
  vZyh_id varchar2,
  vKch_id varchar2,
  vJxb_id varchar2,
  vXh_id varchar2,
  vJflx varchar2
) return number
as
   v_kclbdm varchar2(10);
   v_jfdj number;   ---缴费单价
begin
    begin
        select nvl(max(kclbdm),'wdm') into v_kclbdm from jw_jh_jxzxjhkcxxb where njdm_id=vNjdm_id and zyh_id=vZyh_id and kch_id=vKch_id and kclbdm is not null and rownum=1;
        if v_kclbdm = 'wdm' then
           select nvl(max(kclbdm),'wdm') into v_kclbdm from jw_cj_xscjb where kch_id=vKch_id and xh_id=vXh_id and kclbdm is not null and rownum=1;
           if v_kclbdm = 'wdm' then
               select nvl(max(kclbdm),'wdm') into v_kclbdm from jw_jxrw_jxbhbxxb where njdm_id=vNjdm_id and zyh_id=vZyh_id and jxb_id=nvl(vJxb_id,'wbj') and rownum=1;
               if v_kclbdm = 'wdm' then
                  select nvl(kclbdm,'wdm') into v_kclbdm from jw_jh_kcdmb where kch_id=vKch_id;
               end if;
           end if;
        end if;
        select nvl(max(jfbzje),0) into v_jfdj from jw_xk_jfbzxxb where njdm_id=vNjdm_id and zyh_id=vZyh_id and kclbdm=v_kclbdm and jflx=vJflx;
    exception
        When others then
          v_jfdj := 0;
    end;
    return v_jfdj ;
end fn_cx_jfdj;

/

