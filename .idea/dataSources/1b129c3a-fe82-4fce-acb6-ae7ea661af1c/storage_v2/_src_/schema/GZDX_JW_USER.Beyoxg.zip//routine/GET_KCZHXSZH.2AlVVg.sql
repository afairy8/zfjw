create function get_kczhxszh(vkch_id varchar2,v_lx varchar2)---取课程周学时组合
Return varchar2
as
sKcZhxsZh varchar2(100);
begin
  if v_lx='py' then
       select replace(wm_concat(xsmc||'('||trim(to_char(zhxs,'990.9'))
       ||case when sjbj='+' then '周' else '' end
       ||')'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc,t1.sjbj from JW_JH_PYFAKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='jh' then
     select replace(wm_concat(xsmc||'('||trim(to_char(zhxs,'990.9'))
     ||case when sjbj='+' then '周' else '' end
     ||')'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc,t1.sjbj from JW_JH_JXZXJHKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.jxzxjhkcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='kcsq' then
     select replace(wm_concat(xsmc||'('||trim(to_char(zhxs,'990.9'))||')'),',','-') into sKcZhxsZh from (
     select  t1.xsdm,t1.zhxs,t1.zxs,t3.xsmc from jw_jh_kcdmbbxsdzb t1 , jw_jh_kcdmbbb t2 ,jw_jh_kcxsxxdmb t3
     where t1.kcdmbbb_id = t2.kcdmbbb_id and  t1.xsdm = t3.xsdm AND t2.kcdmbbb_id=vkch_id  order by t1.xsdm );
  elsif v_lx='pyyw' then
     select replace(wm_concat(ywxsmc||'('||trim(to_char(zhxs,'990.9'))||')'),',','-') into sKcZhxsZh from (
     select t1.xsdm,t1.zhxs,t1.zxs,t2.ywxsmc from JW_JH_PYFAKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='zjgydx' then
     select replace(wm_concat(trim(to_char(zhxs,'990.9'))),',','-') into sKcZhxsZh from (
     select t1.xsdm,t1.zhxs,t1.zxs,t2.ywxsmc from JW_JH_PYFAKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='zjgydxTheoryAddTest' then
     select replace(wm_concat(trim(to_char(zhxs,'990.9'))),',','-') into sKcZhxsZh from (
     select t1.xsdm,t1.zhxs,t1.zxs,t2.ywxsmc from jw_jh_kcxsxxdmb t2 ,(select * from JW_JH_PYFAKCXSDZB t1 where t1.xsdm in ('01','02') and  t1.sjbj is null)t1
     where t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='zjcjdx' then
     select replace(wm_concat(trim(to_char(zhxs,'990.9'))),',','-') into sKcZhxsZh from (
     select t1.xsdm,t1.zhxs,t1.zxs,t2.ywxsmc from jw_jh_kcxsxxdmb t2 ,(select * from JW_JH_PYFAKCXSDZB t1 where t1.sjbj is null)t1
     where t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx = 'whqgdx' then
     select replace(wm_concat(trim(to_char(zhxs,'990.9'))),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc from JW_JH_JXZXJHKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.jxzxjhkcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx = 'syhkhtdx' then
     select
         case
           when instr(zhxs, '实践') > 0 then
            substr(zhxs, instr(zhxs, '实践')+3, instr(zhxs, '周')-instr(zhxs, '实践')-2)
           when instr(zhxs, '理论') > 0 then
            substr(zhxs, instr(zhxs, '(')+1, instr(zhxs, ')')-instr(zhxs, '(')-1)
           else
            ''
         end into sKcZhxsZh
  from (
        select replace(wm_concat(xsmc||'('||trim(to_char(zhxs,'990.9'))
         ||case when sjbj='+' then '周' else '' end
         ||')'),',','-') as zhxs from (
      select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc,t1.sjbj from JW_JH_PYFAKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
       t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm ));
  else
    select replace(wm_concat(xsmc||'('||trim(to_char(zhxs,'990.9'))||')'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc from jw_jh_kcxsdzb t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.kch_id = vkch_id order by t1.xsdm );
   end if;
  return sKcZhxsZh;
end;

/

