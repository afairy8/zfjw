create procedure proc_xtsz_xsshxx(vDqxnm in varchar2,vDqxqm in varchar2,vbj out varchar2) is
begin
  --系统设置当前学年学期时更新当前学年学期的学籍信息数据
  begin
  update jw_xjgl_xsjbxxb jb
  set (jb.njdm_id, jb.jg_id, jb.zyh_id, jb.zyfx_id, jb.bh_id, jb.xz, jb.sfzx, jb.xjztdm)=
  (select a.njdm_id,
              a.jg_id,
              a.zyh_id,
              a.zyfx_id,
              a.bh_id,
              a.xz,
              a.sfzx,
              a.xjztdm
         from jw_xjgl_xsxjxxb a
       where  jb.xh_id = a.xh_id
       and a.xnm = vDqxnm and a.xqm = vDqxqm)
       where exists(select 1 from jw_xjgl_xsxjxxb a where a.xh_id = jb.xh_id and a.xnm = vDqxnm and a.xqm = vDqxqm);
   vbj := '1';
    exception
       When others then
        vbj := '0';
        rollback;
     end;
end proc_xtsz_xsshxx;

/

