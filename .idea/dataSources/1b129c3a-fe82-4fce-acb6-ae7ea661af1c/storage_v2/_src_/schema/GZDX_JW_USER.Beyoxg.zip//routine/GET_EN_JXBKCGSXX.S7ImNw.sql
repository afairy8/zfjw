create function Get_En_JxbKcgsxx(vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班课程归属信息----
as
   sKcgsxx varchar2(500);   ---课程归属信息
begin
    sKcgsxx := 'nothing';
    begin
       if vBj='0' then
         select nvl(wm_concat(kcgsywmc),'nothing') into sKcgsxx from (
         select distinct b.kcgsywmc,b.kcgsdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcgsdmb b
                where a.kcgsdm=b.kcgsdm
                  and a.jxb_id= vJxb_id
                  order by b.kcgsdm
          );
       end if ;
     exception
        When others then
          sKcgsxx := 'nothing';
    end;
    return sKcgsxx ;
end Get_En_JxbKcgsxx;

/

