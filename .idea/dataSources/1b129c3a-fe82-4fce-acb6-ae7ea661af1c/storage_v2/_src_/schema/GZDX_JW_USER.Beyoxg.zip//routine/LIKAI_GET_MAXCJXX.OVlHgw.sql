create function likai_get_maxCJXX(v_xh_id in varchar2, v_kch in varchar2, v_sign in varchar2)
  return varchar2 is
  v_jxbid_cj_jd_kcxzdm varchar2(255); --记载成绩的教学班ID，成绩，绩点以及课程性质代码
  v_xnm_xqm            varchar2(255); --记载成绩的学年码，学期码，优先取正考，若无正考则判断是否有重修，则取重修，若无正考，有补考，无重修则不显示
  v_maxbfzcj           varchar2(255);
  begin
    --kch='180210003';xh='1802100012'
    --获取正考学年
    --v_xnm_xqm:='';
    if v_sign = '1'--表示最大成绩跟正考
    then
      select 'xnm' || xnm || 'xqm' || xqm|| 'kcx' || KCXZDM
      into v_xnm_xqm
      from (
             select
               xnm,
               xqm,
               kcxzdm,
               row_number()
               over (
                 partition by cjb.xh_id, cjb.kch_id
                 order by cjb.cjxzm,cjb.xnm, cjb.xqm ) rm
             from jw_cj_xscjb cjb
             where  cjb.xh_id = v_xh_id and cjb.kch_id = (select kch_id
                                                         from jw_jh_kcdmb
                                                         where kch=v_kch or kch_id=v_kch) and cjxzm in ('01','16')) t1
      where t1.rm = 1;
      --若无正考学年，则取重修学年
      if v_xnm_xqm is null
      --if instr(v_xnm_xqm,'@')>0
      then
        select 'xnm' || xnm || 'xqm' || xqm|| 'kcx' || KCXZDM
        into v_xnm_xqm
        from (
               select
                 xnm,
                 xqm,
                 kcxzdm,
                 row_number()
                 over (
                   partition by cjb.xh_id, cjb.kch_id
                   order by cjb.xnm, cjb.xqm ) rm
               from jw_cj_xscjb cjb
               where cjb.xh_id = v_xh_id and cjb.kch_id = (select kch_id
                                                           from jw_jh_kcdmb
                                                           where kch=v_kch or kch_id=v_kch)  and cjxzm in ('16')) t1
        where t1.rm = 1;
      end if;
      --取的最高成绩对应的jxb_id,cj,jd信息
      if v_xnm_xqm is not null
      then
        select max(nvl(bfzcj,0))
        into v_maxbfzcj
        from jw_cj_xscjb cjb
        where cjb.xh_id = v_xh_id and cjb.kch_id = (select kch_id
                                                    from jw_jh_kcdmb
                                                    where kch=v_kch or kch_id=v_kch);
        select 'jxb' || jxb_id || 'cjj' || cj || 'jdd' || jd ||'xff'||xf||'#'
        into v_jxbid_cj_jd_kcxzdm
        from
          (select
             cjb.jxb_id,
             cjb.cj,
             cjb.jd,
             cjb.xf,
             row_number()
             over (
               partition by cjb.XH_ID, cjb.KCH_ID
               order by cjb.CJXZM ) rm
           from jw_cj_xscjb cjb
           where cjb.xh_id = v_xh_id and cjb.kch_id = (select kch_id
                                                       from jw_jh_kcdmb
                                                       where kch=v_kch or kch_id=v_kch) and nvl(cjb.bfzcj,0) = v_maxbfzcj) t2
        where t2.rm = 1;
        return v_xnm_xqm || v_jxbid_cj_jd_kcxzdm;
      else
           return null;
      end if;
    end if;
    if v_sign='2' then--表示最大成绩跟最大成绩对应的学年学期
    select max(nvl(bfzcj,0))
    into v_maxbfzcj
    from jw_cj_xscjb cjb
    where cjb.xh_id = v_xh_id and cjb.kch_id = ( select kch_id
    from jw_jh_kcdmb
    where kch=v_kch or kch_id=v_kch);
      select 'xnm'||xnm||'xqm'||xqm|| 'kcx' || KCXZDM||'jxb' || jxb_id || 'cjj' || cj || 'jdd' || jd||'xff'||xf||'#'  into
      v_jxbid_cj_jd_kcxzdm
      from
        (select
          cjb.xnm,
          cjb.xqm,
           cjb.jxb_id,
           cjb.cj,
           cjb.jd,
           cjb.KCXZDM,
          cjb.xf,
           row_number()
           over (
             partition by cjb.XH_ID, cjb.KCH_ID
             order by cjb.CJXZM ) rm
         from jw_cj_xscjb cjb
         where cjb.xh_id = v_xh_id and cjb.kch_id = (select kch_id
                                                     from jw_jh_kcdmb
                                                     where kch=v_kch or kch_id=v_kch) and nvl(cjb.bfzcj,0) = v_maxbfzcj) t2
      where t2.rm = 1;
      return v_jxbid_cj_jd_kcxzdm;
    end if;
  end;
/

