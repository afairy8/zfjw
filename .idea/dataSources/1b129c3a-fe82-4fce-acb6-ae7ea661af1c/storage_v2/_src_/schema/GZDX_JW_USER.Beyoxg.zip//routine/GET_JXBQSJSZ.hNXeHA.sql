create function get_jxbqsjsz(vJxb_id varchar2)
return number
as
   sXsfp number;   ---学生分配
   sQsjsz number:=0;  ---起始结束周
   begin
       select count(1) into sXsfp from jw_pk_xsfpb where jxb_id=vJxb_id;
       if sXsfp = 0 then --未做学时分配
          select get_bitorsunion(wm_concat(qsjsz)) into sQsjsz from jw_jxrw_jxbjsrkb where jxb_id =vJxb_id;
       else
          select get_bitorsunion(nvl(sum(distinct power(2,zc-1)),'0')) into sQsjsz from jw_pk_xsfpb where jxb_id =vJxb_id and nvl(ks,0)>0;
       end if;
    return sQsjsz;
end get_jxbqsjsz;

/

