create function Get_YjxbRkJsxx(vJxb_id varchar2,vBj varchar2,vYlzd varchar2) return varchar2  ---获取原教学班任课教师信息（参数：教学班id、标记（jsxm：姓名 jgh：教工号）、预留字段）----
as
   sJxbjsxx varchar2(2000);   ---教学班任课教师信息
begin
    sJxbjsxx := '无';
    begin
       ---输出教师姓名
       if vBj = 'jsxm' then

         select wm_concat(xm) into sJxbjsxx from(
                   select jzg.xm, jzg.jgh, jxbjs.jxb_id
                     from jw_jxrw_jxbjsrkb jxbjs, jw_jg_jzgxxb jzg, jw_kw_bkmdb bk
                    where jxbjs.jgh_id = jzg.jgh_id
                      and jxbjs.jxb_id= bk.yjxb_id
                      and bk.jxb_id= vJxb_id
                    group by jzg.xm, jzg.jgh, jxbjs.jxb_id
                    order by jzg.jgh
            );

       end if ;

       ---输出教工号
       if vBj = 'jgh' then

          select wm_concat(jgh) into sJxbjsxx from(
                   select jzg.xm, jzg.jgh, jxbjs.jxb_id
                     from jw_jxrw_jxbjsrkb jxbjs, jw_jg_jzgxxb jzg, jw_kw_bkmdb bk
                    where jxbjs.jgh_id = jzg.jgh_id
                      and jxbjs.jxb_id= bk.yjxb_id
                      and bk.jxb_id= vJxb_id
                    group by jzg.xm, jzg.jgh, jxbjs.jxb_id
                    order by jzg.jgh
            );

       end if;
     exception
        When others then
          sJxbjsxx := '无';
    end;
    if sJxbjsxx is null then
     return '无' ;
    else
    return sJxbjsxx ;
    end if ;
end Get_YjxbRkJsxx;

/

