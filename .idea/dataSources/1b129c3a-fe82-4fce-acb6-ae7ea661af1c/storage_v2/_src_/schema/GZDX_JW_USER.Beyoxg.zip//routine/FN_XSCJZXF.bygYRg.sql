create function fn_xscjzxf(v_xh_id varchar2) return number  ---查询学生总学分函数
as
   v_zxf number;--计算出来的总学分
begin
   select xf  into  v_zxf  from (
     select sum(xf)xf from (
     select row_number () over (partition by xh_id,kch_id order by bfzcj desc)rn,xh_id,kcmc,cj,bfzcj,xf,jd from
     jw_cj_xscjb where xh_id=v_xh_id  and to_number(nvl(bfzcj,'0'))>=60 and kcbj='0'  ) where rn='1'
    );
   return v_zxf;
end fn_xscjzxf;

/

