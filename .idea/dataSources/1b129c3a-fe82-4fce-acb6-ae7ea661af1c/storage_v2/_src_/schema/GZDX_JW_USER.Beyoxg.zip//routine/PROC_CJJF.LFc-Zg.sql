create procedure PROC_CJJF
(
  in_xnm in varchar2,--成绩录入学年
  in_xqm in varchar2,--成绩录入学期
  in_xh_id  in varchar2,
  in_jxb_id in varchar2,
  in_kch_id in varchar2,
  in_bfzcj in varchar2,
  in_cjbz  in varchar2,
  in_jflx  in varchar2,--直接加分
  in_cjxzm in varchar2,--成绩性质（正考、补考、重修）
  in_cjlrjz in varchar2,--成绩录入级制（百分制、五级制。。。）
  in_jfgs in varchar2,--直接加分使用的加分公式
  in_jfgscjsx in varchar2,--直接加分使用的加分成绩上限
  out_jfhbfzcj out varchar2,
  out_jfhzpcj out varchar2,
  out_flag  out varchar2,--加分标识：1：加分成功   0：加分失败或不可加分
  out_msg   out varchar2--返回加分详细情况
)
as
    sqlStr varchar2(2000);
    v_count number;
    v_count2 number;
    v_xsbj varchar2(10);
    v_njdm_id varchar2(32);
    v_zyh_id varchar2(32);
    v_jffsd_id varchar2(32);
    v_xm varchar2(100);
    v_kcmc varchar2(100);
    v_xnmc varchar2(10);
    v_xqmmc varchar2(2);
    v_jffsdsz_id varchar2(32);
    v_jfdmc varchar2(50);
    v_qsf number;
    v_jsf number;
    v_dyf number;
    v_jfgs varchar2(50);
    v_jfgscjsx varchar2(10);--公式加分成绩上限
    v_px varchar2(2);--级制排序
    v_ycj varchar2(10);--原成绩
    v_jzmc varchar2(50);
    v_sfkjf varchar2(2);--1:表示可加分 0:表示不可加分
    v_hjjfhbfzcj varchar2(10);--获奖计算后的成绩 用于和使用规则加分后成绩对比 取最大
    v_jljbmc varchar2(50);--奖励级别名称
    v_jlxmmc varchar2(50);--奖励项目名称
    v_jljf varchar2(50);--奖励加分
    v_jljfsx varchar2(50);--奖励加分上限
    v_jzdyf number;
    v_zhhgs varchar2(50);
    v_sfcjjfsx varchar2(2);
    v_xxdm varchar2(10);--学校代码
    v_cjjfsfyjxbzgfwsx varchar2(2);--成绩加分是否以教学班最高分为上限
    v_jxbzgf varchar2(10);--教学班最高分
begin
    --初始化返回信息
    v_sfkjf := '1';
    out_jfhbfzcj := in_bfzcj;
    v_ycj := in_bfzcj;
    out_flag := '0';
    out_msg := '';
    select xxdm into v_xxdm from zftal_xtgl_xxxxszb;
    --判断是否可加分
    select sfcjcjjf into v_sfkjf from jw_jh_kcdmb where kch_id = in_kch_id;--先判断课程是否可加分
    if v_sfkjf = '0' then
      out_flag := '0';
      out_msg := '当前课程不参与加分!';
      goto nextTwo;
    end if;

    select sfcjcjjf into v_sfkjf from jw_cj_jzdmb where jzdm = nvl(in_cjlrjz,4);
    if v_sfkjf = '0' then
      out_flag := '0';
      out_msg := '当前录入级制不参与加分!';
      goto nextTwo;
    end if;

    select nvl(max(zdz),'0') into v_sfkjf from zftal_xtgl_xtszb where zdm ='CXCJSFKJF';--取系统设置表里的重修补考加分控制设置
    if in_cjxzm in ('16','20','26') then --如果是重修、重修缓考、重考
       if v_sfkjf = '0' or v_sfkjf = '2' then
         out_flag := '0';
         out_msg := '重修课程不参与加分!';
         goto nextTwo;
       end if;
    elsif in_cjxzm in ('11','12','17','21','22') then --如果是补考
       if v_sfkjf = '0' or v_sfkjf = '3' then
         out_flag := '0';
         out_msg := '补考不参与加分!';
         goto nextTwo;
       end if;
    end if;

    if in_cjbz is not null then --判断成绩备注是否可加分
       select count(1) into v_count from jw_cj_bzdmb where cjbzmc = in_cjbz;
       if v_count > 0 then
          select sfcjcjjf into v_sfkjf from jw_cj_bzdmb where cjbzmc = in_cjbz;
          if v_sfkjf = '0' then
             out_flag := '0';
             out_msg := '当前成绩备注不参与加分!';
             goto nextTwo;
          end if;
       else
             out_flag := '0';
             out_msg := '成绩备注不存在!';
             goto nextTwo;
       end if;
     end if;
     select nvl(max(zdz),'0') into v_cjjfsfyjxbzgfwsx from jw_jcdml_xtnzb where zdm ='CJJFSFYJXBZGFWSX';
     if v_cjjfsfyjxbzgfwsx = '1' then --取教学班最高成绩
        select max(nvl(bfzcj,0)) into v_jxbzgf from jw_cj_xscjb where jxb_id=in_jxb_id;
     end if;
    --查询学生的基本信息
    select xsbj,njdm_id,zyh_id,xm into v_xsbj,v_njdm_id,v_zyh_id,v_xm from jw_xjgl_xsjbxxb where xh_id = in_xh_id ;
    select kcmc into v_kcmc from jw_jh_kcdmb where kch_id = in_kch_id;
    select xnmc into v_xnmc from jw_jcdm_xnb where xnm = in_xnm;
    select mc into v_xqmmc from zftal_xtgl_jcsjb where lx = '0001' and dm = in_xqm;
    if in_jflx is null or in_jflx != '3' then
      if v_xxdm != '10010' then --对应规则不可多次加分
          select count(1) into v_count from jw_cj_jfmxb where xnm=in_xnm and xqm=in_xqm and jxb_id=in_jxb_id and xh_id=in_xh_id and kch_id=in_kch_id and nvl(jfly,'-1')!='1' and nvl(shzt,'3')='3' and jflx='3';
          if v_count > 0 then
             select count(1) into v_count from jw_cj_xscjb where xh_id = in_xh_id and jxb_id = in_jxb_id and kch_id = in_kch_id and xnm = in_xnm and xqm = in_xqm;
             if v_count > 0 then
                 select bfzcj into out_jfhbfzcj from jw_cj_xscjb where xh_id = in_xh_id and jxb_id = in_jxb_id and kch_id = in_kch_id and xnm = in_xnm and xqm = in_xqm;
                 out_flag := '2';
                 out_msg := '已提交的成绩,直接取成绩表里的数据!';
                 goto nextOne;
             else
                 out_flag := '0';
                 out_msg := v_xm||'于'||v_xnmc||'学年'||v_xqmmc||'学期,针对课程：'||v_kcmc||'已加过分!';
                 goto nextOne;
             end if;
          end if;
      end if;
      --查询加分规则(先查整体,没有再查详细)
      select count(1) into v_count from jw_cj_jfgzszb where kch_id is null and njdm_id = v_njdm_id and bitand(v_xsbj,xsxzdm)>0 and cjlx = '0';
      if v_count = 0 then
         select count(1) into v_count from jw_cj_jfgzszb where kch_id is null and njdm_id = v_njdm_id and bitand(v_xsbj,xsxzdm)>0
         and (case when cjlx = '0' then ','||in_cjxzm||','
                  when cjlx = '1' then ',01,02,'
                  when cjlx = '2' then ',11,12,17,21,22,'
                  when cjlx = '3' then ',16,20,26,' end) like '%,'||in_cjxzm||',%';
         if v_count = 0 then
            select count(1) into v_count from jw_cj_jfgzszb where njdm_id = v_njdm_id and zyh_id = v_zyh_id and kch_id = in_kch_id and bitand(v_xsbj,xsxzdm)>0 and cjlx = '0';
            if v_count = 0 then
               select count(1) into v_count from jw_cj_jfgzszb where njdm_id = v_njdm_id and zyh_id = v_zyh_id and kch_id = in_kch_id and bitand(v_xsbj,xsxzdm)>0
               and (case when cjlx = '0' then ','||in_cjxzm||','
                   when cjlx = '1' then ',01,02,'
                   when cjlx = '2' then ',11,12,17,21,22,'
                   when cjlx = '3' then ',16,20,26,' end) like '%,'||in_cjxzm||',%';
               if v_count = 0 then
                   out_flag := '0';
                   out_msg := '尚未设置对应的加分规则!';
                   goto nextOne;
               else
                   select max(jffsd_id) into v_jffsd_id from jw_cj_jfgzszb where njdm_id = v_njdm_id and zyh_id = v_zyh_id and kch_id = in_kch_id and bitand(v_xsbj,xsxzdm)>0
                   and (case when cjlx = '0' then ','||in_cjxzm||','
                   when cjlx = '1' then ',01,02,'
                   when cjlx = '2' then ',11,12,17,21,22,'
                   when cjlx = '3' then ',16,20,26,' end) like '%,'||in_cjxzm||',%';
               end if;
            else
               select max(jffsd_id) into v_jffsd_id from jw_cj_jfgzszb where njdm_id = v_njdm_id and zyh_id = v_zyh_id and kch_id = in_kch_id and bitand(v_xsbj,xsxzdm)>0 and cjlx = '0';
            end if;
         else
            select max(jffsd_id) into v_jffsd_id from jw_cj_jfgzszb where kch_id is null and njdm_id = v_njdm_id and bitand(v_xsbj,xsxzdm)>0
            and (case when cjlx = '0' then ','||in_cjxzm||','
                  when cjlx = '1' then ',01,02,'
                  when cjlx = '2' then ',11,12,17,21,22,'
                  when cjlx = '3' then ',16,20,26,' end) like '%,'||in_cjxzm||',%';
         end if;
      else
         select max(jffsd_id) into v_jffsd_id from jw_cj_jfgzszb where kch_id is null and njdm_id = v_njdm_id and bitand(v_xsbj,xsxzdm)>0 and cjlx = '0';
      end if;

      --查询加分分数段设置或者加分公式
      if in_cjlrjz != '4' then --不是百分制
        select count(1) into v_count from jw_cj_jffsdszb where jffsd_id = v_jffsd_id and djjfztjjfjz = in_cjlrjz;
        if v_count = 0 then --分数段对应加分
          select count(1) into v_count2 from jw_cj_jffsdszb where jffsd_id = v_jffsd_id and in_bfzcj*1 >= qsf*1 and in_bfzcj*1 < jsf*1;
          if v_count2 > 0 then
             select jffsdsz_id,jfdmc,qsf,jsf,dyf,jfgs,jfgscjsx into v_jffsdsz_id,v_jfdmc,v_qsf,v_jsf,v_dyf,v_jfgs,v_jfgscjsx
                from jw_cj_jffsdszb
               where jffsd_id = v_jffsd_id
                 and in_bfzcj*1 >= qsf*1
                 and in_bfzcj*1 < jsf*1;
             select dyf into v_jzdyf from jw_cj_dzb where jzdm = in_cjlrjz and in_bfzcj*1 >= qsf*1 and in_bfzcj*1 < jsf*1;
             if v_jfgs is not null then --公式对应计算分数
                select replace(v_jfgs,'cj',in_bfzcj) into v_zhhgs from dual;
                sqlStr := 'select round('||v_zhhgs||') from dual';
                Execute Immediate sqlStr into out_jfhbfzcj;

                if out_jfhbfzcj*1 > nvl(v_jfgscjsx,'100')*1 then --判断加分规则的成绩上限
                   out_jfhbfzcj := nvl(v_jfgscjsx,'100');
                end if;
                if v_cjjfsfyjxbzgfwsx = '1' and out_jfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                    out_jfhbfzcj := nvl(v_jxbzgf,'100');
                end if;

                select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                if v_count = 0 then
                   out_flag := '0';
                   out_msg := '加分失败,加分后成绩不在级制对照信息分数段范围内,无法加分!';
                   goto nextOne;
                else
                   select dzmc,dyf into out_jfhzpcj,out_jfhbfzcj from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                   out_flag := '1';
                   out_msg := '加分成功,ID:'||v_jffsdsz_id||',加分方式:使用规则加分,加分段名称:'||v_jfdmc||',加分公式:'||v_jfgs||',加分公式上限:'||nvl(v_jfgscjsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj||',加分后成绩:'||out_jfhzpcj;
                   goto nextOne;
                end if;

             else --分数段对应分计算分数
                out_jfhbfzcj := v_dyf;
                if v_cjjfsfyjxbzgfwsx = '1' and out_jfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                    out_jfhbfzcj := nvl(v_jxbzgf,'100');
                end if;
                select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                if v_count = 0 then
                    out_flag := '0';
                    out_msg := '加分失败,加分方式:使用规则加分,加分后成绩不在级制对照信息分数段范围内,无法加分!';
                    goto nextOne;
                else
                    select dzmc,dyf into out_jfhzpcj,out_jfhbfzcj from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                    out_flag := '1';
                    out_msg := '加分成功,ID:'||v_jffsdsz_id||',加分方式:使用规则加分,加分段名称:'||v_jfdmc||',加分分数段:'||v_qsf||'-'||v_jsf||',对应分:'||v_dyf||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj||',加分后成绩:'||out_jfhzpcj;
                    goto nextOne;
                end if;
             end if;
           else
              out_flag := '0';
              out_msg := '加分失败,加分规则中没有对应的加分设置!';
              goto nextOne;
           end if;
        else --跳级加分
           select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz;
           select jzmc into v_jzmc from jw_cj_jzdmb where jzdm = in_cjlrjz;
           if v_count = 0 then
              out_flag := '0';
              out_msg := '加分失败,级制对照信息不存在!';
              goto nextOne;
           else
              select px into v_px from (select rank() over (order by dyf desc) px,t.dyf from jw_cj_dzb t where jzdm = in_cjlrjz )where dyf = in_bfzcj;
              if v_px = 1 then
                 out_flag := '0';
                 out_msg := '加分失败,当前等级已经是最高等级,无法跳级!';
              else
                 select dyf,dzmc,sfcjjfsx into v_dyf,out_jfhzpcj,v_sfcjjfsx
                   from (select rank() over(order by dyf desc) px, t.dyf,t.dzmc,t.sfcjjfsx
                           from jw_cj_dzb t
                          where jzdm = in_cjlrjz)
                  where px = (v_px - 1);
                  if v_sfcjjfsx = '1' then
                    out_jfhbfzcj := v_dyf;
                    out_flag := '1';
                    out_msg := '加分成功,ID:'||v_jffsdsz_id||',加分方式:使用规则加分,加分段名称:'||v_jfdmc||',跳级级制名称:'||v_jzmc||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj||',加分后成绩:'||out_jfhzpcj;
                  else
                    out_flag := '0';
                    out_msg := '跳级失败,下一个等级不允许跳级!';
                  end if;
                  goto nextOne;
              end if;
           end if;
        end if;
      else --百分制
         select count(1) into v_count2 from jw_cj_jffsdszb where jffsd_id = v_jffsd_id and in_bfzcj*1 >= qsf*1 and in_bfzcj*1 < jsf*1;
         if v_count2 > 0 then
             select jffsdsz_id,jfdmc,qsf,jsf,dyf,jfgs,jfgscjsx into v_jffsdsz_id,v_jfdmc,v_qsf,v_jsf,v_dyf,v_jfgs,v_jfgscjsx
                from jw_cj_jffsdszb
               where jffsd_id = v_jffsd_id
                 and in_bfzcj*1 >= qsf*1
                 and in_bfzcj*1 < jsf*1;
             if v_jfgs is not null then --公式对应计算分数
                select replace(v_jfgs,'cj',in_bfzcj) into v_zhhgs from dual;
                sqlStr := 'select round('||v_zhhgs||') from dual';
                Execute Immediate sqlStr into out_jfhbfzcj;

                if out_jfhbfzcj*1 > nvl(v_jfgscjsx,'100')*1 then--判断加分规则的成绩上限
                   out_jfhbfzcj := nvl(v_jfgscjsx,'100');
                end if;
                if v_cjjfsfyjxbzgfwsx = '1' and out_jfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                    out_jfhbfzcj := nvl(v_jxbzgf,'100');
                end if;

                out_jfhzpcj := out_jfhbfzcj;
                out_flag := '1';
                out_msg := '加分成功,ID:'||v_jffsdsz_id||',加分方式:使用规则加分,加分段名称:'||v_jfdmc||',加分公式:'||v_jfgs||',加分公式上限:'||nvl(v_jfgscjsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj;
                goto nextOne;
             else --分数段对应分计算分数
                out_jfhbfzcj := v_dyf;
                if v_cjjfsfyjxbzgfwsx = '1' and out_jfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                    out_jfhbfzcj := nvl(v_jxbzgf,'100');
                end if;

                out_jfhzpcj := out_jfhbfzcj;
                out_flag := '1';
                out_msg := '加分成功,ID:'||v_jffsdsz_id||',加分方式:使用规则加分,加分段名称:'||v_jfdmc||',加分分数段:'||v_qsf||'-'||v_jsf||',对应分:'||v_dyf||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj;
                goto nextOne;
             end if;
         else
            out_flag := '0';
            out_msg := '加分失败,加分规则中没有对应的加分设置!';
            goto nextOne;
         end if;
      end if;
    else --直接加分,按传过来的加分 公式和上限 计算分数
         if in_jfgs is null then
             out_flag := '0';
             out_msg := '加分失败,直接加分,公式不存在！';
             goto nextTwo;
         else
             select replace(in_jfgs,'cj',in_bfzcj) into v_jfgs from dual;
             sqlStr := 'select round('||v_jfgs||',1) from dual';
             Execute Immediate sqlStr into out_jfhbfzcj;
             v_jfgscjsx := in_jfgscjsx;
             if out_jfhbfzcj*1 > nvl(v_jfgscjsx,'100')*1 then--判断加分规则的成绩上限
                 out_jfhbfzcj := nvl(v_jfgscjsx,'100');
             end if;
             if v_cjjfsfyjxbzgfwsx = '1' and out_jfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                 out_jfhbfzcj := nvl(v_jxbzgf,'100');
             end if;

             /*判断级制对应名称*/
             if in_cjlrjz is null or in_cjlrjz = '4' then
                 out_jfhzpcj := out_jfhbfzcj;
                 out_flag := '1';
                 out_msg := '加分成功,加分方式:直接加分,加分公式:'||in_jfgs||',加分公式上限:'||nvl(v_jfgscjsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj;
                 goto nextTwo;
             else
                 select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz and out_jfhbfzcj*1 >= qsf*1 and out_jfhbfzcj*1 < jsf*1;
                 if v_count = 0 then
                    out_flag := '0';
                    out_msg := '加分失败,加分后成绩不在级制对应分数段内,请检查!';
                    goto nextTwo;
                 else
                    select dyf into v_jzdyf from jw_cj_dzb where jzdm = in_cjlrjz and in_bfzcj*1 >= qsf*1 and in_bfzcj*1 < jsf*1;
                    select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                    if v_count = 0 then
                        out_flag := '0';
                        out_msg := '加分失败,加分方式:直接加分,加分后成绩不在级制对照信息分数段范围内,无法加分!';
                        goto nextTwo;
                    else
                        select dzmc,dyf into out_jfhzpcj,out_jfhbfzcj from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                        out_flag := '1';
                        out_msg := '加分成功,加分方式:直接加分,加分公式:'||in_jfgs||',加分公式上限:'||nvl(v_jfgscjsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj||',加分后成绩:'||out_jfhzpcj;
                        goto nextTwo;
                    end if;
                 end if;
             end if;
         end if;
    end if;
    <<nextOne>>
    if in_jflx is null or in_jflx = '1' then --加分类型为空（成绩录入、修改、学生申请等）或加分类型是获奖等级加分
      if v_xxdm = '10010' and in_cjlrjz= '4' then --加分成功后判断奖励加分（仅对百分制成绩奖励加分）
           select count(1) into v_count from jw_xjgl_xsjlb a,jw_cj_hjdjjfszb b
           where a.jljbdm=b.jljbdm and a.jldjdm=b.jldjdm and a.jlxmdm=b.jlxmdm and a.xh_id=in_xh_id and a.xnm=in_xnm and a.xqm=in_xqm and bitand(v_xsbj,b.xsxzdm)>0;
           if v_count > 0 then
              select (select t.jlxmmc from jw_xjgl_jlxmdmb t where t.jlxmdm = b.jlxmdm),(select t.mc from zftal_xtgl_jcsjb t where t.lx = '0021' and t.dm = b.jljbdm),
                     b.cjjf,b.cjjfsx into v_jlxmmc, v_jljbmc, v_jljf, v_jljfsx
               from (
                  select b.* from jw_xjgl_xsjlb a,jw_cj_hjdjjfszb b
                  where a.jljbdm=b.jljbdm and a.jldjdm=b.jldjdm and a.jlxmdm=b.jlxmdm and a.xh_id=in_xh_id and a.xnm=in_xnm and a.xqm=in_xqm and bitand(v_xsbj,b.xsxzdm)>0 order by b.cjjf desc
               ) b where rownum=1;
               if out_flag = '1' then
                  v_hjjfhbfzcj := out_jfhbfzcj + v_jljf;
                  out_msg := out_msg;
               else
                  v_hjjfhbfzcj := in_bfzcj + v_jljf;
                  out_msg := '';
               end if;
               if v_hjjfhbfzcj*1 > nvl(v_jljfsx,'100')*1 then
                  v_hjjfhbfzcj := nvl(v_jljfsx,'100');
               end if;
               if v_cjjfsfyjxbzgfwsx = '1' and v_hjjfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                  v_hjjfhbfzcj := nvl(v_jxbzgf,'100');
               end if;
               if v_hjjfhbfzcj*1 > out_jfhbfzcj*1 then
                  out_jfhbfzcj := v_hjjfhbfzcj;
               end if;

               out_jfhzpcj := out_jfhbfzcj;
               out_flag := '1';
               out_msg := out_msg||'加分成功,加分方式:奖励项目加分,奖励项目名称:'||v_jlxmmc||',奖励级别名称:'||v_jljbmc||',奖励加分:'||v_jljf||',加分上限:'||nvl(v_jljfsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj;
           end if;
      else
           select count(1) into v_count from jw_xjgl_xsjlb a,jw_cj_hjdjjfszb b where a.jljbdm=b.jljbdm and a.jldjdm=b.jldjdm and a.jlxmdm=b.jlxmdm and a.xh_id=in_xh_id and bitand(v_xsbj,b.xsxzdm)>0;
           if v_count > 0 then
              select (select t.jlxmmc from jw_xjgl_jlxmdmb t where t.jlxmdm = b.jlxmdm),(select t.mc from zftal_xtgl_jcsjb t where t.lx = '0021' and t.dm = b.jljbdm),
                   b.cjjf,b.cjjfsx into v_jlxmmc, v_jljbmc, v_jljf, v_jljfsx
               from (
                select b.* from jw_xjgl_xsjlb a,jw_cj_hjdjjfszb b where a.jljbdm=b.jljbdm and a.jldjdm=b.jldjdm and a.jlxmdm=b.jlxmdm and a.xh_id=in_xh_id and bitand(v_xsbj,b.xsxzdm)>0 order by b.cjjf desc
               ) b where rownum=1;

               if out_flag = '1' then
                  v_hjjfhbfzcj := out_jfhbfzcj + v_jljf;
                  out_msg := out_msg;
               else
                  v_hjjfhbfzcj := in_bfzcj + v_jljf;
                  out_msg := '';
               end if;
               if v_hjjfhbfzcj*1 > nvl(v_jljfsx,'100')*1 then
                  v_hjjfhbfzcj := nvl(v_jljfsx,'100');
               end if;
               if v_cjjfsfyjxbzgfwsx = '1' and v_hjjfhbfzcj*1 > nvl(v_jxbzgf,'100')*1 then --判断教学班的成绩上限
                  v_hjjfhbfzcj := nvl(v_jxbzgf,'100');
               end if;
               if v_hjjfhbfzcj*1 > out_jfhbfzcj*1 then
                  out_jfhbfzcj := v_hjjfhbfzcj;
               end if;

               if in_cjlrjz != '4' then
                  select count(1) into v_count from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                  if v_count = 0 then
                     out_flag := '0';
                     out_msg := '加分失败,加分后成绩不在级制对照信息分数段范围内,无法加分!';
                  else
                     select dzmc,dyf into out_jfhzpcj,out_jfhbfzcj from jw_cj_dzb where jzdm = in_cjlrjz and qsf*1 <= out_jfhbfzcj*1 and jsf*1 > out_jfhbfzcj*1;
                     out_flag := '1';
                     out_msg := out_msg||'加分成功,加分方式:奖励项目加分,奖励项目名称:'||v_jlxmmc||',奖励级别名称:'||v_jljbmc||',奖励加分:'||v_jljf||',加分上限:'||nvl(v_jljfsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj||',加分后成绩:'||out_jfhzpcj;
                  end if;
               else
                  out_jfhzpcj := out_jfhbfzcj;
                  out_flag := '1';
                  out_msg := out_msg||'加分成功,加分方式:奖励项目加分,奖励项目名称:'||v_jlxmmc||',奖励级别名称:'||v_jljbmc||',奖励加分:'||v_jljf||',加分上限:'||nvl(v_jljfsx,'无')||',原百分制成绩:'||v_ycj||',加分后百分制成绩:'||out_jfhbfzcj;
               end if;
           end if;
      end if;
    end if;
    <<nextTwo>>
    if v_cjjfsfyjxbzgfwsx = '1' and out_flag = '1' then
       out_msg := out_msg||',教学班最高成绩:'||nvl(v_jxbzgf,'无');
    end if;
end PROC_CJJF;

/

