create function get_cjjfbzxx(in_xnm      in varchar2,
                                        in_xqm      in varchar2,
                                        in_xh_id    in varchar2,
                                        in_jxb_id   in varchar2,
                                        in_kch_id   in varchar2,
                                        in_bfzcj    in varchar2,
                                        in_cjbz     in varchar2,
                                        in_jflx     in varchar2,
                                        in_cjxzm    in varchar2,
                                        in_cjlrjz   in varchar2,
                                        in_jfgs     in varchar2,
                                        in_jfgscjsx in varchar2)
  return varchar2 as
  jfbzxx       varchar2(5000);
  out_jfhbfzcj varchar2(5000);
  out_jfhzpcj  varchar2(5000);
  out_flag     varchar2(5000);
  out_msg      varchar2(5000);
begin
  jfbzxx := '';
  PROC_CJJF(in_xnm,
            in_xqm,
            in_xh_id,
            in_jxb_id,
            in_kch_id,
            in_bfzcj,
            in_cjbz,
            in_jflx,
            in_cjxzm,
            in_cjlrjz,
            in_jfgs,
            in_jfgscjsx,
            out_jfhbfzcj,
            out_jfhzpcj,
            out_flag,
            out_msg);
  if out_flag = '1' then
    jfbzxx := out_msg;
  else
    jfbzxx := out_flag;
  end if;
  return jfbzxx;
end get_cjjfbzxx;
/

