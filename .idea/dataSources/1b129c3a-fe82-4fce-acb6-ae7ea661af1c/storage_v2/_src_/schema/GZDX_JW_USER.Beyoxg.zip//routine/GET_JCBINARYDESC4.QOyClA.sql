create Function Get_JcBinaryDesc4(vBinary in integer, vUnit in Varchar)
Return varchar2
as
  type Type_jcArray is table of int;
  aJc integer;  ---节次变量
  JcsDesc varchar2(100); ---节次组合显示
  firstJc integer;--第一节次
  currJc integer; --当前的节次
  prevJc integer; --上一个节次
  nextJc integer; --下一个节次
  jcCount integer;--节次数
  i integer;
  jcArray Type_jcArray := Type_jcArray(); ---节次数组
begin
  if nvl(vBinary,0) = 0 then
    return '无';
  else
  JcsDesc := null;
  firstJc := -1;
  currJc := -1;
  prevJc := -1;
  nextJc := -1;
  i := 1;
  for aJc in 0..log(2,vBinary)  loop  ---log(2,vBinary)取整
    if bitand(vBinary, power(2, aJc))=power(2,aJc) then  ---利用位运算取出二进制数对应的第几节次
      jcArray.Extend;
      jcArray(i) :=  aJc+1;
      jcCount := i;
      i := i + 1;
    end if;
  end loop;

  for i in 0..jcCount loop
    --处理第一节次
    if firstJc=-1 then
      firstJc := jcArray(i+1);
    else
      if i=jcCount then
        currJc := 0;
      else
        currJc := jcArray(i+1);
      end if;
    end if;

    --处理后续
    if(i = jcCount)
      or(currJc - prevJc > 1)
     then
      if JcsDesc is null then
        JcsDesc := (case when firstJc=prevJc then to_char(firstJc) else to_char(firstJc)|| '-'|| to_char(prevJc) end) || vUnit ;
      else
        JcsDesc := JcsDesc ||','|| (case when firstJc=prevJc then to_char(firstJc) else to_char(firstJc)|| '-'|| to_char(prevJc) end) || vUnit;
      end if;

      firstJc := currJc;
      prevJc := currJc;
    else
      prevJc := jcArray(i+1);
    end if;
  end loop;
  return JcsDesc;
  end if;
end;

/

