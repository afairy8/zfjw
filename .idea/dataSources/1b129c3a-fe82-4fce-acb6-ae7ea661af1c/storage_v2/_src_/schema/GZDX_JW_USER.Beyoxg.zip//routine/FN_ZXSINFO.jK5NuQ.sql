create function fn_zxsInfo(vJxb_id varchar2,vKch_id varchar2,vXsdm varchar2,vFlag  varchar2) return  varchar2--返回学时信息（总学时/分项学时）
as
  sXsxx varchar2(20);--学时信息
  v_zxs varchar2(20);--总学时
  v_subitemXs varchar2(20);--分项学时
begin
  sXsxx :='';
  begin
        --总学时
        if vFlag = 'total' or vFlag = 'jhzxs' then
          select sum(zxs) into v_zxs  from (
               select t2.zxs ,rank() over (partition by t1.kch_id order by t3.njdm_id,t3.zyh_id,t3.bh_id,t1.xfyqjd_id) rn
               from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcxsdzb t2,jw_jxrw_jxbhbxxb t3
                 where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                   and t1.njdm_id = t3.njdm_id
                   and t1.zyh_id = t3.zyh_id
                   and t3.jxb_id = vJxb_id
                   and t1.kch_id = vKch_id
            ) where rn = 1;

          --赋值
          sXsxx := v_zxs;
		  return sXsxx;
        end if;

        --分项学时
        if vFlag = 'subitem' then
          select sum(zxs) into v_subitemXs  from (
               select t2.zxs ,rank() over (partition by t1.kch_id order by t3.njdm_id,t3.zyh_id,t3.bh_id,t1.xfyqjd_id) rn
               from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcxsdzb t2,jw_jxrw_jxbhbxxb t3
                 where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                   and t1.njdm_id = t3.njdm_id
                   and t1.zyh_id = t3.zyh_id
                   and t3.jxb_id = vJxb_id
                   and t1.kch_id = vKch_id
                   and t2.xsdm = vXsdm
            ) where rn = 1;

          --赋值
          sXsxx := v_subitemXs;
		  return sXsxx;
        end if;
        -- 有行政班分项学时
      if vFlag != 'subitem' and vFlag != 'total' then
         select sum(zxs) into v_subitemXs  from (
               select t2.zxs ,rank() over (partition by t1.kch_id order by t3.njdm_id,t3.zyh_id,t3.bh_id,t1.xfyqjd_id) rn
               from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcxsdzb t2,jw_jxrw_jxbhbxxb t3
                 where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                   and t1.njdm_id = t3.njdm_id
                   and t1.zyh_id = t3.zyh_id
                   and t3.jxb_id = vJxb_id
                   and t1.kch_id = vKch_id
                   and t2.xsdm = vXsdm
                   and t3.bh_id = vFlag
            ) where rn = 1;

          --赋值
          sXsxx := v_subitemXs;
        end if;
  exception
        When others then
        sXsxx := NULL;
  end;

  if sXsxx is null then
     return NULL;
  else
     return sXsxx;
  end if;
end fn_zxsInfo;

/

