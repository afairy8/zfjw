create view VIEW_CDSYXX_KS as
  select t.xnm,
       sjb.sjbh_id,
       sjb.ksmcdmb_id,
       (select xnmc from jw_jcdm_xnb where xnm = t.xnm) as xn,
       t.xqm,
       (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = t.xqm) as xq,
       t.cdbh,t.cdmc,
       t.xqh_id,
       (select xqmc from zftal_xtgl_xqdmb where xqh_id = t.xqh_id) as xiaoq,
       t.cdlb_id,t.cdejlb_id,
       case when t.cdejlb_id is null then (select cdlbmc from jw_jcdm_cdlbdmb where cdlb_id = t.cdlb_id)
            else (select cdlbmc from jw_jcdm_cdlbdmb where cdlb_id = t.cdlb_id)||'-'||
                 (select cdlbmc from jw_jcdm_cdlbdmb where cdlb_id = t.cdejlb_id) end as cdlb,
        t.zws,
        t.lh,
        nvl((select jxlmc from jw_jcdm_jxldmb where jxldm = t.lh),t.lh) as jxl,
        t.lch,t.kszws1 as kszws,
        t2.xqj,
        t2.zc,
        t3.jc,
        t.cd_id from
jw_jcdm_cdxqxxb t,
(select t1.xnm,t2.dxqm as xqm,t2.rq,t2.xqj,power(2,t2.dxqzc-1) zc from jw_pk_xlb t1,jw_pk_rcmxb t2 where t1.xl_id = t2.xl_id and t2.zc != 0) t2,
(select a.xnm,a.xqm,a.xqh_id,b.jcm as jc,b.qssj,b.jssj from jw_pk_rsdszb a, jw_pk_rjcszb b where a.rsdsz_id = b.rsdsz_id) t3,
jw_kw_kssjb sjb,jw_kw_ksccb ccb,jw_kw_ksddbjdzb dddz,jw_kw_ksddb ddb
where t.xnm = t2.xnm
  and t.xqm = t2.xqm
  and t.xnm = t3.xnm
  and t.xqm = t3.xqm
  and t.xqh_id = t3.xqh_id
  and sjb.ksccb_id = ccb.ksccb_id
  and sjb.sjbh_id = dddz.sjbh_id
  and dddz.kshkbj_id = ddb.kshkbj_id
  and t2.rq = ccb.ksrq
  and t.xnm = ddb.xnm
  and t.xqm = ddb.xqm
  and t.cd_id = ddb.cd_id
  and ccb.ksjssj||':00' > t3.qssj
  and ccb.kskssj||':00' < t3.jssj
/

