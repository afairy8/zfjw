create procedure proc_gcpjtjBykc(---按教师、课程分组统计过程评价正向得分
       v_xnm in varchar2,
       v_xqm in varchar2,
       v_gcpjszlcb_id in varchar2,
       v_kch_id in varchar2,
       v_xsdm in varchar2,
       v_jgh_id in varchar2,
       v_xqh_id in varchar2,
       v_pjrs in varchar2,
       v_zgfbfb in varchar2,
       v_zdfbfb in varchar2
) as
v_sxzg_rs  number; --去掉最高分人数
v_sxzd_rs  number; --去掉最低分人数
v_pfxm varchar(32767);
v_pfdj varchar(32767);
v_fxpf number;
begin

       v_sxzg_rs := round(to_number(v_pjrs)*to_number(v_zgfbfb)/100 ,0) ; --按比例计算应该筛掉的最高分评价人数
       v_sxzd_rs := round(to_number(v_pjrs)*to_number(v_zdfbfb)/100 ,0) ; --按比例计算应该筛掉的最低分评价人数

       if v_xqh_id = 'qbxq_all' then
           update jw_pj_gcpj_jskcpftjb a set (sx_zxzpf, sx_pjrs, sx_zxpjf) =  --按课程计算并更新sx_zxzpf（筛选后正向总分） sx_pjrs（筛选后评价人数） sx_zxpjf（筛选后正向平均分）
           (select sum(zxpf) sx_zxzpf, count(*) sx_pjrs, round(sum(zxpf)/count(*),4) sx_zxpjf from
               (select zxpf,row_number() over(partition by xnm,xqm,gcpjszlcb_id,xsdm,jgh_id,kch_id order by zxpf asc) px
                from jw_pj_gcpjxspftjb where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                and xsdm=v_xsdm and jgh_id=v_jgh_id and kch_id=v_kch_id)
           where to_number(px) > v_sxzd_rs and to_number(px)<= (to_number(v_pjrs) - v_sxzg_rs) )
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id
           and a.xsdm=v_xsdm and a.xqh_id=v_xqh_id and a.jgh_id=v_jgh_id and a.kch_id=v_kch_id;
       else
           update jw_pj_gcpj_jskcpftjb a set (sx_zxzpf, sx_pjrs, sx_zxpjf) =  --按课程计算并更新sx_zxzpf（筛选后正向总分） sx_pjrs（筛选后评价人数） sx_zxpjf（筛选后正向平均分）
           (select sum(zxpf) sx_zxzpf, count(*) sx_pjrs, round(sum(zxpf)/count(*),4) sx_zxpjf from
               (select zxpf,row_number() over(partition by xnm,xqm,gcpjszlcb_id,xsdm,xqh_id,jgh_id,kch_id order by zxpf asc) px
                from jw_pj_gcpjxspftjb where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                and xsdm=v_xsdm and xqh_id=v_xqh_id and jgh_id=v_jgh_id and kch_id=v_kch_id)
           where to_number(px) > v_sxzd_rs and to_number(px)<= (to_number(v_pjrs) - v_sxzg_rs) )
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id
           and a.xsdm=v_xsdm and a.xqh_id=v_xqh_id and a.jgh_id=v_jgh_id and a.kch_id=v_kch_id;
       end if;
     commit;
      EXCEPTION
            when others then
            rollback;

end proc_gcpjtjBykc;

/

