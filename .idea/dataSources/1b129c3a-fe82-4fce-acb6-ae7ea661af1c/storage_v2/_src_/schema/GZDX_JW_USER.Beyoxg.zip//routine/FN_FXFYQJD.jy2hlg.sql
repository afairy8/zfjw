create function fn_fxfyqjd(                --得到父学分要求绩点id
in_xfyqjd_id in varchar2) return varchar2 is
result_id varchar2(100):='';
begin
  if in_xfyqjd_id is not null then
    select xfyqjd_id into result_id from
    (select xfyqjd_id from jw_jh_pyfaxfyqxxb t1
     start with
     xfyqjd_id=in_xfyqjd_id
     connect by prior t1.fxfyqjd_id=t1.xfyqjd_id)  t2
    where exists (select 'X' from jw_jh_pyfaxffb where xfyqjd_id=t2.xfyqjd_id) and rownum='1';
  end if;
return result_id;
end fn_fxfyqjd;

/

