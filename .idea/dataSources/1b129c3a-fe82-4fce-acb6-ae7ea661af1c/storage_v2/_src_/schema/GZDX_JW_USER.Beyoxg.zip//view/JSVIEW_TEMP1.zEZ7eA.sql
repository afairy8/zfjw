create view JSVIEW_TEMP1 as
  select xnm,xqm,jgh_id,jxb_id,cd_id,xqj,fn_bittozc(get_bitorsunion(wm_concat(zcd))*2) zcd,jc,fn_bittozc(jc*2) jcd  from jsview_temp group by xnm,xqm,jgh_id,jxb_id,cd_id,xqj,jc
/

