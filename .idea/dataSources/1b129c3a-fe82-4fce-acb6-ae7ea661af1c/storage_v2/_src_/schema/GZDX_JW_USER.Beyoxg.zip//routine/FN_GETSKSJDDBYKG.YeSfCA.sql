create function fn_getSksjddBykg(v_xnm varchar2,v_xqm varchar2,v_sksjdd varchar2) return varchar2 --根据设置的排课学年学期和教师查询课表的开关确定返回上课时间及地点
as
   v_kg number:=0;--默认为0，可以查看上课时间和地点
begin
   select count(1) into v_kg from zftal_xtgl_xtszb t1,jw_pk_pkkzb t2
    where t1.xtsz_id = 'JSKBCXKG' and t1.ssmk = 'PKGL' and t1.zdz='0' and t2.xnm=v_xnm and t2.xqm=v_xqm and t2.zt='1';
   if v_kg > 0 then
      return '课表尚未开放！';
   else
      return v_sksjdd;
   end if;
end fn_getSksjddBykg;

/

