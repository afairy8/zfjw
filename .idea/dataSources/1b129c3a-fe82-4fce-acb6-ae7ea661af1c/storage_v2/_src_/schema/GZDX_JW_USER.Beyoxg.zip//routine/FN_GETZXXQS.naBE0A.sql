create function fn_getZxxqs(vXh_id varchar2,vXnm varchar2,vXqm varchar2) return  number--返回在校学期数
as
  sXqs number := 0;--学期数
  v_count number;
  v_zsnddm varchar2(10);--招生年度
  v_njdm varchar2(10);--年级代码
  v_xjydxxfs varchar(2);--学籍异动休学方式
begin
  select zsnddm,njdm_id into v_zsnddm,v_njdm from jw_xjgl_xsjbxxb where xh_id=vXh_id;
  if v_njdm is null then
     return sXqs;
  end if;
  select count(1) into v_count from jw_xjgl_xjydb where shzt='3' and ydlbm='11' and xh_id=vXh_id;
  if v_count >0 then --存在休学
     select x.zdz into v_xjydxxfs from jw_jcdml_xtnzb x where x.zdm = 'XJYDXXFS';
     if v_xjydxxfs = '2' then --按学期
        select count(1) into sXqs from jw_jcdm_xnb xn,(select dm,row_number() over (partition by 1 order by dm) rn from zftal_xtgl_jcsjb where lx='0001') xq
         where xn.sfyx='1' and xn.xnm>=v_njdm and xn.xnm||lpad(xq.dm,2,'0')<vXnm||lpad(vXqm,2,'0')
          and xq.rn<=nvl((select zdz from zftal_xtgl_xtszb where zdm='XQZKZ'),2)
          and not exists(
          select 'X' from jw_xjgl_xjydb xjyd
          where xjyd.shzt='3' and xjyd.ydlbm='11' and xjyd.xh_id=vXh_id
            and xn.xnm||lpad(xq.dm,2,'0')<xjyd.ydfxxnm||lpad(xjyd.ydfxxqm,2,'0')
            and xn.xnm||lpad(xq.dm,2,'0')>=xjyd.ydsxxnm||lpad(xjyd.ydsxxqm,2,'0')
          );
     else--按日期
        select count(1) into sXqs from jw_jcdm_xnb xn,(select dm,row_number() over (partition by 1 order by dm) rn from zftal_xtgl_jcsjb where lx='0001') xq
         where xn.sfyx='1' and xn.xnm>=v_njdm and xn.xnm||lpad(xq.dm,2,'0')<vXnm||lpad(vXqm,2,'0')
          and xq.rn<=nvl((select zdz from zftal_xtgl_xtszb where zdm='XQZKZ'),2)
          and not exists(
          select 'X' from jw_xjgl_xjydb xjyd
          where xjyd.shzt='3' and xjyd.ydlbm='11' and xjyd.xh_id=vXh_id
            and xn.xnm||lpad(xq.dm,2,'0')<=(select max(xl.xnm||lpad(xl.xqm,2,'0')) from jw_pk_xlb xl where xjyd.xxjssj>xl.ksrq)
            and xn.xnm||lpad(xq.dm,2,'0')>=xjyd.ydsxxnm||lpad(xjyd.ydsxxqm,2,'0')
          );
     end if;
  else   --不存在休学
     select count(1) into sXqs from jw_jcdm_xnb xn,(select dm,row_number() over (partition by 1 order by dm) rn from zftal_xtgl_jcsjb where lx='0001') xq
      where xn.sfyx='1' and xn.xnm>=v_njdm and xn.xnm||lpad(xq.dm,2,'0')<vXnm||lpad(vXqm,2,'0') and xq.rn<=nvl((select zdz from zftal_xtgl_xtszb where zdm='XQZKZ'),2);
  end if;
  return sXqs;
end fn_getZxxqs;

/

