create function get_xmbmtj(vTj        varchar2,
                                      vXmbmsz_id varchar2,
                                      vXqh_id    varchar2,
                                      vJg_id     varchar2,
                                      vZyh_id    varchar2,
                                      vZyfx_id   varchar2,
                                      vNjdm_id   varchar2,
                                      vBh_id     varchar2,
                                      vXbm       varchar2,
                                      vXslbm     varchar2,
                                      vCcdm      varchar2,
                                      vXsbj      varchar2,
                                      vXh_id     varchar2) ---项目报名条件
 Return varchar2 as
  sSql      varchar2(2000);
  sxnxqtj   varchar2(50);
  sxnxqgx   varchar2(8);
  sxn       varchar2(10);
  sxq       varchar2(10);
  sxmtj     varchar2(50);
  scjtj     varchar2(50);
  scjsxtj   varchar2(50);
  ssfgkyy   varchar2(4);
  sgkyycj   varchar2(50);
  sgx       varchar2(6);
  sdx       varchar2(32);
  tj        number;
  dx        number;
  icount    number;
  imx       number;
  ixz       number;
  icount_mx number;
  icount_xz number;
  jgtj      number;
begin
  tj   := 0;
  dx   := 0;
  jgtj := 0;
  select count(*)
    into icount
    from jw_xmgl_xmbmtjb
   where xmbmsz_id = vXmbmsz_id
     and tj_id = vTj;
  if icount > 0 then
    select xnxqtj, xmtj, cjtj,cjsxtj, gx, dx,xmsfgkyy
      into sxnxqtj, sxmtj, scjtj,scjsxtj, sgx, sdx,ssfgkyy
      from jw_xmgl_xmbmtjb
     where xmbmsz_id = vXmbmsz_id
       and tj_id = vTj;
    --获取学生高考英语成绩
    select ylzd3 into sgkyycj from jw_xjgl_xsjbxxb where xh_id=vXh_id;
    if ssfgkyy = '1' then
       sSql  :='select  count(*) from jw_xmgl_xmbmtjb  where xmbmsz_id = ''' || vXmbmsz_id || ''' and tj_id='''|| vTj ||'''';
          if sgkyycj is null then
               tj :=0;
          else
             if scjtj is not null then
                 sSql := sSql||' and to_number(' || sgkyycj || ') >= to_number(' || scjtj || ')';
             end if;
             if scjsxtj is not null then
                 sSql := sSql||' and to_number(' || sgkyycj || ') <= to_number(' || scjsxtj || ')';
             end if;
            Execute Immediate sSql into icount;
            if icount > 0 then
               tj := 1;
            else
               tj := 0;
            end if;
          end if;
    else
      if sxmtj is null then
         tj := 1;
      else
        if scjtj is null and scjsxtj is null then
          tj:=0;
        else
          sSql    := 'select count(*) from (select max(to_number(case when (select dzb.dyf from jw_xmgl_xmcjdzb dzb,  jw_xmgl_xmjzdmb jzb where t2.jfzdm = jzb.xmjzdm and jzb.xmjzdm = dzb.xmjzdm  and dzb.xmcjmc = t1.xmcj) is null then t1.xmcj else (select dzb.dyf from jw_xmgl_xmcjdzb dzb,  jw_xmgl_xmjzdmb jzb where t2.jfzdm = jzb.xmjzdm and jzb.xmjzdm = dzb.xmjzdm  and dzb.xmcjmc = t1.xmcj) end )) over (partition by 1) zzcj,t1.* from Jw_Xmgl_Xmxsbmqkb t1,JW_XMGL_XMBMSZB t2 where t1.xmbmsz_id = t2.xmbmsz_id
          and t1.xh_id =''' ||vXh_id || ''' and xmdm = ''' || sXmtj || '''';
          if sxnxqtj is  not null then
             sxnxqgx := fn_jqzd(sxnxqtj, '|', 3);
             sxn     := fn_jqzd(sxnxqtj, '|', 1);
             sxq     := fn_jqzd(sxnxqtj, '|', 2);
             sSql    := sSql||' and t2.xnm||lpad(t2.xqm,2,0) ' || sxnxqgx || '''' || sxn ||'''||lpad(' || sxq || ',2,0)';
          end if;
          sSql    := sSql||' ) where 1=1 ';
            if scjtj is not null then
               sSql := sSql||' and to_number(zzcj) >= to_number(' || scjtj || ')';
            end if;
            if scjsxtj is not null then
               sSql := sSql||' and to_number(zzcj) <= to_number(' || scjsxtj || ')';
            end if;

          Execute Immediate sSql into icount;
          if icount > 0 then
            tj := 1;
          end if;

          if scjsxtj is not null and icount <= 0  and scjtj is null then ----当成绩小于时，如果学生没考过等级考试的也可以报名
            sSql    := 'select count(*) from Jw_Xmgl_Xmxsbmqkb t1,JW_XMGL_XMBMSZB t2 where t1.xmbmsz_id = t2.xmbmsz_id
            and t1.xh_id =''' ||vXh_id || ''' and xmdm = ''' || sXmtj || '''';
            if sxnxqtj is  not null then
               sxnxqgx := fn_jqzd(sxnxqtj, '|', 3);
               sxn     := fn_jqzd(sxnxqtj, '|', 1);
               sxq     := fn_jqzd(sxnxqtj, '|', 2);
               sSql    := sSql||' and t2.xnm||lpad(t2.xqm,2,0) ' || sxnxqgx || '''' || sxn ||'''||lpad(' || sxq || ',2,0)';
            end if;
            Execute Immediate sSql into icount;
            if icount <= 0 then
              tj := 1;
            end if;
          end if;
        end if;
      end if;
    end if;

    if sdx is null then
      dx := 1;
    else
      select count(*),nvl(max(decode(xzlb,'mx',1)),0) ,nvl(max(decode(xzlb,'xz',1)),0) into icount,imx,ixz
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ;
      if icount > 0 then
      select count(*)
        into icount_mx
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ
         and xzlb = 'mx'
         and nvl(xqh_id, vXqh_id) = vXqh_id
         and nvl(jg_id, vJg_id) = vJg_id
         and nvl(njdm_id, vnjdm_id) = vnjdm_id
         and nvl(zyh_id, vzyh_id) = vzyh_id
         and nvl(zyfx_id, vzyfx_id) = vzyfx_id
         and nvl(bh_id, vbh_id) = vbh_id
         and nvl(xbm, vXbm) = vXbm
         and nvl(xslbm, vXslbm) = vXslbm
         and nvl(ccdm, vCcdm) = vCcdm
         and bitand(nvl(xsbj, vXsbj), vXsbj) > 0
         and nvl(xh_id, vxh_id) = vxh_id;

      select count(*)
        into icount_xz
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ
         and xzlb = 'xz'
         and nvl(xqh_id, vXqh_id) = vXqh_id
         and nvl(jg_id, vJg_id) = vJg_id
         and nvl(njdm_id, vnjdm_id) = vnjdm_id
         and nvl(zyh_id, vzyh_id) = vzyh_id
         and nvl(zyfx_id, vzyfx_id) = vzyfx_id
         and nvl(bh_id, vbh_id) = vbh_id
         and nvl(xbm, vXbm) = vXbm
         and nvl(xslbm, vXslbm) = vXslbm
         and nvl(ccdm, vCcdm) = vCcdm
         and bitand(nvl(xsbj, vXsbj), vXsbj) > 0
         and nvl(xh_id, vxh_id) = vxh_id;
      if (imx >0 and icount_mx <= 0) or (ixz > 0 and icount_xz > 0 ) then
        dx := 0;
        else
        dx := 1;
      end if;
      end if;
    end if;

    if sgx = 'or' then
      jgtj := bitor(tj, dx);
    else
      jgtj := bitand(tj, dx);
    end if;
    Return to_char(jgtj);
  else
    Return '1';
  end if;
  <<Next_Null>>
  NULL;
end;

/

