create view VIEW_GJBB_XSBDQK as
  select xslbdm,sxqrs,zsrs+fxrs+zrrs+qtzjrs zjhjrs,zsrs,fxrs,zrrs,qtzjrs,
byrs+jyrs+xxrs+txrs+kcrs+swrs+zcrs+qtjsrs hjjsrs,byrs,jyrs,xxrs,txrs,kcrs,swrs,zcrs,qtjsrs
,bxqrs
from (
select xslbdm,sum(sxqrs)sxqrs,sum(bxqrs) bxqrs, sum(zsrs) zsrs,
sum(fxrs) fxrs,sum(zrrs) zrrs,sum(qtzjrs) qtzjrs,sum(byrs)byrs ,
sum(jyrs)jyrs,sum(xxrs)xxrs,sum(txrs)txrs,sum(kcrs)kcrs,
sum(swrs)swrs,sum(zcrs)zcrs,sum(qtjsrs)qtjsrs
from (
select t.xslbdm,t.rs+nvl(tt.sxqrs,0) sxqrs,
nvl(tt.bxqrs,0) bxqrs,t.rs+nvl(tt.zsrs,0) zsrs,
nvl(tt.fxrs,0) fxrs,nvl(tt.zrrs,0) zrrs, nvl(tt.qtzjrs,0) qtzjrs ,
nvl(tt.byrs,0)byrs,nvl(tt.jyrs,0) jyrs,nvl(tt.xxrs,0) xxrs,
nvl(tt.txrs,0) txrs,nvl(tt.kcrs,0) kcrs,nvl(tt.swrs,0) swrs,
nvl(tt.zcrs,0) zcrs,nvl(tt.qtjsrs,0) qtjsrs
from (
select '421'xslbdm,'0'rs from dual
union all
select '411'xslbdm,'0'rs from dual
union all
select '411,421' xslbdm,'0' rs  from dual
) t
full join
(select nvl(nvl(nvl(nvl(nvl(t1.xslbdm,t2.xslbdm),t3.xslbdm),t4.xslbdm),t5.xslbdm),t6.xslbdm) xslbdm,
sxqrs,bxqrs,zsrs,fxrs,zrrs,qtzjrs,byrs,jyrs,xxrs,txrs,kcrs,swrs,zcrs,qtjsrs
from
(select distinct xslbdm,count(xh_id) over(partition by xslbdm ) sxqrs from (
select  a.xh_id ,nvl(b.ydqxjzt,a.xjztdm) xjztdm ,--xjztdm改成sfzx
(select xslbdm from jw_xjgl_xsjbxxb where xh_id = a.xh_id) xslbdm
from jw_xjgl_xsxjxxb a,(
select xh_id , ydqxjzt,ydhxjzt,row_number() over(partition by xh_id order by zzshsj) rn
from jw_xjgl_xjydb where ydsxxnm='2016' and ydsxxqm='3' and shzt ='3'
)b
where a.xnm='2016' and a.xqm='3'
and   a.xh_id=b.xh_id(+)   and b.rn(+) = 1) where xslbdm in ('411','421')
and  xjztdm ='01') t1---xjztdm改成是否在校判断---上学年在校人数
 --on instr(t1.xslbdm ,t2.xslbdm)>0
full join
(select distinct xslbdm,count(xh_id) over(partition by xslbdm ) bxqrs from (
select  a.xh_id ,nvl(b.ydqxjzt,a.xjztdm) xjztdm ,--xjztdm改成sfzx
(select xslbdm from jw_xjgl_xsjbxxb where xh_id = a.xh_id) xslbdm
from jw_xjgl_xsxjxxb a,(
select xh_id , ydqxjzt,ydhxjzt,row_number() over(partition by xh_id order by zzshsj) rn
from jw_xjgl_xjydb where ydsxxnm='2017' and ydsxxqm='3' and shzt ='3'
)b
where a.xnm='2017' and a.xqm='3'
and   a.xh_id=b.xh_id(+)   and b.rn(+) = 1) where xslbdm in ('411','421')
and  xjztdm ='01')t2 ---xjztdm改成sfzx判断
on t1.xslbdm =t2.xslbdm ---本学年在校人数
full join
(select distinct xslbdm,count(xh_id) over(partition by xslbdm) zsrs from jw_xjgl_xsxjxxb where
(case when zsjd = '春' then '2016' else '2017' end) = zsnddm and sfzx ='1'
and xslbdm in ('411','421')
) t3 on t1.xslbdm =t3.xslbdm----招生人数
full join
(select xslbdm,max(fxrs) fxrs,max(zrxs) zrrs,nvl(max(zjydrs),0)-nvl(max(fxrs),0)-nvl(max(zrxs),0) qtzjrs from (
select xslbdm,decode(ydlbmc,'复学',count(xh_id) over(partition by xslbdm,ydlbmc)) fxrs,
decode(ydlbmc,'转入',count(xh_id) over(partition by xslbdm,ydlbmc)) zrxs,
count(xh_id) over(partition by xslbdm) zjydrs from (
select (select xjydmc from  jw_xjgl_xjydlbdmb where ydlbm = a.ydlbm) ydlbmc,
xh_id,(select xslbdm from jw_xjgl_xsxjxxb where xnm=a.xnm and xqm=a.xqm and xh_Id = a.xh_id ) xslbdm
 from jw_xjgl_xjydb a
 where shzt ='3' and ydsxxnm ='2016'and ydhxjzt - ydqxjzt >0 ---ydhxjzt - ydqxjzt要改成sfzx字段判断
) where xslbdm in (421,411))
group by xslbdm) t4 on t1.xslbdm =t4.xslbdm---学籍异动增加在校人数
full join
(select distinct xslbdm,count(xh_id) over(partition by xslbdm) byrs
 from jw_xjgl_xsxjxxb where xnm='2016' and xqm='12' and xjztdm ='07' and sfzx = 0
 and xslbdm in ('411','421')) t5 on t1.xslbdm =t5.xslbdm---毕业人数----怎么统计
 full join
(select xslbdm,max(jyrs) jyrs,max(xxrs) xxrs,
max(txrs) txrs,max(kcrs) kcrs,max(swrs) swrs,max(zcrs) zcrs,
nvl(max(jsydrs),0)-nvl(max(jyrs),0)-nvl(max(xxrs),0)-nvl(max(txrs),0)-nvl(max(kcrs),0)
-nvl(max(swrs),0)-nvl(max(zcrs),0) qtjsrs from (
select xslbdm,decode(ydlbmc,'结业',count(xh_id) over(partition by xslbdm,ydlbmc)) jyrs,
decode(ydlbmc,'休学',count(xh_id) over(partition by xslbdm,ydlbmc)) xxrs,
decode(ydlbmc,'退学',count(xh_id) over(partition by xslbdm,ydlbmc)) txrs,
decode(ydlbmc,'开除',count(xh_id) over(partition by xslbdm,ydlbmc)) kcrs,
decode(ydlbmc,'死亡',count(xh_id) over(partition by xslbdm,ydlbmc)) swrs,
decode(ydlbmc,'转出',count(xh_id) over(partition by xslbdm,ydlbmc)) zcrs,
count(xh_id) over(partition by xslbdm) jsydrs from (
select (select xjydmc from  jw_xjgl_xjydlbdmb where ydlbm = a.ydlbm) ydlbmc,
xh_id,(select xslbdm from jw_xjgl_xsxjxxb where xnm=a.xnm and xqm=a.xqm and xh_Id = a.xh_id ) xslbdm
 from jw_xjgl_xjydb a
 where shzt ='3' and ydsxxnm ='2016'and ydhxjzt - ydqxjzt <0 --ydhxjzt - ydqxjzt要改成sfzx字段判断
) where xslbdm in (421,411))
group by xslbdm)t6 on t1.xslbdm=t6.xslbdm  --学籍异动减少在校人数
)tt on instr(t.xslbdm,tt.xslbdm) >0
) group by xslbdm)
/

