create procedure proc_by_jysh
(
  in_xh_id in varchar2, --学号
  in_byjlfs in varchar2,--毕业结论方式
  in_byjr  in varchar2, ---毕业结论,不是代码
  in_xjztdm in varchar2, ---学籍状态代码
  in_sfzx in varchar2 ---是否在校
)
as
     v_zh1 varchar2(1);
     v_zh2 varchar2(1);
     v_bx1 varchar2(1);
     v_bx2 varchar2(1);
     v_xx1 varchar2(1);
     v_xx2 varchar2(1);
     v_byjl varchar2(100);
     v_result varchar2(200);
     v_num number;
     v_sfby varchar(2);
     v_xxdm varchar(10);
     v_xjztdm varchar(2);
     begin
     v_zh1:=0;
     v_zh2:=0;
     v_bx1:=0;
     v_bx2:=0;
     v_xx1:=0;
     v_xx2:=0;
     v_result:='';
     select xxdm into v_xxdm from zftal_xtgl_xxxxszb;
     if in_byjlfs='1' then --自动设置毕业结论
       select xxsh into v_sfby from jw_bygl_byshb t where xh_id=in_xh_id;
       v_xjztdm:=getXjztdm(in_xh_id);--交大独有的函数
       if v_sfby !='' or v_sfby is not null then
       if v_sfby='1' then
          v_byjl:='毕业';
       else
           if v_xxdm='10191' then
             select (to_number(yqzdxf)-to_number(hdxf)) into v_num from jw_jh_xsjxzxjhxfyqxxb where xh_id=in_xh_id and sfmjd='0' and fxfyqjd_id is null;
             if v_num >5 then
                v_zh1:=0;
                v_result:='必修任选要求和获得学分相差'||v_num||'学分，大于5学分';
             elsif (v_num>0 and v_num<=5) then
                v_zh1:=1;
                v_result:='必修任选要求和获得学分相差'||v_num||'学分，5学分之内';
             else
                v_zh2:=1;
                v_result:='必修+任选要求总学分合格';
             end if;
             select count(1) into v_num from jw_jh_xsjxzxjhkcxxb where xh_id=in_xh_id and kcxzdm='01' and (bfzcj is null or bfzcj<60 );
             if v_num >1 then
                v_bx1:=0;
                v_result:=v_result||',必修课不及格'||v_num||'门';
             elsif v_num=1 then
                v_bx1:=1;
                v_result:=v_result||',必修课不及格1门';
             else
                v_bx2:=1;
                v_result:=v_result||',必修课全部合格';
             end if;

             select (to_number(yqzdxf)-to_number(hdxf)) into v_num from jw_jh_xsjxzxjhxfyqxxb where xh_id=in_xh_id  and xfyqjdmc='任选';
             if v_num>2 then
                v_xx1:=0;
                v_result:=v_result||',任选课不通过'||v_num||'学分';
             elsif (v_num>0 and v_num<=2) then
                v_xx1:=1;
                v_result:=v_result||',任选课不通过'||v_num||'学分';
             else
                v_xx2:=1;
                v_result:=v_result||',任选课全部合格';
             end if;

             if(v_zh2=1 and v_bx2=1 and v_xx2=1) then
               v_byjl:='毕业';

             elsif((v_bx1=1 and v_xx2=1)or(v_zh1=1 and (v_xx1=1 or v_xx2=1))) then
               v_byjl:='结业';
             else
             v_byjl:='不毕业';
             end if;
           else
              v_byjl:='结业';
           end if;
       end if;

       update jw_bygl_bysfzxxb set  byjr=v_byjl where xh_id=in_xh_id;
       update jw_bygl_byshb set  XXRESULT=v_result where xh_id=in_xh_id;
       if v_xxdm!='10345' then--浙师大不用更新学籍
          select xjztdm into v_xjztdm from jw_xjgl_xjztdmb a where a.xjztmc = v_byjl;
          update jw_xjgl_xsjbxxb set xjztdm = v_xjztdm where xh_id=in_xh_id;
          update jw_xjgl_xsxjxxb a set a.xjztdm = v_xjztdm  where a.xnm >=(select zdz  from zftal_xtgl_xtszb where zdm ='DQXNM')
          and a.xqm >=(select zdz from zftal_xtgl_xtszb where zdm ='DQXQM') and a.xh_id = in_xh_id;
       end if;
      if v_xxdm='10248' then ----交大单独的过程
        update jw_xjgl_xsjbxxb set xjztdm = v_xjztdm where xh_id=in_xh_id;
        update jw_xjgl_xsxjxxb a set a.xjztdm = v_xjztdm  where a.xnm >=(select zdz  from zftal_xtgl_xtszb where zdm ='DQXNM')
          and a.xqm >=(select zdz from zftal_xtgl_xtszb where zdm ='DQXQM') and a.xh_id = in_xh_id;
      end if;
      end if;
      elsif in_byjlfs='2' then --手动设置毕业结论,学籍状态都要更新，根据毕业结论名称 去学籍状态表中查找出来xjztdm
        update jw_bygl_bysfzxxb set  byjr= in_byjr where xh_id=in_xh_id;
        if v_xxdm!='10345' then--浙师大不用更新学籍
           select xjztdm into v_xjztdm from jw_xjgl_xjztdmb a where a.xjztmc = in_byjr;
           update jw_xjgl_xsjbxxb set xjztdm = v_xjztdm where xh_id=in_xh_id;
           update jw_xjgl_xsxjxxb a set a.xjztdm = v_xjztdm  where a.xnm >=(select zdz  from zftal_xtgl_xtszb where zdm ='DQXNM')
          and a.xqm >=(select zdz from zftal_xtgl_xtszb where zdm ='DQXQM') and a.xh_id = in_xh_id;
        end if;
     elsif in_byjlfs='3' then --清空毕业结论
        update jw_bygl_bysfzxxb set  byjr='' where xh_id=in_xh_id;
        update jw_bygl_byshb set  XXRESULT='' where xh_id=in_xh_id;
        if v_xxdm!='10345' then--浙师大不用更新学籍
          update jw_xjgl_xsjbxxb set xjztdm = in_xjztdm,sfzx=in_sfzx where xh_id=in_xh_id;
          update jw_xjgl_xsxjxxb a set a.xjztdm = in_xjztdm,sfzx=in_sfzx  where a.xnm >=(select zdz  from zftal_xtgl_xtszb where zdm ='DQXNM')
          and a.xqm >=(select zdz from zftal_xtgl_xtszb where zdm ='DQXQM') and a.xh_id = in_xh_id;
        end if;
     end if;

   exception  When others then
    v_byjl:='无数据';
    update jw_bygl_bysfzxxb set  byjr=v_byjl where xh_id=in_xh_id;

     --   dbms_output.put_line('v_byjl:'||v_byjl||'|v_result:'||v_result);
end;

/

