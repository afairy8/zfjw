create view VIEW_JH_DLQXDZ as
  select distinct njdm_id,dldm,zyh_id from (
  --对于去向设置与大类专业对照表不一致的，剔除
  select njdm_id,zyh_id dldm,sqzyh_id zyh_id from JW_XJGL_ZXZYQRQXKZB a where not exists(select 1 from jw_jh_dlzydzb where zyh_id=a.sqzyh_id and dldm!=a.zyh_id)
  union all
  select njdm_id,dldm,zyh_id from jw_jh_dlzydzb a where not exists(select 1 from JW_XJGL_ZXZYQRQXKZB where njdm_id=a.njdm_id and zyh_id=a.dldm)
)
/

