create function fn_getZtxgl(vXnm in varchar2,vXqm in varchar2,vLrcjjgh_id in varchar2,vBcxgrs in varchar2,vXscjxgsqzb_id in varchar2)-----获取整体修改率
return number is
 sXgrs number;
 sZrs number;
 sZtxgl number;
begin
  begin
      if vXscjxgsqzb_id is not null then
        select count(1) into sXgrs
          from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b,jw_jxrw_jxbxxb c
         where a.xscjxgsqzb_id=b.xscjxgsqzb_id and a.jxb_id=c.jxb_id
           and nvl(a.shzt,'0')<='3'
           and c.xnm=vXnm and c.xqm=vXqm and a.lrcjjgh_id=vLrcjjgh_id and a.xscjxgsqzb_id!=vXscjxgsqzb_id;
      else
        select count(1) into sXgrs
          from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b,jw_jxrw_jxbxxb c
         where a.xscjxgsqzb_id=b.xscjxgsqzb_id and a.jxb_id=c.jxb_id
           and nvl(a.shzt,'0')<='3'
           and c.xnm=vXnm and c.xqm=vXqm and a.lrcjjgh_id=vLrcjjgh_id;
      end if;

      if vBcxgrs is not null then
         sXgrs := sXgrs+to_number(vBcxgrs);
      end if;

      select sum(rs) into sZrs from (
      select count(cj.xh_id) rs
        from jw_jxrw_jxbxxb a,jw_jxrw_jxbjsrkb b,
             (select a.jxb_id,nvl(b.lrcjjgh_id, a.lrcjjgh_id) lrcjjgh_id
                 from jw_cj_xmblszb a, jw_cj_xmjdxblszb b
                where a.jxb_id = b.jxb_id(+)
                  and a.jdxblzbh = b.jdxblzbh(+)
                  and a.xmbl>0 and nvl(b.jdxbl,100)>0
                  and nvl(a.zdzhyccjxbj,a.zhyccjxbj)='1'
                  and nvl(b.lrzt,a.lrzt)='3'
             ) c,
             jw_cj_xscjb cj
       where a.jxb_id=b.jxb_id
         and b.sfcjlrjs = '1'
         and a.jxb_id = c.jxb_id
         and a.jxb_id = cj.jxb_id
         and a.kklxdm !='00'
	       and a.fjxb_id is null
		     and nvl(a.shzt ,'3') = '3'
	   	   and a.kkzt = '1'
         and a.xnm=vXnm and a.xqm=vXqm and nvl(c.lrcjjgh_id,b.jgh_id)=vLrcjjgh_id
      union all
      select count(cj.xh_id) rs
        from jw_jxrw_jxbxxb a,jw_kw_bkmdb bk,jw_cj_xscjb cj
       where a.jxb_id=bk.jxb_id
         and a.jxb_id=cj.jxb_id
         and bk.xh_id=cj.xh_id
         and a.kklxdm ='00'
         and a.xnm=vXnm and a.xqm=vXqm and bk.jgh_id=vLrcjjgh_id
      ) t;
      if sZrs > 0 then
         sZtxgl := round(sXgrs/sZrs*100,2);
      end if;
      return sZtxgl;
  exception When others then
      return null;
  end;
end fn_getZtxgl;

/

