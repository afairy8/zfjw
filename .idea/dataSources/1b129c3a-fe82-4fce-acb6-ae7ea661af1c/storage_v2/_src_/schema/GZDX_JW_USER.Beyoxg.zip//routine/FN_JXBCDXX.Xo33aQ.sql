create function fn_jxbcdxx(vJxb_id varchar2,vZc varchar2,vXqj varchar2,vJc varchar2,vBj varchar2) return varchar2
as
   sCdxx varchar2(2000);   /**---场地信息**/
begin
    sCdxx := '';
    begin
    if vBj = '1' then
    select t3.cdmc into sCdxx from  jw_pk_kbsjb t1, jw_pk_kbcdb t2,jw_jcdm_cdxqxxb t3
                  where t1.kb_id = t2.kb_id
                    and t1.xnm = t3.xnm
                    and t1.xqm = t3.xqm
                    and t2.cd_id = t3.cd_id
                    and jxb_id = vJxb_id
                    and bitand(t2.zcd,power(2,vZc-1)) > 0
                    and t1.xqj = vXqj
                    and bitand(t2.jc,case when nvl(to_number(vJc),0) = 0 then t2.jc else to_number(vJc) end ) > 0
                    and rownum = 1;
     end if;
exception
    When others then
      sCdxx := '';
   end;
  return sCdxx ;
end fn_jxbcdxx;

/

