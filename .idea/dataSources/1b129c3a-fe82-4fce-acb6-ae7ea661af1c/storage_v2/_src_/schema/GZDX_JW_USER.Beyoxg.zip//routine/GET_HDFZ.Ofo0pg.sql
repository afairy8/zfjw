create function get_Hdfz(
vXmlbmc varchar2,      ---项目类别名称
vXmflmc varchar2,
vXmlxmc varchar2,
vXmnr varchar2,
vXmdj1 varchar2,
vXmdj2 varchar2,
vSfydj varchar2,
vSbxmmc varchar2,
vBz varchar2,
vXmfzxssqid varchar2
) return number
as
icount number;   ---记录数
vHdfz number;
vZgf number;
begin
   vHdfz:=0;
   select nvl(to_number(yxfz),0) into vHdfz from jw_cj_xmfzxssqb sqb where sqb.xmfzxssq_id = vXmfzxssqid;
   select count(1) into icount from jw_cj_xmlxdmb lxb where lxb.xmlbmc = vXmlbmc and lxb.xmflmc = vXmflmc and lxb.xmlxmc = vXmlxmc and qyzt ='1';
   if icount>0 then
     select to_number(lxb.fzzgxz) into vZgf from jw_cj_xmlxdmb lxb where lxb.xmlbmc = vXmlbmc and lxb.xmflmc = vXmflmc and lxb.xmlxmc = vXmlxmc and qyzt ='1';
     if vZgf< vHdfz then
       return vZgf;
     end if;
   end if;
  return vHdfz ;
end get_Hdfz;

/

