create function fn_getsxzdjs(v_id varchar2,v_flag varchar2) return varchar2 --实习指导教师信息
as
v_jgh_id varchar2(400);
v_jsxm varchar2(400)  :='';
v_str varchar2(400);
jgh_id_array mytype;
begin
if v_flag=1 then
select  b.jgh_id into v_jgh_id from  jw_sxgl_sxjxrwzb b where  b.id=v_id;
jgh_id_array :=my_split(v_jgh_id,',');
end if;
if v_flag=2 then
select  b.jgh_id into v_jgh_id from  jw_sxgl_sxjxrwzxmb b where  b.id=v_id;
jgh_id_array :=my_split(v_jgh_id,',');
end if;
if v_flag=3 then
select  b.jgh_id into v_jgh_id from  jw_sxgl_xsxkxmb b where  b.id=v_id;
jgh_id_array :=my_split(v_jgh_id,',');
end if;


if v_flag=4 then
select  b.jgh_id into v_jgh_id from  jw_sxgl_xssbxxxmb b where  b.id=v_id;
jgh_id_array :=my_split(v_jgh_id,',');
end if;


for k in 1..jgh_id_array.count loop
      select
        decode((select xm
                from jw_jg_jzgxxb
               where jw_jg_jzgxxb.jgh_id = jgh_id_array(k)),
              '',
              (select xm from jw_sxgl_zdjsxxb where id = jgh_id_array(k)),
              (select xm
                 from jw_jg_jzgxxb
                where jw_jg_jzgxxb.jgh_id = jgh_id_array(k))) into v_str from dual;
  if jgh_id_array.count=1 or v_jsxm is null then
        v_jsxm := v_str;
    else
        v_jsxm := v_jsxm || ',' || v_str;
  end if;
end loop;
return v_jsxm;
end fn_getsxzdjs;

/

