create function Get_Tjjls
(vTjxh number,--条件序号
 vXnm varchar2,
 vXqm varchar2,
 vXh_id varchar2,
 vTjz varchar2,--条件值
 vTjbj  varchar2 --条件标记，0为条件1， 1为条件2
 ) return varchar2
as
 sJlr integer;--记录数
 icount integer;
 sTjz1 varchar2(1000);
 sTjz2 varchar2(1000);
 spjxfjd varchar2(100);
 spjcj varchar2(100);
 str varchar2(4000);
begin
   case vTjxh
       when 8 then
            sJlr :='0';
            return sJlr;
        when 12 then
            if vTjbj = '0' then
               select count(*) into sJlr from V_XSCJXX_JHKC a
                                        where a.xh_id = vXh_id
                                          and a.xnm||lpad(a.xqm, 2, 0) <= vXnm||lpad(vXqm, 2, 0)
                                          and maxbfzcj < 60
                                          and ','||vTjz||',' like '%,'||kcxzdm||',%';
             elsif  vTjbj = '1'  then
                select count(*) into sJlr from V_XSCJXX_JHKC a
                                         where a.xh_id = vXh_id
                                           and a.xnm||lpad(a.xqm, 2, 0) <= vXnm||lpad(vXqm, 2, 0)
                                           and maxbfzcj < 60
                                           and ','||vTjz||',' like '%,'||kclbdm||',%';

             end if;
           return sJlr;
       when 37 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
           select nvl(trim(to_char(sum(a.maxjd*a.xf)/sum(a.xf),'990.99')),0),
            count(*) , nvl(sum(case when a.maxbfzcj >= 60 then 1 else 0 end),0)
            into sPjxfjd,icount,sJlr
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id
                                    and a.xnm||lpad(a.xqm, 2, 0) <= vXnm||lpad(vXqm, 2, 0)
                                    and ','||case when sTjz1 is null then a.kcxzdm else sTjz1 end||',' like '%,'||a.kcxzdm||',%';

          if to_number(sPjxfjd) >= to_number(sTjz2) then
             if icount-sJlr = 0 then
                return '0';---通过
               else
                return '1|'||icount||'|'||sJlr; ---未全通过
             end if;
            else
              if icount-sJlr = 0 then
                return '2|'||sPjxfjd;---平均学分绩点小于要求值
               else
                return '3|'||sPjxfjd||'|'||icount||'|'||sJlr; ---平均学分绩点小于要求值且未全通过
             end if;
          end if;

      when 38 then
           select nvl(trim(to_char(sum(a.maxjd*a.xf)/sum(a.xf),'990.99')),0) into sPjxfjd
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id
                                    and a.xnm||lpad(a.xqm, 2, 0) <= vXnm||lpad(vXqm, 2, 0);
         if to_number(sPjxfjd) >= to_number(vTjz) then
            return '0';---通过
            else
            return '1|'||sPjxfjd;---平均学分绩点小于要求值
         end if;
      when 39 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
        select
         count(*),
         sum(case when a.maxbfzcj < to_number(sTjz2) then 1 else 0 end),
         wm_concat(case when a.maxbfzcj < to_number(sTjz2) then a.kcmc||' 成绩'||a.maxcj else null end)
         into icount,sJlr,str
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id
                                    and exists(select 'X' from jw_jh_kzkcdmb kzkc where kzkc.kch_id = a.kch_id
                                                                                    and ','||sTjz1||',' like '%,'||kzkc.kz_id||',%');
         if icount = 0 then
           return '1';---无要求的课程修读情况
           else
           if sJlr = 0 then
             return '0';  --通过
            else
             return '2|'||str;
           end if;
         end if;

       when 40 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
        select
         count(*),
         avg(a.maxbfzcj),
         wm_concat(a.kcmc||' 成绩'||a.maxcj)
         into icount,spjcj,str
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id
                                    and exists(select 'X' from jw_jh_kzkcdmb kzkc where kzkc.kch_id = a.kch_id
                                    and ','||sTjz1||',' like '%,'||kzkc.kz_id||',%');

        if icount = 0 then
           return '1';---无要求的课程修读情况
           else
           if to_number(spjcj)>= to_number(sTjz2) then
             return '0';  --通过
            else
             return '2|'||spjcj||'|'||str;
           end if;
         end if;

        when 41 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when nvl(a.maxbfzcj,0) < 60 then 1 else 0 end),
            wm_concat(kc.kcmc||' 成绩'||nvl(a.maxcj,'无'))
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sTjz2 = 1 then
             if sJlr = 0 then
               return '0';  --通过
               else
               return '1|'||str;
             end if;
           else
             if icount > sJlr then
               return '0';  --通过
               else
               return '2'; --未一门课程修读通过
             end if;
           end if;
         when 42 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when nvl(a.maxbfzcj,0) < 60 then 1 else 0 end),
            wm_concat(kc.kcmc||' 成绩'||nvl(a.maxcj,'无'))
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sTjz2 = 1 then
             if sJlr = 0 then
               return '0';  --通过
               else
               return '1|'||str;
             end if;
           else
             if icount > sJlr then
               return '0';  --通过
               else
               return '2'; --未一门课程修读通过
             end if;
           end if;

           when 43 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when nvl(a.maxbfzcj,0) < 60 then 1 else 0 end),
            wm_concat(kc.kcmc||' 成绩'||nvl(a.maxcj,'无'))
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sTjz2 = 1 then
             if sJlr = 0 then
               return '0';  --通过
               else
               return '1|'||str;
             end if;
           else
             if icount > sJlr then
               return '0';  --通过
               else
               return '2'; --未一门课程修读通过
             end if;
           end if;

           when 44 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when nvl(a.maxbfzcj,0) < 60 then 1 else 0 end),
            wm_concat(kc.kcmc||' 成绩'||nvl(a.maxcj,'无'))
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sTjz2 = 1 then
             if sJlr = 0 then
               return '0';  --通过
               else
               return '1|'||str;
             end if;
           else
             if icount > sJlr then
               return '0';  --通过
               else
               return '2'; --未一门课程修读通过
             end if;
           end if;

           when 45 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when nvl(a.maxbfzcj,0) < 60 then 1 else 0 end),
            wm_concat(kc.kcmc||' 成绩'||nvl(a.maxcj,'无'))
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sTjz2 = 1 then
             if sJlr = 0 then
               return '0';  --通过
               else
               return '1|'||str;
             end if;
           else
             if icount > sJlr then
               return '0';  --通过
               else
               return '2'; --未一门课程修读通过
             end if;
           end if;

           when 46 then
            sTjz1 := fn_jqzd(vTjz,'|',1);
            sTjz2 := fn_jqzd(vTjz,'|',2);
            select
            count(*),sum(case when to_number(nvl(a.maxbfzcj,0)) < to_number(sTjz2) then 1 else 0 end),
            wm_concat(case when to_number(nvl(a.maxbfzcj,0)) < to_number(sTjz2) then kc.kcmc||' 成绩'||nvl(a.maxcj,'无') else null end)
            into icount,sJlr,str
             from jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where kc.kch_id = a.kch_id(+)
              and  ','||sTjz1||',' like '%,'||kc.kch_id||',%';
           if sJlr > 0 then
               return '1|'||str;
           else
             return '0';  --通过
           end if;

           when 47 then
            select
            count(*),sum(case when to_number(nvl(a.maxbfzcj,0)) < 60 then 1 else 0 end),
            wm_concat(case when to_number(nvl(a.maxbfzcj,0)) < 60 then kc.kcmc||' 成绩'||nvl(a.maxcj,'无') else null end)
            into icount,sJlr,str
             from jw_jh_jxzxjhxfyqxxb xfyq, jw_jh_jxzxjhkcxxb jhkc,jw_xjgl_xsxjxxb xj,jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where xj.xh_id = vXh_id
              and xj.xnm = vXnm
              and xj.xqm = vXqm
              and xj.njdm_id = jhkc.njdm_id
              and xj.zyh_id = jhkc.zyh_id
              and jhkc.xfyqjd_id = xfyq.xfyqjd_id
              and jhkc.kch_id = kc.kch_id
              and decode(xfyq.zyfx_id,'wfx',1,xj.zyfx_id,2,0) > 0
              and jhkc.jyxdxnm||lpad(jhkc.jyxdxqm,2,'0') <vXnm||lpad(vXqm,2,'0')
              and jhkc.kch_id = a.kch_id(+);
           if sJlr > 0 then
               return '1|'||str;
           else
             return '0';  --通过
           end if;

           when 48 then
            select
            count(*),sum(case when to_number(nvl(a.maxbfzcj,0)) < 60 then 1 else 0 end),
            wm_concat(case when to_number(nvl(a.maxbfzcj,0)) < 60 then kc.kcmc||' 成绩'||nvl(a.maxcj,'无') else null end),
            nvl(trim(to_char(sum(a.maxjd*a.xf)/sum(a.xf),'990.99')),0)
            into icount,sJlr,str,sPjxfjd
             from jw_jh_jxzxjhxfyqxxb xfyq, jw_jh_jxzxjhkcxxb jhkc,jw_xjgl_xsxjxxb xj,jw_jh_kcdmb kc,
            (select
            a.kch_id,a.maxcj,a.maxbfzcj,a.xf,a.maxjd
            from V_XSCJXX_JHKC a  where a.xh_id = vXh_id) a
            where xj.xh_id = vXh_id
              and xj.xnm = vXnm
              and xj.xqm = vXqm
              and xj.njdm_id = jhkc.njdm_id
              and xj.zyh_id = jhkc.zyh_id
              and jhkc.xfyqjd_id = xfyq.xfyqjd_id
              and jhkc.kch_id = kc.kch_id
              and decode(xfyq.zyfx_id,'wfx',1,xj.zyfx_id,2,0) > 0
              and jhkc.jyxdxnm||lpad(jhkc.jyxdxqm,2,'0') <vXnm||lpad(vXqm,2,'0')
              and jhkc.kch_id = a.kch_id(+);

             if to_number(sPjxfjd) >= to_number(vTjz) then
             if sJlr > 0 then
               return '1|'||str;
             else
             return '0';  --通过
             end if;
            else
             if sJlr > 0 then
               return '2|'||str||'|'||sPjxfjd;
             else
              return '3|'||sPjxfjd;
             end if;
          end if;



      end case;

end Get_Tjjls;

/

