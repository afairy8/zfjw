create Function Get_JcToBinary(vJc in Varchar)   ---如：1-2 转为 3 ；1-2,4-4 转为11；
Return integer
as
  aJc integer;  ---节次变量
  i integer;
  j integer;
  k integer;
  l integer;
  ijg integer;

  aJcd varchar2(100);
begin
  j := 0;
  ijg := 0;
  if vJc is null then
    return j;
  end if;
  if length(vJc) - length(replace(vJc,'-','')) >0 then
    i := FN_JSFGFS(vJc,',')+1;
    for aJc in 1..i loop
     aJcd :=fn_jqzd(vJc,',',aJc);
     j := fn_jqzd(aJcd,'-',2);
     k := fn_jqzd(aJcd,'-',1);
     if j is null then
       j := k;
     end if;
     for l in k..j loop
     ijg := ijg + power(2,l-1);
     end loop;
    end loop;
  else
    i := FN_JSFGFS(vJc,',')+1;
    for aJc in 1..i loop
     l :=fn_jqzd(vJc,',',aJc);
     ijg := ijg + power(2,l-1);
    end loop;
  end if;
  return ijg;
end;

/

