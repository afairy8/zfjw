create function get_xssnwlx(v_xh_id varchar2)
return varchar2 as
v_snwdm varchar2(100);
v_lysdm varchar2(100);
v_xssnwlx varchar2(100);
v_snswytme varchar2(100);
begin
select decode(lysdm,'','0',lysdm) ,
       nvl(bitand(xsbj,(select xsxzm from jw_xjgl_xsxzdmb where xsxzmc like '%省内三位一体%')),'0') into v_lysdm,v_snswytme from jw_xjgl_xsjbxxb where xh_id = v_xh_id;

  if v_snswytme != '0' then
      v_xssnwlx := '2';          ---v_xssnwlx为'2'代表省内三位一体
  elsif v_lysdm = '33' then      ---v_lysdm为'33'代表是浙江省内
      v_xssnwlx := '1';          ---v_xssnwlx为'1'代表省内普通生
  else
      v_xssnwlx := '3';          ---v_xssnwlx为'3'代表省外普通生
  end if;
  return v_xssnwlx;
end get_xssnwlx;

/

