create function fun_by_getpjxfj(v_xh_id varchar2,v_lx varchar2,v_tjkcxz varchar2,v_btjkc varchar2)
Return varchar2
as
pjxfj varchar2(100);
pjxfj_lc varchar2(100);           ------------历次成绩平均学分绩
pjxfj_zg varchar2(100);           ------------最高成绩平均学分绩
sqlstr varchar2(4000);
begin
--------------(1)先计算最高成绩平均学分绩
sqlstr:= 'select to_char((case when t6.cj_zxf=0 then 0 else nvl(round(t6.zxfj/t6.cj_zxf,2),0) end),''fm9999999990.09'') from ('||
     ' select nvl(sum(to_number(nvl(xf,0))*to_number(nvl(bfzcj,0))),0) zxfj,'||
     ' nvl(sum(to_number(nvl((case when bfzcj is null then 0 else to_number(nvl(xf,0)) end),0))),0) cj_zxf  from '||
     ' (select a.kcxzdm,nvl(a.xf,''0'') xf,nvl(a.bfzcj,0) bfzcj,a.xh_id,a.kch_id,row_number() over(partition by a.xh_id, a.kch_id order by nvl(a.bfzcj,0) desc) rn '||
     ' from jw_cj_xscjb a where a.kcbj=''0'' and a.xh_id = '''||v_xh_id||''' and nvl(a.bfzcj,0) >= 60 '||
     ' and nvl(a.cjbz,''-1'')!=''缓考'' '||
     ' and not exists(select ''X'' from jw_cj_cjjglxsqb zfb where zfb.cjjglx = ''01'' and zfb.shzt = ''3'' and zfb.xh_id = a.xh_id and zfb.kch_id = a.kch_id) ';

     if v_lx='2' then
        sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = a.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
     end if;

     sqlstr:= sqlstr||') e where rn = 1 ';

     if v_tjkcxz is not null and v_tjkcxz!='qb' then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
     end if;

     if v_btjkc is not null then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
     end if;
     sqlstr:= sqlstr||' ) t6';

execute immediate sqlstr into pjxfj_zg;


--------------(2)计算历次成绩平均学分绩
    sqlstr:= 'select to_char((case when greatest(t6.cj_zxf,t7.pyfa_zxf)=0 then 0 else nvl(round(t6.zxfj/greatest(t6.cj_zxf,t7.pyfa_zxf),2),0) end),''fm9999999990.09'') from ('||
     ' select nvl(sum(to_number((case when nvl(bfzcj,0)>=60 then nvl(xf,''0'') else ''0'' end))*to_number(nvl(bfzcj,0))),0) zxfj,'||
     ' nvl(sum(to_number(nvl((case when bfzcj is null then 0 else to_number(nvl(xf,0)) end),0))),0) cj_zxf  from '||
     ' (select a.kcxzdm,nvl(a.xf,''0'') xf,nvl(a.bfzcj,0) bfzcj,a.xh_id,a.kch_id,row_number() over(partition by a.xh_id, a.kch_id order by nvl(a.bfzcj,0) desc) rn '||
     ' from jw_cj_xscjb a where a.kcbj=''0'' and a.xh_id = '''||v_xh_id||''' '||
     ' and nvl(a.cjbz,''-1'')!=''缓考'' '||
     ' and not exists(select ''X'' from jw_cj_cjjglxsqb zfb where zfb.cjjglx = ''01'' and zfb.shzt = ''3'' and zfb.xh_id = a.xh_id and zfb.kch_id = a.kch_id) ';
     if v_lx='2' then
        sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = a.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
     end if;

     sqlstr:= sqlstr||') e where rn = 1 ';

     if v_tjkcxz is not null and v_tjkcxz!='qb' then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
     end if;

     if v_btjkc is not null then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
     end if;
     sqlstr:= sqlstr||' ) t6,';

    sqlstr:= sqlstr||' (select nvl(sum(nvl(xf,0)),0) pyfa_zxf '||
		 ' from jw_jh_pyfaxffb t1 where sftj=''1'' and '||
		    ' pyfaxx_id in ('||
				' select pyfaxx_id from '||
				' (select pyfaxx_id,njdm_id,(select zyh_id from jw_jh_pyfaxxb where pyfaxx_id=t2.pyfaxx_id) zyh_id from JW_JH_PYFASYNJB t2) t3 where '||
				' exists (select ''X'' from jw_xjgl_xsjbxxb where xh_id='''||v_xh_id||''' and zyh_id=t3.zyh_id and njdm_id=t3.njdm_id) and pyfaxx_id is not null '||
			')'||
		') t7';

   execute immediate sqlstr into pjxfj_lc;

   pjxfj:=pjxfj_zg;
--------------(3)返回较大的平均学分绩
   if to_number(pjxfj_lc)>to_number(pjxfj_zg) then
      pjxfj:=pjxfj_lc;
   end if;
  return pjxfj;
end;

/

