create function fun_by_getbypjxfjd(v_xh_id varchar2,v_tjsjz varchar2)
Return varchar2
as
pjxfjd varchar2(100);
sqlstr varchar2(4000);
sJg varchar2(2000);   ---返回审核是否通过描述
begin
    sJg := '合格';
    begin
    sqlstr:= 'select to_char((case when cjjd_zxf=0 then 0 else nvl(round(zxfjd/cjjd_zxf,2),0) end),''fm9999999990.09'') pjxfjd from ('||
     'select nvl(sum(to_number(nvl(xf,0))*to_number(nvl(jd,0))),0) zxfjd,'||
     'nvl(sum(xf),0) cjjd_zxf  from '||
     '(select a.kcxzdm,a.xh_id,a.jd,a.xf,a.jxb_id,a.kch_id,row_number() over(partition by a.xh_id, a.kch_id order by a.bfzcj desc) rn '||
     ' from jw_cj_xscjb a where 1 = 1 '||
     ' and a.kcmc like ''毕业环节：毕业设计%'' '||
     ' and not exists (select ''X''  from jw_cj_cjjglxsqb zfb  where zfb.cjjglx = ''01''  and zfb.shzt = ''3''  and zfb.xh_id = a.xh_id   and zfb.kch_id = a.kch_id)'||
     ' and a.xh_id = '''||v_xh_id||'''  ';

     ---除成绩表内课程名称为“毕业环节：毕业设计(论文) ”的课程、
     sqlstr:= sqlstr||') e where rn = 1 ';
     sqlstr:= sqlstr||' ) ';
     execute immediate sqlstr into pjxfjd;
       if v_tjsjz > pjxfjd then
            sJg:= '毕业环节：毕业设计(论文)GPA为'||pjxfjd||',低于'||v_tjsjz||',不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_getbypjxfjd;

/

