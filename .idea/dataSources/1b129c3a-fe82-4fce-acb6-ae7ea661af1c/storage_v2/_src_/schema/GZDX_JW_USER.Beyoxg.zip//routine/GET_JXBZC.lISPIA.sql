create function get_Jxbzc(vJxb_id varchar2)---教学班合班组成
Return varchar2
as
sJxbzc varchar2(10000);
begin
   select wm_concat(
           (case when t.bh_id is not null then
                      (select bj from zftal_xtgl_bjdmb a where a.bh_id = t.bh_id)
                 when t.zyh_id is not null then
                      trim((select njmc from zftal_xtgl_njdmb b where b.njdm_id = t.njdm_id))||
                      trim((select zymc from zftal_xtgl_zydmb c where c.zyh_id = t.zyh_id)) else '' end)||
           (case when t.zyfx_id is not null then (select zyfxmc from zftal_xtgl_zyfxdmb d where d.zyfx_id = t.zyfx_id) else '' end))
           into sJxbzc
      from jw_jxrw_jxbhbxxb t where t.jxb_id = vJxb_id;
  return sJxbzc;
end;

/

