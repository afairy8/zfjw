create function Get_Xsgjxsddhf(--根据已上学时获得学分
vXh_id varchar2,
vYdsj varchar2,
vJxb_id varchar2,
vXf varchar2
)
 return varchar2
 as
 vHdxf varchar2(10);
 iXs number(10);
 iZxs number(10);

begin
  vHdxf := '';
  iXs := 0;
  iZxs := fn_jxbypxs(vJxb_id);
  if vYdsj is not null then --无学籍异动，则直接返回xf
    select sum(zjs) into iXs from (
        select
           kc.kch as kcdm,
           kc.kcmc,
           get_jcbinarydesc(a.jc,'') as jc,
           xl.dxqzc as zc,
           a.xqj as xqj,
           (select xnmc from jw_jcdm_xnb where xnm = jxb.xnm) as xn,
           (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = jxb.xqm) as xq,
           replace(substr(get_jcbinarydesc(a.jc,''),1,2),'-','') as ksj,
           replace(substr(get_jcbinarydesc(a.jc,''),-2),'-','') as jsj,
           replace(substr(get_jcbinarydesc(a.jc,''),-2),'-','')-replace(substr(get_jcbinarydesc(a.jc,''),1,2),'-','') +1 as zjs,
           jxb.jxbmc,
           xl.rq as skrq,jxb.kch_id from
          (select xnm,xqm,jxb_id,xqj,jc,fn_jszs(jc) as jccd, cd_id ,get_bitorsunion(wm_concat( zcd)) zcd from
          (select t1.xnm,t1.xqm,t1.jxb_id,t1.jgh_id,
          case when t2.cd_id is not null then t2.zcd else t1.zcd end zcd,
          t1.xqj,
          get_bitorsunion(wm_concat( case when t2.cd_id is not null then t2.jc else t1.jc end)) jc,
          t2.cd_id from jw_pk_kbsjb t1,jw_pk_kbcdb t2 where t1.kb_id = t2.kb_id(+)
          group by t1.xnm,t1.xqm,t1.jxb_id,t1.jgh_id,case when t2.cd_id is not null then t2.zcd else t1.zcd end,
          t1.xqj,t2.cd_id)
          group by xnm,xqm,jxb_id,xqj,jc,cd_id) a,
          (select t1.xnm,t1.xqm,t2.dxqzc,t2.xqj,t2.rq from jw_pk_xlb t1,jw_pk_rcmxb t2
                              where t1.xl_id = t2.xl_id ) xl,
          jw_jh_kcdmb kc,jw_jxrw_jxbxxb jxb,jw_xk_xsxkb xk
          where kc.kch_id = jxb.kch_id
            and jxb.jxb_id = a.jxb_id
            and jxb.jxb_id = xk.jxb_id
            and jxb.xnm = xl.xnm
            and jxb.xqm = xl.xqm
            and a.xqj = xl.xqj
            and bitand(a.zcd,power(2,xl.dxqzc-1)) > 0
            and jxb.jxb_id = vJxb_id
            and xk.xh_id = vXh_id
            and xl.rq>=(select ksrq from jw_pk_xlb where xnm = xl.xnm and xqm = xl.xqm)
            and xl.rq <= vYdsj
         );

    --根据教学班id，教工号获取已上课总学时
    if iZxs= 0 then
      vHdxf := '0';
      return vHdxf;
    else
      if iXs is null then
          vHdxf := '0';
         return vHdxf;
       else
          if iXs/iZxs < 1/3 then --如果在1/3以下，则记0分
             vHdxf := '0';
            return vHdxf;
          end if;
          if iXs/iZxs <= 1/2  and  iXs/iZxs >= 1/3 then --如果在1/3和1/2之间，则记xf*1/2分
             vHdxf := to_char(to_number(vXf)*0.5);
            return vHdxf;
          end if;
          if iXs/iZxs > 1/2 then --如果在1/2以上，则记xf分
             vHdxf := vXf;
            return vHdxf;
          end if;
        end if;
    end if;
  else
    vHdxf := vXf;
    return vHdxf;
  end if;
  return vHdxf;
end Get_Xsgjxsddhf;

/

