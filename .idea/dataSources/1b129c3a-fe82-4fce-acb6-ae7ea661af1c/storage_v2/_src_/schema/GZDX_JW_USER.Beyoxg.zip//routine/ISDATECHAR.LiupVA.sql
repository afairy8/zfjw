create Function isDateChar
(
  strDate            In      VarChar2         --日期型字符串
)
Return Number
Is
  ExecResult         Date;
Begin
  ExecResult := To_Date(strDate, 'yyyy-mm-dd');
  Return 0;        --返回值
Exception When Others Then
  Return 1;
End isDateChar;

/

