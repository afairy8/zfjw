create function fn_getKskcxx(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_apfs in varchar2,v_cd_id in varchar2)-----获取考试课程信息
return varchar2 is
    v_sfbk number; --是否补考
    v_axzbpksfqfjxb number; --按行政班排考是否区分教学班(0：否;1:是;)
    sKcxx varchar2(2000):= ''; --考试课程信息
begin
     if v_apfs='0' then --按试卷
        select wm_concat(kcxx) into sKcxx from(
        select distinct kc.kch||'/'||kc.kcmc kcxx from jw_jxrw_jxbxxb jxb,jw_kw_ksmcjxbdzb dzb,jw_jh_kcdmb kc
         where jxb.xnm=v_xnm and jxb.xqm=v_xqm and dzb.jxb_id=jxb.jxb_id and jxb.kch_id=kc.kch_id
           and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
           and dzb.xnm=v_xnm and dzb.xqm=v_xqm
        );
     end if;
     if v_apfs='1' then --按行政班
        select count(1) into v_axzbpksfqfjxb from zftal_xtgl_xtszb where (zdm='AXZBPKSFQFJXB' and zdz='1') or (zdm='AXZBPKFSSZ' and zdz='1');
        if v_axzbpksfqfjxb > 0 then --区分教学班
           select wm_concat(kcxx) into sKcxx from(
           select distinct kc.kch||'/'||kc.kcmc kcxx from jw_jxrw_jxbxxb jxb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jh_kcdmb kc
           where jxb.xnm=v_xnm and jxb.xqm=v_xqm and t3.jxb_id=jxb.jxb_id and jxb.kch_id=kc.kch_id
             and t3.kshkbj_id=t4.kshkbj_id
             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
           );
        else --不区分教学班
          if v_sfbk > 0 then --补考
             select wm_concat(kcxx) into sKcxx from(
             select distinct kc.kch||'/'||kc.kcmc kcxx from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_ksmcjxbdzb t5,jw_jh_kcdmb kc,jw_kw_bkmdb xk, jw_xjgl_xsxjxxb xj
             where xk.kch_id=kc.kch_id and xj.bh_id=t3.bh_id
                   and t5.jxb_id=xk.jxb_id and xk.xh_id=xj.xh_id and xk.xnm=xj.xnm and xk.xqm=xj.xqm
                   and t3.kshkbj_id=t4.kshkbj_id
                   and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
                   and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                   and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
             );
          else --正常考试
             select wm_concat(kcxx) into sKcxx from(
             select distinct kc.kch||'/'||kc.kcmc kcxx from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_ksmcjxbdzb t5,jw_jh_kcdmb kc,jw_xk_xsxkb xk, jw_xjgl_xsxjxxb xj
             where xk.kch_id=kc.kch_id and xj.bh_id=t3.bh_id
                   and t5.jxb_id=xk.jxb_id and xk.xh_id=xj.xh_id and xk.xnm=xj.xnm and xk.xqm=xj.xqm
                   and t3.kshkbj_id=t4.kshkbj_id
                   and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
                   and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                   and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
             );
          end if;
/*           select wm_concat(kcxx) into sKcxx from(
           select distinct kc.kch||'/'||kc.kcmc kcxx from jw_jxrw_jxbxxb jxb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,
                  jw_jxrw_jxbhbxxb hb,jw_kw_ksmcjxbdzb t5,jw_jh_kcdmb kc
           where jxb.xnm=v_xnm and jxb.xqm=v_xqm and hb.jxb_id=jxb.jxb_id and jxb.kch_id=kc.kch_id
                 and t3.kshkbj_id=t4.kshkbj_id
                 and t3.bh_id=hb.bh_id and t5.jxb_id = hb.jxb_id
                 and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
           );*/
         end if;
     end if;
     if v_apfs='2' then --按教学班
        select wm_concat(kcxx) into sKcxx from(
        select distinct kc.kch||'/'||kc.kcmc kcxx from jw_jxrw_jxbxxb jxb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jh_kcdmb kc
         where jxb.xnm=v_xnm and jxb.xqm=v_xqm and t3.jxb_id=jxb.jxb_id and jxb.kch_id=kc.kch_id
           and t3.kshkbj_id=t4.kshkbj_id
           and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
           and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
        );
     end if;
     if v_apfs='3' then --按学院
        select count(1) into v_sfbk from jw_kw_ksmcdmb ksmc where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12','21','22');
        if v_sfbk > 0 then --补考
           select wm_concat(kcxx) into sKcxx from(
           select distinct kc.kch||'/'||kc.kcmc kcxx from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_ksmcjxbdzb t5,jw_jh_kcdmb kc,jw_kw_bkmdb xk, jw_xjgl_xsxjxxb xj
           where xk.kch_id=kc.kch_id and xj.jg_id=t3.jg_id
                 and t5.jxb_id=xk.jxb_id and xk.xh_id=xj.xh_id and xk.xnm=xj.xnm and xk.xqm=xj.xqm
                 and t3.kshkbj_id=t4.kshkbj_id
                 and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
           );
        else --正常考试
           select wm_concat(kcxx) into sKcxx from(
           select distinct kc.kch||'/'||kc.kcmc kcxx from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_ksmcjxbdzb t5,jw_jh_kcdmb kc,jw_xk_xsxkb xk, jw_xjgl_xsxjxxb xj
           where xk.kch_id=kc.kch_id and xj.jg_id=t3.jg_id
                 and t5.jxb_id=xk.jxb_id and xk.xh_id=xj.xh_id and xk.xnm=xj.xnm and xk.xqm=xj.xqm
                 and t3.kshkbj_id=t4.kshkbj_id
                 and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
           );
        end if;
     end if;
     return sKcxx;
end fn_getKskcxx;

/

