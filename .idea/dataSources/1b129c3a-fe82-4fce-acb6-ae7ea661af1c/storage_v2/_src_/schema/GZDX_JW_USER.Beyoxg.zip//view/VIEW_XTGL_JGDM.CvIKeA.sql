create view VIEW_XTGL_JGDM as
  select t.jg_id,
       t.lssjjgid
  from zftal_xtgl_jgdmb t
 where t.lssjjgid is not null
union
select t.jg_id,
       t.jg_id as lssjjgid
  from zftal_xtgl_jgdmb t
/

