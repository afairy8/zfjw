create function fn_sjkxxy(vSjbh_id varchar2,vXnm varchar2,vXqm varchar2) return varchar2  ---获取试卷开课学院----
as
   sKkxy varchar2(32);   ---获取试卷开课学院
   a integer;            ---1课程开课部门 2任务开课部门
begin
    sKkxy := '';
    begin
    select to_number(zdz) into a from jw_jcdml_xtnzb where zdm = 'KKBMQZFS';
    if a=1 then
        select t4.kkbm_id into sKkxy
        from jw_kw_ksmcjxbdzb t1,jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
        where t1.sjbh_id = vSjbh_id and t1.xnm = vXnm and t1.xqm = vXqm
        and t1.jxb_id = t3.jxb_id and t3.kch_id = t4.kch_id
        and t4.kkbm_id is not null and rownum<=1;
    end if;

    if a=2 then
        select nvl(t3.kkbm_id,t4.kkbm_id) into sKkxy
        from jw_kw_ksmcjxbdzb t1,jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
        where t1.sjbh_id = vSjbh_id and t1.xnm = vXnm and t1.xqm = vXqm
        and t1.jxb_id = t3.jxb_id and t3.kch_id = t4.kch_id
        and rownum<=1;
    end if;
    exception
      When others then sKkxy := '无';
    end;
return sKkxy;
end fn_sjkxxy;

/

