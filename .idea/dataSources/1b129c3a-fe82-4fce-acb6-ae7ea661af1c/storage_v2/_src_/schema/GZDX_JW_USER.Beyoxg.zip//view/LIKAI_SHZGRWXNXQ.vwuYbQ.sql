create view LIKAI_SHZGRWXNXQ as
  select
jzg.jgh_id,jzg.zcm,jzg.JG_ID,jzg.DQZT
from JW_JG_JZGSHXXB shb,JW_JG_JZGXXB jzg
where shb.JGH_ID=jzg.JGH_ID
and shb.xnm=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学年')
and shb.xqm=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学期')
and (shb.ZCM<>jzg.ZCM  or shb.JG_ID<>jzg.JG_ID)
/

