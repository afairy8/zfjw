create function fun_getJdqsxf(v_Xh_id varchar2,v_Kcxzdm varchar2)return varchar2
/****获取节点所有缺失学分 kwy 2019年10月11日 11:02:53 ****/
/*可被替代学分总和  当前节点获得学分<要求学分 且 父节点获得学分 < 要求学分 才将当前节点计数考虑被替代 参与求和*/
as
 sResult varchar2(20);
begin

    select sum(t.yqzdxf) - sum(t.hdxf) into sResult
      from (
            select
                  (select hd.hdxf from JW_JH_xsJXZXJHXFYQXXB hd where hd.xfyqjd_id = xxb.fxfyqjd_id and hd.xh_id = v_Xh_id) hdxf,
                  (select hd.yqzdxf from JW_JH_xsJXZXJHXFYQXXB hd where hd.xfyqjd_id = xxb.fxfyqjd_id and hd.xh_id = v_Xh_id) yqzdxf
              from JW_JH_xsJXZXJHXFYQXXB xxb
             where xxb.fxfyqjd_id is not null
               and xxb.sfmjd = '1'
               and xxb.xh_id = v_Xh_id
               and xxb.kcxzdm = v_Kcxzdm
               and nvl(to_number(xxb.yqzdxf), 0) > nvl(to_number(xxb.hdxf), 0)
               and exists(select '1' from JW_JH_xsJXZXJHXFYQXXB b where b.xfyqjd_id = xxb.fxfyqjd_id and b.yqzdxf > b.hdxf and b.xh_id = v_Xh_id)
               group by xxb.fxfyqjd_id
            ) t;

  if sResult is null then
     sResult := 0;
  end if;
  return sResult;
end fun_getJdqsxf;

/

