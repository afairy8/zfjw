create Procedure Pk_GetZhxsfaZdpk(
vZhxs in varchar2,
vPkcs in number,
vBj out varchar2)
as
i number;
nPkcs number;
sPknr varchar2(100);
sPknrDq varchar2(100);

cursor Get_Zhxsfa is     ----取异常教学任务信息。----游标---
   select pknr,pkcs   from jw_pk_zxsfpfab where zhxs = vZhxs and sfsy = '1' order by case when pkcs = vpkcs then 0 else 1 end , yxj;
   Cur_Zhxsfa Get_Zhxsfa%rowtype;
begin
   vBj := '';
   open Get_Zhxsfa;
  loop
     exit when vBj = '1';
    fetch Get_Zhxsfa into Cur_Zhxsfa;
     exit when Get_Zhxsfa%notfound;
     sPknr := Cur_Zhxsfa.Pknr;
     nPkcs := Cur_Zhxsfa.Pkcs;
     for i in 1..nPkcs loop
      sPknrDq := fn_jqzd(sPknr,',',i);
      if instr(sPknrDq,'*') >0 then
      vbj:='1';
      else
      vbj:='2';
      end if;
     end loop;

  end loop;
  close Get_Zhxsfa;
  goto pkjsend;
  <<pkjsend>>
  null;
end;


/

