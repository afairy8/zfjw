create view VIEW_JXRW_BKZYBJ as
  select t1.xnm,
               t1.xqm,
               t2.xqh_id,
               t1.njdm_id,
               t1.zyh_id,
               t1.bh_id,
               t2.bj,
               count(*) rs
          from jw_xjgl_xsxjxxb t1, zftal_xtgl_bjdmb t2
         where t1.bh_id = t2.bh_id
           and t1.xnm = '09'
           and t1.xqm = '12'
           and t2.xqh_id = '1'
           and t1.njdm_id='FC2D5DBF2C4CDE51E040007F01006012'
         group by t1.xnm,
                  t1.xqm,
                  t2.xqh_id,
                  t1.njdm_id,
                  t1.zyh_id,
                  t1.bh_id,
                  t2.bj
/

