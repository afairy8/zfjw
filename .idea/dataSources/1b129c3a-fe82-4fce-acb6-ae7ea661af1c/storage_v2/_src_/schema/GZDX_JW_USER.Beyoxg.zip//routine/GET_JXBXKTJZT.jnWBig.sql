create function get_jxbxktjzt(vXnm varchar2,vXqm varchar2,vJxb_id varchar2,vXh_id varchar2)---教学班选课条件状态
Return varchar2
as
 sSql varchar2(200);
 sXktjxx varchar2(2000);
 sXktjmsxx varchar2(2000);
 icount number;
 stj1 varchar2(4);
 stj2 varchar2(4);
 stj3 varchar2(4);
 stj4 varchar2(4);
begin
 stj1 := '0';
 stj2 := '0';
 stj3 := '0';
 stj4 := '0';
 select substr(xktjxx,1,instr(xktjxx,'|',1)-1),trim(substr(xktjxx,instr(xktjxx,'|',1)+1,length(xktjxx))) into sXktjxx,sXktjmsxx from jw_jxrw_jxbxxb
                                                           where xnm = vXnm
                                                             and xqm = vXqm
                                                             and jxb_id = vJxb_id;
 if sXktjxx is null then
    Return '1';
    goto Next_Null ;
   else
   if instr(sXktjxx,'TJ1') > 0 then
    stj1 := get_jxbxkxmtj('TJ1',vXnm,vXqm,vJxb_id,vXh_id);
   end if;
   if instr(sXktjxx,'TJ2') > 0 then
    stj2 := get_jxbxkxmtj('TJ2',vXnm,vXqm,vJxb_id,vXh_id);
   end if;

   if instr(sXktjxx,'TJ3') > 0 then
  stj3 := get_jxbxkkctj('TJ3',vXnm,vXqm,vJxb_id,vXh_id);
 end if;
 if instr(sXktjxx,'TJ4') > 0 then
  stj4 := get_jxbxkkctj('TJ4',vXnm,vXqm,vJxb_id,vXh_id);
 end if;
  sSql := 'select count(*) from (select '||stj1||' TJ1,'||stj2||' TJ2,'||stj3||' TJ3,'||stj4||' TJ4 from  dual ) where '||sXktjxx;
 Execute Immediate sSql into icount;
 if icount = '1' then
  return '1';
 else
  return '0|'||sXktjmsxx;
 end if;
end if;
 <<Next_Null>>
 NULL;
end;

/

