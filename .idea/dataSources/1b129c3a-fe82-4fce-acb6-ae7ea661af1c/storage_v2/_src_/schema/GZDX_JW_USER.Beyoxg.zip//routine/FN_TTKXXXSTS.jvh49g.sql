create procedure fn_ttkxxxsts(vttk_id varchar2)
as
  sTtk_id varchar2(32);
begin
   sTtk_id := vttk_id;
   insert into zftal_xtgl_xxdlb(xxbt,xxnr,jsdm,yhm,sfyx)
   select
           wm_concat(case when tklxdm = '01'
                     then tklxmc ||'提醒:'||yjsxm||'老师于'||yzcd||'星期'||yxqj||yjc||'在'||ycdmc||'上的'||kcmc||'课程调课到由'||xjsxm||'老师在'||xzcd||'星期'||xxqj||xjc||xcdmc||'上课'
                when tklxdm = '02'
                     then tklxmc ||'提醒:'||xjsxm||'老师将在'||xzcd||'星期'||xxqj||xjc||'对课程'||kcmc||'进行补课'
                when tklxdm = '03'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||'于'||ycdmc||'上的'||kcmc||'课程停上'
                when tklxdm = '04'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||ycdmc||'上的'||kcmc||'课程现改为'||xjsxm||'上课'
                when tklxdm = '05'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||ycdmc||'上的'||kcmc||'课程现改为在'||xcdmc||'上课'
                when tklxdm = '06'
                     then tklxmc ||'提醒:'||xjsxm||'老师将在'||xzcd||'星期'||xxqj||xjc||xcdmc||'对'||kcmc||'课程进行上课'
                end)||'，请各位同学相互告知！',
           wm_concat(case when tklxdm = '01'
                     then tklxmc ||'提醒:'||yjsxm||'老师于'||yzcd||'星期'||yxqj||yjc||'在'||ycdmc||'上的'||kcmc||'课程调课到由'||xjsxm||'老师在'||xzcd||'星期'||xxqj||xjc||xcdmc||'上课'
                when tklxdm = '02'
                     then tklxmc ||'提醒:'||xjsxm||'老师将在'||xzcd||'星期'||xxqj||xjc||'对课程'||kcmc||'进行补课'
                when tklxdm = '03'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||'于'||ycdmc||'上的'||kcmc||'课程停上'
                when tklxdm = '04'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||ycdmc||'上的'||kcmc||'课程现改为'||xjsxm||'上课'
                when tklxdm = '05'
                     then tklxmc ||'提醒:原定'||yjsxm||'老师在'||yzcd||'星期'||yxqj||yjc||ycdmc||'上的'||kcmc||'课程现改为在'||xcdmc||'上课'
                when tklxdm = '06'
                     then tklxmc ||'提醒:'||xjsxm||'老师将在'||xzcd||'星期'||xxqj||xjc||xcdmc||'对'||kcmc||'课程进行上课'
                end)||'，请各位同学相互告知！',
           'xs',
           xh,
           '1'
    from
         (select
              a.xnm,a.xqm,a.jxb_id,xk.xh_id,(select xh from jw_xjgl_xsjbxxb where xh_id = xk.xh_id)xh,
              (select b.jxbmc from jw_jxrw_jxbxxb b where a.jxb_id=b.jxb_id) as jxbmc,
              (select c.kcmc from jw_jxrw_jxbxxb b,jw_jh_kcdmb c where a.jxb_id=b.jxb_id and b.kch_id=c.kch_id) as kcmc,
              a.tklxdm,
              (select tklb.tklxmc from jw_pk_tklxdmb tklb where tklb.tklxdm = a.tklxdm) as tklxmc,
              a.yjgh_id,
              (select xm from jw_jg_jzgxxb where jgh_id=a.yjgh_id and a.tklxdm !='02') yjsxm,
              a.ycd_id,
              (select cdmc from jw_jcdm_cdxqxxb where cd_id = a.ycd_id and xnm=a.xnm and a.tklxdm !='02' and xqm=a.xqm) ycdmc,
              decode(nvl(a.yzcd,'0'),0,'','第'||get_weeksdesc_xnxq(a.xnm,a.xqm,a.yzcd)) yzcd,
              decode(a.yxqj,'1','一','2','二','3','三','4','四','5','五','6','六','7','日','') yxqj,
              decode(nvl(a.yjc,'0'),0,'','第'||get_jcbinarydesc(''||a.yjc,'节')) yjc,
              a.xjgh_id,
              (select xm from jw_jg_jzgxxb where jgh_id=a.xjgh_id and a.tklxdm !='03') xjsxm,
              a.xcd_id,
              (select cdmc from jw_jcdm_cdxqxxb where cd_id = a.xcd_id and xnm=a.xnm and a.tklxdm !='03' and xqm=a.xqm) xcdmc,
              decode(nvl(a.xzcd,'0'),0,'','第'||get_weeksdesc_xnxq(a.xnm,a.xqm,''||a.xzcd)) xzcd,
              decode(a.xxqj,'1','一','2','二','3','三','4','四','5','五','6','六','7','日','') xxqj,
              decode(nvl(a.xjc,'0'),0,'','第'||get_jcbinarydesc(''||a.xjc,'节')) xjc,
              a.yylb,a.tkyy
            from jw_pk_ttksqb a
              right join jw_xk_xsxkb xk on a.jxb_id = xk.jxb_id
           where a.ttk_id = sTtk_id
        )group by tklxdm,tklxmc,yjsxm,yzcd,yxqj,yjc,ycdmc,kcmc,xjsxm,xzcd,xxqj,xjc,xcdmc,xh;
    exception
      When others then
            null;
end;

/

