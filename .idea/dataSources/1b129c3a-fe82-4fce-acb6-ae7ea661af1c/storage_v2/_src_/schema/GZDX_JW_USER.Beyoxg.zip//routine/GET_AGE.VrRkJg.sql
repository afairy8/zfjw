create function get_age(vCsny varchar2) return varchar2
as
   sAge varchar2(2000);   ---字符串类型
begin
    sAge := null;
    begin
select floor(to_number(To_Date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')-To_Date(vCsny, 'yyyy-mm-dd'))/365)
as spanYears  into sAge from dual;
     exception
        When others then
          sAge := null;  --返回值
    end;
    return sAge;
end get_age;

/

