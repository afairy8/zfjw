create procedure PK_SETZDPKJS(
vXnm in varchar2,
vXqm in varchar2,
vJxb_id in varchar2,
nZhxs in number,
nZcd in number,
nXqj in number,
nJcd in number,
nzhbj in number,
vBj out varchar2)
as

begin
vBj := '1';
insert into jw_pk_kbsjb (xnm,xqm,jxb_id,jgh_id,zcd,xqj,jc)
select vXnm,vXqm,jxb_id,jgh_id,get_bitorsunion(wm_concat(zc)) zcd,nXqj xqj,jc from
(select jxb_id,jgh_id,bitand(zc,nZcd) zc,
       get_jctobinary(substr(fn_bittozc(nJcd*2)||',',1,instr(fn_bittozc(nJcd*2)||',' , ',' , 1, ks)-1 )) jc from
  (select jxb_id,jgh_id,zc,case when ks-nZhxs >= 0 then nZhxs else ks end ks,
       case when bj = 1 then rank() over (partition by jxb_id,nvl(zcjc,zc) order by 1 )
            else row_number() over (partition by jxb_id,nvl(zcjc,zc) order by ks desc ) end rn from
    (select jxb_id,jgh_id,zc,ks,bj,
        case when to_char(bitand(get_bitandsintersect(wm_concat(zc) over (partition by jxb_id)),zc)) = '0' then ''
             else to_char(bitand(get_bitandsintersect(wm_concat(zc) over (partition by jxb_id)),zc)) end zcjc  from
      (select t1.jxb_id,t1.jgh_id,t1.zc,
      case when t2.ks is not null then t2.ks - nvl(t3.ks,0) else avg(t1.zhxs  - nvl(t3.ks,0)) over (partition by t1.jxb_id,t1.jgh_id) end ks,
      nvl(t2.xsfpsfcf,t1.rwxssfcf) bj from
       -------------------------------------------------------------------
        (select m.jxb_id,m.jgh_id,l.zc,case when nzhbj = 0 then n.zhxs else 2*n.zhxs end zhxs,n.rwxssfcf from ----任务课时数
               jw_jxrw_jxbjsrkb m,jw_jxrw_jxbxxb n,
               (select power(2,rownum-1) zc,rownum zcm from zftal_xtgl_jcsjb where rownum <= 30) l where
                                                m.jxb_id  in
                                                ( select jxb_id from  jw_pk_bbfzb where
                                                   bbfz_id =
                                                   (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                   union
                                                   select vJxb_id from dual ) and
                                                   m.jxb_id = n.jxb_id and bitand(m.qsjsz,l.zc) >0 and
                                                   l.zcm = (case when nzhbj = 0 then l.zcm
                                                                when  nzhbj = 1 and mod(l.zcm,2) > 0 then l.zcm
                                                                when  nzhbj = 2 and mod(l.zcm,2) = 0 then l.zcm end)
         ) t1
         left join  ----------------------------------------------------------------
         ( select m.jxb_id,m.jgh_id,power(2,m.zc-1) zc ,m.ks,n.xsfpsfcf from
                  jw_pk_xsfpb m,jw_jxrw_jxbxxb n  where
                   m.jxb_id in
                           ( select jxb_id from  jw_pk_bbfzb where
                                                 bbfz_id = (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                            union
                                                            select vJxb_id from dual

                           ) and m.jxb_id = n.jxb_id
          ) t2
          on
          (t1.jxb_id = t2.jxb_id and t1.jgh_id = t2.jgh_id and t1.zc = t2.zc)
          left join  --------------------------------------------已排课时数
          ( select jxb_id,jgh_id,zc,sum(ks) ks from
            ( select jxb_id,jgh_id,zc,xqj,count(distinct jc) ks from
              (select b.jxb_id,b.jgh_id,c.zc,b.xqj,d.jc from
                                jw_pk_kbsjb b,
                                (select power(2,rownum-1) zc from zftal_xtgl_jcsjb where rownum <= 30 ) c,
                                (select power(2,rownum-1) jc from zftal_xtgl_jcsjb where rownum <= 30 ) d where
                                                b.xnm = vXnm and bitand(b.xqm ,vXqm) > 0  and
                                                b.jxb_id in
                                                ( select jxb_id from  jw_pk_bbfzb where
                                                   bbfz_id =
                                                   (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                   union
                                                   select vJxb_id from dual )
                                                 and
                                                bitand(b.zcd,c.zc) >0  and
                                                bitand(b.jc,d.jc) >0
               ) group by jxb_id,jgh_id,zc,xqj
             ) group by jxb_id,jgh_id,zc
           ) t3
           on
           (t1.jxb_id = t3.jxb_id and t1.jgh_id = t3.jgh_id and t1.zc = t3.zc)
        ) where ks > 0
      )
    ) where rn = 1
) group by jxb_id,jgh_id,jc;
commit;
end PK_SETZDPKJS;


/

