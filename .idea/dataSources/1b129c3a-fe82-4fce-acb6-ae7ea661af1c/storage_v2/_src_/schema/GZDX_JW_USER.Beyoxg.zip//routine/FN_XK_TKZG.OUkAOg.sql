create function fn_xk_tkzg(
    in_zh_en in varchar2,
    in_xkxnm in varchar2,
    in_xkxqm in varchar2,
    in_jxb_id in varchar2,
    in_xh_id in varchar2,
    in_xklc in varchar2,
    in_kklxdm in varchar2,
    in_bklx_id in varchar2,
    in_xkbj in varchar2,
    in_sfjf in varchar2,
    in_xxdm in varchar2
) return varchar2 is
    v_count number;
    v_kklxdm varchar2(5);
    v_njdm_id varchar2(5);
    v_bdzcbj varchar2(2);
    v_xkkz_id varchar2(32);
    v_sfktk varchar2(1);
    v_tktjrs number;
    v_gz_xklc number;
    v_gpksfkt varchar2(1);
    v_zckz varchar2(1);
    v_zntxbl varchar2(1);
begin
    v_kklxdm:=in_kklxdm;
    if nvl(in_kklxdm,'w')='w' then
        select kklxdm into v_kklxdm from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=in_jxb_id;
    end if;
    select njdm_id,nvl(bdzcbj,'0') into v_njdm_id,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;

    if v_kklxdm in ('02','03','04') then
        select c.njdm_id into v_njdm_id from jw_fx_fxezybmb a,jw_fx_fxezybmkzb b,jw_jh_jxzxjhxxb c
        where a.fxezybmkz_id=b.fxezybmkz_id and b.jxzxjhxx_id=c.jxzxjhxx_id and b.bmlbdm=decode(v_kklxdm,'02','02','03','03','04','01','00')
            and a.xh_id=in_xh_id and a.zzshjg='3' and rownum=1;
    end if;

    select max(xkkz_id) into v_xkkz_id from jw_xk_xkkzb where xnm=in_xkxnm and xqm=in_xkxqm and kklxdm=v_kklxdm and nvl(bklx_id,'0')=nvl(in_bklx_id,'0')
        and njdm=(select njdm from zftal_xtgl_njdmb where njdm_id=v_njdm_id) and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between xkkssj and xkjssj;
    if nvl(v_xkkz_id,'0')='0' then
        if in_zh_en='en_US' then
            return 'No drop-out now!';
        else
            return '不在可退课时间内！';
        end if;
    end if;

    if nvl(in_sfjf,'0')='1' then
        if in_zh_en='en_US' then
            return 'The course has been paid and can not be dropped out!';
        else
            return '已缴费，不可退！';
        end if;
    end if;

    select nvl(sfktk,'0'),nvl(tktjrs,0),nvl(zntxbl,'0'),nvl(zckz,'0') into v_sfktk,v_tktjrs,v_zntxbl,v_zckz from jw_xk_xkkzxmb where xkkz_id=v_xkkz_id;
    if v_sfktk='0' then
        if in_zh_en='en_US' then
            return 'This kind of course is not allowed to drop out!';
        else
            return '该类课程不允许退！';
        end if;
    end if;

    if v_zckz='1' and v_bdzcbj not in ('2','3') then
        if in_zh_en='en_US' then
            return 'Because the student status is unregistered, can not drop out!';
        else
            return '因学籍未注册而不可退！';
        end if;
    end if;

    if v_sfktk='1' and v_tktjrs>0 then
        select count(*) into v_count from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=in_jxb_id;
        if v_count<=v_tktjrs then
            if in_zh_en='en_US' then
                return 'Not reaching the minimum number of elective courses, can not drop out!';
            else
                return '达到最低选课人数后才可退！';
            end if;
        else
            select count(*) into v_count from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and fjxb_id=in_jxb_id;
        end if;
    end if;

    if v_zntxbl='1' then
        select xklc into v_gz_xklc from jw_xk_xkkzb where xkkz_id=v_xkkz_id;
        if v_gz_xklc!=to_number(nvl(in_xklc,'0')) then
            if in_zh_en='en_US' then
                return 'It’s not the course of this round. You can’t drop out!';
            else
                return '不是本轮选的课程，不可退！';
            end if;
        end if;
    end if;

    if in_xkbj != '10' then
        select nvl(gpksfkt,'0') into v_gpksfkt from (
            select gpksfkt from JW_XK_QTXKGZB
            where xnm=in_xkxnm and xqm=in_xkxqm and xh_id in (in_xh_id,'tongyi')
            order by case when xh_id='tongyi' then 1 else 0 end
        ) where rownum=1;
        if v_gpksfkt='0' then
            if in_zh_en='en_US' then
                return 'The course assigned by the administrator can not be dropped out!';
            else
                return '管理员配的课，不可退！';
            end if;
        elsif v_kklxdm='01' and in_xxdm='10495' then --武汉纺织的主修课只要是管配的，即使设置管配课为可退，也不可退！
            if in_zh_en='en_US' then
                return 'Administrators assigned to major courses, not to drop out!';
            else
                return '管理员配的主修课，不可退！';
            end if;
        end if;
    end if;
    return '1';
end fn_xk_tkzg;

/

