create Procedure Jh_jxrwbkrsSx(vXnm in varchar2,vXqm in varchar2,vClbj in varchar2)----教学任务人数刷新
as
  sXsyxbj varchar2(2);
  sKch_id  varchar2(32);
  sXsdm    varchar2(32);
  sNjdm_id varchar2(32);
  sZyh_id  varchar2(32);
  sBh_id   varchar2(32);
  sZyfx_id varchar2(32);
  sBkxxb_id varchar2(32);
  iJxbgs   number;
  iRsc     number;

  sJxb_id varchar2(50);
  iJxbrs number;
  iKrrl number;
  iCdzws number;
  iRs number;
  iJxbhbgs number;
  iZrs number;
  iRn  number;
  iJgbj number;


  cursor Get_YcJxrwrs is     ----取异常教学任务信息。----游标---
  select distinct a.kch_id,a.xsdm,a.jxbgs,a.rsc,a.bkxxb_id From jw_jh_jxrwhbrsycb a
                                                                     where a.xnm = vXnm
                                                                       and a.xqm = vXqm
                                                                       and a.clbj = vClbj;
  Cur_YcJxrwrs Get_YcJxrwrs%rowtype;

  cursor Get_YcJxrwxx is     ----取异常教学任务信息。----游标---
  select rownum rn,a.jxb_id,a.jxbrs,a.krrl,a.cdzws,a.rs,a.jxbhbgs From jw_jh_jxrwhbxxb a
                                                       where a.xnm = vXnm
                                                         and a.xqm = vXqm
                                                         and a.xsdm = sXsdm
                                                         and a.kch_id = sKch_id
                                                         and a.bkxxb_id = sBkxxb_id
                                                         and a.clbj = vClbj;
  Cur_YcJxrwxx Get_YcJxrwxx%rowtype;
 --------------------------------------------------------------------------------
begin
  -------------------------------------------------------------------------------
  select case when count(*) >0 then '1' else '0' end into sXsyxbj from jw_jcdml_xtnzb where zdm = 'XSYXBJ' and zdz = '1';
  --初始化---全部数据
  delete from jw_jh_jxrwhbxxb a Where a.xnm  = vXnm
                                  and a.xqm = vXqm;
  commit;
  insert into jw_jh_jxrwhbxxb(xnm,xqm,xqh_id,kch_id,xsdm,jxb_id,jxbrs,krrl,cdzws,rs,jxbhbgs,clbj,bkxxb_id)
  select distinct t1.xnm,t1.xqm,t1.xqh_id,t1.kch_id,t1.xsdm,t1.jxb_id,t1.jxbrs,t1.krrl,
         fn_jxbCdrs(t1.jxb_id,t1.xnm,t1.xqm,'0') as cdzws,
         --30 as cdzws,
         jxbrs as rs,
         count(*) over (partition by t1.jxb_id) as jxbhbgs,vClbj,t2.bkxxb_id
    from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2
   where t1.xnm=vXnm
     and t1.xqm=vXqm
     and t1.jxb_id = t2.jxb_id
     and t1.kklxdm = '06'
     and t1.kkzt = '1';


  commit;

  delete from jw_jh_jxrwhbrsb a Where a.xnm = vXnm
                                  and a.xqm = vXqm;
  commit;
  insert into jw_jh_jxrwhbrsb(xnm,xqm,kch_id,xsdm,jxbgs,rs,clbj,bkxxb_id)
  select xnm,xqm,kch_id,xsdm,count(jxb_id) as jxbgs,sum(rs) as rs,vClbj,bkxxb_id from
         jw_jh_jxrwhbxxb
   where xnm = vXnm
     and xqm = vXqm
     and clbj = vClbj
     group by xnm,xqm,kch_id,xsdm,bkxxb_id;
  commit;

  -------学生人数统计-----------------------------------
  delete from jw_jh_tjxsrsb where xnm = vXnm and xqm = vXqm;
  commit;
  insert into jw_jh_tjxsrsb(xnm,xqm,rs,clbj,bkxxb_id)--学籍信息表内学生人数统计包括有方向及无方向人数
        select b.xnm,b.xqm,sum(a.rs) rs,vClbj,a.bkxxb_id
        from jw_jxrw_bkzybjdzb a ,jw_jxrw_bkxxb b
        where  xnm = vXnm
           and xqm = vXqm
           and a.bkxxb_id = b.bkxxb_id
        group by b.xnm,b.xqm,a.bkxxb_id ;
   commit;

  -------任务合班人数小于学生实际人数统计【教学任务合班人数异常表】-----------------------------------
  delete from jw_jh_jxrwhbrsycb a where a.xnm = vXnm and a.xqm = vXqm;
  insert into jw_jh_jxrwhbrsycb(xnm,xqm,kch_id,xsdm,jxbgs,rs,xsskrs,rsc,xsrs,yxxsrs,clbj,bkxxb_id)
  select distinct a.xnm,a.xqm,a.kch_id,a.xsdm,a.jxbgs,a.rs,b.rs as xsskrs,b.rs - a.rs as rsc,b.rs as xsrs,null as yxxsrs,vClbj,a.bkxxb_id from
        jw_jh_jxrwhbrsb a, jw_jh_tjxsrsb b
   where a.xnm = vXnm
     and a.xqm = vXqm
     and b.xnm = vXnm
     and b.xqm = vXqm
     and a.bkxxb_id = b.bkxxb_id
     and a.rs < b.rs;
  commit;
  -------------------------------------------------------------------------------

  open Get_YcJxrwrs;
  loop
    fetch Get_YcJxrwrs into Cur_YcJxrwrs;
     exit when Get_YcJxrwrs%notfound;
     sKch_id  :=Cur_YcJxrwrs.kch_id;
     sXsdm    :=Cur_YcJxrwrs.xsdm;
     sBkxxb_id:= Cur_YcJxrwrs.bkxxb_id;
     iJxbgs   :=Cur_YcJxrwrs.jxbgs;
     iRsc     :=Cur_YcJxrwrs.rsc;
    ----------------------------1---------------------------------------
    open Get_YcJxrwxx;
    loop
    fetch Get_YcJxrwxx into Cur_YcJxrwxx;
     exit when Get_YcJxrwxx%notfound;
     sJxb_id  :=Cur_YcJxrwxx.jxb_id;
     iJxbrs   :=Cur_YcJxrwxx.jxbrs;
     iKrrl    :=Cur_YcJxrwxx.krrl;
     iCdzws   :=Cur_YcJxrwxx.cdzws;
     iRs      :=Cur_YcJxrwxx.rs;
     iJxbhbgs :=Cur_YcJxrwxx.jxbhbgs;
     iRn      :=Cur_YcJxrwxx.rn;
     select nvl(jgbj,0) into iJgbj from jw_jh_jxrwhbxxb where jxb_id = sJxb_id and xsdm = sXsdm and bkxxb_id = sBkxxb_id;
    if iJgbj != 2 then ----iJgbj结果标记0表示默认值，1表示不超出场地座位数或无场地座位数平均分配人数成功，2表示在同课程同一组教学班内
    if iJxbgs = 1 then ---一个教学班也没有合班情况
      if iCdzws is null or (iRs+iRsc <= iCdzws) then
        update jw_jh_jxrwhbxxb set jgrs = iRs+iRsc,jgbj = '1' where jxb_id = sJxb_id and clbj = vClbj;
        else
        update jw_jh_jxrwhbxxb set jgbj = '2' where jxb_id = sJxb_id and clbj = vClbj;
      end if;
     ELSIF iJxbgs > 1 then ---多个教学班有一个合班情况
      if iCdzws is null or (iRs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end) <= iCdzws) then
       update jw_jh_jxrwhbxxb set jgrs = iRs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end),jgbj = '1' where jxb_id = sJxb_id and clbj = vClbj;
       else
       update jw_jh_jxrwhbxxb set jgbj = '2' where jxb_id = sJxb_id and clbj = vClbj;
      end if;

     end if;
     end if;
     end loop;

    close Get_YcJxrwxx;

  end loop;
  close Get_YcJxrwrs;

  null;
-----------------------------------------------------------------------------------------------------------------------
end;
/

