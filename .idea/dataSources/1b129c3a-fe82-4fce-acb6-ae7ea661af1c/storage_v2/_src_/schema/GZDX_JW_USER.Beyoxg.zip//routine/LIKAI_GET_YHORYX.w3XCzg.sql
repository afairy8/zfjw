create function likai_get_yhoryx(v_xh_id in varchar2,
                                            v_xnm   in varchar2,
                                            v_xqm   in varchar2,
                                            v_kch_id   in varchar2) return int is
  v_resSign      int;
  v_resSign_cj   int;
  v_resSign_yx   int;
  v_resSign_qtyx int;
begin
  /**判断一个学生是否已选某门课程,1本学期已选,2已经获得该课程学分,3本学期已选，且已获学分，4，其他学期已选，5，本学期已选，其他学期已选，6，其他学期已选，已获学分，7，本学期已选，其他学期已选，已获学分，0，未选，未获学分**/
  v_resSign_cj := 0;
  v_resSign_yx := 0;
  v_resSign_qtyx:=0;
  /**判断是否已获**/
  select nvl(max(bfzcj),0)
    into v_resSign_cj
    from jw_cj_xscjb cjb
   where cjb.xh_id = v_xh_id
     and cjb.kch_id =v_kch_id;
         --(select distinct kch_id from jw_jh_kcdmb where kch = v_kch);
  if v_resSign_cj >=60 then
    v_resSign_cj := 2;
  else
    v_resSign_cj:=8;
  end if;
/*  select count(*)
    into v_resSign_qtyx
    from jw_xk_xsxkb xkb
   where xkb.kch_id =
         (select distinct kch_id from jw_jh_kcdmb where kch = v_kch)
     and xkb.xh_id = v_xh_id and xkb.xnm<>v_xnm and xkb.xqm<>v_xqm;
  if nvl(v_resSign_qtyx, 0) > 0 then
    v_resSign_qtyx := 4;
  end if;*/
  select count(*)
    into v_resSign_yx
    from jw_xk_xsxkb xkb
   where xkb.kch_id =v_kch_id
         --(select distinct kch_id from jw_jh_kcdmb where kch = v_kch)
     and xkb.xh_id = v_xh_id
     and xkb.xnm = v_xnm
     and xkb.xqm = v_xqm;
  if nvl(v_resSign_yx, 0) > 0 then
    v_resSign_yx := 1;
  end if;
  v_resSign := v_resSign_cj + v_resSign_yx+v_resSign_qtyx;
  return(v_resSign);
end likai_get_yhoryx;


/

