create function Get_Xksxbjzt
(vXnm varchar2,
 vXqm varchar2,
 vKch_id varchar2,
 vJxb_id varchar2,
 vXh_id varchar2,
 vJg_id varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vBj varchar2) return varchar2  ---选课筛选标记状态----
as
   sBjzt varchar2(500);   ---标记状态
   sKkbm_id varchar2(32);
begin
    sBjzt := '0';
    begin
       if vBj = '0' then  ---本开课学院本年级本专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select kkbm_id into sKkbm_id  from jw_jh_kcdmb where kch_id = vKch_id;
         select case when count(*) >0 then '9' else '0' end into  sBjzt from
         (select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2 ---本年级本专业
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = vNjdm_id
                              and t1.zyh_id = vZyh_id
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and sKkbm_id = vJg_id
                              and rownum = 1
          union all
          select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2--本年级大类内其他专业
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = vNjdm_id
                              and t1.zyh_id in (select zyh_id from jw_xk_sxdlzydzb
                                                                  where dlh_id in (select dlh_id from jw_xk_sxdlzydzb
                                                                                            where zyh_id = vZyh_id
                                                                                 )
                                                                    and zyh_id != vZyh_id)
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and rownum = 1
          union all
          select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2,jw_xk_sxjcbdzb t3 --本年级交叉班专业
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = t3.zynjdm_id
                              and t1.zyh_id  = t3.zyh_id
                              and t1.njdm_id = vNjdm_id
                              and t3.jcbzyh_id  = vZyh_id
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and t3.zyjg_id = sKkbm_id
                              and rownum = 1
         );
       end if;
        if vBj = '1' then  ---非本开课学院本年级本专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select kkbm_id into sKkbm_id  from jw_jh_kcdmb where kch_id = vKch_id;
         select case when count(*) >0 then '9' else '0' end into  sBjzt from
         (select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2 ---本年级本专业
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = vNjdm_id
                              and t1.zyh_id = vZyh_id
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and sKkbm_id != vJg_id
                              and rownum = 1

          union all
          select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2,jw_xk_sxjcbdzb t3 --本年级交叉班专业
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = t3.zynjdm_id
                              and t1.zyh_id  = t3.zyh_id
                              and t1.njdm_id = vNjdm_id
                              and t3.jcbzyh_id  = vZyh_id
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and t3.zyjg_id != sKkbm_id
                              and rownum = 1
         );
       end if;
       if vBj = '2' then  ---本年级本学院其他专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when count(*) >0 then '9' else '0' end into  sBjzt from
         (select 1 gs from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                            where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                              and t1.njdm_id = vNjdm_id
                              and t1.zyh_id in (select zyh_id from zftal_xtgl_zydmb
                                                                  where jg_id = vJg_id
                                                                    and zyh_id != vZyh_id)
                              and t1.kch_id = vKch_id
                              and t2.yxkkxnm = vXnm
                              and t2.yxkkxqm = vXqm
                              and rownum = 1
         );
       end if;
       if vBj = '3' then  ---高年级本专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when max(t2.yxkkxnm||to_char(t2.yxkkxqm,'00')) < vXnm||to_char(vXqm,'00') then '9' else '0' end into sBjzt
                   from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                              where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                                and t1.njdm_id = vNjdm_id
                                and t1.zyh_id = vZyh_id
                                and t1.kch_id = vKch_id;
       end if;
       if vBj = '4' then  ---低年级本专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when min(t2.yxkkxnm||to_char(t2.yxkkxqm,'00')) > vXnm||to_char(vXqm,'00') then '9' else '0' end into sBjzt
                   from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                              where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                                and t1.njdm_id = vNjdm_id
                                and t1.zyh_id = vZyh_id
                                and t1.kch_id = vKch_id;
       end if;
       if vBj = '5' then  ---高年级本学院非专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when max(t2.yxkkxnm||to_char(t2.yxkkxqm,'00')) < vXnm||to_char(vXqm,'00') then '9' else '0' end into sBjzt
                   from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                              where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                                and t1.njdm_id = vNjdm_id
                                and t1.zyh_id in (select zyh_id from zftal_xtgl_zydmb where jg_id = vJg_id and zyh_id != vZyh_id)
                                and t1.kch_id = vKch_id;
       end if;
       if vBj = '6' then  ---低年级本学院非专业优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when min(t2.yxkkxnm||to_char(t2.yxkkxqm,'00')) > vXnm||to_char(vXqm,'00') then '9' else '0' end into sBjzt
                   from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                              where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                                and t1.njdm_id = vNjdm_id
                                and t1.zyh_id in (select zyh_id from zftal_xtgl_zydmb where jg_id = vJg_id and zyh_id != vZyh_id)
                                and t1.kch_id = vKch_id;
       end if;
       if vBj = '7' then  ---选课轮次优先
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select case when count(*) > 0 then '9' else '0' end into sBjzt
                   from jw_xk_xsxkb t1,jw_xk_xsxksxb t2
                              where t1.xnm = vXnm
                                and t1.xqm = vXqm
                                and t2.xnm = vXnm
                                and t2.xqm = vXqm
                                and t1.xh_id = t2.xh_id
                                and t1.jxb_id = t2.jxb_id
                                and t1.xh_id = vXh_id
                                and t1.jxb_id = vJxb_id
                                and t2.xh_id = vXh_id
                                and t2.jxb_id = vJxb_id
                                and t1.xklc > t2.xklc;
       end if;
     exception
        When others then
          sBjzt := '0';
    end;
    return sBjzt ;
end Get_Xksxbjzt;

/

