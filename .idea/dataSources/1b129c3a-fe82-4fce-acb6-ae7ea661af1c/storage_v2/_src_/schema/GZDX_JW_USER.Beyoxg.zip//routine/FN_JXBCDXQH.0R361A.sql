create function fn_jxbCdXqh(vJxb_id varchar2,vXnm varchar2,vXqm varchar2) return varchar2  ---教学班场地校区号----
as
   sCdxqh varchar2(32);   ---教学班场地校区号
begin
    sCdxqh := '';
    begin
      select min(t1.xqh_id) into sCdxqh
        from jw_jcdm_cdxqxxb t1,jw_pk_kbsjb t3,jw_pk_kbcdb t4
               where t1.cd_id = t4.cd_id
                 and t4.kb_id = t3.kb_id
                 and t3.jxb_id = vJxb_id
                 and t3.xnm = vXnm
                 and t3.xqm = vXqm
                 and t1.xnm=vXnm
                 and t1.xqm=vXqm;
     exception
        When others then
          sCdxqh := '';
    end;
    if sCdxqh is null then
     return '' ;
    else
    return sCdxqh ;
    end if ;
end fn_jxbCdXqh;

/

