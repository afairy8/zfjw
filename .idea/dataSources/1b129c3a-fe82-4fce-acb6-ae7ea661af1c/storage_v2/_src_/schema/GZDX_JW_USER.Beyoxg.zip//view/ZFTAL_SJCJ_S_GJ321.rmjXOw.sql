create view ZFTAL_SJCJ_S_GJ321 as
  (select
       lb.al,
       rownum bh,
       lb.s17,
       lb.s18,
       lb.s19,
       lb.s20,
       lb.s21,
       lb.s22,
       lb.s23,
       lb.s24,
       lb.s25,
       lb.s26,
       lb.s27,
       lb.s28,
       lb.s29,
       lb.s30,
       lb.s31
from (

  select t.mc al,

         sum(case when age <= 17 then 1 else 0 end) s17,
         sum(case when age = 18 then 1 else 0 end) s18,
         sum(case when age = 19 then 1 else 0 end) s19,
         sum(case when age = 20 then 1 else 0 end) s20,
         sum(case when age = 21 then 1 else 0 end) s21,
         sum(case when age = 22 then 1 else 0 end) s22,
         sum(case when age = 23 then 1 else 0 end) s23,
         sum(case when age = 24 then 1 else 0 end) s24,
         sum(case when age = 25 then 1 else 0 end) s25,
         sum(case when age = 26 then 1 else 0 end) s26,
         sum(case when age = 27 then 1 else 0 end) s27,
         sum(case when age = 28 then 1 else 0 end) s28,
         sum(case when age = 29 then 1 else 0 end) s29,
         sum(case when age = 30 then 1 else 0 end) s30,
         sum(case when age = 31 then 1 else 0 end) s31

    from zftal_xtgl_jcsjb t,
         (select t.csrq,
                 xj.xslbdm,
                 trunc(months_between(sysdate, to_date(t.csrq, 'yyyy-mm-dd')) / 12,0) age
            from jw_xjgl_xsjbxxb t, jw_xjgl_xsxjxxb xj
           where t.csrq like '____-__-__'
             and t.csrq not like '%-00%'
             and t.xh_id = xj.xh_id
             and xj.sfzx = '1'
             and xj.xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')
         ) b
   where t.dm = b.xslbdm
   group by t.mc

) lb)
/

