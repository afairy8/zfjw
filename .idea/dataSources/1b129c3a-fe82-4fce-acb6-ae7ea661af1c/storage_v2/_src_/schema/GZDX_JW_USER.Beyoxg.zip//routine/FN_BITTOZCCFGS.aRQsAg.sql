create function FN_BITTOZCCFGS( ---二进制转换周次重复个数及重复周次段
vZC in varchar2 ,--周次集，如：'1,7,5'   ---------- 0001,0111,0101
iWs in int,      --二进制位数，如：10位  1111111111
iCfgs in int,    --重复个数，如：2
vBj in varchar2) --标记0表示：重复位等于2返回几位重复；标记1表示：重复位大于等于2返回几位重复
return varchar2 is
  i       int;
  k       int;
  n       int;
  m       int;
  iCount  int;
  sZC     varchar2(60);
  iZcd    int;
begin

   /**通过周次二进制计算出，周次明细**/
  if vZC IS NULL then
    return '';
  end if;
  iZcd := 0;
if vBj = '0' then
  k := 1;
  m := 0;
  while k <= iWs Loop

  i := 1;
  iCount := length(vZC)-length(replace(vZC,',',''))+1;
  n :=0;
  while i <= iCount Loop
   sZC := fn_jqzd(vZC,',',i);
   if bitand(power(2,k-1),sZC) > 0 then
    n := n+1;
   end if;
   i := i+1;
  End Loop;
    if n = iCfgs then
     m := m+1;
     iZcd := iZcd + power(2,k-1);
    end if;
     k :=  k+1;
  End Loop;
end if;

if vBj = '1' then
  k := 1;
  m := 0;
  while k <= iWs Loop

  i := 1;
  iCount := length(vZC)-length(replace(vZC,',',''))+1;
  n :=0;
  while i <= iCount Loop
   sZC := fn_jqzd(vZC,',',i);
   if bitand(power(2,k-1),sZC) > 0 then
    n := n+1;
   end if;
   i := i+1;
  End Loop;
    if n >= iCfgs then
     m := m+1;
     iZcd := iZcd + power(2,k-1);
    end if;
     k :=  k+1;
  End Loop;
end if;

  return(to_char(m)||'-'||to_char(iZcd));
end FN_BITTOZCCFGS;

/

