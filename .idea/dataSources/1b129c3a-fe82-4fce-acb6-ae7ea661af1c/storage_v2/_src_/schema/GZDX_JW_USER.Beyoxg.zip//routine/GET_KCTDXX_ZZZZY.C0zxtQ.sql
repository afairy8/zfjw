create function get_Kctdxx_zzzzy(v_bj varchar2, v_kcthzbm varchar2, v_tkxx varchar2, v_thxx varchar2, v_kcthzh_id varchar2, v_xh_id varchar2, v_xxdm varchar2)
  Return varchar2 as
  out_Kctdxx    varchar2(4000);
  begin
    out_Kctdxx    := '';

    if v_bj='1' then--thxx
      select (select wm_concat(kcmc)
           from(select kc.kcmc
                from jw_cj_xscjb jxb, jw_jh_kcdmb kc
                where kc.kch_id = jxb.kch_id
                  and jxb.xh_id = v_xh_id
                  and instr(',' || v_thxx || ',', ',' || jxb.jxb_id || ',') > 0 order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='2' then--tkxx
      select  (select wm_concat(kcmc)
           from(select kc.kcmc
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          )  into out_Kctdxx from dual;
    end if;

    if v_bj='3' then--thxnmmc
      select (select wm_concat(xnmc)
           from(select (select xn.xnmc from jw_jcdm_xnb xn where xn.xnm = d.xnm) xnmc
                from jw_cj_xsgrcjdtb d
                where instr(',' || v_thxx || ',', ',' || d.jxb_id || ',') > 0
                  and d.kcthzh_id = v_kcthzh_id order by d.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='4' then--thxqmmc
      select  (select wm_concat(mc)
           from(select (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = d.xqm) mc
                from jw_cj_xsgrcjdtb d
                where instr(',' || v_thxx || ',', ',' || d.jxb_id || ',') > 0
                  and d.kcthzh_id = v_kcthzh_id order by d.kch_id desc
               )
          )  into out_Kctdxx from dual;
    end if;

    if v_bj='5' then--tkxnmmc
      select   (select wm_concat(mc)
           from(select (select xn.xnmc from jw_jcdm_xnb xn where xn.xnm = d.xnm) mc
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          )  into out_Kctdxx from dual;
    end if;

    if v_bj='6' then--tkxqmmc
      select (select wm_concat(mc)
           from (select (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = d.xqm) mc
                 from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                 where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                   and d.kch_id = kc.kch_id
                   and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
                )
          )  into out_Kctdxx from dual;
    end if;

    if v_bj='7' then--thkch
      select (select wm_concat(kch)
           from(select kc.kch
                from jw_cj_xscjb jxb, jw_jh_kcdmb kc
                where kc.kch_id = jxb.kch_id
                  and jxb.xh_id = v_xh_id
                  and instr(',' || v_thxx || ',', ',' || jxb.jxb_id || ',') > 0 order by kc.kch_id desc
               )
          )  into out_Kctdxx from dual;
    end if;

    if v_bj='8' then--tkkch
      select  (select wm_concat(kch)
           from(select kc.kch
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='9' then--thkcxzmc
      select  (select wm_concat(mc)
           from(select (select (case
                                  when v_xxdm = '10511' then
               kcxz.kcxzjc
                                  else
               kcxz.kcxzmc
               end)
                        from jw_jh_kcxzdmb kcxz
                        where kcxz.kcxzdm = jxb.kcxzdm) mc
                from jw_cj_xscjb jxb, jw_jh_kcdmb kc
                where kc.kch_id = jxb.kch_id
                  and jxb.xh_id = v_xh_id
                  and instr(',' || v_thxx || ',', ',' || jxb.jxb_id || ',') > 0
                order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='10' then--tkkcxzmc
      select (select wm_concat(mc)
           from(select (select kcxz.kcxzmc from jw_jh_kcxzdmb kcxz where kcxz.kcxzdm = d.kcxzdm) mc
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='11' then--thxf
      select (select wm_concat(xf)
           from(select kc.xf
                from jw_cj_xscjb jxb, jw_jh_kcdmb kc
                where kc.kch_id = jxb.kch_id
                  and jxb.xh_id = v_xh_id
                  and instr(',' || v_thxx || ',', ',' || jxb.jxb_id || ',') > 0  order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='12' then--tkxf
      select  (select wm_concat(xf)
              --                           from(select d.xf
           from(select to_char(d.xf, 'fm9999999990.0') xf
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='13' then--thbfzcj
      select (select wm_concat(bfzcj)
           from(select jxb.bfzcj
                from jw_cj_xscjb jxb, jw_jh_kcdmb kc
                where kc.kch_id = jxb.kch_id
                  and jxb.xh_id = v_xh_id
                  and instr(',' || v_thxx || ',', ',' || jxb.jxb_id || ',') > 0
                order by kc.kch_id desc
               )
          ) into out_Kctdxx from dual;
    end if;

    if v_bj='14' then--tkbfzcj
      select (select wm_concat(bfzcj)
           from(select wm_concat(d.bfzcj)bfzcj
                from jw_jh_kcdmb kc, jw_cj_xsgrjhdtb d
                where instr(',' || v_tkxx || ',', ',' || kc.kch_id || ',') > 0
                  and d.kch_id = kc.kch_id
                  and d.kcthzh_id = v_kcthzh_id order by kc.kch_id desc
               )
          )into out_Kctdxx from dual;
    end if;

    if v_bj='15' then--kkbmmc
      select (select wm_concat(kkbmmc) from (select distinct jg.jgmc kkbmmc
                from zftal_xtgl_jgdmb jg, jw_cj_xsgrjhdtb d
                where jg.jg_id = d.kkbm_id
                  and d.kcthzh_id = v_kcthzh_id

          ))into out_Kctdxx from dual;
    end if;

    return out_Kctdxx;
  end get_Kctdxx_zzzzy;

/

