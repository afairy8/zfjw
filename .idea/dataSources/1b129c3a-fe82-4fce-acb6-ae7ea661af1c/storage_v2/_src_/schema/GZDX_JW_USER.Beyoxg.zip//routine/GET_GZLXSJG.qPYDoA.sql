create function Get_Gzlxsjg( ---取教师教学班工作量系数集返回结果值
vXnm varchar2,      ---学年码
vXqm varchar2,      ---学期码
vKch_id varchar2,   ---课程号ID
vJxb_id varchar2,   ---教学班ID
vXsdms varchar2,    ---系数集
iXsdmsgs integer,    ---系数集个数
vBj varchar2) return varchar2  ---vBj做备用字段信息默认值为0-
as
   i number;
   icount number;   ---记录数
   v_count number;  ---用于判断是否合班数据
   v_bbJxb_ids varchar2(1000); --并班教学班
   sGs varchar2(500); ---公式
   sGsms varchar2(1000); ---公式描述
   sDqXs varchar2(500); ---当前系数
   sXs varchar2(500);  ---系数
   sSql varchar2(100);
begin
    begin --dbms_output.put_line('vJxb_id:'||vJxb_id);
          select count(*) into v_count from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1';
          if v_count > 0 then --是否并班教学班
              select wm_concat(jxb_id) into v_bbJxb_ids from jw_pk_bbfzb where bbfz_id in (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1');
              select count(*) into icount from jw_jg_gzljxbxsszb where xnm = vXnm and xqm = vXqm and ','||v_bbJxb_ids||',' like '%,'||jxb_id||',%' and gs is not null;
              if icount > 0 then
                 select gs,'公式到任务:'||gsms into sGs,sGsms from jw_jg_gzljxbxsszb where xnm = vXnm and xqm = vXqm and ','||v_bbJxb_ids||',' like '%,'||jxb_id||',%' and gs is not null and rownum = 1 ;
              else
                 select count(*) into icount from jw_jg_gzlkcxsszb where kch_id = vKch_id and gs is not null;
                   if icount >0 then
                      select gs,'公式到课程:'||gsms into sGs,sGsms  from jw_jg_gzlkcxsszb where kch_id = vKch_id;
                     else
                      select count(*) into icount from jw_jg_gzlgsb where xnm = vXnm and xqm = vXqm and rownum = 1;
                      if icount >0 then
                          select gs,'统一公式:'||gsms into sGs,sGsms from jw_jg_gzlgsb where xnm = vXnm and xqm = vXqm and rownum = 1;
                       else
                         if vBj='0' then
                         return null;
                         end if;
                         if vBj = '1' then
                           return '未设置公式';
                         end if;
                         Goto Exend;
                       end if;
                   end if;
              end if;
          else
              select count(*) into icount from jw_jg_gzljxbxsszb where xnm = vXnm and xqm = vXqm and jxb_id = vJxb_id and gs is not null;
              if icount > 0 then
                select gs,'公式到任务:'||gsms into sGs,sGsms from jw_jg_gzljxbxsszb where xnm = vXnm and xqm = vXqm and jxb_id = vJxb_id ;
              else
                   select count(*) into icount from jw_jg_gzlkcxsszb where kch_id = vKch_id and gs is not null;
                   if icount >0 then
                      select gs,'公式到课程:'||gsms into sGs,sGsms  from jw_jg_gzlkcxsszb where kch_id = vKch_id;
                     else
                      select count(*) into icount from jw_jg_gzlgsb where xnm = vXnm and xqm = vXqm and rownum = 1;
                      if icount >0 then
                          select gs,'统一公式:'||gsms into sGs,sGsms from jw_jg_gzlgsb where xnm = vXnm and xqm = vXqm and rownum = 1;
                       else
                         if vBj='0' then
                         return null;
                         end if;
                         if vBj = '1' then
                           return '未设置公式';
                         end if;
                         Goto Exend;
                       end if;
                   end if;
               end if;
          end if;
     if vBj = '0' or vBj = '1' then  ---备用字段信息默认值为0---vXsdms--|rsxs:1.0|ndxs:1.0|cfxs:1.2|zcxs:1.3|zfjxs:1.5|
       for i in 1..iXsdmsgs loop
         sDqXs:=substr(vXsdms,instr(vXsdms,'|',1,i)+1,instr(vXsdms,'|',1,i+1)-instr(vXsdms,'|',1,i)-1);
         if sDqXs is not null and instr(sGs,substr(sDqXs,1,instr(sDqXs,':',1,1)-1)) >0 then
           sGs := replace(sGs,substr(sDqXs,1,instr(sDqXs,':',1,1)-1),trim(substr(sDqXs,instr(sDqXs,':',1,1)+1,20)));
         end if;
       end loop;
       sGs := trim(substr(replace(sGs,',',''),2,1000));
       sSql := 'select 1*'||sGs||' from dual';
       Execute Immediate sSql into sXs;
       if vBj = '0' then
       return sXs ;
       end if;
     end if;
     if vBj = '1' then
      return sGsms;
     end if;
    exception
        When others then
        if vBj='0' then
         return null;
         end if;
         if vBj = '1' then
           return '设置公式异常';
         end if;
    end;
   <<Exend>>
   null;
end Get_Gzlxsjg;

/

