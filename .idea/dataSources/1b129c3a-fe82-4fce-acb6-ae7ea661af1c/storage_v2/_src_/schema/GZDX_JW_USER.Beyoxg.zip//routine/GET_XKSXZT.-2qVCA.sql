create function Get_Xksxzt
(vXnm varchar2,
 vXqm varchar2,
 vKch_id varchar2,
 vJxb_id varchar2,
 vXh_id varchar2,
 vKcbj varchar2 ) return varchar2  ---选课筛选标记状态----
as
   sZt varchar2(500);   ---标记状态
   sJg_id varchar2(32);
   sNjdm_id varchar2(32);
   sZyh_id varchar2(32);
   sNjdm varchar2(8);
begin
    sZt := '';
    select a.jg_id,a.njdm_id,a.zyh_id,
           (select to_char(sysdate,'yyyy') -njdm+2 from zftal_xtgl_njdmb
                                                      where njdm_id = a.njdm_id)
          into sJg_id,sNjdm_id,sZyh_id,sNjdm from jw_xjgl_xsxjxxb a
                                            where a.xnm = vXnm
                                              and a.xqm = vXqm
                                              and a.xh_id = vXh_id;
    begin
      if Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'7') = '9' then
        sZt := '9000000000'||sNjdm;
       elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'0') = '9' then
        sZt := '0900000000'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'1') = '9' then
        sZt := '0090000000'||sNjdm;
      elsif nvl(vKcbj,0) != '0' then
        sZt := '0009000000'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'2') = '9' then
        sZt := '0000900000'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'3') = '9' then
        sZt := '0000090000'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'4') = '9' then
        sZt := '0000009000'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'5') = '9' then
        sZt := '0000000900'||sNjdm;
      elsif Get_Xksxbjzt(vXnm,vXqm,vKch_id,vJxb_id,vXh_id,sJg_id,sNjdm_id,sZyh_id,'6') = '9' then
        sZt := '0000000090'||sNjdm;
      else
        sZt := '0000000009'||sNjdm;
     end if;
     exception
        When others then
        szt := '0000000000'||sNjdm;
    end;
    return szt ;
end Get_Xksxzt;

/

