create function get_Kch(v_kcxx varchar2)
 Return varchar2 as
  cursor c_gzxxs is
    select zdm, zdsylx, sfbl, ws, zdz,qsw from jw_jh_kchgzszb order by xh asc;
  c_gzxx     c_gzxxs%rowtype;
  out_kch    varchar2(4000);
  xxdm    varchar2(10);
  kcxx_array mytype; --存放传入课程信息分割后的数组
  zdxx_array mytype; --存放kcxx_array中分割后的字段名和字段值
  v_tmp      varchar2(4000);
  v_bj       varchar2(1);
  v_count    number;
  v_sql      varchar2(4000);
  v_flag    number;--是否存在课程号
  v_kc varchar2(4000);--常量之前的课程号
  v_ws    number; --常量位数
  v_nd    varchar2(10);
begin
  out_kch    := '';
  v_flag     :=0;
  kcxx_array := my_split(v_kcxx, ';');
  select xxdm into xxdm from zftal_xtgl_xxxxszb;
  for c_gzxx in c_gzxxs loop
    v_bj  := '0';
    v_tmp := '';
    FOR j IN 1 .. kcxx_array.count LOOP
      zdxx_array := my_split(kcxx_array(j), ':');
      if zdxx_array(1) = c_gzxx.zdm then
        v_bj := '1';
        if c_gzxx.zdm = 'kkbm_id' then
         select jg.jgdm into zdxx_array(2) from zftal_xtgl_jgdmb jg where jg.jg_id =  zdxx_array(2);
        end if;

        ---北化工
        if xxdm='10010' then
          if c_gzxx.zdm = 'xf' then
               select (case when (floor(zdxx_array(2))-1)*2>9 then 'A' else to_char((floor(zdxx_array(2))-1)*2) end) into zdxx_array(2) from dual;
          end if;
          if c_gzxx.zdm = 'kclbdm' then
               select kclbywmc into zdxx_array(2) from jw_jh_kclbdmb where kclbdm=zdxx_array(2);
          end if;
        end if;

        if c_gzxx.zdsylx = '0' then
          if c_gzxx.sfbl = '1' and c_gzxx.ws is not null then
            v_tmp:= lpad(nvl(substr(zdxx_array(2),nvl(c_gzxx.qsw,1),nvl(c_gzxx.ws,length(zdxx_array(2)))),'0'),nvl(c_gzxx.ws,length(zdxx_array(2))), '0');

           -- v_tmp := lpad(zdxx_array(2), c_gzxx.ws, '0');
          --elsif c_gzxx.qsw is not null and  c_gzxx.ws is not null  then



          else
             v_tmp:= nvl(substr(zdxx_array(2),nvl(c_gzxx.qsw,1),nvl(c_gzxx.ws,length(zdxx_array(2)))),'0');
          --  v_tmp := zdxx_array(2);
          end if;

        end if;
      end if;
    end LOOP;
    v_kc:=out_kch;
    if v_bj = '0' then
      --标识不是提交的字段，即可能为序列号也可能是常量
      if c_gzxx.zdsylx = '2' then
        --常量
        v_tmp := c_gzxx.zdz;
      elsif c_gzxx.zdsylx = '1' then
        --v_sql := 'select count(1) from jw_jh_kcdmb where 1=1';

      v_sql :=  'select count(1) from(
          select KCH_ID,KCH,KCMC,KCYWMC,KKBM_ID,XF,ZXS,KCLBDM,KCGSDM,QYNJ,ZWKCJJ,YWKCJJ,ZWJXDG,YWJXDG,CJLRJB,SFKSQMT,TYAPBKBJ,KSXKBJ,PKYXJ,KCLRR,KCLRSJ,MXDXBZ
          ,TKBJ,BZ,TKSJ,TKR,KCFZR,KCJC,SFSJK,XQM,SFBKBJ,SSKCH_ID,SJZS,XKKXS,SFYXSJZCT,KCSYFWHSKYYDM,KCLXDM,KCXZDM,KCJA,KXKSPB,XKDLDM,XKXLDM
          ,XBYSDM,ZZHXS,KCSZZSYQ,KCSZNLYQ,KCDCMB,JPKFKCDM,ZYHXKCDM,DLSZSYKDM,SYNJ,KHFSDM,KCGLBM_ID,KCJXNRLJ,KCJXNRFJM,XXMB
          ,QTXX,KHFSXX
          from jw_jh_kcdmb
          union all
          select KCH_ID,KCH,KCMC,KCYWMC,KKBM_ID,XF,ZXS,KCLBDM,KCGSDM,QYNJ,ZWKCJJ,YWKCJJ,ZWJXDG,YWJXDG,CJLRJB,SFKSQMT,TYAPBKBJ,KSXKBJ,PKYXJ,KCLRR,KCLRSJ,MXDXBZ
          ,TKBJ,BZ,TKSJ,TKR,KCFZR,KCJC,SFSJK,XQM,SFBKBJ,SSKCH_ID,SJZS,XKKXS,SFYXSJZCT,KCSYFWHSKYYDM,KCLXDM,KCXZDM,KCJA,KXKSPB,XKDLDM,XKXLDM
          ,XBYSDM,ZZHXS,KCSZZSYQ,KCSZNLYQ,KCDCMB,JPKFKCDM,ZYHXKCDM,DLSZSYKDM,SYNJ,KHFSDM,KCGLBM_ID,KCJXNRLJ,KCJXNRFJM,XXMB
          ,QTXX,KHFSXX
          from jw_jh_kcdmbbb
          ) where 1=1 ';

        --   CHR(39)标识单引号
        FOR j IN 1 .. kcxx_array.count LOOP

          zdxx_array := my_split(kcxx_array(j), ':');
           ---北化工
          if xxdm='10010' then
            if zdxx_array(1) = 'xf' then
               select (case when (floor(zdxx_array(2))-1)*2>9 then 'A' else to_char((floor(zdxx_array(2))-1)*2) end) into zdxx_array(2) from dual;
               select '(case when (floor(xf)-1)*2>9 then ''A'' else to_char((floor(xf)-1)*2) end)' into zdxx_array(1) from dual;
             end if;
           end if;
          v_sql      := v_sql ||' and '||zdxx_array(1)||'='||chr(39)||zdxx_array(2)||chr(39);
        end LOOP;
        dbms_output.put_line(v_sql);
        Execute Immediate v_sql into v_count;
        if c_gzxx.sfbl = '1' and c_gzxx.ws is not null then
          v_tmp := lpad(v_count+1, c_gzxx.ws, '0');
          v_ws:=c_gzxx.ws;
        else
          v_tmp := v_count+1;
        end if;
      end if;
    end if;
    out_kch := out_kch || v_tmp;
     dbms_output.put_line(out_kch);
  end loop;
  ---南通大学
        if xxdm='10304' then
          out_kch    := '';
          select zdz into v_nd from ZFTAL_XTGL_XTSZB where ZDM='DQND';
          out_kch:=substr(v_nd,greatest(-2,-length(v_nd)),2);
          FOR j IN 1 .. kcxx_array.count LOOP
            zdxx_array := my_split(kcxx_array(j), ':');
            if zdxx_array(1) = 'kkbm_id' then
               out_kch := out_kch || rpad(zdxx_array(2),3,'0');
              end if;
             end loop;
             out_kch := out_kch || '1000';
          end if;
  ---发现已经存在的课程号，自动往后加一位
  select count(kch) into v_flag from (select kch from jw_jh_kcdmb  union all select kch from jw_jh_kcdmbbb ) where kch = out_kch;
       if xxdm='10304' then
         while v_flag>0 LOOP
           out_kch := out_kch +1;
           select count(kch) into v_flag from (select kch from jw_jh_kcdmb  union all select kch from jw_jh_kcdmbbb ) where kch = out_kch;
          end loop;
        else
      while v_flag>0 LOOP
            v_count:=v_count+1;
            if v_ws is not null  then
              v_tmp := lpad(v_count+1, v_ws, '0');
            else
              v_tmp := v_count+1;
            end if;
           out_kch := v_kc || v_tmp;
           select count(kch) into v_flag from (select kch from jw_jh_kcdmb  union all select kch from jw_jh_kcdmbbb ) where kch = out_kch;
      end loop;
      end if;
  return out_kch;
end get_Kch;

/

