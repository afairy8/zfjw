create function get_jsxyzzytj_gxh(v_xnm varchar2,
                                         v_xqm varchar2,
                                         v_njdm_id varchar2,
                                         v_zryh_id varchar2,
                                         v_zyh_id varchar2,
                                         v_bh_id varchar2,
                                         v_xh_id varchar2,
                                         v_tjz varchar2,
                                         v_tjz1 varchar2,
                                         v_tjxh number)--个性化判断转专业条件函数
Return varchar2
as
     sZdkcxzBjgmc varchar2(2000);
     sFhjg varchar2(2000);
     sCount1  number;
begin
     case v_tjxh
          when 1000 then
               dbms_output.put_line('无');
          when 1001 then  ---修读原专业(类) 通识教学平台、学科教学平台的必修课程并取得相应学分，且平均学分绩点不低于___
          select Get_Tjjls_gxh(1001,v_xnm,v_xqm,v_xh_id,v_tjz,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||'存在部分课程，修读原专业(类) 通识教学平台、学科教学平台的必修课程未取得相应学分；不符合转专业条件。';
          end if;

          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := '修读原专业(类) 通识教学平台、学科教学平台的必修课程并取得相应学分，但平均学分绩点'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'低于要求平均学分绩点：'||v_tjz||'；不符合转专业条件。';
          end if;

          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '3' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||'存在部分课程，修读原专业(类) 通识教学平台、学科教学平台的必修课程未取得相应学分，且平均学分绩点'||fn_jqzd(sZdkcxzBjgmc,'|',3)||'低于要求平均学分绩点：'||v_tjz||'；不符合转专业条件。';
          end if;

          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '4' then
             sFhjg := '未修读原专业(类) 通识教学平台、学科教学平台的必修课程；不符合转专业条件。';
          end if;

          when 1002 then  ---修读原专业（类）通识教学平台的数学类必修课程，并取得相应学分
          select Get_Tjjls_gxh(1002,v_xnm,v_xqm,v_xh_id,v_tjz,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||',修读原专业（类）通识教学平台的数学类必修课程，并取得相应学分；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := '未修读原专业（类）通识教学平台的数学类必修课程；不符合转专业条件。';
          end if;

          when 1003 then  ---A 级起点课程成绩须达到______分，B 级起点学生成绩须达到______分
          select Get_Tjjls_gxh(1003,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||',A、B级起点课程成绩未达到要求；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := 'A、B级起点课程未修读未达到要求；不符合转专业条件。';
          end if;

     end case;
     return sFhjg;
end get_jsxyzzytj_gxh;
/

