create function f_fx_xy_xkml(
  i_njdm_id   varchar2,
  i_sq_zyh_id varchar2,
  i_xs_jg_id  varchar2,
  i_xs_zyh_id varchar2,
  i_bj        varchar2
)
  return varchar2
as
  v_sq_xkml  varchar2(10);
  v_xs_xkml  varchar2(10);
  v_sq_jg_id varchar2(10);
  v_bj       varchar2(1) default '0'; --默认学科门类相同
  begin
    select nvl(max(t2.mldm), 'w') into v_sq_xkml
    from jw_jh_dlzydzb t3,
         zftal_xtgl_xxzydmb t2
    where t3.njdm_id = t2.pcdm
      and t3.xxzydm = t2.zydm
      and t3.njdm_id = i_njdm_id
      and t3.zyh_id = i_sq_zyh_id;
    select nvl(max(t2.mldm), 'w') into v_xs_xkml
    from jw_jh_dlzydzb t3,
         zftal_xtgl_xxzydmb t2
    where t3.njdm_id = t2.pcdm
      and t3.xxzydm = t2.zydm
      and t3.njdm_id = i_njdm_id
      and t3.zyh_id = i_xs_zyh_id;
    select nvl(max(jg_id), 'w') into v_sq_jg_id from zftal_xtgl_zydmb where zyh_id = i_sq_zyh_id;
    if i_bj = 'fbxyfbml'
    then --非本学院非本学科门类,
      if v_sq_jg_id != nvl(i_xs_jg_id, 'w') and v_sq_xkml != v_xs_xkml
      then
        v_bj := '1';
      end if;
    end if;

    if i_bj = 'bxyfbml'
    then --本学院非本学科门类
      if v_sq_jg_id = nvl(i_xs_jg_id, 'w') and v_sq_xkml != v_xs_xkml
      then
        v_bj := '1';
      end if;
    end if;

    return v_bj;
end;

/

