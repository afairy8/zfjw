create Function Get_WeeksDesc(vWeeksBinary in integer) ---周二进制流对应十进制数
Return varchar2
as
begin
  if vWeeksBinary is null then
  return '0';
  else
  return Get_BinaryDesc(vWeeksBinary, '周'); ---生成周信息
  end if;
end;


/

