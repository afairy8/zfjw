create view VIEW_BZHB_BZKZY as
  select zyh zydm,zymc,'' zylb,xz,
       (select mc from zftal_xtgl_jcsjb where lx = '0027' and dm = t.xkmlm) xw,zyywmc,
       (select jgdm from zftal_xtgl_jgdmb where jg_id = t.jg_id) yx,'' ssxdm,'' ls,
       (select mc from zftal_xtgl_jcsjb where lx = '0014' and dm = t.ccdm) cc from zftal_xtgl_zydmb t
/

