create function fn_getKsjkjs
(vXnm in varchar2,
 vXqm in varchar2,
 vSjbh_id in varchar2,
 vCd_id in varchar2,
 vKsdd_id in varchar2,
 vKshkbj_id in varchar2,
 iDj in number,
 vBj in varchar2)-----获取考试监考教师
return varchar2 is
 jkjs varchar2(4000);
begin
  begin
  if vBj = 'jgh' then
    select wm_concat(jkjs) into jkjs from
    (select js.jgh as jkjs from jw_kw_ksddb ksdd,jw_kw_ksddjkb ksddjk,jw_kw_jkjsxxb js
                          where ksdd.ksdd_id = ksddjk.ksdd_id
                            and ksddjk.jgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and js.xnm = vXnm
                            and js.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)
                            order by  ksddjk.jklx
      );
      if iDj is null then
      jkjs := fn_jqzd(jkjs,',',iDj);
      else
       jkjs := jkjs;
      end if;
      return jkjs;
  end if;

  if vBj = 'jsxm' then
    select wm_concat(jkjs) into jkjs from
    (select js.xm as jkjs from jw_kw_ksddb ksdd,jw_kw_ksddjkb ksddjk,jw_kw_jkjsxxb js
                          where ksdd.ksdd_id = ksddjk.ksdd_id
                            and ksddjk.jgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and js.xnm = vXnm
                            and js.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)
                            order by  ksddjk.jklx
      );
      if iDj is null then
      jkjs := fn_jqzd(jkjs,',',iDj);
      else
       jkjs := jkjs;
      end if;
      return jkjs;
  end if;

  if vBj = 'zxkjgh' then
    select wm_concat(jkjs) into jkjs from
    (select js.jgh as jkjs from jw_kw_ksddb ksdd,jw_jg_jzgxxb js
                          where ksdd.zxkjgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and ksdd.xnm = vXnm
                            and ksdd.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)

      );
      jkjs := jkjs;
      return jkjs;
  end if;

  if vBj = 'zxkjsxm' then
    select wm_concat(jkjs) into jkjs from
    (select js.xm as jkjs from jw_kw_ksddb ksdd,jw_jg_jzgxxb js
                          where ksdd.zxkjgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and ksdd.xnm = vXnm
                            and ksdd.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)

      );
      jkjs := jkjs;
      return jkjs;
  end if;

  if vBj = 'fxkjgh' then
    select wm_concat(jkjs) into jkjs from
    (select js.jgh as jkjs from jw_kw_ksddb ksdd,jw_jg_jzgxxb js
                          where ksdd.fxkjgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and ksdd.xnm = vXnm
                            and ksdd.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)

      );
      jkjs := jkjs;
      return jkjs;
  end if;

  if vBj = 'fxkjsxm' then
    select wm_concat(jkjs) into jkjs from
    (select js.xm as jkjs from jw_kw_ksddb ksdd,jw_jg_jzgxxb js
                          where ksdd.fxkjgh_id = js.jgh_id
                            and ksdd.cd_id = vCd_id
                            and ksdd.xnm = vXnm
                            and ksdd.xqm = vXqm
                            and exists(select 'X' from jw_kw_ksddbjdzb dzb where dzb.kshkbj_id = ksdd.kshkbj_id
                            and dzb.sjbh_id = vSjbh_id
                            and dzb.xnm = vXnm
                            and dzb.xqm = vXqm)

      );
      jkjs := jkjs;
      return jkjs;
  end if;

  exception
    When others then
      return null;
  end;
end fn_getKsjkjs;

/

