create function fun_by_zkcjxfsh(v_xh_id varchar2,v_tjsjz varchar2, v_tjkcxz varchar2,
       v_btjkc varchar2,v_xdlx varchar2) return varchar2
as
   sJg varchar2(2000);-----正考成绩不合格学分>=35不授学位--四川传媒
   sqlstr varchar2(4000);
   v_xdlx_temp varchar2(5000);
   v_xf number;---数量
begin
    sJg := '合格';
    begin

          sqlstr :='select sum(t.xf) from jw_cj_xscjb t
          where  t.bfzcj<60 and t.cjxzm=''01''  and t.xh_id='''||v_xh_id||'''';

      --课程性质
      if v_tjkcxz is not null and v_tjkcxz!='qb' then
         sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||t.kcxzdm||'','' )>0 ';
      end if;

      --修读类型
      if v_xdlx is not null and v_xdlx!='qb' then
        v_xdlx_temp:= ' AND EXISTS (select 1 from (SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxb xfyq,JW_JH_xsJXZXJHKCXXB kcxx'||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id union all '||
                      ' SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxfxezyb xfyq,Jw_Jh_Xsjxzxjhkcxxfxezyb kcxx '||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id) a '||
                      ' WHERE a.XH_ID=t.XH_ID  AND a.KCH_ID=nvl(t.sskch_id,t.KCH_ID) AND ('||

                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 ))';
          sqlstr:= sqlstr||v_xdlx_temp;

       end if;

       --不统计课程
       if v_btjkc is not null then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||t.kch_id||'','' )<1 ';
       end if;

       execute immediate sqlstr into v_xf;

         if to_number(v_xf) >=to_number(v_tjsjz) then
            sJg:= '正考成绩不通过学分为'||v_xf||',超过'||v_tjsjz||',不合格！';
         else
            sJg:= '正考成绩不通过学分为'||v_xf||',合格！';
         end if;
       exception
      When others then
        sJg := '查询出错，不合格！';
  end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_zkcjxfsh;

/

