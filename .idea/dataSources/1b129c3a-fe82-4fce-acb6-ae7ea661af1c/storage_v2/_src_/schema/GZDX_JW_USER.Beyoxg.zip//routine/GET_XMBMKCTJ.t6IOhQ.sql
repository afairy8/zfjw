create function get_xmbmkctj(vTj        varchar2,
                                        vXmbmsz_id varchar2,
                                        vXqh_id    varchar2,
                                        vJg_id     varchar2,
                                        vZyh_id    varchar2,
                                        vZyfx_id   varchar2,
                                        vNjdm_id   varchar2,
                                        vBh_id     varchar2,
                                        vXbm       varchar2,
                                        vXslbm     varchar2,
                                        vCcdm      varchar2,
                                        vXsbj      varchar2,
                                        vXh_id     varchar2) ---项目报名条件
 Return varchar2 as
  sSql      varchar2(2000);
  sxnxqtj   varchar2(50);
  sxnxqgx   varchar2(8);
  sxn       varchar2(10);
  sxq       varchar2(10);
  sxmtj     varchar2(500);
  scjtj     varchar2(50);
  scjsxtj   varchar2(50);
  sgx       varchar2(6);
  sdx       varchar2(32);
  tj        number;
  dx        number;
  icount    number;
  imx       number;
  ixz       number;
  icount_mx number;
  icount_xz number;
  jgtj      number;
begin
  tj   := 0;
  dx   := 0;
  jgtj := 0;
  select count(*)
    into icount
    from jw_xmgl_xmbmtjb
   where xmbmsz_id = vXmbmsz_id
     and tj_id = vTj;
  if icount > 0 then
    select xnxqtj, xmtj, cjtj,cjsxtj, gx, dx
      into sxnxqtj, sxmtj, scjtj,scjsxtj, sgx, sdx
      from jw_xmgl_xmbmtjb
     where xmbmsz_id = vXmbmsz_id
       and tj_id = vTj;
    if sxmtj is null then
      tj := 1;
    else
      if scjtj is null and scjsxtj is null then
        tj:=0;
      else
         sSql := 'select count(*) from (select max(t1.bfzcj) over(partition by t1.kch_id) as bfzcj1, t1.*  from jw_cj_xscjb t1 where t1.xh_id =''' || vXh_id || ''' and  ''' || sXmtj || ''' like ''%''||kch_id||''%''';

         if sxnxqtj is not null then
          sxnxqgx := fn_jqzd(sxnxqtj, '|', 3);
          sxn     := fn_jqzd(sxnxqtj, '|', 1);
          sxq     := fn_jqzd(sxnxqtj, '|', 2);
          sSql    := sSql||'and t1.xnm||lpad(t1.xqm,2,0) ' || sxnxqgx || '''' || sxn || '''||lpad(' || sxq || ',2,0)';
        end if;
          sSql    := sSql||' ) where 1=1 ';
        if scjtj is not null then
           sSql:= sSql||' and to_number(bfzcj1) >= to_number(' || scjtj || ')';
         end if;
         if scjsxtj is not null then
           sSql:= sSql||' and to_number(bfzcj1) <= to_number(' || scjsxtj || ')';
         end if;

        Execute Immediate sSql  into icount;
        if icount > 0 then
          tj := 1;
        end if;
       end if;
    end if;

    if sdx is null then
      dx := 1;
    else
      select count(*),nvl(max(decode(xzlb,'mx',1)),0) ,nvl(max(decode(xzlb,'xz',1)),0) into icount,imx,ixz
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ;
      if icount > 0 then
      select count(*)
        into icount_mx
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ
         and xzlb = 'mx'
         and nvl(xqh_id, vXqh_id) = vXqh_id
         and nvl(jg_id, vJg_id) = vJg_id
         and nvl(njdm_id, vnjdm_id) = vnjdm_id
         and nvl(zyh_id, vzyh_id) = vzyh_id
         and nvl(zyfx_id, vzyfx_id) = vzyfx_id
         and nvl(bh_id, vbh_id) = vbh_id
         and nvl(xbm, vXbm) = vXbm
         and nvl(xslbm, vXslbm) = vXslbm
         and nvl(ccdm, vCcdm) = vCcdm
         and bitand(nvl(xsbj, vXsbj), vXsbj) > 0
         and nvl(xh_id, vxh_id) = vxh_id;

      select count(*)
        into icount_xz
        from JW_XMGL_XMBMTJMXDXB
       where xmbmsz_id = vXmbmsz_id
         and tj_id = vTJ
         and xzlb = 'xz'
         and nvl(xqh_id, vXqh_id) = vXqh_id
         and nvl(jg_id, vJg_id) = vJg_id
         and nvl(njdm_id, vnjdm_id) = vnjdm_id
         and nvl(zyh_id, vzyh_id) = vzyh_id
         and nvl(zyfx_id, vzyfx_id) = vzyfx_id
         and nvl(bh_id, vbh_id) = vbh_id
         and nvl(xbm, vXbm) = vXbm
         and nvl(xslbm, vXslbm) = vXslbm
         and nvl(ccdm, vCcdm) = vCcdm
         and bitand(nvl(xsbj, vXsbj), vXsbj) > 0
         and nvl(xh_id, vxh_id) = vxh_id;
      if (imx >0 and icount_mx <= 0) or (ixz > 0 and icount_xz > 0 ) then
        dx := 0;
        else
        dx := 1;
      end if;
      end if;
    end if;

    if sgx = 'or' then
      jgtj := bitor(tj, dx);
    else
      jgtj := bitand(tj, dx);
    end if;
    Return to_char(jgtj);
  else
    Return '1';
  end if;
  <<Next_Null>>
  NULL;
end;

/

