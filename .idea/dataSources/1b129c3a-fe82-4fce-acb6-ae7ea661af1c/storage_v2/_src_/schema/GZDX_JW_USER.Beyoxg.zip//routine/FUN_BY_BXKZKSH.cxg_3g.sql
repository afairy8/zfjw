create function fun_by_bxkzksh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_flag int;
begin
    sJg := '合格';
    begin
        select sum(xf) into v_flag from (
            select cj.*, row_number() over(partition by cj.xh_id, cj.kch_id order by cj.BFZCJ desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id = v_xh_id and cj.cjxzm='01'
            and exists(select 1 from jw_jh_kcxzdmb kcxz where kcxz.kcxzdm =cj.kcxzdm and kcxz.xbx='bx' )
            )where rn=1
            and bfzcj<60 ;

         if v_flag>v_tjsjz then
            sJg:= '必修课正考累计不及格分数'||v_flag||'>'||v_tjsjz||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_bxkzksh;

/

