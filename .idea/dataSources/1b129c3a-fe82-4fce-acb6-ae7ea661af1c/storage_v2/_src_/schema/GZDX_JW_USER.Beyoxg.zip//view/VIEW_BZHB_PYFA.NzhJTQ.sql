create view VIEW_BZHB_PYFA as
  select
     (select njdm from zftal_xtgl_njdmb where njdm_id =t1.njdm_id)||(select zyh from zftal_xtgl_zydmb where zyh_id = t1.zyh_id) jxjhh,
     (select zyh from zftal_xtgl_zydmb where zyh_id =t1.zyh_id) zydm,
     (select zymc from zftal_xtgl_zydmb where zyh_id = t1.zyh_id) zymc,
     t4.kch kcdm,
     t4.kcmc,
     t4.xf,
     t4.zxs zhxs,
     (select kcxzmc from jw_jh_kcxzdmb where kcxzdm = t3.kcxzdm) kcxz,
     (select xnmc from jw_jcdm_xnb where xnm = t3.jyxdxnm) xn,
     (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = t3.jyxdxqm) xq,
     '' jyxdxq,
     (select zyfxmc from zftal_xtgl_zyfxdmb where zyfx_id = t2.zyfx_id) zyfx
 from jw_jh_jxzxjhxxb t1,jw_jh_jxzxjhxfyqxxb t2,jw_jh_jxzxjhkcxxb t3,jw_jh_kcdmb t4 where
t1.jxzxjhxx_id = t2.jxzxjhxx_id and t2.xfyqjd_id = t3.xfyqjd_id and t3.kch_id = t4.kch_id
/

