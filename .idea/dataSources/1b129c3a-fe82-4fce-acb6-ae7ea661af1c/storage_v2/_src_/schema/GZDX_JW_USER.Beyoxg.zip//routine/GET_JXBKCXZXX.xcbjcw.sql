create function Get_JxbKcxzxx(vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班课程性质信息----
as
   sKcxzxx varchar2(500);   ---课程性质信息
begin
    sKcxzxx := '无';
    begin
       if vBj = '0' then
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select nvl(wm_concat(kcxzmc),'无') into sKcxzxx from (
         select distinct b.kcxzmc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm = b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
       end if ;
     if vBj = '1' then
       select nvl(wm_concat(kcxzjc),'无') into sKcxzxx from (
         select distinct b.kcxzmc kcxzjc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm = b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
    end if ;

    if vBj = '2' then
       select nvl(wm_concat(kcxzdm),'无') into sKcxzxx from (
         select distinct b.kcxzjc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm = b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
    end if ;

     exception
        When others then
          sKcxzxx := '无';
    end;
    return sKcxzxx ;
end Get_JxbKcxzxx;
/

