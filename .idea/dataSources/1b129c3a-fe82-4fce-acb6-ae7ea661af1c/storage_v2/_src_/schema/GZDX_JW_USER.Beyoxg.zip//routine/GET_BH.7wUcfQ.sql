create function get_Bh(v_njdm_id varchar2, v_zyh_id varchar2)
 Return varchar2 as
  cursor c_gzxxs is
    select tjszzd, qsw, xxz, wsbl, ppbmzd from jw_xsgl_tjgzpzxxb
	where pzgz_id = nvl(
		 (select pz.pzgz_id from jw_xsgl_fbbxhgzpzb pz where pz.gzdm = 'BBGZ' and jg_id = (select zy.jg_id from zftal_xtgl_zydmb zy where zy.zyh_id = v_zyh_id) and pz.qyzt='1'),
		 (select pz.pzgz_id from jw_xsgl_fbbxhgzpzb pz where pz.gzdm = 'BBGZ' and jg_id is null and pz.qyzt='1')
		 )
	and tjgz_id='BJDMGZ'
	order by sx asc;
  c_gzxx     c_gzxxs%rowtype;
  out_bh    varchar2(4000);
  v_tmp      varchar2(4000);
  v_lsh      varchar2(4000);
  v_count    number;
  v_flag    number;--是否存在班号
begin
  out_bh    := '';
  v_flag     :=0;
  for c_gzxx in c_gzxxs loop
    v_tmp := '';
    if c_gzxx.tjszzd = 'CL' then
        v_tmp := c_gzxx.xxz;
        out_bh := out_bh || v_tmp;
   elsif c_gzxx.tjszzd = 'LSH' then
		select count(bh) into v_count from zftal_xtgl_bjdmb where njdm_id = v_njdm_id and zyh_id = v_zyh_id;
        if c_gzxx.wsbl = '1' and c_gzxx.xxz is not null then
			if length(v_count)-to_number(c_gzxx.xxz)<0 then
				v_tmp:= lpad(v_count+1,c_gzxx.xxz,'0');
			else
				v_tmp:= lpad(v_count+1,length(v_count),'0');
			end if;
        else
            v_tmp:= to_char(v_count+1);
        end if;
		v_lsh := v_tmp;
		out_bh := out_bh || v_tmp;
	 elsif c_gzxx.tjszzd = 'XQH' then
		select xqh into v_tmp from zftal_xtgl_xqdmb where xqh_id = (select xqh_id from jw_xjgl_njzyzsjhb where njdm_id = v_njdm_id and zyh_id = v_zyh_id);
		if c_gzxx.xxz is null then
			if c_gzxx.qsw is null then
				v_tmp := v_tmp;
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw);
			end if;
		else
			if c_gzxx.qsw is null then
				v_tmp := substr(v_tmp,-c_gzxx.xxz);
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw,c_gzxx.xxz);
			end if;
		end if;
		out_bh := out_bh || v_tmp;
	elsif c_gzxx.tjszzd = 'JGDM' then
		select jgdm into v_tmp from zftal_xtgl_jgdmb where jg_id = (select jg_id from jw_xjgl_njzyzsjhb where njdm_id = v_njdm_id and zyh_id = v_zyh_id);
		if c_gzxx.xxz is null then
			if c_gzxx.qsw is null then
				v_tmp := v_tmp;
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw);
			end if;
		else
			if c_gzxx.qsw is null then
				v_tmp := substr(v_tmp,-c_gzxx.xxz);
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw,c_gzxx.xxz);
			end if;
		end if;
		out_bh := out_bh || v_tmp;
	elsif c_gzxx.tjszzd = 'NJMC' then
		select njdm into v_tmp from zftal_xtgl_njdmb where njdm_id = v_njdm_id;
		if c_gzxx.xxz is null then
			if c_gzxx.qsw is null then
				v_tmp := v_tmp;
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw);
			end if;
		else
			if c_gzxx.qsw is null then
				v_tmp := substr(v_tmp,-c_gzxx.xxz);
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw,c_gzxx.xxz);
			end if;
		end if;
		out_bh := out_bh || v_tmp;
	elsif c_gzxx.tjszzd = 'ZYH' then
		select zyh into v_tmp from zftal_xtgl_zydmb where zyh_id = v_zyh_id;
		if c_gzxx.xxz is null then
			if c_gzxx.qsw is null then
				v_tmp := v_tmp;
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw);
			end if;
		else
			if c_gzxx.qsw is null then
				v_tmp := substr(v_tmp,-c_gzxx.xxz);
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw,c_gzxx.xxz);
			end if;
		end if;
		out_bh := out_bh || v_tmp;
	elsif c_gzxx.tjszzd = 'CCDM' then
		select max(decode(ccdm,ccdm,ccdm)) into v_tmp from zftal_xtgl_zydmb where zyh_id = v_zyh_id;
		if c_gzxx.xxz is null then
			if c_gzxx.qsw is null then
				v_tmp := v_tmp;
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw);
			end if;
		else
			if c_gzxx.qsw is null then
				v_tmp := substr(v_tmp,-c_gzxx.xxz);
			else
				v_tmp := substr(v_tmp,c_gzxx.qsw,c_gzxx.xxz);
			end if;
		end if;
		out_bh := out_bh || v_tmp;
	end if;

  end loop;
  ----判断流水号为空，返回1
  if v_lsh is null then
	out_bh := '1';
  else
	----按规则生成班号是否失败，返回0
	if out_bh is null then
		out_bh := '0';
	else
		---发现已经存在的班号，返回-1
		select count(bh) into v_flag from zftal_xtgl_bjdmb where bh = out_bh;
		if v_flag>0 then
			out_bh := '-1';
		end if;
	end if;
  end if;

  return out_bh;
end get_Bh;

/

