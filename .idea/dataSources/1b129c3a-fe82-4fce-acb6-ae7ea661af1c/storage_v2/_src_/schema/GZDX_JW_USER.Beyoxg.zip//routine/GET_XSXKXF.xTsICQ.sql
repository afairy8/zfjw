create function Get_Xsxkxf
(vXnm varchar2,
 vXqm varchar2,
 vXh_id varchar2,
 vBj  varchar2) return varchar2----0：总学分；1：正修学分；2：重修学分；3：辅修学分 ;jhxf:计划学分（如果学分为空或0时直接取课程学分）
as
 sXf varchar2(8); ---学分
 sBj varchar2(100);
 sNjdm_id varchar2(50);
 sZyh_id varchar2(50);
 sKch_id varchar2(100);
 sSfzjxb varchar2(50);
 sZyfx_id varchar2(50);
 sJxb_id varchar2(50);
begin
     sXf:='0';
     sBj := fn_jqzd(vBj,'|',1);
     if sBj = '0' then---总学分

        select to_char(nvl(sum(kc.xf),'0')) into sXf from jw_xk_xsxkb xk, jw_jxrw_jxbxxb jxb, jw_jh_kcdmb kc
        where xk.jxb_id = jxb.jxb_id and jxb.kch_id = kc.kch_id and jxb.fjxb_id is null
          and xk.xnm = vXnm and xk.xqm = vXqm and xk.xh_id = vXh_id;

     end if;

     if sBj = '1' then---正修学分

        select to_char(nvl(sum(kc.xf),'0')) into sXf from jw_xk_xsxkb xk, jw_jxrw_jxbxxb jxb, jw_jh_kcdmb kc
        where xk.jxb_id = jxb.jxb_id and jxb.kch_id = kc.kch_id and jxb.fjxb_id is null
          and xk.xnm = vXnm and xk.xqm = vXqm and xk.xh_id = vXh_id
          and nvl(xk.cxbj,'0') != '1' and nvl(xk.fxbj,'0') != '1';

     end if;

     if sBj = '2' then---重修学分

        select to_char(nvl(sum(kc.xf),'0')) into sXf from jw_xk_xsxkb xk, jw_jxrw_jxbxxb jxb, jw_jh_kcdmb kc
        where xk.jxb_id = jxb.jxb_id and jxb.kch_id = kc.kch_id and jxb.fjxb_id is null
          and xk.xnm = vXnm and xk.xqm = vXqm and xk.xh_id = vXh_id
          and xk.cxbj = '1';

     end if;

     if sBj = '3' then---辅修学分

        select to_char(nvl(sum(kc.xf),'0')) into sXf from jw_xk_xsxkb xk, jw_jxrw_jxbxxb jxb, jw_jh_kcdmb kc
        where xk.jxb_id = jxb.jxb_id and jxb.kch_id = kc.kch_id and jxb.fjxb_id is null
          and xk.xnm = vXnm and xk.xqm = vXqm and xk.xh_id = vXh_id
          and xk.fxbj = '1';

     end if;

     if sBj = 'jhxf' then---计划学分（如果学分为空或0时直接取课程学分）
        sNjdm_id := fn_jqzd(vBj,'|',2);
        sZyh_id := fn_jqzd(vBj,'|',3);
        --sZyfx_id := fn_jqzd(vBj,'|',4);
        sKch_id := fn_jqzd(vBj,'|',5);
        --sJxb_id := fn_jqzd(vBj,'|',6);
        sSfzjxb := fn_jqzd(vBj,'|',7);
        if sSfzjxb = 1 then
        select max(nvl(jh.xf,'0')) into sXf from
        jw_jh_jxzxjhkcxxb jh
        where jh.kch_id = sKch_id
          and jh.njdm_id = sNjdm_id
          and jh.zyh_id = sZyh_id
          and rownum = 1;

          if sXf = '0' then
            select max(nvl(kc.xf,'0')) into sXf from jw_jh_kcdmb kc where kc.kch_id = sKch_id;
          end if;

       else
         sXf:='0';
       end if;

     end if;

     if sXf is null then
        sXf:='0';
     end if;

  return sXf;
end Get_Xsxkxf;

/

