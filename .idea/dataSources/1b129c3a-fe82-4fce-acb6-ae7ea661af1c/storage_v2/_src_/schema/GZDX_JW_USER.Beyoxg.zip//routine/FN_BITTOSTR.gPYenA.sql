create function fn_bittostr(
  iZcd in number
) return varchar2 as
qfhcs varchar2(50);
begin
   qfhcs := '';
   for i in 1..25 loop
      if bitand(iZcd,power(2,i-1)) >0 then
         qfhcs := qfhcs||'1';
      else
         qfhcs := qfhcs||'0';
      end if;
   end loop;
   return qfhcs;
end fn_bittostr;
/

