create function fn_sjkcxx(vSjbh_id varchar2,vXnm varchar2,vXqm varchar2) return varchar2  ---人机监考课程信息显示----
as
   sKcxx varchar2(2000);   ---人机监考课程信息显示
begin
    sKcxx := '';
    begin
    select wm_concat(kcxx) into sKcxx from (
      select distinct t4.kch||'/'||t4.kcmc kcxx
      from jw_kw_ksmcjxbdzb t1,jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
      where t1.sjbh_id = vSjbh_id and t1.xnm = vXnm and t1.xqm = vXqm
      and t1.jxb_id = t3.jxb_id and t3.kch_id = t4.kch_id
      and t4.kch is not null);
     exception
        When others then
          sKcxx := '无';
    end;
    return sKcxx ;
end fn_sjkcxx;

/

