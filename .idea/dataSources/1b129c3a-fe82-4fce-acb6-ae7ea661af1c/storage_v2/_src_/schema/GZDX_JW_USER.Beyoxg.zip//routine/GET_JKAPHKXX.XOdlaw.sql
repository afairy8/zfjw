create function Get_JkapHkxx(vKsdd_id in varchar2, vApfs in varchar2) return varchar2  -----监考安排合考信息-----
as
  v_hkxx varchar2(2000);   ---合考信息
begin
  begin
  v_hkxx := '';
  if vApfs = '0' then
      select nvl((
            select wm_concat(t5.sjbh) from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_kssjb t5
             where t2.kshkbj_id = t1.kshkbj_id
               and t1.ksdd_id=Vksdd_id
               and t2.apfs = '0'
               and t1.xnm = t2.xnm
               and t1.xqm = t2.xqm
               and t5.xnm = t2.xnm
               and t5.xqm = t2.xqm
               and t2.sjbh_id = t5.sjbh_id
               and rownum = 1
     ),'') kszc into v_hkxx
		 from jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
	   where t3.kch_id = t4.kch_id
		 and rownum = 1
     and t3.jxb_id in(
        select t2.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '2'
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '0'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
          select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
		 )
		 order by t3.jxbmc;
  end if;
  if vApfs = '1' then
      select nvl((
            select wm_concat(t5.bj) from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,zftal_xtgl_bjdmb t5
			      where t2.kshkbj_id = t1.kshkbj_id
			       and t1.ksdd_id = vKsdd_id
					   and t2.apfs = '1'
					   and t1.xnm = t2.xnm
					   and t1.xqm = t2.xqm
					   and t2.bh_id = t5.bh_id(+)
     ),'') kszc into v_hkxx
		 from jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
	   where t3.kch_id = t4.kch_id
     and rownum = 1
		 and t3.jxb_id in(
        select t2.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '2'
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '0'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
          select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
		 )
		 order by t3.jxbmc;
  end if;
  if vApfs = '2' then
      select nvl(wm_concat(t3.jxbmc),'') kszc into v_hkxx
		    from jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
	     where t3.kch_id = t4.kch_id
		     and t3.jxb_id in(
        select t2.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '2'
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '0'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
          select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
		 )
		 order by t3.jxbmc;
  end if;
  if vApfs = '3' then
      select nvl((
             select wm_concat(t5.jgmc) from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,zftal_xtgl_jgdmb t5
               where t2.kshkbj_id = t1.kshkbj_id
                 and t1.ksdd_id=Vksdd_id
                 and t2.apfs = '3'
                 and t1.xnm = t2.xnm
                 and t1.xqm = t2.xqm
                 and t2.jg_id = t5.jg_id
      ),'') kszc into v_hkxx
		 from jw_jxrw_jxbxxb t3,jw_jh_kcdmb t4
	   where t3.kch_id = t4.kch_id
     and rownum = 1
		 and t3.jxb_id in(
        select t2.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '2'
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '0'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
          select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '1'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.bh_id=t2.bh_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_xk_xsxkb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
        union all
        select t3.jxb_id
            from jw_kw_ksddb t1,jw_kw_ksddbjdzb t2,jw_kw_ksmcjxbdzb t3
           where t2.kshkbj_id = t1.kshkbj_id
             and t1.ksdd_id=Vksdd_id
             and t2.apfs = '3'
             and t2.sjbh_id = t3.sjbh_id
             and t1.xnm = t2.xnm
             and t1.xqm = t2.xqm
             and t1.xnm = t3.xnm
             and t1.xqm = t3.xqm
             and exists(
                 select 'X' from jw_kw_bkmdb t4,jw_xjgl_xsjbxxb t5
                 where t3.jxb_id=t4.jxb_id
                   and t4.xh_id=t5.xh_id
                   and t5.jg_id=t2.jg_id
             )
		 )
		 order by t3.jxbmc;
  end if;
  end;
      return v_hkxx;
end Get_JkapHkxx;

/

