create view KCXSZH as
  (select kch_id,sum(zxs)zxs from jw_jh_kcxsdzb group by kch_id)
/

