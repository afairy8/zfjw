create function Get_Zyctzt--专业冲突状态
(vXnm varchar2,
 vXqm varchar2,
 vXh_id varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vBj  varchar2) return varchar2
as
 sCtzt varchar2(8); ---冲突状态
 sCount number;---冲突数
begin
     sCtzt:='否';
     select count(*) into sCount
       from jw_xjgl_xszzysqb
      where xnm = vXnm
        and xqm = vXqm
        and xh_id = vXh_id
        and shzt != '5'
        and zyh_sqzr_id in
            (select zyh_id
               from jw_xjgl_jszyctzyxxb
              where zyh_id != vZyh_id
                and njdm_id = vNjdm_id
                and ctzyxx_id in
                    (select ctzyxx_id
                       from jw_xjgl_jszyctzyxxb
                      where zyh_id = vZyh_id
                        and njdm_id = vNjdm_id));

     if vBj='0' then--返回中文：是、否
        if sCount>0 then
           sCtzt:='是';
        else
           sCtzt:='否';
        end if;
     end if;

     if vBj='1' then--返回数字
        select to_char(sCount) into sCtzt from dual;
     end if;

  return sCtzt;
end Get_Zyctzt;

/

