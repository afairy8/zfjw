create function fn_cjsftj(cj in varchar2)
    ----华中师范-----要求成绩为:合格或者通过的,在统计全部课程平均学分绩的时候不统计,
    ----返回值:0-成绩不统计,1-成绩统计
     return varchar2 as
     result_flag varchar2(1);
    begin
       result_flag := '1';
       if trim(cj)='合格' or trim(cj)='通过' or cj is null then
          result_flag := '0';
       end if;
       return result_flag ;
    end fn_cjsftj;


/

