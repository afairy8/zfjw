create procedure p_cx_check_cxxk
(
    in_xh_id in varchar2,
    in_jxb_id in varchar2,
    in_xqh_id in varchar2,
    in_yxzx in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
) as
    v_kbzdmc varchar2(4);
    v_count number;
    v_kch_id varchar2(32);
    v_xkxnm varchar2(5);
    v_xkxqm varchar2(2);
    v_jfsj varchar2(4);
    v_jfzt varchar2(4);
    v_cxbmkcrxkg varchar2(2);
    v_kbzgxf varchar2(4);--可报最高学分
    v_zxfs varchar2(10);--当前所选课程总学分
    v_xf varchar2(10);
    jxb_id_array mytype;--jxb_id （主教学班判断时 jxb_id 只有一个 如果是子教学班的话 可能会有多个）
    v_cxbmbyskz varchar2(2);

begin
    jxb_id_array := my_split(in_jxb_id,',');-- 初始化
    out_flag := 1;
    v_cxbmbyskz := '0';
    select count(1) into v_count from jw_jcdml_xtnzb where zdm = 'CXBMBYSKZ';
    if v_count >0  then
        select zdz into v_cxbmbyskz from jw_jcdml_xtnzb where zdm = 'CXBMBYSKZ';
    end if;
    select xnm,xqm into v_xkxnm,v_xkxqm from jw_cj_cxbmszb where zt = '1';
    --select count(*) into v_count from jw_xmgl_jxxmbmszb t where t.jxxmlbdm='1008' and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between t.kssj and t.jssj;
    select count(*) into v_count from jw_cj_cxbmszb t where xnm=v_xkxnm and xqm=v_xkxqm and sysdate between t.kssj and t.jssj;
    if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，当前时间不可报名，如有需要，请与管理员联系！';
        goto nextOne;
    end if;

    select count(*) into v_cxbmkcrxkg from jw_jcdml_xtnzb where zdm='CXBMKCRXKG' and zdz='1';
    if v_cxbmkcrxkg>0 then ---一门课程至少同时存在跟班重修、单开班重修、重修报名三个页签下中的两个时，可任选其中一个页签里的教学班或报名课程
      select kch_id into v_kch_id from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(1);
      select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and kch_id=v_kch_id and xh_id=in_xh_id;
      if v_count>0 then
        out_flag := -1;
            out_msg := '对不起，您已选过该课程的教学班，不可再选！';
            goto nextOne;
      end if;
	  select count(*) into v_count from jw_cj_cxbmb where xnm=v_xkxnm and xqm=v_xkxqm and kch_id=v_kch_id and xh_id=in_xh_id;
	  if v_count>0 then
        out_flag := -1;
            out_msg := '对不起，您已报名重修课程，不可再选教学班！';
            goto nextOne;
      end if;
    end if;

    select count(1) into v_count from jw_bygl_bysfzxxb where xh_id = in_xh_id;
    if v_count >0 and v_cxbmbyskz = '1' then
        out_flag := -1;
        out_msg := '毕业生请在重修报名页签下选择!';
        goto nextOne;
    end if;

    select kbzdmc,kbzgxf into v_kbzdmc,v_kbzgxf from jw_cj_cxbmszb t where xnm=v_xkxnm and xqm=v_xkxqm and sysdate between t.kssj and t.jssj;
    if v_kbzdmc is not null then
		select count(*) into v_count from jw_jcdml_xtnzb where zdm='CXBMZGMCXZFW' and zdz='0'; --最高门次限制的统计范围开关(默认三类全统计)
		if v_count=1 then --只统计跟班重修和单开班重修的选课总门次
			select count(distinct kch_id) into v_count from jw_xk_xsxkb where cxbj='1' and xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
		else --统计跟班重修、单开班重修和重修课程报名的课程总门次
			select count (distinct kch_id) into v_count from (
				select kch_id from jw_xk_xsxkb where cxbj='1' and xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
				union all
				select kch_id from jw_cj_cxbmb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
			);
		end if;
        if v_count>=to_number(v_kbzdmc) then
            out_flag := -1;
            out_msg := '对不起，最大报名门次为'||v_kbzdmc||'！';
            goto nextOne;
        end if;
    end if;

    if v_kbzgxf is not null then
		select count(*) into v_count from jw_jcdml_xtnzb where zdm='CXBMZGXFXZFW' and zdz='1'; --最高分数限制的统计范围开关(默认统计重修选课)
		select distinct t1.xf into v_xf from jw_jxrw_jxbxxb t, jw_jh_kcdmb t1 where t.kch_id = t1.kch_id and ','||in_jxb_id||',' like '%,' || jxb_id || ',%';
		if v_count=0 then --只统计跟班重修和单开班重修的选课总学分
			/*select
				to_char(sum(nvl(c.xf, 0)), 'FM9990.0') zxfs into v_zxfs
			from
				jw_jh_kcdmb c, jw_jxrw_jxbxxb a, jw_xk_xsxkb b
			where
				a.jxb_id = b.jxb_id and a.kch_id = c.kch_id and a.sfzjxb = '1' and b.cxbj = '1'
				and a.xnm = v_xkxnm and a.xqm = v_xkxqm and b.xh_id = in_xh_id and b.xnm = v_xkxnm and b.xqm = v_xkxqm;*/
			select
				to_char(sum(nvl(t1.xf, 0)), 'FM9990.0') zxfs into v_zxfs
			from jw_jh_kcdmb t1
			where exists(
				select 1 from jw_xk_xsxkb t2 where t1.kch_id=t2.kch_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.xh_id=in_xh_id and t2.cxbj='1'
			);
		else --统计跟班重修、单开班重修和重修课程报名的课程总学分
			select
				to_char(sum(nvl(xf,0)), 'FM9990.0') into v_zxfs
			from
				jw_jh_kcdmb t1
			where exists(
				select 1 from (
					select kch_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and cxbj='1'
					union all
					select kch_id from jw_cj_cxbmb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
				) t2 where t1.kch_id=t2.kch_id
			);

		end if;
        if nvl(v_zxfs,0)*1+nvl(v_xf,0)*1 > v_kbzgxf*1 then
            out_flag := -1;
            out_msg := '对不起，最高可报学分为'||v_kbzgxf||'，选课后总学分为'||(nvl(v_zxfs,0)*1+nvl(v_xf,0)*1)||'，已超过最高学分！';
            goto nextOne;
        end if;
    end if;

    FOR i IN 1..jxb_id_array.count LOOP --添加循环jxb_id  in_jxb_id修改为 jxb_id_array(i)
        select kch_id into v_kch_id from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(i);

		select jfsj into v_jfsj from jw_cj_cxbmszb t where xnm=v_xkxnm and xqm=v_xkxqm and sysdate between t.kssj and t.jssj;
		if v_jfsj = '1' then   --选课前缴费
			select count(1) into v_count from jw_cj_cxbmb where xnm = v_xkxnm and xqm = v_xkxqm and xh_id =in_xh_id and kch_id=v_kch_id ;
			if v_count>0 then
				select nvl(jfzt,'0') into v_jfzt from jw_cj_cxbmb where xnm = v_xkxnm and xqm = v_xkxqm and xh_id =in_xh_id and kch_id=v_kch_id ;
				if v_jfzt != '1' then  --查询缴费状态为未交费
					out_flag := 3;  --注意 flag 不能设置为2 因为在外面业务中2已经被占用
					out_msg := '对不起，请在缴费后申请！';
					goto nextOne;
				end if;
			elsif v_count = 0 then
				out_flag := 3;  --注意 flag 不能设置为2 因为在外面业务中2已经被占用
				out_msg := '对不起，请在缴费后申请！';
				goto nextOne;
			end if;
		end if;

        select count(*) into v_count from jw_xk_xsxkb where xh_id=in_xh_id and kch_id=v_kch_id and xnm=v_xkxnm and xqm=v_xkxqm;
        if v_count>0 then
            out_flag := -1; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
            out_msg := '对不起，同一门课程只可报一个重修教学班！';
            goto nextOne;
         end if;

        select count(*) into v_count
        from
            (
                select a.jxb_id, b.xqj, b.zcd, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where a.jxb_id = b.jxb_id and a.kch_id != v_kch_id
                    and a.xh_id = in_xh_id and b.xnm = v_xkxnm
                    and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm and a.zxbj != '1'
             ) t1,
            (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2
        where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;

        if v_count>0 and in_yxzx = '0' then
            out_flag := 0; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
            out_msg := '所选教学班与其他教学班的上课时间有冲突';
            goto nextOne;
        end if;

        select count(*) into v_count from (
            select sum(zc) zcd,xqj,jc from (
                select zc,xqj,sum(jcm) jc from (
                    select
                        t2.zc, t2.xqj, t3.xh_id, b.jcm, t3.xnm, t3.xqm, a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq
                    from
                        (select a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b where a.xl_id = b.xl_id  and b.dxqzc <> 0) t2,
                        jw_pk_rsdszb a,
                        jw_pk_rjcszb b,
                        jw_pk_rsddmb c,
                        (
                            --正考学生--
                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                            where
                                t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                            --group by t2.ksrq, t2.kskssj, t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                            union all
                            --补考学生--
                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                            where
                                t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id and t4.bkqrbj = '1'
                                and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                            --group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm
                        )t3
                    where
                        a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and a.xnm = t3.xnm and a.xqm = t3.xqm
                        and a.xqh_id = in_xqh_id and b.qssj < t3.ksjssj||':00' and b.jssj > t3.kskssj||':00'
                        and c.qyzt = '1' and t2.xnm = t3.xnm and t2.xqm = t3.xqm and t2.rq = t3.ksrq
                ) group by zc,xqj
            ) group by jc,xqj
        ) t1,
        (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2
    where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;

    if v_count>0 and in_yxzx = '0' then
       out_flag := 0; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
       out_msg := '所选教学班上课时间与考试时间有冲突';
       goto nextOne;
    end if;



       select count(1) into v_count
    from
        (select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
           from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
           where t1.xnm = t2.xnm
            and t1.xqm = t2.xqm
            and t1.xnm = t3.xnm
            and t1.xqm = t3.xqm
            and t1.sjbh_id = t3.sjbh_id
            and t1.ksccb_id = t2.ksccb_id
            and t3.jxb_id = t4.jxb_id
            and t4.xh_id = in_xh_id
            and t1.xnm = v_xkxnm
            and t1.xqm = v_xkxqm
            and t4.xnm = v_xkxnm
            and t4.xqm = v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm,t4.kch_id,t4.jxb_id
           union all
           select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
           from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
           where t1.xnm = t2.xnm
            and t1.xqm = t2.xqm
            and t1.xnm = t3.xnm
            and t1.xqm = t3.xqm
            and t1.sjbh_id = t3.sjbh_id
            and t1.ksccb_id = t2.ksccb_id
            and t3.jxb_id = t4.jxb_id
            and t4.bkqrbj = '1'
            and t4.xh_id = in_xh_id
            and t1.xnm = v_xkxnm
            and t1.xqm = v_xkxqm
            and t4.xnm = v_xkxnm
            and t4.xqm = v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm,t4.kch_id,t4.jxb_id
        ) t1,
        (select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
            where t1.xnm = t2.xnm
              and t1.xqm = t2.xqm
              and t1.xnm = t3.xnm
              and t1.xqm = t3.xqm
              and t1.sjbh_id = t3.sjbh_id
              and t1.ksccb_id = t2.ksccb_id
              and t3.jxb_id = t4.jxb_id
              and t1.xnm = v_xkxnm
              and t1.xqm = v_xkxqm
              and t4.xnm = v_xkxnm
              and t4.xqm = v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj,t1.xnm, t1.xqm,t4.kch_id,t4.jxb_id
          ) t2
    where t1.ksrq = t2.ksrq
    and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj
    and t2.jxb_id=jxb_id_array(i)
    and t1.jxb_id !=t2.jxb_id;

    if v_count>0  then
       out_flag := 0; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
       out_msg := '所选教学班考试时间与考试时间有冲突';
       goto nextOne;
    end if;

     select count(1) into v_count
    from
        (
         select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a,jw_xk_xsxkb b where a.jxb_id = b.jxb_id and b.xh_id = in_xh_id and b.xnm = v_xkxnm and b.xqm = v_xkxqm and nvl(b.zxbj,'0') = '0') t1,
        (select sum(zc) zcd,xqj,jc,kch_id,jxb_id from(
          select zc,xqj,sum(jcm) jc,kch_id,jxb_id from (
          select t2.zc, t2.xqj,b.jcm, t3.xnm, t3.xqm, a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id
            from (select a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b where
                                    a.xl_id = b.xl_id  and b.dxqzc <> 0 )t2,
                jw_pk_rsdszb a,
                jw_pk_rjcszb b,
                jw_pk_rsddmb c,
                (
                select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                where t1.xnm = t2.xnm
                 and t1.xqm = t2.xqm
                 and t1.xnm = t3.xnm
                 and t1.xqm = t3.xqm
                 and t1.sjbh_id = t3.sjbh_id
                 and t1.ksccb_id = t2.ksccb_id
                 and t3.jxb_id = t4.jxb_id
                 and t1.xnm = v_xkxnm
                 and t1.xqm = v_xkxqm
                 and t4.xnm = v_xkxnm
                 and t4.xqm = v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj,t1.xnm, t1.xqm,t4.kch_id,t4.jxb_id
                 )t3
           where a.rsdsz_id = b.rsdsz_id
            and a.rsd_id = c.rsd_id
            and a.xnm = t3.xnm
            and a.xqm = t3.xqm
            and a.xqh_id = in_xqh_id
            and b.qssj < t3.ksjssj||':00' and b.jssj > t3.kskssj||':00'
            and c.qyzt = '1'
            and t2.xnm = t3.xnm
            and t2.xqm = t3.xqm
            and t2.rq = t3.ksrq
            )group by zc,xqj,kch_id,jxb_id)group by jc,xqj,kch_id,jxb_id) t2
    where t1.xqj = t2.xqj
    and bitand(t1.zcd, t2.zcd)>0
    and bitand(t1.jc, t2.jc)>0
    and t2.jxb_id=jxb_id_array(i)
    and t1.jxb_id !=t2.jxb_id;

    if v_count>0  then
       out_flag := 0; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
       out_msg := '所选教学班考试时间与上课时间有冲突';
       goto nextOne;
    end if;

end LOOP;
    <<nextOne>>

    if out_flag = '-1' then
        rollback;
    else
        commit;
    end if;
end;

/

