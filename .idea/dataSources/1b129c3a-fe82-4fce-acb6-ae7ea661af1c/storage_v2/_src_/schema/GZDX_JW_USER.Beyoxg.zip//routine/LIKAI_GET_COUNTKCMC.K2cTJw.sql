create FUNCTION likai_get_countkcmc ( v_xh_id IN varchar2,v_kch in varchar2, v_kcmc IN varchar2) RETURN INT IS v_bfzcj INT; v_count2 int;
BEGIN
v_count2:=0;
select count(*) into v_count2 from (select xh_id,KCH_ID,kch,kcmc,likai_get_iszf(XH_ID,JXB_ID,CJ) zfzt,max(BFZCJ) zgcj from JW_CJ_XSCJB
where  XH_ID=v_xh_id
and kcmc=v_kcmc
group by xh_id,KCH_ID,kch,kcmc,likai_get_iszf(XH_ID,JXB_ID,CJ)
order by kcmc) a
where a.zfzt=0 and a.KCH<>v_kch;
return v_count2;
end  likai_get_countkcmc;
/

