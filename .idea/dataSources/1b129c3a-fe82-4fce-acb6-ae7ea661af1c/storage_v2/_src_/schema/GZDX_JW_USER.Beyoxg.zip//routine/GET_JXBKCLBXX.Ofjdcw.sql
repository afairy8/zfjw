create function Get_JxbKclbxx(vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班课程性质信息----
as
   sKclbxx varchar2(500);   ---课程类别信息
begin
    sKclbxx := '无';
    begin
       if vBj = '0' then
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select nvl(wm_concat(kclbmc),'无') into sKclbxx from (
         select distinct b.kclbmc,b.kclbdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kclbdmb b
                where a.kclbdm = b.kclbdm
                  and a.jxb_id= vJxb_id
                  order by b.kclbdm
          );
       end if ;
      if vBj = '1' then
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select nvl(wm_concat(kclbdm),'无') into sKclbxx from (
         select distinct b.kclbmc,b.kclbdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kclbdmb b
                where a.kclbdm = b.kclbdm
                  and a.jxb_id= vJxb_id
                  order by b.kclbdm
          );
       end if ;
     exception
        When others then
          sKclbxx := '无';
    end;
    return sKclbxx ;
end Get_JxbKclbxx;

/

