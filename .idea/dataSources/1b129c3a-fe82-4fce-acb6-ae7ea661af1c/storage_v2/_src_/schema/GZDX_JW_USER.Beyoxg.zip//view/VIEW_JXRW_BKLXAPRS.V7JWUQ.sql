create view VIEW_JXRW_BKLXAPRS as
  select t2.xnm, t2.xqm, t2.xqh_id, t2.njdm_id, t1.zyh_id, t1.bh_id, rs
  from jw_jxrw_bkzybjdzb t1, jw_jxrw_bkxxb t2
 where t1.bkxxb_id = t2.bkxxb_id
   and t2.xnm = '09'
   and t2.xqm = '12'
   and t2.xqh_id = '1'
   and t2.njdm_id = 'FC2D5DBF2C4CDE51E040007F01006012'
   and t2.bklx_id='0000'
/

