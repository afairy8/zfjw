create function get_PYFAKCISCSJSY(vPyfakcxx_id varchar2,vKch_id varchar2,vBj varchar2)
return number
as
vresult number;
begin
vresult:=0;
  begin
    --查询该课程是否存在实践学时
    if vBj='0' then
        select
        case when (count(*)- sum(case when (b.xsmc like '%实践%' or b.xsmc like '%实验%') then 1 else 0 end)  = 0) and count(*) =1 then 1 else 0 end into vresult
        from jw_jh_pyfakcxsdzb a, jw_jh_kcxsxxdmb b
          where a.pyfakcxx_id = vPyfakcxx_id
            and a.xsdm = b.xsdm
            and a.kch_id = vKch_id;
     end if;
         exception
         When others then
         vresult:=0;
  end;
  return vresult;
end get_PYFAKCISCSJSY;

/

