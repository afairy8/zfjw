create function fn_getTjzmc(vTjz varchar2,vSzzmcSql varchar2) return varchar2  ---返回条件值名称----
as
   sTjzmc     varchar2(2000);   ---条件值名称
   sSzzmcSql  varchar2(4000); ---取值sql
begin
   sTjzmc := vTjz;
   if trim(vSzzmcSql) is not null then ---取值sql不为空
      begin
         sSzzmcSql := vSzzmcSql;
         if instr(vSzzmcSql,'?')>0 then
            sSzzmcSql := replace(vSzzmcSql,'?','''' ||vTjz|| '''');
         end if;
         execute immediate sSzzmcSql into sTjzmc;
      exception When others then
         sTjzmc := '';
      end;
   end if;
   return sTjzmc;
end fn_getTjzmc;

/

