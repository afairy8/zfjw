create function Get_Skdxssxy(
vXnm varchar2,
vXqm varchar2,
vJxb_id varchar2,
vBj varchar2) return varchar2  ---教学班配课人数----  标记目前不为1、2时 可传专业方向信息--
as
   sSkdx varchar2(5000);
begin
    sSkdx := '无';
    begin
      if vBj = '0' then
      select wm_concat(skdx) into sSkdx from (
      select jgmc||count(distinct bh_id)||'个班级共'||sum(rs)||'个学生' skdx from (
      select  (select a.jgmc from zftal_xtgl_jgdmb a, zftal_xtgl_zydmb b where a.jg_id = b.jg_id and b.zyh_id = t2.zyh_id)jgmc ,
              t2.bh_id,
              Get_Jxbpkrs(t1.xnm,t1.xqm,t1.kch_id,t1.jxb_id,t2.njdm_id,t2.zyh_id,t2.bh_id,'3') rs from jw_jxrw_jxbxxb t1,
           jw_jxrw_jxbhbxxb t2 where t1.jxb_id = t2.jxb_id and
           t1.jxb_id = vJxb_id
            and t1.xnm = vXnm
            and t1.xqm = vXqm
            ) group by jgmc);
    end if;

    if vBj = '1' then
      select wm_concat(skdx) into sSkdx from (
      select jgmc as skdx from (
      select  (select a.jgmc from zftal_xtgl_jgdmb a, zftal_xtgl_zydmb b where a.jg_id = b.jg_id and b.zyh_id = t2.zyh_id) jgmc from jw_jxrw_jxbxxb t1,
           jw_jxrw_jxbhbxxb t2 where t1.jxb_id = t2.jxb_id and
           t1.jxb_id = vJxb_id
            and t1.xnm = vXnm
            and t1.xqm = vXqm
            ) group by jgmc);
    end if;
    if sSkdx is null then
      sSkdx :='无合班信息';
    end if;
    exception
        When others then
          sSkdx := '无0';
    end;
    return sSkdx ;
end Get_Skdxssxy;

/

