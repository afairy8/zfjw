create function FN_GetTdxx(v_xh_id varchar2,v_kch_id varchar2,v_kcxzdm varchar2,v_kcgsdm varchar2) return varchar2
/****查询节点课程的替代信息 kwy ****/
as
   kcbzxx varchar2(200);
begin

      select
           case when (select count(1) from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b where b.xrdz_id = t.rdz_id and b.shjg='3' and b.xh_id = v_xh_id and t.kch_id = v_kch_id) > 0
               then (select '认定课程:'||(SELECT wm_concat(s.kcmc) FROM JW_CJ_XFRDMXB s WHERE s.rdz_id = b.yrdz_id GROUP BY s.rdz_id) xwkcmc
                     from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                     where  b.rdlybj = '0' and b.xrdz_id = t.rdz_id and b.shjg='3' and b.xh_id = v_xh_id and t.kch_id = v_kch_id)


               when (select count(1) from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b where b.yrdz_id = t.rdz_id and b.shjg='3' and b.xh_id = v_xh_id and t.kcmc = v_kch_id) > 0
               then (select '被认定课程:'||(SELECT wm_concat(s.kcmc) FROM JW_CJ_XFRDMXB s WHERE s.rdz_id = b.xrdz_id GROUP BY s.rdz_id) xwkcmc
                     from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                     where b.rdlybj = '0' and b.xrdz_id = t.rdz_id and b.shjg='3' and b.xh_id = v_xh_id and t.kch_id = v_kch_id)

               when (select count(1) from jw_cj_xsgrcjdtb t where t.zszt='3' and t.xh_id = v_xh_id and t.kcthzbm = 'xnkc' and t.kch_id = v_kch_id) > 0
               then (select '被替代课程:' || wm_concat((select d.kcmc from jw_jh_kcdmb d where d.kch_id = jhdtb.kch_id)) tkkcmc
                       from jw_cj_xsgrjhdtb jhdtb,
                            (select zb.kcthzh_id,cjdtb.kch_id  from
                               jw_cj_xsgrcjdtb cjdtb, jw_cj_xsgrdtzb zb
                             where  cjdtb.kcthzh_id = zb.kcthzh_id
                                and cjdtb.xh_id = v_xh_id
                                and zb.kcthzbm = 'xnkc'
                                and zb.zszt ='3')zb
                       where zb.kcthzh_id = jhdtb.kcthzh_id
                         and zb.kch_id = v_kch_id
                         and jhdtb.xh_id = v_xh_id)

               when (select count(1) from jw_cj_xsgrjhdtb t where t.zszt='3' and t.xh_id = v_xh_id and t.kch_id = v_kch_id) > 0
               then (select '替代课程:' ||wm_concat((select d.kcmc  from jw_cj_xscjb jxb, jw_jh_kcdmb d  where jxb.jxb_id = cjdtb.jxb_id  and jxb.kch_id = d.kch_id  and jxb.xh_id = cjdtb.xh_id)) thkcmc
                      from jw_cj_xsgrcjdtb cjdtb,
                           ( select zb.kcthzh_id,jhdtb.kch_id from jw_cj_xsgrjhdtb jhdtb, jw_cj_xsgrdtzb zb
                             where  jhdtb.kcthzh_id = zb.kcthzh_id
                                and jhdtb.xh_id = v_xh_id
                                and zb.kcthzbm = 'xnkc'
                                and zb.zszt ='3') zb
                      where zb.kcthzh_id = cjdtb.kcthzh_id
                        and zb.kch_id = v_kch_id
                        and cjdtb.xh_id = v_xh_id
                        )
             end || (select (case when v_kcxzdm = '04' then (select '课程归属:'||kcgsmc from jw_jh_kcgsdmb where kcgsdm = v_kcgsdm)  else '' end) from dual)  into kcbzxx
         from dual;

    if kcbzxx is null then
       kcbzxx := '';
    end if;
    return kcbzxx;
end FN_GetTdxx;

/

