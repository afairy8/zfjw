create function fun_by_xwzgsh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---通过学位资格审核
   v_count number;--数量
   --（1）学生在学期间获得国家级或省部级奖励和成果；
   --（2）学生在申请学位时已具有中级及以上专业技术职务者；
   --（3）学生在申请学位时已获得国家承认的其他学士学位证书者；
   --（4）通过北京地区成人学位英语统一考试；
begin
   -- sJg := '合格';
    begin
    select count(1) into v_count from view_by_qtkccjb a where a.xh_id = ''||v_xh_id||'' and a.lbdm='xwzg' ;
    if v_count =  0 then
       sJg:='无申报资格的数据，不合格！';
    else
       select wm_concat(kcmc||BFZCJ||'分') into sJg from (
       select (case when a.BFZCJ>=60 then 'Y' else 'N' end)tgzt, a.kcmc,a.BFZCJ
       from view_by_qtkccjb a where a.xh_id = ''||v_xh_id||'' and a.lbdm='xwzg'
       ) where tgzt='Y';

       if sJg is null then
         select wm_concat(kcmc||BFZCJ||'分')||',不合格！' into sJg from (
         select (case when a.BFZCJ>=60 then 'Y' else 'N' end)tgzt, a.kcmc,a.BFZCJ
         from view_by_qtkccjb a where a.xh_id = ''||v_xh_id||'' and a.lbdm='xwzg'
         ) where tgzt='N';
       else
          sJg:=sJg||',合格！';
       end if;
    end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;
    return sJg ;
end fun_by_xwzgsh;

/

