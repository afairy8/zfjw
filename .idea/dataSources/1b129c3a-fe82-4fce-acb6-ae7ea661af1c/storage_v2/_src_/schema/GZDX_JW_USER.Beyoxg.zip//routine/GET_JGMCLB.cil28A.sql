create FUNCTION get_jgmclb  (
    jgidlb in varchar
)
RETURN VARCHAR2 IS
    jgmclb varchar(200);
  cursor get_jgmc_cursor is
    select jgmc from zftal_xtgl_jgdmb where jg_id in (jgidlb);
    jgmc zftal_xtgl_jgdmb.jgmc%type;
BEGIN
    open get_jgmc_cursor;
    dbms_output.put_line(jgidlb);
  loop
    fetch get_jgmc_cursor into jgmc;
		exit when get_jgmc_cursor%notfound;
    dbms_output.put_line(jgmc);
    jgmclb:=jgmclb||','||jgmc;
  end loop;
  close get_jgmc_cursor;
    RETURN jgmclb;
END;


/

