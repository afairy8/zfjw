create view VIEW_GJBB_ZXSFNLQK as
  with temp_a as  --temp_a 在校生统计
(select nvl(t1.dm,t2.dm) dm,nvl(t1.mc,t2.mc) mc,nvl(t1.njdm_id,t2.njdm_id) njdm_id,hj,a17,a18,a19,a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31
from
(select *
          from (select dm,mc from zftal_xtgl_jcsjb where lx = '0016'),
               (select njdm_id from zftal_xtgl_njdmb)) t1
full join
(select lb.dm ,
       lb.mc,
       xs.njdm_id,
       count(1) hj,--合计,
       sum(decode(floor(nl / 18), 0, 1, 0)) a17,sum(decode(nl, 18, 1, 0)) a18,sum(decode(nl, 19, 1, 0)) a19,
       sum(decode(nl, 20, 1, 0)) a20,sum(decode(nl, 21, 1, 0)) a21,sum(decode(nl, 22, 1, 0)) a22,
       sum(decode(nl, 23, 1, 0)) a23,sum(decode(nl, 24, 1, 0)) a24,sum(decode(nl, 25, 1, 0)) a25,
       sum(decode(nl, 26, 1, 0)) a26,sum(decode(nl, 27, 1, 0)) a27,sum(decode(nl, 28, 1, 0)) a28,
       sum(decode(nl, 29, 1, 0)) a29,sum(decode(nl, 30, 1, 0)) a30,sum(decode(floor(nl / 31), 0, 0, 1)) a31
  from (select jcsjb.dm, jcsjb.mc
          from zftal_xtgl_jcsjb jcsjb
         where jcsjb.lx = '0016') lb,
       (select a.xh_id,
                    a.xslbdm,
                    a.xbm,
                    a.njdm_id,
                    ((to_char(sysdate, 'yyyy') -
                    to_char(to_date(a.csrq, 'yyyy-mm-dd'), 'yyyy')) +
                    decode(to_char(to_date(a.csrq, 'yyyy-mm-dd'), 'mm'),
                     '09',-1,'10',-1,'11',-1,'12',-1,0)) nl --计算年龄
               from jw_xjgl_xsjbxxb a
              where a.sfzx = '1' and isDateChar(a.csrq) = 0) xs
       where lb.dm = xs.xslbdm
   group by lb.dm,lb.mc,xs.njdm_id) t2
on t1.dm=t2.dm
and t1.njdm_id=t2.njdm_id),
temp_b as --temp_b 在校女生统计
(select nvl(t1.dm,t2.dm) dm,'其中：女' mc,nvl(t1.njdm_id,t2.njdm_id) njdm_id,hj,a17,a18,a19,a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31
from  (select *
          from (select dm,mc from zftal_xtgl_jcsjb where lx = '0016'),
               (select njdm_id from zftal_xtgl_njdmb)) t1
full join
(select lb.dm ,
       lb.mc,
       xs.njdm_id,
       count(1) hj,--合计,
       sum(decode(floor(nl / 18), 0, 1, 0)) a17,sum(decode(nl, 18, 1, 0)) a18,sum(decode(nl, 19, 1, 0)) a19,
       sum(decode(nl, 20, 1, 0)) a20,sum(decode(nl, 21, 1, 0)) a21,sum(decode(nl, 22, 1, 0)) a22,
       sum(decode(nl, 23, 1, 0)) a23,sum(decode(nl, 24, 1, 0)) a24,sum(decode(nl, 25, 1, 0)) a25,
       sum(decode(nl, 26, 1, 0)) a26,sum(decode(nl, 27, 1, 0)) a27,sum(decode(nl, 28, 1, 0)) a28,
       sum(decode(nl, 29, 1, 0)) a29,sum(decode(nl, 30, 1, 0)) a30,sum(decode(floor(nl / 31), 0, 0, 1)) a31
  from (select jcsjb.dm, jcsjb.mc
          from zftal_xtgl_jcsjb jcsjb
         where jcsjb.lx = '0016') lb,
       (select a.xh_id,
                    a.xslbdm,
                    a.xbm,
                    a.njdm_id,
                    ((to_char(sysdate, 'yyyy') -
                    to_char(to_date(a.csrq, 'yyyy-mm-dd'), 'yyyy')) +
                    decode(to_char(to_date(a.csrq, 'yyyy-mm-dd'), 'mm'),
                     '09',-1,'10',-1,'11',-1,'12',-1,0)) nl
               from jw_xjgl_xsjbxxb a
              where a.sfzx = '1' and isDateChar(a.csrq) = 0) xs
       where lb.dm = xs.xslbdm
         and xs.xbm='2'
   group by lb.dm,lb.mc,xs.njdm_id) t2
on t1.dm=t2.dm
and t1.njdm_id=t2.njdm_id)--总计
(select '1' bh,'' dm,'总计' mc,njdm_id,sum(hj) hj,sum(a17) a17,sum(a18) a18,sum(a19) a19,sum(a20) a20,sum(a21) a21,sum(a22) a22,
        sum(a23) a23,sum(a24) a24,sum(a25) a25,sum(a26) a26,sum(a27) a27,sum(a28) a28,sum(a29) a29,sum(a30) a30,sum(a31) a31
from temp_a
group by njdm_id)
union all
(select '2' bh,'' dm,'其中：女' mc,njdm_id,sum(hj) hj,sum(a17) a17,sum(a18) a18,sum(a19) a19,sum(a20) a20,sum(a21) a21,sum(a22) a22,
        sum(a23) a23,sum(a24) a24,sum(a25) a25,sum(a26) a26,sum(a27) a27,sum(a28) a28,sum(a29) a29,sum(a30) a30,sum(a31) a31
from temp_b
group by njdm_id)
union all--分类别统计
select '3' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='411'
union all
select '4' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='411'
union all
select '5' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='421'
union all
select '6' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='421'
union all
select '7' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='412'
union all
select '8' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='412'
union all
select '9' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='422'
union all
select '10' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='422'
union all
select '11' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='413'
union all
select '12' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='413'
union all
select '13' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='423'
union all
select '14' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='423'
union all
select '15' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='431'
union all
select '16' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='431'
union all
select '17' bh, temp_a."DM",temp_a."MC",temp_a."NJDM_ID",temp_a."HJ",temp_a."A17",temp_a."A18",temp_a."A19",temp_a."A20",temp_a."A21",temp_a."A22",temp_a."A23",temp_a."A24",temp_a."A25",temp_a."A26",temp_a."A27",temp_a."A28",temp_a."A29",temp_a."A30",temp_a."A31" from temp_a where temp_a.dm='432'
union all
select '18' bh, temp_b."DM",temp_b."MC",temp_b."NJDM_ID",temp_b."HJ",temp_b."A17",temp_b."A18",temp_b."A19",temp_b."A20",temp_b."A21",temp_b."A22",temp_b."A23",temp_b."A24",temp_b."A25",temp_b."A26",temp_b."A27",temp_b."A28",temp_b."A29",temp_b."A30",temp_b."A31" from temp_b where temp_b.dm='432'
/

