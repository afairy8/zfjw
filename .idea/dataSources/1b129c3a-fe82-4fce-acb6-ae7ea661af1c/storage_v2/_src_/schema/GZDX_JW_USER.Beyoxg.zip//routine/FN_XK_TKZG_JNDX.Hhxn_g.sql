create function fn_xk_tkzg_jndx(
    in_zh_en in varchar2,
    in_xkxnm in varchar2,
    in_xkxqm in varchar2,
    in_xkkz_id in varchar2,
    in_xh_id in varchar2,
    in_xklc in varchar2,
    in_xkbj in varchar2,
    in_sfjf in varchar2
) return varchar2 is
    v_count number;
    v_xklc number;
    v_kklxdm varchar2(5);
    v_sfktk varchar2(1);
    v_gpksfkt varchar2(1);
    v_zntxbl varchar2(1);
begin
    if nvl(in_sfjf,'0')='1' then
        if in_zh_en='en_US' then
            return 'The course has been paid and can not be dropped out!';
        else
            return '已缴费，不可退！';
        end if;
    end if;

    select count(*) into v_count from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if v_count=0 then
        if in_zh_en='en_US' then
            return 'No drop-out now!';
        else
            return '不在可退课时间内！';
        end if;
    end if;
    select kklxdm,xklc into v_kklxdm,v_xklc from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id;
    if v_kklxdm='01' and in_xkbj!='10' then
        if in_zh_en='en_US' then
            return 'Administrators assigned to major courses, not to drop out!';
        else
            return '管理员配的主修课，不可退！';
        end if;
    end if;

    select nvl(sfktk,'0'),nvl(zntxbl,'0') into v_sfktk,v_zntxbl from jw_xk_xkkzxmb where xkkz_id=in_xkkz_id;
    if v_sfktk='0' then
        if in_zh_en='en_US' then
            return 'This kind of course is not allowed to drop out!';
        else
            return '该类课程不允许退！';
        end if;
    end if;

    if v_zntxbl='1' and to_number(nvl(in_xklc,'0'))!=v_xklc then
        if in_zh_en='en_US' then
            return 'It’s not the course of this round. You can’t drop out!';
        else
            return '不是本轮选的课程，不可退！';
        end if;
    end if;

    if in_xkbj != '10' then
        select nvl(gpksfkt,'0') into v_gpksfkt from (
            select gpksfkt from JW_XK_QTXKGZB
            where xnm=in_xkxnm and xqm=in_xkxqm and xh_id in (in_xh_id,'tongyi')
            order by case when xh_id='tongyi' then 1 else 0 end
        ) where rownum=1;
        if v_gpksfkt='0' then
            if in_zh_en='en_US' then
                return 'The course assigned by the administrator can not be dropped out!';
            else
                return '管理员配的课，不可退！';
            end if;
        end if;
    end if;

    return '1';
end fn_xk_tkzg_jndx;

/

