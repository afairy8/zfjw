create function Get_RwJxbxx
(vXnm varchar2,
 vXqm varchar2,
 vJxb_id varchar2,
 vKch_id varchar2,
 vbj varchar2) return varchar2
as
 sJg varchar(100);---查询结果
begin
     sJg:='';

     if vBj='1' then--是否专业核心课程（执行计划中）
        select decode(max(kc.zyhxkcbj),'0','否','1','是','') into sJg from jw_jh_jxzxjhkcxxb kc, jw_jxrw_jxbhbxxb jxb
         where kc.zyh_id = jxb.zyh_id
           and kc.njdm_id = jxb.njdm_id
           and jxb.jxb_id = vJxb_id
           and kc.kch_id = vKch_id;
     end if;

  return sJg;
end Get_RwJxbxx;

/

