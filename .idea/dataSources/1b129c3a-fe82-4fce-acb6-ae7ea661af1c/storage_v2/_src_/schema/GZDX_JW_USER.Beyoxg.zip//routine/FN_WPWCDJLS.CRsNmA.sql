create function fn_wpwcdjls(fn_jxbId varchar2,fn_xqj varchar2,fn_jc number,fn_jgh varchar2)return number
as
   --查询未安排完场地记录数
   v_jls number;
begin
    select count(*) into v_jls from (
       select a1.jgh_id,a1.ypsjzcd,a2.ypcdsjzcd from (
       select jgh_id,Get_BitorsUnion(wm_concat(zcd)) ypsjzcd from jw_pk_kbsjb where jxb_id=fn_jxbId
       and instr(fn_jgh,''''||jgh_id||'''')>0 and xqj=fn_xqj  and bitand(jc,power(2,fn_jc-1))>0
       group by jgh_id,xqj,jc)a1,(
       select m.jgh_id,Get_BitorsUnion(wm_concat(n.zcd)) ypcdsjzcd from jw_pk_kbsjb m,jw_pk_kbcdb n where m.kb_id=n.kb_id
       and m.jxb_id=fn_jxbId and m.xqj=fn_xqj and instr(fn_jgh,''''||m.jgh_id||'''')>0
       and bitand(n.jc,power(2,fn_jc-1))>0  group by m.jgh_id,m.xqj,n.jc)a2 where a1.jgh_id=a2.jgh_id(+)
    ) where (ypsjzcd<>ypcdsjzcd or ypcdsjzcd is null);
    return v_jls;
end fn_wpwcdjls;

/

