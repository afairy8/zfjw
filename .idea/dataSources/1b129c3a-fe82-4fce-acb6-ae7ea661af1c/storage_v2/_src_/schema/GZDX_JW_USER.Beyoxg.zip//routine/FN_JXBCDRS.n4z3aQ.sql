create function fn_jxbCdrs(vJxb_id varchar2,vXnm varchar2,vXqm varchar2,vBj varchar2) return varchar2
as
   sCdrs number;   ---教学班场地人数
begin
    sCdrs := 0;
    begin
    select zws into sCdrs from (
        select rq,jc,sum(zws) zws from (
          select distinct cd.zws,t2.rq,t5.jc,t4.cd_id
          from jw_jcdm_cdxqxxb cd,jw_pk_kbsjb t3,jw_pk_kbcdb t4,jw_pk_xlb t1,jw_pk_rcmxb t2,
               (select rownum jc from zftal_xtgl_jcsjlxb where rownum <= 20) t5
                 where cd.cd_id = t4.cd_id
                   and t4.kb_id = t3.kb_id
                   and t1.xl_id=t2.xl_id
                   and bitand(power(2,t2.zc-1),t4.zcd)>0
                   and t2.xqj=t3.xqj
                   and bitand(power(2,t5.jc-1),t4.jc)>0
                   and t1.xnm=vXnm
                   and t1.xqm=vXqm
                   and cd.xnm=vXnm
                   and cd.xqm=vXqm
                   and t3.xnm = vXnm
                   and t3.xqm = vXqm
                   and t3.jxb_id = vJxb_id
                   ) group by rq,jc
                   order by (case when to_date(rq,'yyyy-mm-dd')>trunc(sysdate,'d') then 1 else 2 end)/*,abs(to_date(rq,'yyyy-mm-dd')-trunc(sysdate,'d'))*/,zws
     ) where rownum <=1;
     exception
        When others then
          sCdrs := '';
    end;
    if sCdrs is null then
     return '' ;
    else
    return sCdrs ;
    end if ;
end fn_jxbCdrs;

/

