create view V_JW_XSXKBB as
  select
a.jxb_id||a.xh_id as id,
a.jxb_id jxb_id ,
(select v.jxbmc from  jw_jxrw_jxbxxb v where v.jxb_id=a.jxb_id )jxbmc ,
(select xs.xh from jw_xjgl_xsjbxxb xs where xs.xh_id=a.xh_id) as xh,
(select kc.kch from jw_jh_kcdmb kc where kc.kch_id=a.kch_id) as kcdm,
a.xksj, decode(a.xnm,'2018','2018-2019','2019','2019-2020','2020','2020-2021','2021','2021-2022','2022','2022-2023','2023','2023-2024',
'2024','2024-2025','2025','2025-2026','2027','2027-2018') xn ,decode( a.xqm,3,1,12,2)xq
from jw_xk_xsxkb a where a.xqm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXQM') and a.xnm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXNM'
)
/

