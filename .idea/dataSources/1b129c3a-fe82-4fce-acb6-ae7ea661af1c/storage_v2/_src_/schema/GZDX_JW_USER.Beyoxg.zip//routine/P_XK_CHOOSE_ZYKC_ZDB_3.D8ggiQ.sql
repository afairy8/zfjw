create procedure p_xk_choose_zykc_zdb_3
(
  in_jxb_array in varchar2,
  in_xh_id in varchar2,
  in_njdm_id in varchar2,
  in_kxkxxq in varchar2,
  in_cxbj in varchar2,
  in_xxkbj in varchar2,
  in_kch_id in varchar2,
  in_xkkz_id in varchar2,
  in_qz in varchar2,
  in_sxbj in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
    sqlStr varchar2(1000);
    v_fjxb_id varchar2(40);
    v_fbxbj varchar2(1);
    v_jxb_ids varchar2(500);
    v_jxb_tab varchar2(800);
    v_fxbj varchar2(1);
    v_xnxxq varchar2(60);
    v_xkxnm varchar2(4);
    v_xkxqm varchar2(2);
    v_kklxdm varchar2(2);
    v_xklc number;
    v_count number;
    v_zdzys number;
    v_sfzyxk varchar2(1);
    v_rlkz varchar2(1);
    v_sfqjszws varchar2(1);
    v_bklx_id varchar2(32);
    v_sfkzyxk varchar2(1);
	v_xzjxbCount number;
    v_len number;
    v_tmp_zy number;
    jxb_array mytype;
    jxbzh_array mytype;
	xxq_array mytype;
begin
    out_flag := '1';
    --判断该课程学生是否已选过
    select count(*) into v_count from jw_xk_xsxkb a where xh_id=in_xh_id and a.jxb_id=v_fjxb_id;
    if v_count = '1' then
       out_flag := '1';--该教学班该学生已选过
       goto nextOne; --跳出循环
    end if;

    --判断当前是否在选课时间内
    select count(*) into v_count from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if v_count = '0' then
       out_flag := '0';--不在选课时间内
       out_msg := '选课时间已过，不可再选！';
       goto nextOne; --跳出循环
    end if;

    --查找可能要用到的选课规则设置项
    select a.xnm,a.xqm,a.kklxdm,a.xklc,b.sfzyxk,nvl(b.zdzys,1),nvl(b.sfqjszws,'0'),b.rlkz
           into
           v_xkxnm,v_xkxqm,v_kklxdm,v_xklc,v_sfzyxk,v_zdzys,v_sfqjszws,v_rlkz
    from JW_XK_XKKZB a,JW_XK_XKKZXMB b where a.xkkz_id=b.xkkz_id and a.xkkz_id=in_xkkz_id;

    v_fxbj := '0';
    jxb_array := my_split(in_jxb_array,',');
	xxq_array := my_split(substr(substr(in_kxkxxq,0,length(in_kxkxxq)-2),3),''',''');--分割出小学期
    v_len:=jxb_array.count;
    v_tmp_zy := 0;
    FOR i IN 1..jxb_array.count LOOP
        jxbzh_array := my_split(jxb_array(i),'~');
        if i=1 then
            v_fjxb_id:=jxbzh_array(1);
            v_fbxbj:=jxbzh_array(3);
            if v_len>=2 then
               v_jxb_ids:='('''||jxbzh_array(1)||'''';
            end if;
        else
            v_jxb_ids:=v_jxb_ids||','''||jxbzh_array(1)||'''';
            if v_tmp_zy != jxbzh_array(2) then --每一个新的志愿要新增一个“父教学班+新志愿”记录
               if v_tmp_zy=0 then--刚开始拼接教学班信息时，从select开始
                   v_jxb_tab:='select '''||v_fjxb_id||''' jxb_id,'||jxbzh_array(2)||' zy,'''||v_fbxbj||''' xsbxf from dual'||
                              ' union all '||
                              'select '''||jxbzh_array(1)||''' jxb_id,'||jxbzh_array(2)||' zy,'''||jxbzh_array(3)||''' xsbxf from dual';
               else
                   v_jxb_tab:=v_jxb_tab||' union all '||--说明不是开始，所以要从union all开始
                              'select '''||v_fjxb_id||''' jxb_id,'||jxbzh_array(2)||' zy,'''||v_fbxbj||''' xsbxf from dual'||
                              ' union all '||
                              'select '''||jxbzh_array(1)||''' jxb_id,'||jxbzh_array(2)||' zy,'''||jxbzh_array(3)||''' xsbxf from dual';

               end if;
               v_tmp_zy := jxbzh_array(2);
            else
                v_jxb_tab:=v_jxb_tab||' union all select '''||jxbzh_array(1)||''' jxb_id,'||jxbzh_array(2)||' zy,'''||jxbzh_array(3)||''' xsbxf from dual';
            end if;
        end if;
    end LOOP;
    if v_len>=2 then
       v_jxb_ids:=v_jxb_ids||')';
    end if;

  	FOR i IN 1..xxq_array.count LOOP
  		if i=1 then
  			v_xnxxq := '('''||v_xkxnm||xxq_array(i);
  		else
  			v_xnxxq := v_xnxxq||''','''||v_xkxnm||xxq_array(i);
  		end if;
  	END LOOP;
  	v_xnxxq := v_xnxxq||''')';

    if v_kklxdm='04' then
       v_fxbj:='1';
    end if;

    if in_xxkbj='1' then
        select nvl((select sfkzyxk from jw_xk_qtxkgzb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id='tongyi'),'0') into v_sfkzyxk from dual;
        if v_sfkzyxk='1' then --判断先行课（预修课）控制是否设置为控制
  			sqlStr:='select count(1) from (select a.kch_id,a.yxkch_id from jw_jh_kcyxyqb a,jw_xk_xsxkb b,jw_jxrw_jxbxxb c where a.yxkch_id=c.kch_id and b.jxb_id=c.jxb_id and c.xnm||c.xqm not in '||v_xnxxq||' and b.xh_id = '''||in_xh_id||''' and a.kch_id = '''||in_kch_id||''')';
  			Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
  			if v_count = 0 then
                 out_flag := '0';
                 out_msg :='该课程的先行课未修，不可选！';
                 goto nextOne; --跳出检验
              end if;
          end if;
    end if;

    --最大志愿数判断
    if v_sfzyxk='1' then
       sqlStr:='select count(*) from jw_jxrw_jxbxxb a,jw_xk_xsxkb b,jw_jh_kcdmb c where a.jxb_id=b.jxb_id and a.kch_id=c.kch_id and a.fjxb_id is null and a.xnm='''||v_xkxnm||''' and a.xqm in '||in_kxkxxq||' and nvl(c.sskch_id,a.kch_id)='''||in_kch_id||''' and b.xh_id='''||in_xh_id||'''';
       Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
	   if v_count >= v_zdzys then
           out_flag := '0';
           out_msg := '超过最大志愿数限制，不可再选！';
           goto nextOne; --跳出循环
       end if;
    end if;

    --判断学生是否已选体育课
    if v_kklxdm='05' then
  		  sqlStr:='select count(*) from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != '''||in_kch_id||''' and a.xnm='''||v_xkxnm||''' and a.xqm in '||in_kxkxxq||' and a.xh_id = '''||in_xh_id||'''';
  		  Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
  		  if v_count > 0 then
    			 out_flag := '0';
    			 out_msg :='您已选过体育课，不可再选！';
    			 goto nextOne; --跳出循环
  		  end if;
    end if;

    --板块课同一个课组只能选一门课程
    if v_kklxdm='06' then
       --该课程是否为某课组内课程
       sqlStr:='select nvl((select bklx_id from view_xk_bkkkzb a where xnm='''||v_xkxnm||''' and xqm in '||in_kxkxxq||' and kch_id='''||in_kch_id||''' and njdm_id='''||in_njdm_id||''' and exists (select 1 from jw_xjgl_xsbklxcjb b where a.bklx_id = b.bklx_id and b.xh_id = '''||in_xh_id||''')),''0'') from dual';
       Execute Immediate sqlStr into v_bklx_id;--满足约束条件的记录个数
	     if v_bklx_id != '0' then
    		sqlStr:='select count(*) from jw_xk_xsxkb a,view_xk_bkkkzb b where a.kch_id=b.kch_id and a.kch_id != '''||in_kch_id||''' and a.xnm=b.xnm and a.xqm=b.xqm and b.njdm_id='''||in_njdm_id||''' and a.xnm='''||v_xkxnm||''' and a.xqm in '||in_kxkxxq||' and a.xh_id='''||in_xh_id||''' and b.bklx_id='''||v_bklx_id||'''';
          	Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
		    if v_count > 0 then
	             out_flag := '0';
	             out_msg :='您已选过该课程所在课组的其他课程，不可再选！';
	             goto nextOne; --跳出循环
          	end if;
       end if;
    end if;

    if in_qz='0' then
          sqlStr := 'select count(*) from JW_XK_XSXKB where xh_id='''||in_xh_id||''' and jxb_id in (select jxb_id from jw_jxrw_jxbxxb a,jw_jh_kcdmb b where a.kch_id=b.kch_id and nvl(b.sskch_id,b.kch_id)='''||in_kch_id||''' and a.xnm='''||v_xkxnm||''' and a.xqm in '||in_kxkxxq||' and a.fjxb_id is null)';
          Execute Immediate sqlStr into v_xzjxbCount;--满足约束条件的记录个数
    else
          v_xzjxbCount := 0;
    end if;

    if v_len>=2 then
        sqlStr := 'select count(*) from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3 where t1.ksccb_id=t2.ksccb_id and t1.sjbh_id=t3.sjbh_id and t3.jxb_id in '||v_jxb_ids||' and exists(select 1 from jw_kw_kssjb t4,jw_kw_ksccb t5,jw_kw_ksmcjxbdzb t6,jw_xk_xsxkb t7,jw_jh_kcdmb t8 where t4.ksccb_id=t5.ksccb_id and t4.sjbh_id=t6.sjbh_id and t7.jxb_id=t6.jxb_id and t7.kch_id=t8.kch_id and t7.xh_id='''||in_xh_id||''' and nvl(t8.sskch_id,t7.kch_id) != '''||in_kch_id||''' and t7.xnm='''||v_xkxnm||''' and t7.xqm in '||in_kxkxxq||' and t2.ksrq=t5.ksrq and t2.kskssj=t5.kskssj and t2.ksjssj=t5.ksjssj)';
    else
        sqlStr := 'select count(*) from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3 where t1.ksccb_id=t2.ksccb_id and t1.sjbh_id=t3.sjbh_id and t3.jxb_id='''||v_fjxb_id||''' and exists(select 1 from jw_kw_kssjb t4,jw_kw_ksccb t5,jw_kw_ksmcjxbdzb t6,jw_xk_xsxkb t7,jw_jh_kcdmb t8 where t4.ksccb_id=t5.ksccb_id and t4.sjbh_id=t6.sjbh_id and t7.jxb_id=t6.jxb_id and t7.kch_id=t8.kch_id and t7.xh_id='''||in_xh_id||''' and nvl(t8.sskch_id,t7.kch_id) != '''||in_kch_id||''' and t7.xnm='''||v_xkxnm||''' and t7.xqm in '||in_kxkxxq||' and t2.ksrq=t5.ksrq and t2.kskssj=t5.kskssj and t2.ksjssj=t5.ksjssj)';
    end if;
    Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
    if v_count > 0 then
       out_flag := '0';
       out_msg := '所选教学班的考试时间与其他教学班有冲突！';
       goto nextOne; --跳出循环
    end if;

    if v_rlkz != '1' then
       v_count:=0;
    else
        if v_len=1 and v_sfqjszws='0' then
            select count(*) into v_count from (select nvl(t1.jxbrs,0)+nvl(t1.krrl,0)-(select count(*) from jw_xk_xsxkb t2 where t2.jxb_id=t1.jxb_id) yl from jw_jxrw_jxbxxb t1 where t1.jxb_id=v_fjxb_id) where yl<=0;
        elsif v_len=1 and v_sfqjszws='1' then
            select count(*) into v_count from (select nvl(t1.jsrl,0)-(select count(*) from jw_xk_xsxkb t2 where t2.jxb_id=t1.jxb_id) yl from jw_jxrw_jxbxxb t1 where t1.jxb_id=v_fjxb_id) where yl<=0;
        elsif v_len>=2 and v_sfqjszws='0' then
            sqlStr:='select count(*) from (select nvl(t1.jxbrs,0)+nvl(t1.krrl,0)-(select count(*) from jw_xk_xsxkb t2 where t2.jxb_id=t1.jxb_id) yl from jw_jxrw_jxbxxb t1 where t1.jxb_id in '||v_jxb_ids||') where yl<=0';
            Execute Immediate sqlStr into v_count;
        else
            sqlStr:='select count(*) from (select nvl(t1.jsrl,0)-(select count(*) from jw_xk_xsxkb t2 where t2.jxb_id=t1.jxb_id) yl from jw_jxrw_jxbxxb t1 where t1.jxb_id in '||v_jxb_ids||') where yl<=0';
            Execute Immediate sqlStr into v_count;
        end if;
    end if;
    if v_count > 0 then
        out_flag := '0';
        out_msg := '教学班已无余量，不可选！';
        goto nextOne; --跳出循环
    end if;

    if v_len=1 then
        select count(*) into v_count from (select a.kch_id,b.xqj,b.jc,b.zcd from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jh_kcdmb c where a.jxb_id = b.jxb_id and a.kch_id=c.kch_id and nvl(c.sskch_id,c.kch_id) != in_kch_id and a.xh_id = in_xh_id and b.xnm = v_xkxnm and bitand(b.xqm,v_xkxqm)>0) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=v_fjxb_id) t2 where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0;
        if v_count > 0 then
           out_flag := '0';
           out_msg := '所选教学班的上课时间与其他教学班有冲突！';
           goto nextOne; --跳出循环
        end if;

        insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,bxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id)
    		    select jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,(v_xzjxbCount+1),in_qz,in_sxbj,v_fbxbj,'10',v_fxbj,in_cxbj,v_xkxnm,xqm,kch_id from jw_jxrw_jxbxxb where jxb_id=v_fjxb_id;
    else
        sqlStr := 'select count(*) from (select a.kch_id,b.xqj,b.jc,b.zcd from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jh_kcdmb c where a.jxb_id = b.jxb_id and a.kch_id=c.kch_id and nvl(c.sskch_id,c.kch_id) != '''||in_kch_id||''' and a.xh_id = '''||in_xh_id||''' and b.xnm = '''||v_xkxnm||''' and bitand(b.xqm,'''||v_xkxqm||''')>0) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id in '||v_jxb_ids||') t2 where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
        Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
        if v_count > 0 then
           out_flag := '0';
           out_msg := '所选教学班的上课时间与其他教学班有冲突！';
           goto nextOne; --跳出循环
        end if;

        sqlStr:='insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,bxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id)'||
                'select t1.jxb_id,'''||in_xh_id||''','''||v_xklc||''',to_char(sysdate,''yyyy-mm-dd hh24:mi:ss''),'''||in_xh_id||
                ''',('||v_xzjxbCount||'+t2.zy),'||in_qz||','''||in_sxbj||''',t2.xsbxf,''10'','''||v_fxbj||''','''||in_cxbj||''','''||v_xkxnm||
                ''',t1.xqm,t1.kch_id from jw_jxrw_jxbxxb t1,('||v_jxb_tab||') t2 where t1.jxb_id=t2.jxb_id';
        Execute Immediate sqlStr;
    end if;
    <<nextOne>>

    if out_flag != '0' then
       commit;
    end if;
end;

/

