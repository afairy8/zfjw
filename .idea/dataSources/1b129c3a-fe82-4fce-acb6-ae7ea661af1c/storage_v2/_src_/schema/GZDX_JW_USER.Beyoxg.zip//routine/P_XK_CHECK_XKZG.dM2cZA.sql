create procedure p_xk_check_xkzg(
	in_xkxnm in varchar2,
	in_xkxqm in varchar2,
	in_xkkz_id in varchar2,
    in_xh_id in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
) as
	v_xnm varchar2(5);
	v_xqm varchar2(3);
	v_count number;
	v_jzxkf varchar2(1);
begin
	select count(1) into v_count from jw_xk_xskxszb where xnm=in_xkxnm and xqm=in_xkxqm;
	if v_count>0 then
		select count(1) into v_count from jw_xk_xskxszb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;
		if v_count=0 then
			out_flag:='0';
			out_msg:='对不起，您不可选课，如有需要，请与管理员联系！';
			goto EndPoint;
		end if;
	end if;
	<<EndPoint>>
	null;
end;

/

