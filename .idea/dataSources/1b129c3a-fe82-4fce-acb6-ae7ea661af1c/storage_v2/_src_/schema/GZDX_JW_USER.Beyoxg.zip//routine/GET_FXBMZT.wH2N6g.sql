create function get_fxbmzt(vXnm varchar2,--报名学年
                                         vXqm varchar2,--报名学期
                                         vNjdm_id varchar2,--报名年级
                                         vZyh_id varchar2,--报名专业号ID
                                         vXh_id varchar2,--申请人
                                         vbmlbdm varchar2,--报名类别代码01辅修 02二专业 03二学位
                                         vfxezybmkz_id varchar2)
return varchar2
as
       cursor v_tjxhs is
       select tjxh,nvl(substr(tjz||'%',0,instr(tjz||'%','%','1')-1), '-1') tjz,nvl(substr(tjz1||'%',0,instr(tjz1||'%','%','1')-1), '-1')tjz1,nvl(substr(tjz2||'%',0,instr(tjz2||'%','%','1')-1), '-1')tjz2 from (
       select t2.tjxh, nvl(t2.tjz, '-1') tjz, nvl(t2.tjz1, '-1') tjz1, nvl(t2.tjz2, '-1') tjz2
       from jw_fx_fxezybmkzb t1, jw_fx_fxezytjxxb t2
       where t1.fxezybmkz_id = t2.fxezybmkz_id
         and t1.fxezybmkz_id = vfxezybmkz_id);

       v_tjxh   v_tjxhs%rowtype;
       sFhjg    varchar2(2000);--接受条件的返回所有结果
       sFhbj    varchar2(2);
       sTjxx    varchar2(200);--接受条件的返回结果
       sXqh_id varchar2(32);--学生校区
       sJg_id varchar2(32);--学生机构
       sNjdm_id varchar2(32);--学生年级
       sZyh_id varchar2(32);--学生专业
       sZyfx_id varchar2(32);--学生专业方向
       sBh_id varchar2(32);--学生班号
       sXbm varchar2(32);--学生性别
       sXslbm varchar2(32);--学生类别
       sCcdm varchar2(32);--学生层次
       sXsbj varchar2(32);--学生标记
       icount number;
       imx number;--面向
       ixz number;--限制
       icount_mx number;
       icount_xz number;
begin
       sFhbj := '1';
       --查询学生相关信息
       select nvl((select xqh_id from zftal_xtgl_bjdmb where bh_id = t2.bh_id),-1),
              nvl(t2.jg_id,-1),nvl(t2.njdm_id,-1),nvl(t2.zyh_id,-1),nvl(t2.zyfx_id,-1),
              nvl(t2.bh_id,-1),nvl(t1.xbm,-1),nvl(t2.xslbdm,-1),nvl(t2.pyccdm,-1),nvl(t1.xsbj,4294967296)
              into sXqh_id,sJg_id,sNjdm_id,sZyh_id,sZyfx_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj from
              jw_xjgl_xsjbxxb t1,jw_xjgl_xsxjxxb t2
                        where t1.xh_id = t2.xh_id
                          and t2.xh_id = vXh_id
                          and t2.xnm = vXnm
                          and t2.xqm = vXqm;

       select count(*),nvl(max(decode(b.xzlb,'mx',1)),0) ,nvl(max(decode(b.xzlb,'xz',1)),0) into icount,imx,ixz
       from jw_fx_fxezybmkzb c, jw_fx_fxezybmkzb a, jw_fx_mxdxb b
       where c.fxezybmkz_id = a.fxezybmkz_id
             and a.fxezybmkz_id=b.fxezybmkz_id
             and c.njdm_id = vNjdm_id
             and c.zyh_id = vZyh_id;

       if icount > 0 then
         select count(*) into icount_mx
         from jw_fx_fxezybmkzb c, jw_fx_fxezybmkzb a, jw_fx_mxdxb b
       where c.fxezybmkz_id = a.fxezybmkz_id
             and a.fxezybmkz_id=b.fxezybmkz_id
             and c.njdm_id = vNjdm_id
             and c.zyh_id = vZyh_id
             and xzlb = 'mx'
             and nvl(b.xqh_id,sxqh_id) = sxqh_id
             and nvl(b.jg_id,sJg_id) = sJg_id
             and nvl(b.njdm_id,snjdm_id) = snjdm_id
             and nvl(b.zyh_id,szyh_id) = szyh_id
             and nvl(b.zyfx_id,sZyfx_id) = szyfx_id
             and nvl(b.bh_id,sbh_id) = sbh_id
             and nvl(b.xbm,sxbm) = sXbm
             and nvl(b.xslbm,sxslbm) = sxslbm
             and nvl(b.ccdm,sccdm) = sccdm
             and bitand(nvl(b.xsbj,sxsbj),sxsbj) >0
             and nvl(b.xh_id,vXh_id) = vXh_id;

       select count(*) into icount_xz
         from jw_fx_fxezybmkzb c, jw_fx_fxezybmkzb a, jw_fx_mxdxb b
       where c.fxezybmkz_id = a.fxezybmkz_id
             and a.fxezybmkz_id=b.fxezybmkz_id
             and c.njdm_id = vNjdm_id
             and c.zyh_id = vZyh_id
             and xzlb = 'xz'
             and nvl(b.xqh_id,sxqh_id) = sxqh_id
             and nvl(b.jg_id,sJg_id) = sJg_id
             and nvl(b.njdm_id,snjdm_id) = snjdm_id
             and nvl(b.zyh_id,szyh_id) = szyh_id
             and nvl(b.zyfx_id,sZyfx_id) = szyfx_id
             and nvl(b.bh_id,sbh_id) = sbh_id
             and nvl(b.xbm,sxbm) = sXbm
             and nvl(b.xslbm,sxslbm) = sxslbm
             and nvl(b.ccdm,sccdm) = sccdm
             and bitand(nvl(b.xsbj,sxsbj),sxsbj) >0
             and nvl(b.xh_id,vXh_id) = vXh_id;

         if (imx > 0 and icount_mx <= 0) or (ixz > 0 and icount_xz > 0 ) then
           sFhbj := '0';--被限制
         else
           sFhbj := '1';--被面向
         end if;
       end if;

       if sFhbj='1' then
         for v_tjxh in v_tjxhs loop
             sTjxx := get_fxtj(vXnm,vXqm,vNjdm_id,vZyh_id,vXh_id,v_tjxh.tjz,v_tjxh.tjz1,v_tjxh.tjz2,v_tjxh.tjxh,vbmlbdm);
             if sTjxx is not null then
                sFhjg := sFhjg||sTjxx;
                sFhbj := '0';
                Goto Exend;
             end if;
         end loop;
       else
         sFhjg := '您已被限制报名该辅修！';
       end if;
       <<Exend>>
       return sFhbj||'/'||sFhjg;
end get_fxbmzt;

/

