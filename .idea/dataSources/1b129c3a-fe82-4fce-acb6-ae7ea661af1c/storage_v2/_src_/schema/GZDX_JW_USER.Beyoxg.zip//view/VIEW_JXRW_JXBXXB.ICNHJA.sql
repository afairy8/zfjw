create view VIEW_JXRW_JXBXXB as
  select (case when zrs>yxkrs then '0' else '1' end) sfyxm,t2."ZRS",t2."YXKRS",t2."KCH_ID",t2."JXB_ID",t2."JXBMC",t2."XQH_ID",t2."JXBRS",t2."SFXKBJ",t2."XNM",t2."XQM",t2."SKSJ",t2."JXDD",t2."SKFSDM",t2."SFSYKJSK",t2."APKSFSDM",t2."PKXQ",t2."MXDX",t2."FJXB_ID",t2."XSDM",t2."KKZT",t2."JXMS",t2."QSZ",t2."ZZZ",t2."ZHXS",t2."KKLXDM",t2."KRRL",t2."CDLB_ID",t2."CDEJLB_ID",t2."RWXSSFCF",t2."XSFPSFCF",t2."SFGCGL",t2."RWZXS",t2."SXBJ",t2."CJLRJB",t2."BZ",t2."SHZT",t2."SHSJ",t2."SHRJGH_ID",t2."ZYJSBJ",t2."CJLRZT",t2."CJLRKSSJ",t2."CJLRJSSJ",t2."CJLRJGH_ID",t2."YXZRS",t2."BXRS",t2."KSMCDMB_ID",t2."JSRL",t2."YL",t2."CJSFABLLR",t2."CXBMKG",t2."LRKSSJ",t2."CJLRXNM",t2."CJLRXQM",t2."ZYSFBJ",t2."JSXX",t2."SFKXK",t2."SKSJMS",t2."DXQM",t2."SFZJXB",t2."XF",t2."KKBM_ID",t2."KSFSDM",t2."KHFSDM",t2."QSJSZ" from
(select nvl(jxbrs,0)+nvl(krrl,0) zrs,(select count(*) from jw_xk_xsxkb where jxb_id=t1.jxb_id) yxkrs,
t1.* from JW_JXRW_JXBXXB t1 where krrl is not null) t2
/

