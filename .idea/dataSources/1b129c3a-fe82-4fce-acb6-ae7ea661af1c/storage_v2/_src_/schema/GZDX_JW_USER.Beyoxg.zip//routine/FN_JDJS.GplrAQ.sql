create function fn_jdjs  ----单门课程绩点返回（存在不计算绩点返回为NULL"即无绩点"）
(vXnm        in varchar2,  ---学年码
 vXqm        in varchar2,  ---学期码
 vSskch_id   in varchar2,  ---所属课程号ID
 vKch_id     in varchar2,  ---课程号ID
 vKcmc       in varchar2,  ---课程名称
 vJxb_id     in varchar2,  ---教学班
 vXh_id      in varchar2,  ---学号ID
 vKcxzdm     in varchar2,  ---课程性质代码
 vKclbdm     in varchar2,  ---课程类别代码
 vCjxzm      in varchar2,  ---成绩性质码
 vKcbj       in varchar2,  ---课程标记
 vJzdm       in varchar2,  ---级制代码
 vCjbz       in varchar2,  ---成绩备注
 iJd         in number,    ---成绩绩点
 iBfzcj      in number,    ---成绩百分制
 vCjly       in varchar2,  ---成绩来源
 vFs         in varchar2,  ---方式（xs显示、tj统计）
 vBj         in varchar2)  ---标记默认为0，如有特殊再做扩展
return number is
      iCount number;
      sJzdm varchar2(32);
      sKczyxxs varchar2(4);
      iJsjd number;
      sXxdm varchar2(20);
begin
  begin
  select max(xxdm) into sXxdm from zftal_xtgl_xxxxszb where rownum = 1;
  select count(*) into sKczyxxs from jw_jcdml_xtnzb where zdm = 'SFSYKCZYXXS' and zdz = '1' and rownum = 1;---是否使用课程重要性系数
  if vBj = '0' then
    if iJd is null then
      return iJd;
      Goto Exend;
    end if;


    if vFs = 'xs' then  ---显示方式直接返回原绩点
      return iJd;
      Goto Exend;
    end if;
    if vCjly in ('11','22','33','44') then
      return null;
      Goto Exend;
    end if;
   ---'bxwxfrdkc':被校外学分认定的课程；'cjb-dtkc':成绩表代替课程；'cjb-bdtkc':成绩表被代替课程；
   ---'bdtkc':成绩表被代替课程；


    select count(*) into iCount from jw_jh_kcrwszb where sfcjjdjs = '0' and kch_id = vKch_id;  ---当课程不参加绩点计算时判断
    if iCount > 0 then
      return null;
      Goto Exend;
    end if;


    select count(*) into iCount from jw_jh_kcxzdmb where sftjjd = '0' and kcxzdm = vKcxzdm;----当课程性质不统计绩点时判断
    if iCount > 0 then
      return null;
      Goto Exend;
    end if;


    select count(*) into iCount from jw_cj_bzdmb where sfcjjsjd = '0' and cjbzmc = vCjbz;----当成绩备注不统计绩点时判断
    if iCount > 0 then
      return null;
      Goto Exend;
    end if;


    select (case when vCjxzm in ('11','12','21','22')
                  then (select t.cjlrjb from jw_kw_bkmdb t where t.jxb_id = vJxb_id and t.xh_id = vXh_id)
                  else (select t.cjlrjb from jw_jxrw_jxbxxb t where t.jxb_id = vJxb_id)
                  end) into sJzdm from dual;


    select count(*) into iCount from jw_cj_jzdmb                                         ----当成绩级制不统计绩点时判断
    where sfcjjdjs = '0' and jzdm = sJzdm;


    if iCount > 0 then
      return null;
      Goto Exend;
    end if;


    select count(*) into iCount from JW_CJ_DZB                                             ----当前对照成绩不统计绩点时判断
    where to_number(iBfzcj) >= to_number(qsf) and to_number(iBfzcj) <= to_number(jsf) and sfjsjd = '0' and jzdm = sJzdm;


   if iCount > 0 then
      return null;
      Goto Exend;
    end if;


  end if;


  iJsjd := iJd;
  if sKczyxxs = '1' then
    if vCjxzm not in ('16','17','21','22') then
     select
     case when max(nvl(kczyxxs,1)) is null then iJd else max(nvl(kczyxxs,1))*iJd end into iJsjd
      from jw_jh_jxzxjhkcxxb t1,jw_xjgl_xsjbxxb t2
      where t1.njdm_id = t2.njdm_id
        and t1.zyh_id = t2.zyh_id
        and t2.xh_id = vXh_id
        and t1.kch_id = case when length(vSskch_id) = 1 or vSskch_id is null then vKch_id else vSskch_id end
        and rownum = 1;
     end if;
  end if;

  if sXxdm = '10623' then  ---西华大学
   if vCjxzm not in ('16','17','21','22') then
    select nvl(max(case when xbx = 'bx' then 1.0 else 0.8 end),1)*iJd into iJsjd from jw_jh_kcxzdmb where kcxzdm = vKcxzdm;
   end if;
  end if;

  return  iJsjd;
 exception
   WHEN OTHERS THEN
   return iJd;
 end;
  <<Exend>>
  null;
end fn_jdjs;

/

