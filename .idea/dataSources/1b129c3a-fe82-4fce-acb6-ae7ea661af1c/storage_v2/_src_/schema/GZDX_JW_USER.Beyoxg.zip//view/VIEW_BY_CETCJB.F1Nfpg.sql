create view VIEW_BY_CETCJB as
  select rn, xh_id, xmcj, xmbfzcj, xmdm, xmmc
  from (select t1.xh_id,
               t1.xmcj,
               t2.xmdm,
               (select xmmc from jw_jcdm_xmdmb where xmdm = t2.xmdm) xmmc,
               row_number() over(partition by t1.xh_id,t2.xmdm order by to_number(nvl(nvl((select dzb.dyf
                                                                                    from jw_xmgl_xmcjdzb dzb,
                                                                                         jw_xmgl_xmjzdmb jzb
                                                                                   where t2.jfzdm =
                                                                                         jzb.xmjzdm
                                                                                     and jzb.xmjzdm =
                                                                                         dzb.xmjzdm
                                                                                     and dzb.xmcjmc =
                                                                                         t1.xmcj), nvl(t1.xmcj, 0)), 0)) desc) rn,
               to_number(nvl((select dzb.dyf
                               from jw_xmgl_xmcjdzb dzb, jw_xmgl_xmjzdmb jzb
                              where t2.jfzdm = jzb.xmjzdm
                                and jzb.xmjzdm = dzb.xmjzdm
                                and dzb.xmcjmc = t1.xmcj),
                             nvl(t1.xmcj, 0))) xmbfzcj,
               t1.xmbmsz_id,
               t2.jfzdm
          from jw_xmgl_xmxsbmqkb t1, jw_xmgl_xmbmszb t2
         where t1.xmbmsz_id = t2.xmbmsz_id(+)
        )
        where rn=1
/

