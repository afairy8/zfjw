create function fun_by_kcxzsh(v_xh_id varchar2,v_zyh_id varchar2,v_njdm_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_pyfaxx_id varchar2(32);--培养方案
   v_flag varchar2(2);begin
    sJg := '合格';
    begin
    select t.pyfaxx_id into v_pyfaxx_id from jw_jh_pyfaxxb t where t.zyh_id=v_zyh_id
    and exists(select 1 from jw_jh_pyfasynjb nj where nj.pyfaxx_id = t.pyfaxx_id and nj.njdm_id=v_njdm_id);

    ---培养方案课程性质审核，只统计学分分布中的课程性质学分
      with temp as(
           select  e.zgshzt,e.zxf,e.hdxf, e.kcxzmc
        from(
           select e2.hdxf, e1.zxf,e1.kcxzdm kcxzmc,

           decode(sign(nvl(e2.hdxf,0) - e1.zxf), '-1', 'N', '0', 'Y', '1', 'Y') zgshzt
      from (select kcxzdm ,(to_char(nvl(sum(zxf), 0), 'fm99990.09')) zxf from
            (select t.pyfaxx_id,
                   (select kcxzjc from jw_jh_kcxzdmb kcxz where kcxz.kcxzdm = t.kcxzdm) kcxzdm,
                   (to_char(nvl(sum(temp.xf), 0), 'fm99990.09')) zxf,
                   temp.sftj
              from jw_jh_pyfaxfyqxxb t,
                   (select nvl(t2.pyfaxx_id, t1.pyfaxx_id) pyfaxx_id,
                           nvl(t2.xfyqjd_id, t1.xfyqjd_id) xfyqjd_id,
                           nvl(t2.xq, t1.xq) xq,
                           nvl(t2.xf, t1.xf) xf,
                           t2.sftj
                      from (select t.pyfaxx_id,
                                   t.xfyqjd_id,
                                   t.xq,
                                   nvl(sum(xf), 0) xf
                              from (select t1.pyfaxx_id,
                                           t1.xfyqjd_id,
                                           to_number(nvl((select t3.xf
                                                           from jw_jh_kcdmb t3
                                                          where t3.kch_id =
                                                                t2.kch_id),
                                                         '0')) xf,
                                           t2.jyxdnjdm || '-' || t2.jyxdxqm xq
                                      from jw_jh_pyfaxfyqxxb t1, jw_jh_pyfakcxxb t2
                                     where t1.xfyqjd_id = t2.xfyqjd_id(+)
                                       and t1.pyfaxx_id = v_pyfaxx_id) t
                             group by t.pyfaxx_id, t.xfyqjd_id, t.xq) t1
                      full join (select *
                                  from jw_jh_pyfaxffb
                                 where pyfaxx_id = v_pyfaxx_id) t2 on (t1.pyfaxx_id =
                                                                     t2.pyfaxx_id and
                                                                     t1.xfyqjd_id =
                                                                     t2.xfyqjd_id and
                                                                     t1.xq =
                                                                     t2.xq)) temp

             where temp.xfyqjd_id = t.xfyqjd_id
               and t.pyfaxx_id = v_pyfaxx_id
               and t.xdlx = 'zx'
               and t.sfmjd = '1'
               and temp.sftj = '1'
             group by t.pyfaxx_id, t.kcxzdm, temp.sftj, t.sfmjd)
             group by kcxzdm) e1,
           (select xh_id, kcxzdm, sum(xf) hdxf
              from
              (select kch_id,xh_id,bfzcj,(select kcxzjc from jw_jh_kcxzdmb kcxz where kcxz.kcxzdm = t.kcxzdm)kcxzdm,xf from
              (select a.kch_id, a.xh_id, max(a.bfzcj) bfzcj, a.kcxzdm, a.xf
                      from jw_cj_xscjb a
                     where xh_id = v_xh_id
                     and kcbj='0'
                     and bfzcj >= 60
                     and not exists(select 1 from jw_cj_xsgrdtzb t1,jw_cj_xsgrcjdtb tt where t1.zszt = '3' and t1.kcthzh_id = tt.kcthzh_id and tt.jxb_id = a.jxb_id and tt.xh_id=v_xh_id)---替代
                     and not exists(select 1 from jw_cj_xsgrdtzb t1,jw_cj_xsgrjhdtb bb where t1.zszt = '3' and t1.kcthzh_id = bb.kcthzh_id and bb.kch_id = a.kch_id and bb.xh_id=v_xh_id)--被替代
                     group by a.xh_id, a.kch_id, a.kcxzdm, a.xf

             union all
            /* select t2.kch_id,t2.xh_id,null bfzcj,fun_getkcxzdm(t2.xh_id,t2.kch_id,'kcxz') as kcxzdm,
                    fun_getkcxzdm(t2.xh_id,t2.kch_id,'xf') as xf from
                           jw_cj_xsgrdtzb t1, jw_cj_xsgrjhdtb t2 where t1.zszt = '3'
                                                                   and t1.kcthzh_id = t2.kcthzh_id
                                                                   and t2.xh_id = v_xh_id*/

              select t2.kch_id,
                     t2.xh_id,
                     t3.bfzcj,
                     t4.kcxzdm,
                     to_char(nvl(t4.xf,t3.xf))xf
                from jw_cj_xsgrdtzb t1, jw_cj_xsgrcjdtb t2 ,jw_cj_xscjb t3, jw_cj_xsgrjhdtb t4
               where t1.zszt = '3'
                 and t1.kcthzh_id = t2.kcthzh_id
                 and t1.kcthzh_id = t4.kcthzh_id
                 and t3.xh_id = t2.xh_id
                 and t3.jxb_id = t2.jxb_id
                 and t2.xh_id = v_xh_id
              )t)
             group by xh_id, kcxzdm) e2
             where e1.kcxzdm = e2.kcxzdm(+)
             order by e1.kcxzdm

             )e

             union  all
             select 'Y','0',sum(xf) hdxf,'辅修'
                  from (select row_number() over(partition by xh_id, kch_id order by nvl(bfzcj, 0) desc) rn,
                               xh_id,
                               kch_id,
                               nvl(xf, '0') xf,
                               nvl(bfzcj, 0) bfzcj
                          from jw_cj_xscjb
                         where kcbj in ('1', '2', '3'))
                 where rn = '1'
                   and bfzcj >= 60
                   and xh_id = v_xh_id
    )
    select nvl(wm_concat(kcxzmc||'不合格(应获'||zxf||'分，实获'||hdxf||'分)'),'合格') into sJg from (
    select distinct zgshzt,zxf,hdxf,nvl(kcxz.kcxzjc,kcxz.kcxzmc)kcxzmc from temp,jw_jh_kcxzdmb kcxz
    where  nvl(kcxz.kcxzjc,kcxzdm) = temp.kcxzmc
    and (kcxz.kcxzhbshbj is null or (instr(kcxz.kcxzhbshbj,temp.kcxzmc)>0 and instr(kcxz.kcxzhbshbj,'sh')>0 ))
    union all
    select (case when sum(hdxf)>=sum (zxf) then 'Y' else 'N' end)zgshzt,to_char(sum (zxf))zxf,sum(hdxf)hdxf,wm_concat(kcxzmc)||'总和' kcxzmc from(
    select distinct zxf,hdxf,a.kcxzmc from temp a ,jw_jh_kcxzdmb kcxz
    where instr(kcxz.kcxzhbshbj||'辅修',a.kcxzmc)>0
    )
   )
    where zgshzt='N';
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_kcxzsh;

/

