create function fun_by_zkcjxdblsh(v_xh_id varchar2,v_tjsjz varchar2, v_lx varchar2,
v_tjkcxz varchar2,v_btjkc varchar2,v_xdlx varchar2,v_tjsjmc varchar2) return varchar2
as
   sJg varchar2(2000);-----计划课程成绩合格判断
   sqlstr varchar2(4000);
   v_xdlx_temp varchar2(5000);
   v_count number;---数量
   v_bl number;--比例
begin
    sJg := '合格';
    begin

          sqlstr :='select nvl(sum(t.xf),0) from jw_jh_xsjxzxjhkcxxb t, jw_jh_xsjxzxjhxfyqxxb t1, jw_jh_jxzxjhkcxxb t2
          where t.xfyqjd_id =t1.xfyqjd_id  and t2.xfyqjd_id = t1.xfyqjd_id  and t.kch_id = t2.kch_id  and t.xh_id = t1.xh_id
           and nvl(t.bfzcj, 0) < 60 and t.xh_id='''||v_xh_id||'''';


           sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = t.kch_id and c.zyh_id = b.zyh_id and
           c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''') ';

      --课程性质
      if v_tjkcxz is not null and v_tjkcxz!='qb' then
         sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||t1.kcxzdm||'','' )>0 ';
      end if;

      --修读类型
      if v_xdlx is not null and v_xdlx!='qb' then
        v_xdlx_temp:= ' AND EXISTS (select 1 from (SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxb xfyq,JW_JH_xsJXZXJHKCXXB kcxx'||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id union all '||
                      ' SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxfxezyb xfyq,Jw_Jh_Xsjxzxjhkcxxfxezyb kcxx '||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id) a '||
                      ' WHERE a.XH_ID=t.XH_ID  AND a.KCH_ID=nvl(t.sskch_id,t.KCH_ID) AND ('||

                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 ))';
          sqlstr:= sqlstr||v_xdlx_temp;

       end if;

       --不统计课程
       if v_btjkc is not null then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||t.kch_id||'','' )<1 ';
       end if;

       execute immediate sqlstr into v_count;

       sqlstr:='select case when '||v_count||'=0 then ''0'' else  to_char(('||v_count||'/yqzdxf*100),''fm9999999990.00'')  end
       from (select yqzdxf from jw_jh_xsjxzxjhxfyqxxb a where a.fxfyqjd_id is null and a.xh_id='''||v_xh_id||''' )';
       execute immediate sqlstr into v_bl;

         if to_number(v_bl) >to_number(v_tjsjz) then
            sJg:= '(计划课程正考不及格学分/毕业要求学分)为'||v_bl||'%,大于'||v_tjsjz||'%,不合格！';
         else
            sJg:= '(计划课程正考不及格学分/毕业要求学分)为'||v_bl||'%,合格！';
         end if;
       exception
      When others then
        sJg := '查询出错，不合格！';
  end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_zkcjxdblsh;

/

