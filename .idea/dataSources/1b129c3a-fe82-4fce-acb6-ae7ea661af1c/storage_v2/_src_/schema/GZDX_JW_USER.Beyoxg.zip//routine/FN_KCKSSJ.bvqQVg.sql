create function fn_kckssj(vJxb_id varchar2) return varchar2 /**---课程开始时间----**/
 as
  sSjxx        varchar2(32); /**---返回的时间信息**/
  v_xnm        varchar2(32); /**---学年标记**/
  v_xqm        varchar2(32); /**---学年标记**/
  v_section    varchar2(32); /**---节次信息**/
  v_TimePrefix varchar2(32); /*时间前缀*/
  v_xiaoq      varchar2(32);
begin
  sSjxx := '';
  begin

    --获取时间前缀
    select xqh_id, rq,(case when instr(jc,',')>0 then substr(jc,instr(jc,',')+1,length(jc)-instr(jc,',')) else jc end),xnm,xqm
      into v_xiaoq, v_TimePrefix, v_section,v_xnm,v_xqm
      from (select row_number() over(partition by s.jxb_id order by b.rq asc, to_number(replace(substr(fn_bittozc(s.jc*2), -2), ',', '')) asc) rn,
                   jxb.xqh_id,
                   b.rq,
                   fn_bittozc(s.jc * 2)as jc,
                   jxb.xnm,
                   jxb.xqm
              from jw_pk_xlb      a,
                   jw_pk_rcmxb    b,
                   jw_jxrw_jxbxxb jxb,
                   jw_pk_kbsjb    s
             where a.xl_id = b.xl_id
               and a.xnm = jxb.xnm
               and a.xqm = jxb.xqm
               and s.xnm = jxb.xnm
               and s.xqm = jxb.xqm
               and jxb.jxb_id = s.jxb_id
               and s.jxb_id = vJxb_id
               and b.xqj = s.xqj
               and bitand(power(2, b.dxqzc - 1), s.zcd) > 0)
     where rn = '1';

    sSjxx := v_TimePrefix;
  exception
    When others then
      sSjxx := '';
  end;
  return sSjxx;
end fn_kckssj;

/

