create function Get_Xqjxx(vXqj in varchar2,vbj in integer) return varchar2 as
---vbj = 0 表示集中优先排时间反之分散优先排时间（以隔一天为最优处理）
  i int;
  k int;
  ayjys varchar2(100);
  aejys varchar2(100);
  asjys varchar2(100);
  ashjys varchar2(100);
  ------------------------
  yjys varchar2(100);
  ejys varchar2(100);
  sjys varchar2(100);
  jgys varchar2(100);
  jgys1 varchar2(100);
  ------------------------
  areturn varchar2(100);
begin
  if vXqj is null then
    return '';
  end if;
    ayjys := '';
    aejys := '';
    asjys := '';
    ashjys := '';

    yjys := '';
    ejys := '';
    sjys := '';
    jgys :='';
  if fn_jsfgfs(vXqj,',') = 0 then
   for i in 1..5 loop
     if abs(vXqj - i) = 2 and
        instr(vXqj,i)<= 0 and
        abs(vXqj - i)>= 1 and
        abs(vXqj - i) <= 5 then
        if ayjys is null then
          ayjys := i;
          else
          ayjys := ayjys||','||i;
          end if;
       end if;

      if abs(vXqj - i) = 1 and
        instr(vXqj,i)<= 0 and
        abs(vXqj - i)>= 1 and
        abs(vXqj - i) <= 5 then
        if aejys is null then
          aejys :=  i;
          else
          aejys := aejys||','||i;
        end if;
       end if;

       if abs(vXqj - i) = 0  then
        if asjys is null then
          asjys := i;
          else
          asjys := asjys||','||i;
        end if;
       end if;

       if abs(vXqj - i) > 2 and
        instr(vXqj,i)<= 0 and
        abs(vXqj - i)>= 1 and
        abs(vXqj - i) <= 5 then
        if ashjys is null then
          ashjys := i;
          else
          ashjys := ashjys||','||i;
        end if;
       end if;
   end loop;
   jgys1 :=ayjys;
   else
   for i in 1..5 loop
     if instr(vXqj,i) = 0 then
       if ayjys is null then
       ayjys :=  i;
       else
       ayjys := ayjys||','||i;
       end if;
      else
       if asjys is null then
         asjys := i;
         else
           asjys := asjys||','||i;
       end if;
      end if;
   end loop;

   k := fn_jsfgfs(ayjys,',');
   while k >= 0 loop
      if fn_jqzd(ayjys,',',k+1) < 3 then
        i := 0;
          while i <=fn_jsfgfs(vXqj,',') loop
          if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) = 2 and
             instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0 then
             if yjys is null then
               yjys := fn_jqzd(ayjys,',',k+1);
             else
                yjys := yjys||','||fn_jqzd(ayjys,',',k+1);
             end if;

             if yjys is not null then
             jgys := jgys||','||yjys;
             end if;

             end if;
          if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) = 1 and
             instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0 then
             if ejys is null then
               ejys := fn_jqzd(ayjys,',',k+1);
             else
                ejys := ejys||','||fn_jqzd(ayjys,',',k+1);
             end if;

             if ejys is not null then
              jgys := jgys||','||ejys;
             end if;

             end if;
          if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) > 2 and
             instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0  then
             if sjys is null then
               sjys := fn_jqzd(ayjys,',',k+1);
             else
                sjys := sjys||','||fn_jqzd(ayjys,',',k+1);
             end if;
            if sjys is not null then
            jgys := jgys||','||sjys;
            end if;
          end if;
          i := i + 1;
        end loop;
        else
        i :=fn_jsfgfs(vXqj,',');
      while i >=0 loop
        if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) = 2 and
           instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0 then
           if yjys is null then
             yjys := fn_jqzd(ayjys,',',k+1);
           else
              yjys := yjys||','||fn_jqzd(ayjys,',',k+1);
           end if;

           if yjys is not null then
           jgys := jgys||','||yjys;
           end if;

           end if;
        if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) = 1 and
           instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0 then
           if ejys is null then
             ejys := fn_jqzd(ayjys,',',k+1);
           else
              ejys := ejys||','||fn_jqzd(ayjys,',',k+1);
           end if;

           if ejys is not null then
            jgys := jgys||','||ejys;
           end if;

           end if;
        if abs(fn_jqzd(ayjys,',',k+1) - fn_jqzd(vXqj,',',i+1)) > 2 and
           instr(nvl(jgys,0),fn_jqzd(ayjys,',',k+1)) = 0  then
           if sjys is null then
             sjys := fn_jqzd(ayjys,',',k+1);
           else
              sjys := sjys||','||fn_jqzd(ayjys,',',k+1);
           end if;
          if sjys is not null then
          jgys := jgys||','||sjys;
          end if;
        end if;
        i := i - 1;
      end loop;
      end if;
      k := k -1;
   end loop;

   ----------------------------------
  jgys := '';
  if vbj = 0 then
    if ejys is not null then
      if jgys is null then
      jgys :=ejys;
      else
      jgys := jgys||','||ejys;
      end if;
    end if;

    if yjys is not null then
       if jgys is null then
       jgys := yjys;
       else
       jgys := jgys||','||yjys;
       end if;
    end if;

    if sjys is not null then
      if jgys is null then
       jgys := sjys;
       else
       jgys := jgys||','||sjys;
      end if;
    end if;


  else
    if yjys is not null then
       if jgys is null then
       jgys := yjys;
       else
       jgys := jgys||','||yjys;
       end if;
    end if;

    if sjys is not null then
       if jgys is null then
         jgys := sjys;
        else
         jgys := jgys||','||sjys;
       end if;
     end if;

    if ejys is not null then
       if jgys is null then
        jgys :=ejys;
        else
        jgys := jgys||','||ejys;
       end if;
    end if;

   end if;

   if jgys is not null then
    jgys1 := jgys;
   end if;
  ----------------------------------
  end if;


  if vbj = 0 then ---------------同天优邻天次之隔天再次之超出天再次之

  if asjys is not null then
      if areturn is null then
      areturn := asjys;
      else
      areturn := areturn||','||asjys;
      end if;
  end if;

  if aejys is not null then
      if areturn is null then
       areturn := aejys;
      else
       areturn := areturn||','||aejys;
      end if;
  end if;

  if jgys1 is not null then
     if areturn is null then
       areturn := jgys1;
     else
       areturn := areturn||','||jgys1;
     end if;
  end if;

  if ashjys is not null then
      if areturn is null then
      areturn := ashjys;
      else
      areturn := areturn||','||ashjys;
      end if;
   end if;

  else
  ---------------隔天优邻天次之同天再次之超出天再次之
  if jgys1 is not null then
     if areturn is null then
       areturn := jgys1;
     else
       areturn := areturn||','||jgys1;
     end if;
  end if;

  if ashjys is not null then
      if areturn is null then
      areturn := ashjys;
      else
      areturn := areturn||','||ashjys;
      end if;
   end if;

  if aejys is not null then
      if areturn is null then
       areturn := aejys;
      else
       areturn := areturn||','||aejys;
      end if;
  end if;

  if asjys is not null then
      if areturn is null then
      areturn := asjys;
      else
      areturn := areturn||','||asjys;
      end if;
  end if;

  ---------------
  end if;
  return(areturn||',6,7');
end Get_Xqjxx;


/

