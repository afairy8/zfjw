create view V_JH_JXRW as
  select jxb.jxb_id,kc.kcmc,kc.xf,kc.xf||'-0.0('||jxb.qsz||'-'||jxb.zzz||'周)' qzz,kc.zxs,jk.zxs jk_zxs,sy.zxs sy_zxs,sj.zxs sj_zxs,jxb.jxbmc,jxb.jxbrs,kc.bz from
jw_jxrw_jxbxxb jxb,jw_jxrw_jxbjsrkb rk,jw_jh_kcdmb kc,
(select kch_id,xsdm,zxs from JW_JH_KCXSDZB
where xsdm = '01') jk,
(select kch_id,xsdm,zxs from JW_JH_KCXSDZB
where xsdm = '02') sy,
(select kch_id,xsdm,zxs from JW_JH_KCXSDZB
where xsdm = '04') sj
where
    jxb.jxb_id = rk.jxb_id
and jxb.kch_id = kc.kch_id
and kc.kch_id = jk.kch_id(+)
and kc.kch_id = sy.kch_id(+)
and kc.kch_id = sj.kch_id(+)
/

