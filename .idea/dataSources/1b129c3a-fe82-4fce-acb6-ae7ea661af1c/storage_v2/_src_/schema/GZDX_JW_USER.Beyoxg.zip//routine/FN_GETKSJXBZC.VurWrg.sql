create function fn_getKsjxbzc(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_apfs in varchar2,v_cd_id in varchar2)-----获取考试教学班组成
return varchar2 is
    v_sfbk number; --是否补考
    v_jxbzc varchar2(2000):= ''; --教学班组成
begin
     select count(1) into v_sfbk from jw_kw_ksmcdmb ksmc where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12');
     if v_apfs='0' and v_sfbk=0 then --按试卷且不是补考
         select wm_concat(zcxx) into v_jxbzc from(
         select distinct fn_jxbzh(dzb.jxb_id, 0) zcxx from jw_kw_ksmcjxbdzb dzb
         where dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id and dzb.xnm=v_xnm and dzb.xqm=v_xqm);
     end if;
     if v_apfs='1' then --按行政班
         select wm_concat(zcxx) into v_jxbzc from(
         select distinct bj.bj zcxx from zftal_xtgl_bjdmb bj,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
         where t3.bh_id=bj.bh_id and t3.kshkbj_id=t4.kshkbj_id
           and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
           and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm);
     end if;
     if v_apfs='2' and v_sfbk=0  then --按教学班且不是补考
         select wm_concat(zcxx) into v_jxbzc from(
         select distinct fn_jxbzh(t3.jxb_id, 0) zcxx from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
         where t3.kshkbj_id=t4.kshkbj_id
           and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
           and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm);
     end if;
     if v_apfs='3' then --按学院
        v_jxbzc := '';
     end if;
     return v_jxbzc;
end fn_getKsjxbzc;

/

