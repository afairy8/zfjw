create function fun_byysh_hdxfsh(v_xh_id varchar2) return varchar2
as
sJg varchar2(2000);   ---(毕业要求学分—实践平台学分)<=(学生修读获得学分（不包含实践平台学分）+除实践平台课程外的在修学分）
v_flag int;
v_byyqxf number;----毕业要求学分
v_sjkxf number;----实践平台学分
v_xfhdxf number;----学生修读获得学分（不包含实践平台学分）
v_zxxf number;---在修学分
begin
sJg := '合格';
begin
	select  nvl(t.yqzdxf,0),nvl(t.hdxf,0) into v_byyqxf, v_xfhdxf from  JW_JH_XSJXZXJHXFYQXXYSHB t  where t.xh_id = v_xh_id and t.fxfyqjd_id is null;
	select  nvl(sum(t.hdxf),0) into v_sjkxf from  JW_JH_XSJXZXJHXFYQXXYSHB t  where t.xh_id = v_xh_id  and t.kcxzdm='06' and t.sfmjd='1' ;

	select nvl(sum(xf),0) into v_zxxf from JW_JH_XSJXZXJHKCXXYSHB t where t.xh_id =  v_xh_id
	and exists(select 1 from jw_xk_xsxkb a where a.xh_id = v_xh_id and t.kch_id = a.kch_id )
	and (t.bfzcj is null or t.cjbz is null)
	and t.kcxzdm <>'06';

	if ((v_byyqxf-v_sjkxf)<=((v_xfhdxf-v_sjkxf)+v_zxxf)) then

	   sJg := '(毕业要求学分'||v_byyqxf||'—实践平台学分'||v_sjkxf||')<=(学生修读获得学分(不包含实践平台学分)'||(v_xfhdxf-v_sjkxf)||
	   '+除实践平台课程外的在修学分'||v_zxxf||'),'||(v_byyqxf-v_sjkxf)||'<='||((v_xfhdxf-v_sjkxf)+v_zxxf)||',合格!';
	else
	  sJg := '(毕业要求学分'||v_byyqxf||'—实践平台学分'||v_sjkxf||')>(学生修读获得学分(不包含实践平台学分)'||(v_xfhdxf-v_sjkxf)||
	   '+除实践平台课程外的在修学分'||v_zxxf||'),'||(v_byyqxf-v_sjkxf)||'>'||((v_xfhdxf-v_sjkxf)+v_zxxf)||',不合格!';
	end if;

 exception
	When others then
	  sJg := '查询出错，不合格！';
 end;
if sJg is null then
 return '系统无数据，不合格！' ;
else
return sJg ;
end if ;
end fun_byysh_hdxfsh;

/

