create function fun_by_dxyykysh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---大学英语4成绩>=60且口语通过
   v_count number;  --外语四级个数
   v_dxyycj number;     --外语成绩
   v_kycj number;     --口语成绩
begin
    sJg := '合格';
    begin
    select count(1), max(a.xmcj) into v_count, v_dxyycj
      from (select cj.*,
                   row_number() over(partition by cj.xh_id order by nvl(cj.xmcj, '0') desc) rn
              from jw_cj_xmcjb cj, jw_jh_kcdmb kc
             where cj.xh_id = ''||v_xh_id||''
               and cj.kch_id = kc.kch_id
               and kc.kcmc = '大学英语4'
               and cj.xmbl_id in ('QMCJ', 'ks_cjfx')
            ) a
     where rn = 1;

    if v_count = 0 then
       sJg :='无大学英语4卷面成绩，不合格！';
    else
       if v_dxyycj<60 then
           sJg :='大学英语4卷面成绩'||v_dxyycj||',不合格！';
       else
           sJg :='大学英语4卷面成绩'||v_dxyycj||'！';
       end if;
    end if;

    select count(1),max(a.bfzcj) into v_count, v_kycj from (
            select cj.*, row_number() over(partition by cj.xh_id order by nvl(cj.BFZCJ,'0') desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id = ''||v_xh_id||''
            and cj.kcmc='大学英语4口语'
            )a where rn=1
            ;

    if v_count = 0 then
       sJg :=sJg||'无大学英语4口语成绩，不合格！';
    else
       if v_kycj<60 then
           sJg :=sJg||'大学英语4口语成绩'||v_kycj||',不合格！';
       end if;
    end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if;
end fun_by_dxyykysh;

/

