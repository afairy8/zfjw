create function fn_jxbcdapqk(iypsjzxs number,iypcdzxs number) return varchar2  ---教学班场地安排情况
as
begin
   return (case when iypcdzxs=0 then '未排' when iypcdzxs>=iypsjzxs then '已排' else '部分' end);
end fn_jxbcdapqk;

/

