create function Get_Kscc
(vXnm varchar2,
 vXqm varchar2,
 vKsmcdmb_id varchar2,
 vSjbh_id varchar2,
 vKsccb_id varchar2,
 vKsrq varchar2,
 vKskssj varchar2,
 vKsjssj varchar2,
 vBj  varchar2) return varchar2
as
 sKscc varchar(32);
begin
 if vBj = '1' then---默认取考试场次（按当前考试场次日期内开始考试时间排序取值）
  select min(rn) into sKscc from (
  select t.*,dense_rank() over (partition by 1 order by kskssj ) rn from
           jw_kw_ksccb  t where t.xnm = vXnm
                            and t.xqm = vXqm
                            and t.ksrq = vKsrq
                            ) where kskssj = vKskssj;
 end if;
 return sKscc;
end Get_Kscc;

/

