create function get_fxtj(v_xnm varchar2,
                                         v_xqm varchar2,
                                         v_njdm_id varchar2,
                                         v_zyh_id varchar2,
                                         v_xh_id varchar2,
                                         v_tjz varchar2,
                                         v_tjz1 varchar2,
                                         v_tjz2 varchar2,
                                         v_tjxh number,
                                         vbmlbdm varchar2)
Return varchar2
as
     sFhjg varchar2(2000); -- 返回结果
     sfx varchar2(10); -- 辅修课程总学分
     sBjgkcs varchar2(10); -- 不及格课程数
     sXnxqmc varchar2(200); -- 学年学期名称
     sXnxqmc1 varchar2(200); -- 学年学期名称1
     sKcxzmc varchar2(200); -- 学年学期名称
     sPjxfjd number; --平均学分绩点
     sCfjls number; -- 处分记录数
     sFhnjs number; -- 符合年级数
     sPjcj number;--平均成绩
begin

     case v_tjxh
          when 1 then

                  if v_tjz!='-1' then
                     select Get_Fxcjtj('1',v_xnm,v_xqm,v_xh_id,'',v_tjz,v_tjz1,'0') into sfx from dual;
                     if to_number(nvl(sfx,'0')) < to_number(v_tjz) then
                        sFhjg := '辅修课程获得总学分：'||nvl(sfx,'0')||'小于辅修条件设置值：'||v_tjz||'，您不符合报名条件！';
                     end if;
                  end if;

          when 2 then--正考成绩不及格
                  select Get_Fxcjtj('2',v_xnm,v_xqm,v_xh_id,'',v_tjz,v_tjz1,'0') into sBjgkcs from dual;
                  if sBjgkcs > 0 then
                     if v_tjz!='-1' and v_tjz1!='-1' then
                        select a.xnmc||'-'||b.mc into sXnxqmc from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz;
                        select a.xnmc||'-'||b.mc into sXnxqmc1 from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz1;
                        sFhjg := '学年学期'||sXnxqmc||'到学年学期'||sXnxqmc1||'存在不及格课程，不符合报名条件。';
                     else
                        sFhjg := '存在不及格课程，不符合报名条件。';
                     end if;
                  end if;
         when 3 then--存在不及格课程
                 select (case when count(*)>0 then (case when count(*)=sum(jgs) then 0 else 1 end) else 1 end) into sBjgkcs from
                 (select max(a.bfzcj) bfzcj, a.jxb_id, a.kch_id, (case when max(a.bfzcj)<60 then '0' else '1' end) jgs from jw_cj_xscjb a
                 where a.xh_id = v_xh_id and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end)
                   and ','||v_tjz2||',' like '%,'||a.kcxzdm||',%' group by a.jxb_id, a.kch_id);
                 if sBjgkcs > 0 then
                     if v_tjz!='-1' and v_tjz1!='-1' then
                        select a.xnmc||'-'||b.mc into sXnxqmc from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz;
                        select a.xnmc||'-'||b.mc into sXnxqmc1 from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz1;
                        select wm_concat(a.kcxzmc) into sKcxzmc from jw_jh_kcxzdmb a where ',' || v_tjz2 || ',' like '%,' || a.kcxzdm || ',%';
                        sFhjg := '学年学期'||sXnxqmc||'到学年学期'||sXnxqmc1||'课程性质'||sKcxzmc||'存在不及格课程，不符合报名条件。';
                     else
                        sFhjg := '存在不及格课程，不符合报名条件。';
                     end if;
                 end if;
         when 4 then--所学课程平均绩点需达到
                 select case when nvl(sum(case when t.jd is null then '0' else '1' end ),'0') = '0' then 0 else nvl(round(sum(t.jd)/sum(case when t.jd is null then '0' else '1' end ),2),0) end into sPjxfjd from
                 (select row_number() over(partition by nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) pm, a.kch_id, a.bfzcj,
                        fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,a.cjxzm,a.kcbj,null,a.cjbz,a.jd,a.bfzcj,'cjb','tj','0') as jd, a.xf
                 from jw_cj_xscjb a where  a.xh_id = v_xh_id
                  and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end)) t where pm='1';
                 if v_tjz2 != '-1' and sPjxfjd < v_tjz2 then
                    sFhjg := sFhjg||'课程平均绩点：'||sPjxfjd||'小于条件值'||v_tjz2||'，不符合报名条件。';
                 end if;
         when 5 then--所学主修课程平均学分绩点需达到
               select case when nvl(sum(case when t.jd is null then '0' else t.xf end ),'0') = '0' then 0 else nvl(round(sum(t.jd*t.xf)/sum(case when t.jd is null then '0' else t.xf end ),2),0) end into sPjxfjd from
               (select row_number() over(partition by nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) pm, a.kch_id, a.bfzcj,
                       fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,a.cjxzm,a.kcbj,null,a.cjbz,a.jd,a.bfzcj,'cjb','tj','0') as jd, a.xf
               from jw_cj_xscjb a where a.xh_id = v_xh_id and a.kcbj = '0'
                and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end)) t where pm='1';
               if v_tjz2 != '-1' and sPjxfjd<v_tjz2 then
                  sFhjg := sFhjg||'主修课程平均学分绩点：'||sPjxfjd||'小于条件值'||v_tjz2||'，不符合报名条件。';
               end if;
         when 6 then--存在处分记录
               select count(*) into sCfjls from jw_xjgl_xscfb a where a.xh_id = v_xh_id and (select jb from zftal_xtgl_jcsjb where lx = '0018' and dm=a.cfdm) <= to_number(v_tjz2)
                  and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end);
               if sCfjls > 0 then
                 sFhjg := '存在处分记录，不符合报名条件。';
               end if;
         when 7 then--符合年级
               if v_tjz != '-1' then
                  select count(*) into sFhnjs from jw_xjgl_xsjbxxb a where a.xh_id = v_xh_id and ','||v_tjz||',' like '%,'||a.njdm_id||',%';
                  if sFhnjs = 0 then
                     sFhjg := '不在设置年级范围内，不符合报名条件。';
                  end if;
               end if;
          when 8 then  --平均成绩
            select avg(t.bfzcj) into sPjcj from
            (select row_number() over(partition by nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) pm,a.kch_id,a.bfzcj from jw_cj_xscjb a where  a.xh_id = v_xh_id
                  and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end))t where pm='1';
             select (case when count(*)>0 then (case when count(*)=sum(jgs) then 0 else 1 end) else 1 end) into sBjgkcs from
                 (select  (case when max(a.bfzcj)<60 then '0' else '1' end) jgs from jw_cj_xscjb a
                 where a.xh_id = v_xh_id and (case when v_tjz='-1' then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1='-1' then '999999' else v_tjz1 end)
                    group by  a.kch_id,a.xh_id);
             if v_tjz2 != '-1' and sPjcj < v_tjz2 then
                    sFhjg := sFhjg||'所有科目补考重修后平均分：'||sPjcj||'小于条件值'||v_tjz2||'，不符合报名条件。';
                    else
                    if sBjgkcs > 0 then
                     if v_tjz!='-1' and v_tjz1!='-1' then
                        select a.xnmc||'-'||b.mc into sXnxqmc from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz;
                        select a.xnmc||'-'||b.mc into sXnxqmc1 from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                           and a.xnm||lpad(b.dm,2,'0')=v_tjz1;
                        sFhjg := '学年学期'||sXnxqmc||'到学年学期'||sXnxqmc1||'存在不及格课程，不符合报名条件。';
                     else
                        sFhjg := '存在不及格课程，不符合报名条件。';
                     end if;
                 end if;
               end if;
     end case;
     return sFhjg;
end get_fxtj;

/

