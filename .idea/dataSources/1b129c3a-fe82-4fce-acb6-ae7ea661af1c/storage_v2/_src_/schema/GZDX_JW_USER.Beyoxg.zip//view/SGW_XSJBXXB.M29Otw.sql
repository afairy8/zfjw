create view SGW_XSJBXXB as
  select (select jgmc from zftal_xtgl_jgdmb jg where jg.jg_id=xs.jg_id) zyxy,
       JG_ID, ZYH_ID,BH_ID,NJDM_ID,
		(select jgmc from zftal_xtgl_jgdmb jg where jg.jg_id=xs.zsjg_id) xy,
		(select zymc from zftal_xtgl_zydmb zy where zy.zyh_id=xs.zyh_id) zymc,
		(select bj from zftal_xtgl_bjdmb bj where bj.bh_id=xs.bh_id) bjmc,xh,xh_id,xm,
		(select mc from zftal_xtgl_jcsjb jc where lx='0006'and jc.dm=xs.xbm) xb,
		(select mc from zftal_xtgl_jcsjb jc where lx='0007'and jc.dm=xs.mzm) mz,
		(select mc from zftal_xtgl_jcsjb jc where lx='0008'and jc.dm=xs.zzmmm) zzmm,
		(select mc from zftal_xtgl_jcsjb jc where lx='0028'and jc.dm=xs.xjztdm) xjzt,
		(select mc from zftal_xtgl_jcsjb jc where lx='0014'and jc.dm=xs.pyccdm) cc,njdm_id dqszj,xz,zjhm,
		(select zdxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  yinghdxyxf,
		(select bsfxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  yinghdxyxjf,
		(select zdxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  xyxf,
		(select bsfxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  xyxjf,
		(select dektxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  yinghdzxf,
		(select fxxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  yhdzxjf,
		(select ezyxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  pyfayqzxf,
		(select exwxf  from jw_jh_jxzxjhxxb  jh where jh.zyh_id=xs.zyh_id and jh.njdm_id=xs.njdm_id )  pyfayqzxjf
 from jw_xjgl_xsjbxxb xs
where 1=1 order by xy,zymc,bjmc,xh
/

