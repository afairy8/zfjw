create view VIEW_XKGL_XSXKCX as
  select
t1.jxb_id||'-'||t1.xh_id xkcx_id,
t1.xnm,
(select xnmc from jw_jcdm_xnb where xnm=t1.xnm) xnmc,
t1.xqm,
(select mc from zftal_xtgl_jcsjb where lx = '0001' and dm=t1.xqm) xqmc,
t1.kch_id,
(select kch from jw_jh_kcdmb where kch_id=t1.kch_id) kch,
(select kcmc from jw_jh_kcdmb where kch_id=t1.kch_id) kcmc,
(select kcywmc from jw_jh_kcdmb where kch_id=t1.kch_id) kcywmc,
t1.jxb_id,
t3.jxbmc,
t3.jsxx,
t3.sksj,
t3.jxdd,
t3.kklxdm,
(select kklxmc from JW_JCDM_KKLXDMB where kklxdm=t3.kklxdm) kklxmc,
t1.xksj,
(select xf from jw_jh_kcdmb where kch_id=t1.kch_id) xf,
t3.xqh_id,
(select xqh from zftal_xtgl_xqdmb where xqh_id=t3.xqh_id) xqh,
(select xqmc from zftal_xtgl_xqdmb where xqh_id=t3.xqh_id) xqhmc,
(select kkbm_id from jw_jh_kcdmb where kch_id=t1.kch_id) kkxy_id,
(select jgdm from zftal_xtgl_jgdmb where jg_id=(select kkbm_id from jw_jh_kcdmb where kch_id=t1.kch_id)) kkxydm,
(select jgmc from zftal_xtgl_jgdmb where jg_id=(select kkbm_id from jw_jh_kcdmb where kch_id=t1.kch_id)) kkxymc,
(select kclbdm from jw_jh_kcdmb where kch_id=t1.kch_id) kclbdm,
(select kclbmc from jw_jh_kclbdmb where kclbdm=(select kclbdm from jw_jh_kcdmb where kch_id=t1.kch_id)) kclbmc,'' kcxzdm,
Get_JxbKcxzxx(t1.jxb_id,'0') kcxzmc,
(select kcgsdm from jw_jh_kcdmb where kch_id=t1.kch_id) kcgsdm,
(select kcgsmc from jw_jh_kcgsdmb where kcgsdm=(select kcgsdm from jw_jh_kcdmb where kch_id=t1.kch_id)) kcgsmc,XH_ID,
(select xh from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) xh,
(select xm from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) xm,
(select xbm from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) xbm,
(select mc from zftal_xtgl_jcsjb a where lx='0006' and dm=(select xbm from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) xbmc,
(select jg_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) jg_id,
(select jgdm from zftal_xtgl_jgdmb where jg_id=(select jg_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) jgdm,
(select jgmc from zftal_xtgl_jgdmb where jg_id=(select jg_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) jgmc,
(select zyh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) zyh_id,
(select zyh from zftal_xtgl_zydmb where zyh_id=(select zyh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) zydm,
(select zymc from zftal_xtgl_zydmb where zyh_id=(select zyh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) zymc,
(select njdm_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) njdm_id,
(select njmc from zftal_xtgl_njdmb where njdm_id=(select njdm_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) njmc,
(select bh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) bh_id,
(select bh from zftal_xtgl_bjdmb where bh_id=(select bh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) bjdm,
(select bj from zftal_xtgl_bjdmb where bh_id=(select bh_id from jw_xjgl_xsjbxxb where xh_id=t1.xh_id)) bjmc,
(case when t1.xdbj='0' then '2' when t1.xdbj='1' then '3' when t1.cxbj='1' then '1' else '0' end) xxlx,
(case when t1.xdbj='0' then '补修' when t1.xdbj='1' then '先修' when t1.cxbj='1' then '重修' else '正常' end) xxlxmc,
(select distinct ksrq||' '||kskssj||'-'||ksjssj kssj from jw_kw_ksccb t4 where
 exists (select 'X' from jw_kw_ksmcdmb where sfqmks='1' and ksmcdmb_id=t4.ksmcdmb_id) and ksccb_id=(select ksccb_id from jw_kw_kssjb where sjbh_id=
(select sjbh_id from jw_kw_xsksxxb t5 where exists (select 'X' from jw_kw_ksmcdmb where sfqmks='1' and ksmcdmb_id=t5.ksmcdmb_id) and jxb_id=t1.jxb_id and
xh_id=t1.xh_id))) kssj,
(select cdbh||'('||cdmc||')' from JW_JCDM_CDJBXXB where
cd_id=(select cd_id from jw_kw_xsksxxb t5 where exists (select 'X' from jw_kw_ksmcdmb where sfqmks='1' and ksmcdmb_id=t5.ksmcdmb_id) and
jxb_id=t1.jxb_id and xh_id=t1.xh_id)) ksdd from
jw_xk_xsxkb t1,jw_pk_jxrwb t2,JW_JXRW_JXBXXB t3 where
t1.jxb_id=t2.jxb_id(+) and
t1.jxb_id=t3.jxb_id(+)
/

