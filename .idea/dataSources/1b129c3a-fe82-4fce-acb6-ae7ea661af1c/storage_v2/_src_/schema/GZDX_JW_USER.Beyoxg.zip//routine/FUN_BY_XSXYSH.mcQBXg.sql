create function fun_by_xsxysh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
begin
    sJg := '合格';
    begin
    select wm_concat(sJg) into sJg
      from (select decode(wm_concat(e.xfyqjdmc),
                          '',
                          '节点学分合格',
                          wm_concat(e.xfyqjdmc || '不合格(应获' || e.yqzdxf || '分，实获' ||
                                    nvl(hdxf, 0) || '分)')) as sJg
              from (select *
                      from jw_jh_xsjxzxjhxfyqxxb
                     where xh_id = v_xh_id
                       and sfmjd = '0'
                       and yxjd = '1'
                       and fxfyqjd_id is not null) e
             where zgshzt = 'N'
            union all
            select decode(sign(max(nvl(t.bfzcj, 0)) - 60),
                          '-1',
                          '毕业体育达标' || max(nvl(t.bfzcj, 0)) || '分不合格',
                          '体育达标通过') as sjg
              from jw_jh_xsjxzxjhkcxxb t
             where t.kch_id = '1120005'
               and t.xh_id = v_xh_id);
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_xsxysh;

/

