create function fn_getKsgxyrszb(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2)-----获取考试各学院人数占比
return varchar2 is
    v_sfbk number; --是否补考
    v_gxyrszb varchar2(2000):= ''; --各学院人数占比
begin
    select count(1) into v_sfbk from jw_kw_ksmcdmb ksmc where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12','21','22');
    if v_sfbk>0 then
      select wm_concat(jgmc||':'||round((rs/zrs),2)*100||'%') into v_gxyrszb from (
        select distinct (select f.jgmc from zftal_xtgl_jgdmb f where f.jg_id = e.jg_id) as jgmc,
               count(distinct d.xh_id) over (partition by e.jg_id) as rs,
               count(distinct d.xh_id) over (partition by b.sjbh_id) as zrs
        	from jw_kw_ksmcjxbdzb b,jw_kw_bkmdb d, jw_xjgl_xsxjxxb e
        	  where b.ksmcdmb_id = v_ksmcdmb_id	and b.sjbh_id = v_sjbh_id
        		  and b.jxb_id = d.jxb_id and b.xnm = d.xnm and b.xqm = d.xqm and d.bkqrbj = '1'
        		  and d.xh_id = e.xh_id	and d.xnm = e.xnm and d.xqm = e.xqm
        		  and e.jg_id is not null
      );
    else
      select wm_concat(jgmc||':'||round((rs/zrs),2)*100||'%') into v_gxyrszb from (
        select distinct (select f.jgmc from zftal_xtgl_jgdmb f where f.jg_id = e.jg_id) as jgmc,
               count(distinct d.xh_id) over (partition by e.jg_id) as rs,
               count(distinct d.xh_id) over (partition by b.sjbh_id) as zrs
        	from jw_kw_ksmcjxbdzb b,jw_xk_xsxkb d, jw_xjgl_xsxjxxb e
        	  where b.ksmcdmb_id = v_ksmcdmb_id	and b.sjbh_id = v_sjbh_id
        		  and b.jxb_id = d.jxb_id and b.xnm = d.xnm and b.xqm = d.xqm
        		  and d.xh_id = e.xh_id	and d.xnm = e.xnm and d.xqm = e.xqm
        		  and e.jg_id is not null
      );
    end if;
    return v_gxyrszb;
end fn_getKsgxyrszb;

/

