create function fn_getJysj(vYyxx_id varchar2,vJyfs varchar2,vLocaleKey varchar2) return varchar2--返回借用时间
as
   s_jysj varchar(200):='';--借用时间
begin
   if vJyfs = '0' then --按周次
      if vLocaleKey = 'en_US' then
         select 'Weeks:'||Get_BinaryDescyw(zcd,'')||' '||(select wm_concat(ywmc) from zftal_xtgl_jcsjb where lx='0036' and instr(xqj,dm)>0)||' Section:'||get_jcbinarydesc4(jcd,'') into s_jysj from(
            select sum(distinct zcd) zcd,wm_concat(xqj) xqj,sum(distinct jc) jcd from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id
         );
      else
         select '第'||Get_BinaryDesc(zcd,'周')||' 星期'||replace((select wm_concat(mc) from zftal_xtgl_jcsjb where lx='0036' and instr(xqj,dm)>0),'星期','')||' 第'||get_jcbinarydesc4(jcd,'')||'节' into s_jysj from(
            select sum(distinct zcd) zcd,wm_concat(xqj) xqj,sum(distinct jc) jcd from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id
         );
      end if;
   elsif vJyfs = '1' then--按日期连续
      select min(rq||' '||qssjd)||' ~ '||max(rq||' '||jssjd) into s_jysj from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id;
   elsif vJyfs = '2' then--按日期节次
      if vLocaleKey = 'en_US' then
         select min(rq)||' - '||max(rq)||' ('||'Section:'||get_jcbinarydesc4(sum(distinct jc),'')||')' into s_jysj from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id;
      else
         select min(rq)||' - '||max(rq)||' ('||'第'||get_jcbinarydesc4(sum(distinct jc),'')||'节'||')' into s_jysj from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id;
      end if;
   elsif vJyfs = '3' then--按日期间断
      select min(rq)||' - '||max(rq)||' ('||min(qssjd)||' - '||max(jssjd)||')' into s_jysj from jw_pk_jxcdyuysjb where yyxx_id=vYyxx_id;
   else
      s_jysj := '';
   end if;
   return s_jysj;
end fn_getJysj;

/

