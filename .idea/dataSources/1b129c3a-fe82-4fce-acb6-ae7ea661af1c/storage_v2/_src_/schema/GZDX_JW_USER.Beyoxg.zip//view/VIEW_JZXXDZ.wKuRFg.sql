create view VIEW_JZXXDZ as
  select null as jgh ,null as rszgh from dual
/

