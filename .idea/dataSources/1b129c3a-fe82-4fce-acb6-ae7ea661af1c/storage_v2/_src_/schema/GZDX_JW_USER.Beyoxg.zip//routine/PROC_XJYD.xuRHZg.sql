create procedure proc_xjyd(vXjyd_id in varchar2 ,v_ydsxxnm in varchar2,v_ydsxxqm in varchar2, out_flag out varchar,out_msg out varchar) as
  row_xjyd jw_xjgl_xjydb%rowtype; --学籍异动表行
  nCount   number; --计数
  dqXnm    varchar2(32); --当前学年码
  dqXqm    varchar2(32); --当前学期码
  ydsxxnm  varchar2(32);--异动生效学年码
  ydsxxqm  varchar2(32);--异动生效学期码
begin
  --1.获取学籍异动信息
  select * into row_xjyd from jw_xjgl_xjydb where xjyd_id = vXjyd_id;

  if row_xjyd.ydsxxnm is null or row_xjyd.ydsxxqm is null then
    ydsxxnm:=v_ydsxxnm;
    ydsxxqm:=v_ydsxxqm;
  else
    ydsxxnm:=row_xjyd.ydsxxnm;
    ydsxxqm:=row_xjyd.ydsxxqm;
  end if;

  --2.判断异动生效学年学期 是否已经有学籍信息
  select count(xj.xh_id)
    into nCount
    from jw_xjgl_xsxjxxb xj
   where xj.xh_id = row_xjyd.xh_id
     and xj.xnm = ydsxxnm
     and xj.xqm = ydsxxqm;
 --没有异动生效学年学期的学生学籍信息，返回提示信息
  if nCount = 0 then
     out_flag := '-1';--返回-1
     out_msg := '保存失败，请先生成生效学年学期的学生学籍信息！';
       goto nextOne; --跳出循环
  end if;

  --3.更新学籍信息
  update jw_xjgl_xsxjxxb xj
     set xj.njdm_id = row_xjyd.ydhnjdm_id,
         xj.jg_id   = row_xjyd.ydhjg_id,
         xj.x_id    = row_xjyd.ydhx_id,
         xj.zyh_id  = row_xjyd.ydhzyh_id,
         xj.zyfx_id = row_xjyd.ydhzyfx,
         xj.bh_id   = row_xjyd.ydhbh_id,
         xj.xz      = row_xjyd.ydhxz,
         xj.sfzx    = row_xjyd.ydhsfzx,
         xj.xjztdm  = row_xjyd.ydhxjzt,
         xj.bdzcbj  = row_xjyd.ydhbdzcbj,
         xj.xslbdm  = row_xjyd.ydhxslbdm,
         xj.pyfsdm  = row_xjyd.ydhpyfsdm,
         xj.xszxdm  = row_xjyd.ydhxszxdm
   where xj.xh_id = row_xjyd.xh_id
   --学籍学年学期大于等于生效学年学期
     and xj.xnm||trim(lpad(xj.xqm, 2, '0')) >= ydsxxnm||trim(lpad(ydsxxqm, 2,'0'));

  --4.当前学年码
  select zdz into dqXnm from zftal_xtgl_xtszb where zdm = 'DQXNM';

  --5.当前学期码
  select zdz into dqXqm from zftal_xtgl_xtszb where zdm = 'DQXQM';

  --6.更新学生基本信息
  if dqXnm = ydsxxnm and dqXqm = ydsxxqm then
     update jw_xjgl_xsjbxxb jb
      set jb.njdm_id = row_xjyd.ydhnjdm_id,
          jb.jg_id   = row_xjyd.ydhjg_id,
          jb.x_id    = row_xjyd.ydhx_id,
          jb.zyh_id  = row_xjyd.ydhzyh_id,
          jb.zyfx_id = row_xjyd.ydhzyfx,
          jb.bh_id   = row_xjyd.ydhbh_id,
          jb.xz      = row_xjyd.ydhxz,
          jb.sfzx    = row_xjyd.ydhsfzx,
          jb.xjztdm  = row_xjyd.ydhxjzt,
          jb.bdzcbj  = row_xjyd.ydhbdzcbj,
          jb.xslbdm  = row_xjyd.ydhxslbdm,
          jb.pyfsdm  = row_xjyd.ydhpyfsdm,
          jb.xszxdm  = row_xjyd.ydhxszxdm
      where jb.xh_id = row_xjyd.xh_id;
  end if;

  --7.更新学生用户表所在部门
  update zftal_xtgl_yhb yh
     set yh.jgdm = row_xjyd.ydhjg_id
    where yh.yhm = (select xh from jw_xjgl_xsjbxxb where xh_id =  row_xjyd.xh_id) and row_xjyd.ydhjg_id is not null;
  <<nextOne>>
  if out_flag = '-1' then
       rollback;
  else
     out_msg := '保存成功！';
    end if;
end;

/

