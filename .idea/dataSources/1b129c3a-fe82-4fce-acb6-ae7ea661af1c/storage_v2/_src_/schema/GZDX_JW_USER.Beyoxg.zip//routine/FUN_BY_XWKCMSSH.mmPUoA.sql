create function fun_by_xwkcmssh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---学位课程门数(成绩>=65)/学位课程总数
   v_xwtgms number;
   v_xwzms number;
   v_bl varchar2(6);
begin
    sJg := '合格';
    begin
        select count(1) into v_xwzms from jw_jh_jxzxjhkcxxb c

            where  exists (select 1 from jw_xjgl_xsjbxxb b where
             c.zyh_id = b.zyh_id
             and c.njdm_id = b.njdm_id
             and b.xh_id = ''||v_xh_id||'' and c.zyzgkcbj = '1');

            select count(1) into v_xwtgms from (
            select cj.*, row_number() over(partition by cj.xh_id, cj.kch_id order by nvl(cj.BFZCJ,'0') desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id = ''||v_xh_id||''
            ) a where rn=1
            and a.bfzcj>=65
            and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where
             c.zyh_id = b.zyh_id
             and c.njdm_id = b.njdm_id
             and b.xh_id = a.xh_id
             and c.kch_id = a.kch_id
             and b.xh_id = ''||v_xh_id||''
             and c.zyzgkcbj = '1');
         select to_char(v_xwtgms/v_xwzms,'fm9999999990.00') into v_bl  from dual;
         if to_number(v_bl)<to_number(v_tjsjz) then
            sJg:= '学位课程通过门数'||v_xwtgms||'和学位课程总数'||trunc(v_xwzms,0)||'比例'||v_bl||'小于'||v_tjsjz||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_xwkcmssh;

/

