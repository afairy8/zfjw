create procedure proc_jsjxrljc(vJsjxrl_id_orig in varchar2 ,
                                          vJsjxrl_id_dest in varchar2,
                                          vJxb_id in varchar2,
                                          vXnm in varchar2,
                                          vXqm in varchar2,
                                          vJgh_id in varchar2,
                                          vJsjxrlfs in varchar2) as
vCount varchar2(100);
vJsjxrl_id varchar2(32);
kc_orig varchar2(100);
kc_dest varchar2(100);
begin
   select count(*) into vCount from jw_jh_jsjxrl where jxb_id = vJxb_id;
   vJsjxrl_id := sys_guid();

   if vCount > 0 then
      select count(*) into kc_orig from jw_jh_jsjxrlkcb where jsjxrl_id = vJsjxrl_id_orig;
      select count(*) into kc_dest from jw_jh_jsjxrlkcb where jsjxrl_id = vJsjxrl_id_dest;
         update jw_jh_jsjxrlkcb kcb set (sknr,skyq,bz,skxsm) =
            (select sknr,skyq,bz,skxsm from jw_jh_jsjxrlkcb where jsjxrl_id = vJsjxrl_id_orig and kc = kcb.kc)
            where jsjxrl_id = vJsjxrl_id_dest
              and exists(select 'X' from  jw_jh_jsjxrlkcb t where t.jsjxrl_id = vJsjxrl_id_orig and kcb.kc = t.kc);
   else
      insert into jw_jh_jsjxrl(jsjxrl_id,xnm,xqm,jxb_id,jgh_id,shzt,dysj,dydd,zyskfsdm,zyskdddm,sfpzjskc)
      values(vJsjxrl_id,vXnm,vXqm,vJxb_id,vJgh_id,'0','','','','','');

      if vJsjxrlfs = '1' then
      -----select jsjxrl_id,kc,rq,zc,xqj,jc,skxsm,sknr,skyq,bz,xs,khhgnr,khhgtjsj,khhgtjzt from jw_jh_jsjxrlkcb
        insert into jw_jh_jsjxrlkcb(jsjxrl_id,kc,sknr,skyq,bz,skxsm)
               select vJsjxrl_id ,kcb.kc,kcb.sknr,kcb.skyq,kcb.bz,kcb.skxsm from jw_jh_jsjxrlkcb kcb
                   where kcb.jsjxrl_id = vJsjxrl_id_orig
                 order by to_number(zc),rq,to_number(replace(substr(decode(jc,'无','0-0'), 1, 2), '-', '')), to_number(kc);

      else
         insert into jw_jh_jsjxrlkcb(jsjxrl_id,kc,rq,zc,xqj,jc,sknr,skyq,bz,skxsm) --,xs
         select vJsjxrl_id,t.kc,t.rq,t.dxqzc,t.xqj,t.jc,kcb.sknr,kcb.skyq,kcb.bz,kcb.skxsm from  --,t.kss
         (select row_number() over (partition by 1 order by  b.rn, a.xqj, to_number(fn_jqzd(a.jc, '-', 1))) kc,
               b.rn dxqzc,
               a.xqj,
               a.jc,
               a.ks as kss,
               (select t2.zc
                  from jw_pk_xlb t1, jw_pk_rcmxb t2
                 where t1.xl_id = t2.xl_id
                   and t1.xnm = a.xnm
                   and bitand(t2.dxqm, a.xqm) > 0
                   and t2.dxqzc = b.rn
                   and t2.xqj = a.xqj) zc,
               (select rq
                  from jw_pk_xlb t1, jw_pk_rcmxb t2
                 where t1.xl_id = t2.xl_id
                   and t1.xnm = a.xnm
                   and bitand(t2.dxqm, a.xqm) > 0
                   and t2.dxqzc = b.rn
                   and t2.xqj = a.xqj) rq
          from (select xnm,
                       xqm,
                       xqj,
                       fn_bittozc(zcd * 2) zcd,
                       jc,
                       fn_jszs(jc) ks
                  from (select xnm, xqm, xqj, get_bitorsunion(wm_concat(zcd)) zcd, jc
                          from (select xnm, xqm, xqj, zcd, get_bitorsunion(wm_concat(jc)) jc, jgh_id
                                  from jw_pk_kbsjb
                                 where jxb_id = vJxb_id
                                 group by xnm, xqm, xqj, zcd, jgh_id)
                         group by xnm, xqm, xqj, jc
                         order by xqj, jc, zcd)) a,
               (select 0 rn
                  from dual
                union all
                select rownum rn from zftal_xtgl_jcsjb) b
         where instr(',' || a.zcd || ',', ',' || b.rn || ',') > 0) t ,(select * from jw_jh_jsjxrlkcb where jsjxrl_id = vJsjxrl_id_orig ) kcb where t.kc = kcb.kc(+);

      end if;
   end  if;
end;

/

