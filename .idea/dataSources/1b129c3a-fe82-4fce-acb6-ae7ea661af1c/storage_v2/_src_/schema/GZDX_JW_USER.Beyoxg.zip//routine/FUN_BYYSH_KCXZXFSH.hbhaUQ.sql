create function fun_byysh_kcxzxfsh(v_xh_id  varchar2,
                                              v_tj_id  varchar2,
                                              v_tjmc   varchar2,
                                              v_tjsjz  varchar2,
                                              v_tjsjgx varchar2,
                                              v_lx     varchar2,
                                              v_tjsjmc varchar2,
                                              v_btjkc  varchar2,
                                              v_tjsjcs varchar2,
                                              v_tjkcxz varchar2)
  return varchar2 as
  sJg      varchar2(2000); ---返回审核是否通过描述
  v_zxf    varchar2(10); ---总学分
  sqlstr   varchar2(4000);
  v_dm     varchar2(10); ---存储课程性质代码或课程类别代码 课程归属代码还是考级代码
  v_lb     varchar2(6); ------判断是课程性质还是课程类别
  v_count  number;
  v_kcxzmc varchar2(100);
  v_yqzxf  float;
  v_hdzxf  float;
  v_yqtx   float;
  v_hdtx   float;
  v_yqtb   float;
  v_hdtb   float;
  v_yqzb   float;
  v_hdzb   float;
  v_hdzx   float;
  v_yqzx   float;
  v_byjr   varchar2(255);
begin
  begin
    ---likai
    select nvl(xsbz,'无')
      into v_byjr
      from JW_BYGL_BYSHB shb
     where xh_id = v_xh_id and shb.bynd='2019';
    sJg     := '合格[学院备注:' || v_byjr || ']';
    v_hdzxf := 0;
    --获得总学分
    select sum(hdxf)
      into v_hdzxf
      from jw_jh_xsjxzxjhkcxxyshb
     where xh_id = v_xh_id and bfzcj>=60;
    --应取总学分
    select sum(xfb.yqzdxf)
      into v_yqzxf
      from jw_jh_jxzxjhxfyqxxb xfb,
           jw_jh_jxzxjhxxb     jhb,
           jw_bygl_byyshb      ysb,
           jw_xjgl_xsjbxxb     xsj
     where xfb.jxzxjhxx_id = jhb.jxzxjhxx_id
       and jhb.njdm_id = xsj.njdm_id
       and jhb.zyh_id = xsj.zyh_id
       and xsj.xh_id = ysb.xh_id
       and xfb.sfmjd = '1'
       and ysb.xh_id = v_xh_id;
    ----------
    --获得通选
    select sum(hdxf) hdzxf
      into v_hdtx
      from jw_jh_xsjxzxjhkcxxyshb xsb
     where xh_id = v_xh_id
       and xsb.kcxzdm in ('2', '19') and bfzcj>=60;
    --应取通选
    select sum(xfb.yqzdxf)
      into v_yqtx
      from jw_jh_jxzxjhxfyqxxb xfb,
           jw_jh_jxzxjhxxb     jhb,
           jw_bygl_byyshb      ysb,
           jw_xjgl_xsjbxxb     xsj
     where xfb.jxzxjhxx_id = jhb.jxzxjhxx_id
       and jhb.njdm_id = xsj.njdm_id
       and jhb.zyh_id = xsj.zyh_id
       and xsj.xh_id = ysb.xh_id
       and xfb.sfmjd = '1'
       and xfb.kcxzdm in ('2', '19')
       and ysb.xh_id = v_xh_id;
    -----------
    --获得通必
    select sum(hdxf) hdzxf
      into v_hdtb
      from jw_jh_xsjxzxjhkcxxyshb xsb
     where xh_id = v_xh_id
       and xsb.kcxzdm in ('1','11', '22') and bfzcj>=60;
    --应取通必
    select sum(xfb.yqzdxf)
      into v_yqtb
      from jw_jh_jxzxjhxfyqxxb xfb,
           jw_jh_jxzxjhxxb     jhb,
           jw_bygl_byyshb      ysb,
           jw_xjgl_xsjbxxb     xsj
     where xfb.jxzxjhxx_id = jhb.jxzxjhxx_id
       and jhb.njdm_id = xsj.njdm_id
       and jhb.zyh_id = xsj.zyh_id
       and xsj.xh_id = ysb.xh_id
       and xfb.sfmjd = '1'
       and xfb.kcxzdm in ('1','11','22')
       and ysb.xh_id = v_xh_id;
    ----------------
    --获得专必
    select sum(hdxf) hdzxf
      into v_hdzb
      from jw_jh_xsjxzxjhkcxxyshb xsb
     where xh_id = v_xh_id
       and xsb.kcxzdm in ('13', '14', '16', '24','23') and bfzcj>=60;
    --应取专必
    select sum(xfb.yqzdxf)
      into v_yqzb
      from jw_jh_jxzxjhxfyqxxb xfb,
           jw_jh_jxzxjhxxb     jhb,
           jw_bygl_byyshb      ysb,
           jw_xjgl_xsjbxxb     xsj
     where xfb.jxzxjhxx_id = jhb.jxzxjhxx_id
       and jhb.njdm_id = xsj.njdm_id
       and jhb.zyh_id = xsj.zyh_id
       and xsj.xh_id = ysb.xh_id
       and xfb.sfmjd = '1'
       and xfb.kcxzdm in ('13', '14', '16', '24','23')
       and ysb.xh_id = v_xh_id;
      ----------------
    --获得专选
    select sum(hdxf) hdzxf
      into v_hdzx
      from jw_jh_xsjxzxjhkcxxyshb xsb
     where xh_id = v_xh_id
       and xsb.kcxzdm in ('4', '15') and bfzcj>=60;
    --应取专选
    select sum(xfb.yqzdxf)
      into v_yqzx
      from jw_jh_jxzxjhxfyqxxb xfb,
           jw_jh_jxzxjhxxb     jhb,
           jw_bygl_byyshb      ysb,
           jw_xjgl_xsjbxxb     xsj
     where xfb.jxzxjhxx_id = jhb.jxzxjhxx_id
       and jhb.njdm_id = xsj.njdm_id
       and jhb.zyh_id = xsj.zyh_id
       and xsj.xh_id = ysb.xh_id
       and xfb.sfmjd = '1'
       and xfb.kcxzdm in ('4', '15')
       and ysb.xh_id = v_xh_id;
    --描述
    select '学院备注:' || v_byjr || ',总学分已获：' || v_hdzxf || '要求(' || v_yqzxf || '),' ||
           '通选已获：' || v_hdtx || '要求(' || v_yqtx || '),' || '通必已获：' ||
           v_hdtb || '要求(' || v_yqtb || '),' || '专必已获：' || v_hdzb || '要求(' ||
           v_yqzb || ')'|| '专选已获：' || v_hdzx || '要求(' ||v_yqzx || ')'
      into sqlstr
      from dual;
    if v_hdzxf < v_yqzb or v_hdtx < v_yqtx or v_hdtb < v_yqtb or
       v_hdzb < v_yqzb or v_hdzx<v_yqzx then
      sJg := '不合格[' || sqlstr || ']';
    end if;
    ---end likai
    
  exception
    When others then
      sJg := '查询出错，不合格！';
  end;
  if sJg is null then
    return '系统无数据，不合格！';
  else
    return sJg;
  end if;
end fun_byysh_kcxzxfsh;





/*create or replace function fun_byysh_kcxzxfsh_bak(v_xh_id varchar2,v_tj_id varchar2,v_tjmc varchar2,v_tjsjz varchar2,v_tjsjgx varchar2,
                                       v_lx varchar2,v_tjsjmc varchar2,v_btjkc varchar2,v_tjsjcs varchar2,v_tjkcxz varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_zxf varchar2(10);   ---总学分
   sqlstr varchar2(4000);
   v_dm  varchar2(10);  ---存储课程性质代码或课程类别代码 课程归属代码还是考级代码
   v_lb varchar2(6); ------判断是课程性质还是课程类别
   v_count number;
   v_kcxzmc varchar2(100);
begin
   begin
     select (case when instr(v_tj_id,'kcxz')>0 then 'kcxz'
                  when instr(v_tj_id,'kclb')>0 then 'kclb'
                  when instr(v_tj_id,'kcgs')>0 then 'kcgs'
                  when instr(v_tj_id,'kjxm')>0 then 'kjxm'
                  when instr(v_tj_id,'pycc')>0 then 'pycc'
                  else '' end) into v_lb from dual;
    -- select substr(v_tjsjcs,instr(v_tjsjcs,v_lb)+4) into v_dm from dual;
       select substr(v_tj_id,instr(v_tj_id,v_lb)+4) into v_dm from dual;

     if (v_lb<>'kjxm' and v_lb<>'pycc')   then
        sqlstr:= ' select nvl((sum(xf)), 0) xf from (select e.xf from (select a.kcxzdm, a.xh_id,  a.jd, a.xf, a.jxb_id, a.kch_id,'||
                 ' row_number() over(partition by a.xh_id, nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) rn  from jw_cj_xscjb a where a.bfzcj >= 60';

        if v_lb='kcxz' then
           sqlstr:= sqlstr||'and a.kcxzdm='''||v_dm||'''';
        end if;

        if v_lb='kclb' then
           sqlstr:= sqlstr||'and exists(select 1 from jw_jh_kcdmb kc where kc.kch_id = a.kch_id and kc.kclbdm='''||v_dm||''')';
        end if;

        if v_lb='kcgs' then
           sqlstr:= sqlstr||'and exists(select 1 from jw_jh_kcdmb kc where kc.kch_id = a.kch_id and kc.kcgsdm='''||v_dm||''')';
        end if;

       sqlstr:= sqlstr||' and not exists (select ''X''  from jw_cj_cjjglxsqb zfb'||
       ' where zfb.cjjglx = ''01''  and zfb.shzt = ''3'' and zfb.xh_id = a.xh_id  and zfb.kch_id = a.kch_id)'||
       ' and a.xh_id  = '''||v_xh_id||'''  ';

       if v_lx='2' then
          sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = a.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
       end if;

       sqlstr:= sqlstr||') e where rn = 1 ';
       if v_btjkc is not null then
          sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
       end if;
       sqlstr:= sqlstr||' ) ';
       ---------查出类型的学分
       dbms_output.put_line(sqlstr);
       execute immediate sqlstr into v_zxf;

      sJg := '合格';
      sqlstr:='select (case when '||v_zxf||v_tjsjgx||v_tjsjz||' then ''合格'' else '''||v_tjmc||v_zxf||',低于'||v_tjsjz||',不合格！'' end) from dual';
      execute immediate sqlstr into sJg;
    elsif v_lb='kjxm' then
    ----查询考级项目成绩，从视图查询
      select nvl(max(a.xmbfzcj),0) into v_zxf from  view_by_cetcjb a where a.xh_id=''||v_xh_id||''
      and a.xmdm = ''||v_dm||'';
      if to_number(v_zxf)<v_tjsjz then
         sJg := v_tjmc||'成绩'||v_zxf||',低于'||v_tjsjz||',不合格！';
      else
         sJg := '合格';
      end if;

    elsif v_lb='pycc' then
         --根据课程类型获得总学分
         if v_tjkcxz is not null and v_tjkcxz='qb' then
            v_kcxzmc:='全部课程性质';
            select count(cj.kch_id) into v_count from jw_cj_xscjb cj  where cj.xh_id = v_xh_id;
         elsif v_tjkcxz is not null and v_tjkcxz!='qb' then
               sqlstr:= ' select  wm_concat(kcxzmc)kcxzmc from jw_jh_kcxzdmb where   instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
                execute immediate sqlstr into v_kcxzmc;
             sqlstr:= 'select count(cj.kch_id) count from jw_cj_xscjb cj  where cj.xh_id ='''||v_xh_id||'''  and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||cj.kcxzdm||'','' )>0 ';
             execute immediate sqlstr into v_count;
         end if;
           if v_count>0 then
           sqlstr:='select nvl(count(a.kch_id),0) count from (select cj.kch_id,cj.bfzcj,row_number() '||
                   'over(partition by cj.xh_id, cj.kch_id order by cj.BFZCJ desc) rn from jw_cj_xscjb cj where cj.xh_id = '''||v_xh_id||'''';
           if v_tjkcxz is not null and v_tjkcxz!='qb' then
              sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||cj.kcxzdm||'','' )>0 ';
           end if;

           if v_btjkc is not null then
              sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
            end if;
           sqlstr:= sqlstr||' ) a   where rn = 1 and a.bfzcj<'||v_tjsjz;
           execute immediate sqlstr into v_count;
              if v_count>0 then
                 sJg:= v_kcxzmc||'共有'||v_count||'门课程低于'||v_tjsjz||'分，不合格！';
              else
                 sJg:= '合格！';
              end if;
            else
                sJg:= '无'||v_kcxzmc||'课程成绩，不合格！';
            end if;

    end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;
    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_byysh_kcxzxfsh_bak;*/

