create function fn_isHasCtxx(Vxnm varchar2,Vxqm varchar2,Vsyfjid varchar2,Vrq varchar2,Vhbjcd varchar2,Vkc varchar2,Vjxb_id varchar2,Vsyxm_id varchar2,Vbj varchar2) return varchar2
as
  ctresult varchar2(2);--冲突结果1或0
  ctxxCount number;--冲突数量
  ctxxCount1 number;--冲突数量
  ctxxCount2 number;--冲突数量
  ctxxCount3 number;--冲突数量
begin
  if Vbj='0' then
    select
     count(*) into ctxxCount1
    from
      (  select e.jsjxrl_id,e.xnm,e.xqm,e.jxb_id,jxb.jxbmc,kc.kkbm_id,kc.kch_id,kc.kch,kc.kcmc,e.jgh_id,js.jgh,js.xm,js.jg_id as jsbm_id,a.rq,a.zc,a.kc,a.syxm_id,a.sysid,a.syfsid,f.dm as syfjdm,f.mc as syfjmc,a.sycdlb,b.hbjcd  from
       jw_jh_jsjxrlsyxmb a, jw_jh_jsjxrlkcb2 b, jw_jh_jsjxrl2 e,jw_jxrw_jxbxxb jxb,jw_jh_kcdmb kc,jw_jg_jzgxxb js,
       (select t2.id,nvl(t2.sys_id,t.sys_id) as sys_id,t2.syfs_id,t2.dm,t2.mc  from  jw_sygl_syfsxxb t, jw_sygl_syfjxxb t2 where t.id(+) = t2.syfs_id) f
           where a.jsjxrl_id = b.jsjxrl_id
           and a.rq = b.rq
           and a.zc = b.zc
           and a.kc = b.kc
           and a.jsjxrl_id = e.jsjxrl_id
           and jxb.jxb_id = e.jxb_id
           and jxb.kch_id = kc.kch_id
           and e.jgh_id = js.jgh_id
           and nvl(e.shzt, '0') != '0'
           and a.sycdlb !='4'
           and a.sysid = f.sys_id
           and nvl(a.syfsid,'-1') = nvl(f.syfs_id,'-1')
           and instr(','||a.syfjid||',' , ','||f.id||',') >0
          ) t1
     where t1.xnm = Vxnm
         and t1.xqm = Vxqm
         and not exists (select 1 from jw_jh_jsjxrlsyxmshb2 s where s.jsjxrl_id = t1.jsjxrl_id and s.shzt='4')--去除审核状态为退回的记录
         and exists(select '1' from jw_sygl_syfjxxb where id=Vsyfjid and dm=t1.syfjdm)
         and t1.rq = Vrq
         and bitand(power(2,t1.kc), nvl(Vhbjcd, power(2,Vkc))) >0
         and t1.jxb_id ||nvl(t1.syxm_id,'@')!=Vjxb_id||nvl(Vsyxm_id,'@')
         and rownum =1
         ;



          select
     count(*) into ctxxCount3
    from
      (  select e.xjsjxrlb_id,e.xnm,e.xqm,e.jxb_id,jxb.jxbmc,kc.kkbm_id,kc.kch_id,kc.kch,kc.kcmc,e.sqrjgh_id,js.jgh,js.xm,js.jg_id as jsbm_id,a.rq,a.zc,a.jc,a.syxm_id,a.sysid,a.syfsid,f.dm as syfjdm,f.mc as syfjmc,a.sycdlb,b.hbjcd  from
       JW_JH_JSJXRLSYXMBGB a, JW_JH_JSJXRLSJDDSYXMBGB b, jw_jh_jxrlbgsqb e,jw_jxrw_jxbxxb jxb,jw_jh_kcdmb kc,jw_jg_jzgxxb js,
       (select t2.id,nvl(t2.sys_id,t.sys_id) as sys_id,t2.syfs_id,t2.dm,t2.mc  from  jw_sygl_syfsxxb t, jw_sygl_syfjxxb t2 where t.id(+) = t2.syfs_id) f
           where a.jsjxrlb_id = b.jsjxrlb_id
           and a.rq = b.rq
           and a.zc = b.zc
           and a.jc = b.jc
           and a.jsjxrlb_id = e.xjsjxrlb_id
           and jxb.jxb_id = e.jxb_id
           and jxb.kch_id = kc.kch_id
           and e.sqrjgh_id = js.jgh_id
           and nvl(e.shzt, '0') != '0'
           and a.sycdlb !='4'
           and a.sysid = f.sys_id
           and nvl(a.syfsid,'-1') = nvl(f.syfs_id,'-1')
           and instr(','||a.syfjid||',' , ','||f.id||',') >0
          ) t1
     where t1.xnm = Vxnm
         and t1.xqm = Vxqm
         and not exists (select 1 from jw_jh_jsjxrlsyxmshb2 s where s.jsjxrl_id = t1.xjsjxrlb_id and s.shzt='4')--去除审核状态为退回的记录
         and exists(select '1' from jw_sygl_syfjxxb where id=Vsyfjid and dm=t1.syfjdm)
         and t1.rq = Vrq
         and bitand(power(2,t1.jc), nvl(Vhbjcd, power(2,Vkc))) >0
         and t1.jxb_id ||nvl(t1.syxm_id,'@')!=Vjxb_id||nvl(Vsyxm_id,'@')
         and rownum =1
         ;



         select
           count(*) into ctxxCount2
          from
            (
             select a.jsjxrl_id,a.xnm,a.xqm,a.jsjxrl_id as jxb_id,null as jxbmc,null as kkbm_id,null as kch_id,null as kch,
               a.kcmc,null as jgh_id,null as jgh,a.rklsmc as xm,null as jsbm_id,a.rq,
               to_char((select t2.dxqzc zc from jw_pk_xlb t1,jw_pk_rcmxb t2 where t1.xl_id = t2.xl_id and t2.zc != 0 and t2.rq=a.rq)) zc,
              to_char(g.rn) as kc,
                a.xmmc as syxm_id,
                b.sysid,
                b.syfsid,
                f.dm as syfjdm,
                f.mc as syfjmc,
                b.sycdlb,
                get_jctobinary(a.qsjc||'-'||a.jsjc)*2 as hbjcd
               from JW_JH_KFGXSYDDSQB b,JW_JH_KFGXSYSQB a , jw_sygl_syfjfzrxxb c,
               (select t2.id,nvl(t2.sys_id,t1.sys_id) as sys_id,t2.syfs_id,t2.dm,t2.mc  from  jw_sygl_syfsxxb t1, jw_sygl_syfjxxb t2 where t1.id(+) = t2.syfs_id) f,
               (select power(2,rownum-1) bit,rownum rn from zftal_xtgl_jcsjlxb where rownum <=20 ) g
               where  a.jsjxrl_id = b.jsjxrl_id
               and a.shzt != '0'
               and b.sysid = f.sys_id
               and nvl(b.syfsid,'-1') = nvl(f.syfs_id,'-1')
               and instr(','||b.syfjid||',' , ','||f.id||',') >0
               and c.syfj_id = f.id
               and bitand(get_jctobinary(a.qsjc||'-'||a.jsjc),g.bit) > 0

             ) t1
           where t1.xnm = Vxnm
               and t1.xqm = Vxqm
               and not exists (select 1 from jw_jh_jsjxrlsyxmshb2 s where s.jsjxrl_id = t1.jsjxrl_id and s.shzt='4')--去除审核状态为退回的记录
               and exists(select '1' from jw_sygl_syfjxxb where id=Vsyfjid and dm=t1.syfjdm)
               and t1.rq = Vrq
               and bitand(power(2,t1.kc), nvl(Vhbjcd, power(2,Vkc))) >0
               and t1.jxb_id ||nvl(t1.syxm_id,'@')!=Vjxb_id||nvl(Vsyxm_id,'@')
               and rownum =1
               ;
  end if;
  ctxxCount := ctxxCount1+ctxxCount2+ctxxCount3;
  if ctxxCount=0 then
     ctresult:='0';
  end if;
  if ctxxCount>0 then
     ctresult:='1';
  end if;
  if ctxxCount is null then
     ctresult:='0';
  end if;
  return ctresult;
end fn_isHasCtxx;

/

