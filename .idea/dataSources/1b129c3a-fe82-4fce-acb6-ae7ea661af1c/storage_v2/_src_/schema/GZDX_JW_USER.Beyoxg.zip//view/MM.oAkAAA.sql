create view MM as
  select xh, getmd5( substr(zjhm,-6,6)) kl, substr(zjhm,-6,6) p from jw_xjgl_xsjbxxb
/

