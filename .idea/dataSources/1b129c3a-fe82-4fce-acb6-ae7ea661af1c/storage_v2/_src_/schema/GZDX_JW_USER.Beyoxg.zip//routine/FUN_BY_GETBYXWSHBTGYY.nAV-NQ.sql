create function fun_by_getbyxwshbtgyy(                     ----得到毕业学位审核不通过原因
v_xh_id  varchar2,
v_bynd   varchar2,
v_xdlx   varchar2              ----主修或者辅修:1-主修,2-辅修
)
Return varchar2
as
tname1   varchar2(200);        -----要查询的表名1
tname2   varchar2(200);        -----要查询的表名2
sqlstr   varchar2(4000);       -----执行语句
num      number;               -----数量
lsbl     varchar2(20);         -----临时变量
temp_jg  varchar2(4000);       -----临时结果
jg       varchar2(4000);       -----结果
begin
     if v_xh_id is not null and
        v_bynd is not null  and
        v_xdlx is not null  then
        if v_xdlx = '1'     then
          tname1:='jw_bygl_byshb';
          tname2:='jw_bygl_xwshb';
        else
          tname1:='jw_bygl_fxshb';
          tname2:='jw_bygl_fxxwshb';
        end if;

       for i in 1..20 loop
          if i<10 then
             lsbl := '0'||i;
          end if;
          sqlstr:= 'select count(*) from '||tname1||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and tj'||lsbl||'=''2''';
            execute immediate sqlstr into num;
          if num >0 then
             sqlstr:= 'select result'||lsbl||' from '||tname1||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||'''';
             execute immediate sqlstr into temp_jg;
             jg := jg||' '||temp_jg;
          end if;
        end loop;

        for i in 1..20 loop
          if i<10 then
             lsbl := '0'||i;
          end if;
          sqlstr:= 'select count(*) from '||tname2||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and tj'||lsbl||'=''2''';
            execute immediate sqlstr into num;
          if num >0 then
             sqlstr:= 'select result'||lsbl||' from '||tname2||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||'''';
             execute immediate sqlstr into temp_jg;
             jg := jg||' '||temp_jg;
          end if;
        end loop;

     end if;
  return jg;
end;

/

