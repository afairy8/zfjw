create function bitrmv(x IN NUMBER,y IN NUMBER)---以X值右移Y位
return number is
begin
return trunc(x/ power(2,y));
end;


/

