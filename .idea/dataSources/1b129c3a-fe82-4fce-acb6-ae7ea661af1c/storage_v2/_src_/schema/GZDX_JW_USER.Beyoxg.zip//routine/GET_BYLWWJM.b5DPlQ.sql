create function get_bylwwjm(
vxtb_id varchar2,  ---vxtb_id:选题表id;
vzlmc varchar2     ---vzlmc:资料类型名称
) return varchar2
as
   wjm varchar2(2000);   ---毕业过程资料命名
   vxxdm varchar2(20);    ---学校代码
begin
    wjm := null;
    begin

    select xxdm into vxxdm from zftal_xtgl_xxxxszb a where rownum=1;

    if vxxdm='10125' then  ---如果是山西财经大学
       select xs_jg_mc||'_'||xs_xh||'_'||xs_xm||'_'||replace(REPLACE(translate(ktmc,'$/\:*?"<>''|;[]{},.()：；‘’“”【】《》，。（）？、_',' '),' ',''),
       to_char(chr(13))||to_char(chr(10)),'_r_n') ||'_'|| vzlmc as wjmc into wjm from view_bysj_xs_xtxx where xtb_id=vxtb_id;

    elsif  vxxdm='10353' then  ---如果是浙江工商大学
       select xs_xh||'+'||xs_xm||'+'||replace(REPLACE(translate(ktmc,'$/\:*?"<>''|;[]{},.()：；‘’“”【】《》，。（）？、_',' '),' ',''),
       to_char(chr(13))||to_char(chr(10)),'_r_n')||'('||kt_jg_xm||')' ||'+'|| vzlmc as wjmc into wjm from view_bysj_xs_xtxx where xtb_id=vxtb_id;

    else ---其他学校
       select xs_xh||'+'||xs_xm||'+'||replace(REPLACE(translate(ktmc,'$/\:*?"<>''|;[]{},.()：；‘’“”【】《》，。（）？、_',' '),' ',''),
       to_char(chr(13))||to_char(chr(10)),'_r_n')||'('||kt_jg_xm||')' ||'+'|| vzlmc as wjmc into wjm from view_bysj_xs_xtxx where xtb_id=vxtb_id;
    end if;

    exception
        When others then
          wjm := null;  --返回值
    end;
    return wjm;
end get_bylwwjm;

/

