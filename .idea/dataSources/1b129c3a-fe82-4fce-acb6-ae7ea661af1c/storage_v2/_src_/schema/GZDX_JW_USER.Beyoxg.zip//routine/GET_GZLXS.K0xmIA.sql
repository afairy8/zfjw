create function Get_Gzlxs(
vXnm varchar2,      ---学年码
vXqm varchar2,      ---学期码
vKch_id varchar2,   ---课程号ID
vJxb_id varchar2,   ---教学班ID
vJgh_id varchar2,   ---教工号ID
vZj     varchar2,   ---主讲
vJxmsm   varchar2,  ---教学模式码
vGzlxsdm varchar2,  ---工作量系数代码
iXkrs number,       ---选课人数
iCxrs number,       ---重修人数
iHbgs number,       ---合班个数
vBj varchar2) return varchar2  ---取教师教学班工作量系数---vBj做备用字段信息默认值为0-
as
   icount number;   ---记录数
   v_count number;  ---用于判断是否合班数据
   v_bbJxb_ids varchar2(1000); --并班教学班
   v_xkrs number;--选课人数
   v_Cxrs number;--重修人数
   v_Hbgs number;--合班个数
   iCfbxl number;   ---重复班序列
   iCfbxl1 number;  ---重复班序列（教学班人数倒序排序实际序列）
   iMaxCfbxl number;---重复班序列（设置最大序列）
   sXl varchar2(100); ---学历
   sZc varchar2(100); ---职称
   sJb varchar2(100); ---级别
   sRsd varchar2(100); ---人数段
   sZfj varchar2(100); ---主辅教
   sJxms varchar2(100); ---教学模式
   sXs varchar2(500);  ---系数
   sSql_xx varchar2(100);
   sSql varchar2(100);
   xxdm varchar2(100); ----学校代码
   v_pjdf varchar2(100); --评价得分
begin
    begin --dbms_output.put_line('vJxb_id:'||vJxb_id);
       if vBj = '0' then  ---备用字段信息默认值为0

         if vGzlxsdm = 'xlxs' then  --学历系数
          select to_char(a.xlxs,'0.90'),(select mc from zftal_xtgl_jcsjb where lx = '0014' and dm = b.xldm) into sXs,sXl from
                 JW_JG_GZLXLXSB a,jw_jg_jzgxxb b
           where a.xldm = b.xldm
             and a.xlxs is not null
             and b.jgh_id = vJgh_id;
          sXs:= sXs||'|学历:'||sXl||'['||sXs||']';
         end if;

         if vGzlxsdm = 'zcxs' then  --职称系数
          select to_char(a.zcxs,'0.90'),a.zcmc into sXs,sZc from JW_JG_ZYJSZCB a,jw_jg_jzgxxb b
                                           where a.zcm = b.zcm
                                             and a.zcxs is not null
                                             and b.jgh_id = vJgh_id;
          sXs:= sXs||'|职称:'||sZc||'['||sXs||']';
         end if;

         if vGzlxsdm = 'jbxs' then  --级别系数
          select to_char(a.jbxs,'0.90'),a.zwjbmc into sXs,sJb from JW_JG_ZWJBDMB a,jw_jg_jzgxxb b
                                             where a.zwjbm = b.zwjbm
                                               and a.jbxs is not null
                                               and b.jgh_id = vJgh_id;
          sXs:= sXs||'|级别:'||sJb||'['||sXs||']';
         end if;
         ------人数系数-----begin-------------
         if vGzlxsdm = 'rsxs' then  --人数系数
           select count(*) into v_count from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1';
           if v_count > 0 then --并班
              select wm_concat(jxb_id) into v_bbJxb_ids from jw_pk_bbfzb where bbfz_id in (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1');
              select count(*),sum(case when cxbj = '1' then 1 else 0 end) into v_xkrs,v_cxrs  from jw_xk_xsxkb where xnm = vXnm and xqm = vXqm and ','||v_bbJxb_ids||',' like '%,'||jxb_id||',%';
              select count(distinct njdm_id||zyh_id||bh_id) into v_hbgs  from jw_jxrw_jxbxxb a,jw_jxrw_jxbhbxxb b where a.xnm = vXnm and a.xqm = vXqm and a.jxb_id = b.jxb_id and a.kklxdm = '01' and ','||v_bbJxb_ids||',' like '%,'||a.jxb_id||',%';
              select count(*) into icount from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflrsxsb b
                                      where a.rsxsdm = b.kcfldm
                                        and a.xnm = vXnm
                                        and a.xqm = vXqm
                                        and ','||v_bbJxb_ids||',' like '%,'||a.jxb_id||',%';
              if icount > 0 then --设置了教学班系数
                select nvl(b.rsxsgs,b.rsxs),b.rsxx||'-'||b.rssx into sXs,sRsd from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflrsxsb b
                                             where a.rsxsdm = b.kcfldm
                                               and a.xnm = vXnm
                                               and a.xqm = vXqm
                                               and ','||v_bbJxb_ids||',' like '%,'||a.jxb_id||',%'
                                               and to_number(v_xkrs) >= b.rsxx
                                               and to_number(v_xkrs) < b.rssx
                             and (b.rsxsgs is not null or b.rsxs is not null)
                             and rownum = 1;
                  sSql_xx:=replace(sXs,'cxrs',v_cxrs);
                  sSql_xx:=replace(sSql_xx,'hbgs',v_hbgs);
                  sSql_xx:=replace(sSql_xx,'rs',v_xkrs);
                  sSql := 'select to_char('||sSql_xx||',''0.90'')  from dual';
                  Execute Immediate sSql into sXs;
                  if sXs is null then
                     sXs:= '|无人数系数{任务}设置人数段:'||sRsd||' 选课人数:'||v_xkrs||'|'||v_xkrs||' 重修人数:'||v_Cxrs||' 合班个数:'||v_hbgs;
                  else
                     sXs:= sXs||'|任务设置人数段:'||sRsd||' 选课人数:'||v_xkrs||'['||sXs||']|'||v_xkrs||' 重修人数:'||v_Cxrs||' 合班个数:'||v_hbgs;
                  end if;
               else --设置了课程系数
                  select nvl(b.rsxsgs,b.rsxs),b.rsxx||'-'||b.rssx into sXs,sRsd from jw_jg_gzlkcxsszb a, jw_jg_gzlkcflrsxsb b
                                             where a.rsxsdm = b.kcfldm
                                               and a.kch_id = vkch_id
                                               and to_number(v_xkrs) >= b.rsxx
                                               and to_number(v_xkrs) < b.rssx;
                  sSql_xx:=replace(sXs,'cxrs',v_cxrs);
                  sSql_xx:=replace(sSql_xx,'hbgs',v_hbgs);
                  sSql_xx:=replace(sSql_xx,'rs',v_xkrs);
                  sSql := 'select to_char('||sSql_xx||',''0.90'') from dual';
                  Execute Immediate sSql into sXs;
                  if sXs is null then
                     sXs:= '|无人数系数{课程}设置人数段:'||sRsd||' 选课人数:'||'|'||v_xkrs||' 重修人数:'||v_Cxrs||' 合班个数:'||v_hbgs;
                     else
                     sXs:= sXs||'|课程设置人数段:'||sRsd||' 选课人数:'||v_xkrs||'['||sXs||']|'||v_xkrs||' 重修人数:'||v_Cxrs||' 合班个数:'||v_hbgs;
                  end if;
              end if;
           else
              select count(*) into icount from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflrsxsb b
                                      where a.rsxsdm = b.kcfldm
                                        and a.xnm = vXnm
                                        and a.xqm = vXqm
                                        and a.jxb_id = vJxb_id;
              if icount > 0 then  ---教学班设置人数系数时
               select nvl(b.rsxsgs,b.rsxs),b.rsxx||'-'||b.rssx into sXs,sRsd from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflrsxsb b
                                     where a.rsxsdm = b.kcfldm
                                       and a.xnm = vXnm
                                       and a.xqm = vXqm
                                       and a.jxb_id = vJxb_id
                                       and to_number(iXkrs) >= b.rsxx
                                       and to_number(iXkrs) < b.rssx;
               sSql_xx:=replace(sXs,'cxrs',icxrs);
               sSql_xx:=replace(sSql_xx,'hbgs',ihbgs);
               sSql_xx:=replace(sSql_xx,'rs',iXkrs);
               sSql := 'select to_char('||sSql_xx||',''0.90'')  from dual';
               Execute Immediate sSql into sXs;
               if sXs is null then
                 sXs:= '|无人数系数{任务}设置人数段:'||sRsd||' 选课人数:'||iXkrs||'|'||iXkrs||' 重修人数:'||iCxrs||' 合班个数:'||ihbgs;
                 else
                 sXs:= sXs||'|任务设置人数段:'||sRsd||' 选课人数:'||iXkrs||'['||sXs||']|'||iXkrs||' 重修人数:'||iCxrs||' 合班个数:'||ihbgs;
               end if;
             else  ---教学班未设置人数系数，课程设置人数系数
               select nvl(b.rsxsgs,b.rsxs),b.rsxx||'-'||b.rssx into sXs,sRsd from jw_jg_gzlkcxsszb a, jw_jg_gzlkcflrsxsb b
                                     where a.rsxsdm = b.kcfldm
                                       and a.kch_id = vkch_id
                                       and to_number(iXkrs) >= b.rsxx
                                       and to_number(iXkrs) < b.rssx;
               sSql_xx:=replace(sXs,'cxrs',icxrs);
               sSql_xx:=replace(sSql_xx,'hbgs',ihbgs);
               sSql_xx:=replace(sSql_xx,'rs',iXkrs);
               select xxdm into xxdm from zftal_xtgl_xxxxszb;
               ---判断如果学校代码为14020 天津城市建设管理职业技术学院 针对系数输出保留一位小数
               if xxdm = 14020 then
                 sSql := 'select to_char('||sSql_xx||',''0.9'') from dual';
                 else
                 sSql := 'select to_char('||sSql_xx||',''0.90'') from dual';
               end if;
               Execute Immediate sSql into sXs;

               if sXs is null then
                 sXs:= '|无人数系数{课程}设置人数段:'||sRsd||' 选课人数:'||iXkrs||'|'||iXkrs||' 重修人数:'||iCxrs||' 合班个数:'||ihbgs;
                 else
                 sXs:= sXs||'|课程设置人数段:'||sRsd||' 选课人数:'||iXkrs||'['||sXs||']|'||iXkrs||' 重修人数:'||iCxrs||' 合班个数:'||ihbgs;
               end if;
             end if;
           end if;
          end if;
          -----人数系数-------end------------
          -----重复系数-----begin------------
          if vGzlxsdm = 'cfxs' then  --重复系数
           select count(*),max(b.cfbxl) into icount,iMaxCfbxl from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflcfxsb b
                                                                                      where a.cfxsdm = b.kcfldm
                                                                                        and a.xnm = vXnm
                                                                                        and a.xqm = vXqm
                                                                                        and a.jxb_id = vJxb_id;
           if icount > 0 then  ---教学班设置重复系数时
           select rn into iCfbxl from ---找出此教学班的重复班序列
           (select t1.jxb_id,
                  row_number() over (partition by t1.kch_id
                                         order by (select count(*) from jw_xk_xsxkb xkb
                                                                  where xkb.jxb_id = t1.jxb_id) desc) rn from
                         jw_jxrw_jxbxxb t1,jw_jxrw_jxbjsrkb t2,jw_jg_gzljxbxsszb t3
                                                               where t1.jxb_id = t2.jxb_id
                                                                 and t1.xnm = vXnm
                                                                 and t1.xqm = vXqm
                                                                 and t1.kch_id = vKch_id
                                                                 and t1.jxb_id = t3.jxb_id
                                                                 and t1.xnm = t3.xnm
                                                                 and t1.xqm = t3.xqm
                                                                 and t3.kch_id = vKch_id
                                                                 and t2.jgh_id = vJgh_id
                                                                 and t3.cfxsdm is not null ) where jxb_id = vJxb_id;
            iCfbxl1 := iCfbxl;
            if iCfbxl > iMaxCfbxl then
              iCfbxl := iMaxCfbxl;
            end if;

            select to_char(b.cfxs,'0.90') into sXs from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflcfxsb b where a.cfxsdm = b.kcfldm
                                                                                    and a.xnm = vXnm
                                                                                    and a.xqm = vXqm
                                                                                    and a.jxb_id = vJxb_id
                                                                                    and b.cfbxl = iCfbxl;
           if sXs is null then
               sXs:= '|无重复系数{任务}设置最大重复序列:'||iMaxCfbxl||' 此教学班重复序列:'||iCfbxl1;
               else
               sXs:= sXs||'|课程设置最大重复序列:'||iMaxCfbxl||' 此教学班重复序列:'||iCfbxl1||'['||sXs||']';
           end if;
           else  ---教学班未设置重复系数，课程设置重复系数

           select count(*),max(b.cfbxl) into icount,iMaxCfbxl from jw_jg_gzlkcxsszb a, jw_jg_gzlkcflcfxsb b
                                                             where a.cfxsdm = b.kcfldm
                                                               and a.kch_id = vKch_id;

           select rn into iCfbxl from ---找出此教学班的重复班序列
           (select t1.jxb_id,
                  row_number() over (partition by t1.kch_id
                                         order by (select count(*) from jw_xk_xsxkb xkb
                                                                  where xkb.jxb_id = t1.jxb_id) desc) rn from
                         jw_jxrw_jxbxxb t1,jw_jxrw_jxbjsrkb t2 where t1.jxb_id = t2.jxb_id
                                                                 and t1.xnm = vXnm
                                                                 and t1.xqm = vXqm
                                                                 and t1.kch_id = vKch_id
                                                                 and t2.jgh_id = vJgh_id
                                                                 and not exists(select 'X' from jw_jg_gzljxbxsszb t3
                                                                                          where t1.jxb_id = t3.jxb_id
                                                                                            and t1.xnm = t3.xnm
                                                                                            and t1.xqm = t3.xqm
                                                                                            and t3.kch_id = vKch_id
                                                                                            and t3.cfxsdm is not null
                                                                                            )

                                                                 ) where jxb_id = vJxb_id;
            iCfbxl1 := iCfbxl;
            if iCfbxl > iMaxCfbxl then
              iCfbxl := iMaxCfbxl;
            end if;

            select to_char(b.cfxs,'0.90') into sXs from jw_jg_gzlkcxsszb a, jw_jg_gzlkcflcfxsb b where a.cfxsdm = b.kcfldm
                                                                                    and a.kch_id = vKch_id
                                                                                    and b.cfbxl = iCfbxl;
           if sXs is null then
               sXs:= '|无重复系数{课程}设置最大重复序列:'||iMaxCfbxl||' 此教学班重复序列:'||iCfbxl1;
               else
               sXs:= sXs||'|课程设置最大重复序列:'||iMaxCfbxl||' 此教学班重复序列:'||iCfbxl1||'['||sXs||']';
            end if;
           end if;

          end if;
          -----重复系数-------end------------
          ----主辅教系数----begin----------
          if vGzlxsdm = 'zfjxs' then  --主辅教系数
           select count(*) into icount from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflzfjxsb b where a.zfjxsdm = b.kcfldm
                                                                                        and a.xnm = vXnm
                                                                                        and a.xqm = vXqm
                                                                                        and a.jxb_id = vJxb_id;
           if icount > 0 then  ---教学班设置主辅教系数时
              select to_char(b.zfjxs,'0.90'),
                     (select mc from zftal_xtgl_jcsjb where lx= '1036' and dm=vZj)into sXs,sZfj from
                     jw_jg_gzljxbxsszb a, jw_jg_gzlkcflzfjxsb b
               where a.zfjxsdm = b.kcfldm
                 and a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and b.zfjlxm = vZj;
            if sXs is null then
               sXs:= '|无主辅教('||sZfj||')系数{任务}';
               else
               sXs:= sXs||'|任务设置:'||sZfj||'['||sXs||']';
            end if;
           else  ---教学班未设置主辅教系数，课程设置主辅教系数
               select to_char(b.zfjxs,'0.90'),(select mc from zftal_xtgl_jcsjb where lx= '1036' and dm=vZj) into sXs,sZfj from
                      jw_jg_gzlkcxsszb a, jw_jg_gzlkcflzfjxsb b
                      where a.zfjxsdm = b.kcfldm
                        and a.kch_id = vkch_id
                        and b.zfjlxm = vZj;
            if sXs is null then
               sXs:= '|无主辅教('||sZfj||')系数{课程}';
               else
               sXs:= sXs||'|课程设置:'||sZfj||'['||sXs||']';
             end if;
           end if;
          end if;
          ----主辅教系数------end----------


          ----教学模式系数----begin----------
          if vGzlxsdm = 'jxmsxs' then  --教学模式系数
           select count(*) into icount from jw_jg_gzljxbxsszb a, jw_jg_gzlkcfljxmsxsb b where a.zfjxsdm = b.kcfldm
                                                                                        and a.xnm = vXnm
                                                                                        and a.xqm = vXqm
                                                                                        and a.jxb_id = vJxb_id;
           if icount > 0 then  ---教学班设置教学模式系数时
              select to_char(b.jxmsxs,'0.90'),(select mc from zftal_xtgl_jcsjb where lx = '0032' and dm = b.jxmsm) into sXs,sJxms from
                     jw_jg_gzljxbxsszb a, jw_jg_gzlkcfljxmsxsb b
               where a.jxmsxsdm = b.kcfldm
                 and a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and b.jxmsm = vJxmsm;
            if sXs is null then
               sXs:= '|无教学模式('||sJxms||')系数{任务}';
               else
               sXs:= sXs||'|任务设置:'||sJxms||'['||sXs||']';
            end if;
           else  ---教学班未设置主辅教系数，课程设置主辅教系数
               select to_char(b.jxmsxs,'0.90'),(select mc from zftal_xtgl_jcsjb where lx = '0032' and dm = b.jxmsm) into sXs,sJxms from
                      jw_jg_gzlkcxsszb a, jw_jg_gzlkcfljxmsxsb b
                      where a.jxmsxsdm = b.kcfldm
                        and a.kch_id = vkch_id
                        and b.jxmsm = vJxmsm;
            if sXs is null then
               sXs:= '|无教学模式('||sJxms||')系数{课程}';
               else
               sXs:= sXs||'|课程设置:'||sJxms||'['||sXs||']';
             end if;
           end if;
          end if;
          ----教学模式系数------end----------

          ----难度系数------begin----------
          if vGzlxsdm = 'ndxs' then  --难度系数
           select count(*) into icount from jw_jg_gzljxbxsszb a, jw_jg_gzlkcflndxsb b where a.ndxsdm = b.kcfldm
                                                                                        and a.xnm = vXnm
                                                                                        and a.xqm = vXqm
                                                                                        and a.jxb_id = vJxb_id;
           if icount > 0 then  ---教学班设置难度系数时
              select to_char(b.ndxs,'0.90') into sXs from
                     jw_jg_gzljxbxsszb a, jw_jg_gzlkcflndxsb b
               where a.ndxsdm = b.kcfldm
                 and a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id;
             if sXs is null then
               sXs:= '|无难度系数{任务}';
               else
               sXs:= sXs||'|任务设置:难度系数['||sXs||']';
             end if;
           else  ---教学班未设置难度系数，课程设置难度系数
               select to_char(b.ndxs,'0.90')  into sXs from
                      jw_jg_gzlkcxsszb a, jw_jg_gzlkcflndxsb b
                      where a.ndxsdm = b.kcfldm
                        and a.kch_id = vkch_id;
             if sXs is null then
               sXs:= '|无难度系数{课程}';
               else
               sXs:= sXs||'|课程设置:难度系数['||sXs||']';
             end if;
           end if;

          end if;
          ----难度系数--------end----------

          ----调整系数------begin----------
          if vGzlxsdm = 'tzxs' then  --调整系数
           select count(*) into icount from jw_jg_gzljxbxsszb a  where a.xnm = vXnm
                                                                   and a.xqm = vXqm
                                                                   and a.jxb_id = vJxb_id
                                                                   and a.tzxs is not null;
           if icount > 0 then  ---教学班设置调整系数时
              select to_char(a.tzxs,'0.90') into sXs from
                     jw_jg_gzljxbxsszb a
               where a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and a.tzxs is not null;
             if sXs is null then
               sXs:= '|无调整系数{任务}';
               else
               sXs:= sXs||'|任务设置:调整系数['||sXs||']';
             end if;
           else  ---教学班未设置调整系数，课程设置调整系数
               select to_char(a.tzxs,'0.90')  into sXs from
                      jw_jg_gzlkcxsszb a
                      where a.kch_id = vkch_id
                        and a.tzxs is not null;
           if sXs is null then
               sXs:= '|无调整系数{课程}';
               else
               sXs:= sXs||'|课程设置:调整系数['||sXs||']';
           end if;
           end if;

          end if;
          ----调整系数--------end----------

          ----新开课系数-----begin----------
         if vGzlxsdm = 'xkkxs' then  --新开课系数
           select count(*) into icount from jw_jg_gzljxbxsszb a  where a.xnm = vXnm
                                                                   and a.xqm = vXqm
                                                                   and a.jxb_id = vJxb_id
                                                                   and a.xkkxs is not null;
           if icount > 0 then  ---教学班设置新开课系数时
              select to_char(a.xkkxs,'0.90') into sXs from
                     jw_jg_gzljxbxsszb a
               where a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and a.xkkxs is not null;
             if sXs is null then
               sXs:= '|无新开课系数{任务}';
               else
               sXs:= sXs||'|任务设置:新开课系数['||sXs||']';
             end if;
           else  ---教学班未设置新开课系数，课程设置新开课系数
               select to_char(a.xkkxs,'0.90')  into sXs from
                      jw_jh_kcdmb a
                      where a.kch_id = vKch_id
                        and a.xkkxs is not null;
           if sXs is null then
               sXs:= '|无新开课系数{课程}';
               else
               sXs:= sXs||'|课程设置:新开课系数['||sXs||']';
           end if;
           end if;
          end if;
          ----新开课系数-------end----------
          ----环节系数------begin----------
          if vGzlxsdm = 'hjxs' then  --环节系数
           select count(*) into icount from jw_jg_gzljxbxsszb a  where a.xnm = vXnm
                                                                   and a.xqm = vXqm
                                                                   and a.jxb_id = vJxb_id
                                                                   and a.hjxs is not null;
           if icount > 0 then  ---教学班设置调整系数时
              select to_char(a.hjxs,'0.90') into sXs from
                     jw_jg_gzljxbxsszb a
               where a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and a.hjxs is not null;
             if sXs is null then
               sXs:= '|无环节系数{任务}';
               else
               sXs:= sXs||'|任务设置:环节系数['||sXs||']';
             end if;
           else  ---教学班未设置环节系数，课程设置环节系数
               select to_char(a.hjxs,'0.90')  into sXs from
                      jw_jg_gzlkcxsszb a
                      where a.kch_id = vkch_id
                        and a.hjxs is not null;
           if sXs is null then
               sXs:= '|无环节系数{课程}';
               else
               sXs:= sXs||'|课程设置:环节系数['||sXs||']';
           end if;
           end if;

          end if;
          ----环节系数--------end----------
          ----教学评价系数------begin----------
          if vGzlxsdm = 'jxpjxs' then  --教学评价系数
           select count(*) into icount from jw_jg_gzljxbxsszb a, JW_JG_GZLKCFLJXPJXSB b where a.jxpjxsdm = b.kcfldm
                                                                                        and a.xnm = vXnm
                                                                                        and a.xqm = vXqm
                                                                                        and a.jxb_id = vJxb_id;


           if icount > 0 then  ---教学班设置教学评价系数

            select nvl(sum(to_char(nvl(tjb.bfzpf,0),'990.99')),0) into v_pjdf
            from jw_pj_xspjjxbtjb tjb
            where tjb.pjdxdm = '01'
              and tjb.xnm = vXnm
              and tjb.xqm = vXqm
              and tjb.jxb_id = vJxb_id
              and tjb.kch_id = vKch_id
              and tjb.jgh_id = vJgh_id;

              select to_char(b.jxpjxs,'0.90'), b.fsdxx || '-' || b.fsdsx into sXs,sRsd
                from jw_jg_gzljxbxsszb a, JW_JG_GZLKCFLJXPJXSB b
               where a.jxpjxsdm = b.kcfldm
                 and a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.jxb_id = vJxb_id
                 and to_number(v_pjdf) >= b.fsdxx
                 and to_number(v_pjdf) < b.fsdsx;

             if sXs is null then
               sXs:= '|无教学评价系数{任务}';
               else
               sXs:= sXs||'|教学评价任务分数段:'||sRsd||' 评价得分:'||iXkrs||'['||sXs||']|';
             end if;

           else  ---教学班未设置难度系数，课程设置难度系数

                select nvl(sum(to_char(nvl(tjb.bfzpf,0),'990.99')),0) into v_pjdf
                from jw_pj_xspjjxbtjb tjb
                where tjb.pjdxdm = '01'
                  and tjb.xnm = vXnm
                  and tjb.xqm = vXqm
                  and tjb.kch_id = vKch_id
                  and tjb.jxb_id = vJxb_id
                  and tjb.jgh_id = vJgh_id;

              select to_char(b.jxpjxs,'0.90'), b.fsdxx || '-' || b.fsdsx into sXs,sRsd
                from jw_jg_gzlkcxsszb a, JW_JG_GZLKCFLJXPJXSB b
               where a.jxpjxsdm = b.kcfldm
                 and a.kch_id = vKch_id
                 and to_number(v_pjdf) >= b.fsdxx
                 and to_number(v_pjdf) < b.fsdsx;

               if sXs is null then
                 sXs:= '|无教学评价系数{课程}';
                 else
                 sXs:= sXs||'|教学评价课程分数段:'||sRsd||' 评价得分:'||v_pjdf||'['||sXs||']|';
               end if;
             end if;

          end if;
          ----教学评价系数--------end----------

       end if;

    exception
        When others then
          if vGzlxsdm = 'xlxs' then  --学历系数
            sXs := '|无学历系数.';
          end if;
          if vGzlxsdm = 'zcxs' then  --职称系数
            sXs := '|无职称系数.';
          end if;
          if vGzlxsdm = 'jbxs' then  --级别系数
            sXs := '|无级别系数.';
          end if;
          if vGzlxsdm = 'rsxs' then  --人数系数
            sXs := '|无人数系数.'||'|'||v_xkrs;
          end if;
          if vGzlxsdm = 'cfxs' then  --重复系数
            sXs := '|无重复系数.';
          end if;
          if vGzlxsdm = 'zfjxs' then  --主辅教系数
            sXs := '|无主辅教系数.';
          end if;
          if vGzlxsdm = 'jxmsxs' then  --教学模式系数
            sXs := '|无教学模式系数.';
          end if;
          if vGzlxsdm = 'ndxs' then  --难度系数
            sXs := '|无难度系数.';
          end if;
          if vGzlxsdm = 'tzxs' then  --调整系数
            sXs := '|无调整系数.';
          end if;
          if vGzlxsdm = 'tzxs' then  --新开课系数
            sXs := '|无新开课系数.';
          end if;
          if vGzlxsdm = 'hjxs' then  --环节系数
            sXs := '|无环节系数.';
          end if;
          if vGzlxsdm = 'jxpjxs' then  --教学评价系数
            sXs := '|无教学评价系数.';
          end if;
    end;
    return sXs ;
end Get_Gzlxs;

/

