create view ZFTAL_SJCJ_GZYRSTJ as
  select xj.njdm_id,
       jg.jgmc,
       (select zymc from zftal_xtgl_zydmb where zyh_id=xj.zyh_id) zymc,
       count(1) zrs,
       sum(case
             when xs.xbm = '2' then
              1
             else
              0
           end) nss,
       (select xqmc from zftal_xtgl_xqdmb t where xqh_id = jg.lsxqid) xqmc
  from jw_xjgl_xsxjxxb xj,
       jw_xjgl_xsjbxxb xs,
       zftal_xtgl_jgdmb jg
 where xj.njdm_id is not null
   and xj.jg_id is not null
   and xj.zyh_id is not null
   and xj.xh_id = xs.xh_id
   and xj.jg_id = jg.jg_id
   and xj.xnm = '2014'
   and xj.xqm = '3'
 group by xj.njdm_id, jg.jgmc, xj.jg_id, xj.zyh_id,jg.lsxqid
/

