create function fn_encrypt_des(p_text varchar2) return varchar2 is
v_text varchar2(4000);
v_enc varchar2(4000);
raw_input RAW(128) ;
key_input RAW(128) ;
decrypted_raw RAW(2048);
v_key varchar2(128);
v_sfjm varchar2(10);
begin
  if p_text is null then
    return '';
  end if;
  v_text := rpad( p_text, (trunc(length(p_text)/8)+1)*8, chr(0));
  select zdz into v_key from jw_jcdml_xtnzb where zdm='ZJHMMY';
  select zdz into v_sfjm from jw_jcdml_xtnzb where zdm='ZJHMSFJJM';
  if v_sfjm='1' then
    raw_input := UTL_RAW.CAST_TO_RAW(v_text);
    key_input := UTL_RAW.CAST_TO_RAW(v_key);
    dbms_obfuscation_toolkit.DESEncrypt(input => raw_input,key => key_input,encrypted_data =>decrypted_raw);
    v_enc := rawtohex(decrypted_raw);
  else
    v_enc :=  p_text;
  end if;
    dbms_output.put_line(v_enc);
  return v_enc;
end;

/

