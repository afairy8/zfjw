create function Get_Kssj
(vXnm varchar2,
 vXqm varchar2,
 vKsccb_id varchar2,
 vBj  varchar2) return varchar2
as
 sKssjgs varchar2(8); ---考试时间格式
 sKssj varchar(100);---考试时间
 sKsrq varchar(32);
 sKskssj varchar(12);
 sKsjssj varchar(12);
 sZc number;
 sXqj number;
 sJc number;
begin
  select max(zdz) into sKssjgs from jw_jcdml_xtnzb where ZDM='KSSJGS';
  select max(ksrq),max(kskssj),max(ksjssj),max(zc),max(xqj),max(jc) into sKsrq,sKskssj,sKsjssj,sZc,sXqj,sJc from jw_kw_ksccb where xnm = vXnm and xqm = vXqm and ksccb_id = vKsccb_id;
     if sZc is null then
        select max(t2.zc) ,max(t2.xqj) into sZc,sXqj
          from jw_pk_xlb t1,jw_pk_rcmxb t2,jw_kw_ksccb t3
	       where t3.ksccb_id=vKsccb_id
           and t1.xl_id=t2.xl_id
           and t1.xnm=vXnm
           and t1.xqm=vXqm
           and t3.xnm=vXnm
           and t3.xqm=vXqm
           and t3.ksrq=t2.rq;
     end if;

     if vBj = '0' then---列表中考试时间
        if sKssjgs='0' then ---默认:2017-10-18(10:30-11:30)
           sKssj := sKsrq||'('||sKskssj||'-'||sKsjssj||')';
        end if;

        if sKssjgs='1' then ---格式一：第19周,周5,(2017-11-10),10:40:00-12:15:00
           sKssj:= (case when sZc is null then '' else '第'||sZc||'周,'||'周'||sXqj||',' end)||'('||sKsrq || '),' || sKskssj || '-' ||sKsjssj;
        end if;

        if sKssjgs='2' then ---格式二：第19周周一(2018-04-01) 09:00-11:00
           sKssj := (case when sZc is null then '' else '第'||sZc||'周'||'周'||sXqj end)||'('||sKsrq || ') ' || sKskssj || '-' ||sKsjssj;
        end if;

        if nvl(sKssj,'-1')='-1' then
           sKssj := sKsrq||'('||sKskssj||'-'||sKsjssj||')';
        end if;

     end if;

     if vBj = '1' then---集中排考试时间右边“日期/场次”格式
        if sKssjgs='0' then ---默认:2017-10-18
           sKssj := sKsrq;
        end if;

        if sKssjgs='1' then ---格式一：2017-10-18
           sKssj := sKsrq;
        end if;

        if sKssjgs='2' then ---格式二：第19周周一 2018-04-01
           sKssj := (case when sZc is null then '' else '第'||sZc||'周'||'周'||sXqj end)||' '||sKsrq;
        end if;

        if nvl(sKssj,'-1')='-1' then
           sKssj := sKsrq;
        end if;
     end if;

  return sKssj;
end Get_Kssj;

/

