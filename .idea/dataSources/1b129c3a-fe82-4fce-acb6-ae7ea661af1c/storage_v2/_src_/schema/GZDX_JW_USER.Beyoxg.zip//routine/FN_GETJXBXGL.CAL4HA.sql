create function fn_getJxbxgl(vJxb_id in varchar2,vSfbkbj in varchar2,vYjxb_id in varchar2,vLrcjjgh_id in varchar2,vBcxgrs in varchar2,vXscjxgsqzb_id in varchar2)-----获取教学班修改率
return number is
 sXgrs number;
 sZrs number;
 sJxbxgl number;
begin
  begin
      if vXscjxgsqzb_id is not null then
        if nvl(vSfbkbj,'0') > '0' then
           if vYjxb_id is null then
              select count(1) into sXgrs
                from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
               where a.xscjxgsqzb_id=b.xscjxgsqzb_id
                 and nvl(a.shzt,'0')<='3'
                 and a.jxb_id=vJxb_id
                 and a.lrcjjgh_id=vLrcjjgh_id and a.xscjxgsqzb_id!=vXscjxgsqzb_id;
            else
              select count(1) into sXgrs
                from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
               where a.xscjxgsqzb_id=b.xscjxgsqzb_id
                 and nvl(a.shzt,'0')<='3'
                 and a.jxb_id=vJxb_id
                 and a.lrcjjgh_id=vLrcjjgh_id
                 and a.yjxb_id=vYjxb_id and a.xscjxgsqzb_id!=vXscjxgsqzb_id;
            end if;
        else
          select count(1) into sXgrs
            from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
           where a.xscjxgsqzb_id=b.xscjxgsqzb_id
             and nvl(a.shzt,'0')<='3'
             and a.jxb_id=vJxb_id and a.xscjxgsqzb_id!=vXscjxgsqzb_id;
        end if;
      else
        if nvl(vSfbkbj,'0') > '0' then
           if vYjxb_id is null then
              select count(1) into sXgrs
                from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
               where a.xscjxgsqzb_id=b.xscjxgsqzb_id
                 and nvl(a.shzt,'0')<='3'
                 and a.jxb_id=vJxb_id
                 and a.lrcjjgh_id=vLrcjjgh_id;
            else
              select count(1) into sXgrs
                from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
               where a.xscjxgsqzb_id=b.xscjxgsqzb_id
                 and nvl(a.shzt,'0')<='3'
                 and a.jxb_id=vJxb_id
                 and a.lrcjjgh_id=vLrcjjgh_id
                 and a.yjxb_id=vYjxb_id;
            end if;
        else
          select count(1) into sXgrs
            from jw_cj_xscjxgsqzb a,jw_cj_xscjxgsqb b
           where a.xscjxgsqzb_id=b.xscjxgsqzb_id
             and nvl(a.shzt,'0')<='3'
             and a.jxb_id=vJxb_id;
        end if;
      end if;

      if vBcxgrs is not null then
         sXgrs := sXgrs+to_number(vBcxgrs);
      end if;

      if nvl(vSfbkbj,'0') > '0' then
         if vYjxb_id is null then
            select count(1) into sZrs
              from jw_cj_xscjb a,jw_kw_bkmdb b
             where a.jxb_id=b.jxb_id and a.xh_id=b.xh_id
               and a.jxb_id=vJxb_id
               and b.jgh_id=vLrcjjgh_id;
         else
            select count(1) into sZrs
              from jw_cj_xscjb a,jw_kw_bkmdb b
             where a.jxb_id=b.jxb_id and a.xh_id=b.xh_id
               and a.jxb_id=vJxb_id
               and b.jgh_id=vLrcjjgh_id
               and nvl(b.yjxb_id,b.jxb_id)=vYjxb_id;
         end if;
      else
        select count(1) into sZrs
          from jw_cj_xscjb a
         where a.jxb_id=vJxb_id;
      end if;

      if sZrs > 0 then
         sJxbxgl := round(sXgrs/sZrs*100,2);
      end if;
      return sJxbxgl;
  exception When others then
      return null;
  end;
end fn_getJxbxgl;

/

