create function fun_by_xfyqzjd(v_xh_id varchar2) return varchar2
as
   sJg varchar2(4000);   ---返回审核是否通过描述
   v_flag int;
   --v_yj varchar(2);----预警结果
begin
    sJg := '合格';
    begin

        --select  yj into  v_yj from  JW_BYGL_xsxyyjjgb  where xh_id = v_xh_id;
        --if v_yj = '1' then
          select  nvl(instr(a.zt,'N'),'1') into v_flag from  (select wm_concat(zgshzt)zt  from JW_JH_xsJXZXJHXFYQXXB where xh_id=v_xh_id and yxjd='1')a;
           if v_flag>0 then
              select wm_concat(
                    case when (nvl(t.yqzdxf,0) >=0 and t.yqzdxf > nvl(t.hdxf,0) and t.kczdms is null)
                             then t.xfyqjdmc ||'要求' || t.yqzdxf || '学分,实际获得' ||nvl(t.hdxf, '0')||'学分'
                         when  (nvl(t.yqzdxf,0) = 0 and t.kczdms is not null and t.kczdms > nvl(t.hdkcms,0))
                             then t.xfyqjdmc ||'要求' || t.kczdms || '门数,实际获得' ||nvl(t.hdkcms, '0')||'门数'
                         when ( (t.yqzdxf is not null and t.yqzdxf > nvl(t.hdxf,0)) or ( t.kczdms is not null and t.kczdms > nvl(t.hdkcms,0)) )
                            then   t.xfyqjdmc ||'要求' || t.yqzdxf || '学分,实际获得' ||nvl(t.hdxf, '0')||'学分,或要求' || t.kczdms || '门数,实际获得' ||nvl(t.hdkcms, '0')||'门数'
                         end
                 ) into sJg
                  from JW_JH_xsJXZXJHXFYQXXB t
                 where t.xh_id = v_xh_id
                   and t.xdlx = 'zx'
                   and t.zgshzt = 'N'
           and t.yxjd='1'
           and t.fxfyqjd_id is not null;
              sJg := sJg||',不合格!';
           else
              sJg:= '合格！';
           end if;
         --end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_xfyqzjd;

/

