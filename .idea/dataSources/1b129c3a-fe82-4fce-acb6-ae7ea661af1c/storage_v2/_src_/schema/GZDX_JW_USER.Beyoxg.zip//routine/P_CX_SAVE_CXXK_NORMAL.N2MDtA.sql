create procedure p_cx_save_cxxk_normal
(
    in_xh_id in varchar2,
    in_jxb_id in varchar2,
    in_xqh_id in varchar2,
    in_bmsj in varchar2,
    in_cxbmlx in varchar2,
    in_sfqzbj in varchar2,
    in_yxzx in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
) as
    v_count number;
    v_jxbrl number;
    v_yxrs number;
    v_xf number;
    v_jfdj number;
    v_njdm_id varchar2(32);
    v_zyh_id varchar2(32);
    v_kch_id varchar2(32);
    v_kcmc varchar2(100);
    v_xkxnm varchar2(5);
    v_xkxqm varchar2(2);
    v_sfqzbj varchar2(2);
    v_yxzx varchar2(2);
    v_gbcxcrlkg varchar2(2);--跟班重修超容量开关
    v_dkbcxcrlkg varchar2(2);--单开班重修超容量开关
    v_dkbcxkxqkg varchar2(4);
    v_gbcxkxqkg varchar2(4);
    v_count_2 number;
    v_count_bct number;
    v_count_zib number;
    v_zi_jxb varchar2(32);
    v_fjxb_id varchar2(32);
    v_jxb_ids1 varchar2(4000);
    v_jxb_ids2 varchar2(4000);
    v_jxb_ids3 varchar2(4000);
    jxb_array mytype;
  jxb_id_array mytype; -- 理论带实验的 会传多个jxb_id 以逗号隔开
begin
    jxb_id_array := my_split(in_jxb_id,',');-- 初始化
    v_sfqzbj := in_sfqzbj;
    v_yxzx := in_yxzx;
    out_flag := 1;
    if in_yxzx is null then
        v_yxzx := '0';
    end if;

    /*select count(*) into v_count from jw_bygl_bysfzxxb where xh_id=in_xh_id;
    if v_count >0 then
       out_flag := -1;
       out_msg := '对不起，毕业班的学生不建议跟班选课，请在重组报名页签报名，如有需要，请与管理员联系！';
       goto nextOne;
    end if;*/
    select count(*) into v_count from jw_cj_cxbmszb where zt='1' and sysdate between kssj and jssj;
    if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，重修选课时间已过，不可再选！';
        goto nextOne;
    end if;

    select
        xnm,xqm,gbcxcrlkg,dkbcxcrlkg,dkbcxkxqkg,gbcxkxqkg
        into
        v_xkxnm,v_xkxqm,v_gbcxcrlkg,v_dkbcxcrlkg,v_dkbcxkxqkg,v_gbcxkxqkg
    from jw_cj_cxbmszb where zt='1';

    select kch_id into v_kch_id from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=jxb_id_array(1);
    select nvl(t1.xf,0),kcmc into v_xf,v_kcmc from jw_jh_kcdmb t1 where t1.kch_id=v_kch_id;

    if v_yxzx='1' then
        select count(*) into v_count from jw_jcdml_xtnzb where zdm='CXZZXXZKG' and zdz='1';
        if v_count>0 then --只有正常重修的课程无容量或有上课时间冲突时，才能选自修课程
            if in_cxbmlx='1' then --跟班重修
                if v_gbcxkxqkg='1' then --跨校区
                    select
                        count(*) into v_count
                    from
                        jw_jxrw_jxbxxb t
                    where
                        --有无任务教学班
                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.cxbmkg ='1'
                        --有可能跨校区
                        and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                        --有无余量
                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));

                    if v_count>0 then --有容量时，还需要判断有无上课时间冲突情况
                        select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
                            select rn,wm_concat(jxb_id) as jxb_ids from (
                                select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from (
                                    select jxb_id from jw_jxrw_jxbxxb t
                                    where
                                        --有无任务教学班
                                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.cxbmkg ='1'
                                        --有可能跨校区
                                        and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                        --有无余量
                                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                                    minus
                                    select jxb_id from (
                                        select t2.jxb_id from (
                                            select a.jxb_id, b.xqj, b.zcd, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                                            where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id and a.xh_id=in_xh_id and b.xnm=v_xkxnm
                                                and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj != '1'
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where
                                                t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                                --有可能跨校区
                                                and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0)))
                                        ) t2
                                    where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                    union
                                    select t2.jxb_id from (
                                        select sum(zc) zcd, xqj, jc from (
                                            select zc, xqj, sum(jcm) jc from (
                                                select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                                    select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b
                                                    where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                ) t2,
                                                jw_pk_rsdszb a,
                                                jw_pk_rjcszb b,
                                                jw_pk_rsddmb c,
                                                (
                                                    --正考学生--
                                                    select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                                    where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                        and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                        and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                    group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    union all
                                                    --补考学生--
                                                    select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                                    where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                        and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                        and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm
                                                        and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                    group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                ) t3
                                                where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                    and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                    and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                            )
                                            group by zc, xqj
                                        )
                                        group by jc, xqj
                                    ) t1,
                                    (
                                        select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                        where exists (
                                            select 'x' from jw_jxrw_jxbxxb t
                                            --有无任务教学班
                                            where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                            --有可能跨校区
                                            and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                            --有无余量
                                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                        )
                                    ) t2
                                    where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                    union
                                    select t2.jxb_id from (
                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                            and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        union all
                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                            and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                    ) t1,
                                    (
                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                            and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                    ) t2
                                    where t1.ksrq=t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                                        and exists (
                                            select 'x' from jw_jxrw_jxbxxb t
                                            --有无任务教学班
                                            where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                            --有可能跨校区
                                            and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                            --有无余量
                                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                        )
                                    union
                                    select t2.jxb_id from (
                                        select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                                        where a.jxb_id=b.jxb_id and b.xh_id=in_xh_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and nvl(b.zxbj, '0')='0'
                                    ) t1,
                                    (
                                        select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                                            select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                                select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                                    select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                    from jw_pk_xlb a, jw_pk_rcmxb b
                                                    where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                ) t2,
                                                jw_pk_rsdszb a,
                                                jw_pk_rjcszb b,
                                                jw_pk_rsddmb c,
                                                (
                                                    select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                    from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb   t4
                                                    where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                        and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                        and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                    group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                ) t3
                                                where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                    and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                    and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                            )
                                            group by zc, xqj, kch_id, jxb_id
                                        )
                                        group by jc, xqj, kch_id, jxb_id
                                    ) t2
                                    where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                                        and exists(
                                            select 'x' from jw_jxrw_jxbxxb t
                                            --有无任务教学班
                                            where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                            --有可能跨校区
                                            and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                            --有无余量
                                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                        )
                                    )
                                )
                            )
                            group by rn
                        );

                        if v_jxb_ids1 is not null then
                            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
                            for i in 1..jxb_array.count loop
                                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                                if v_zi_jxb=1 then
                                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                                        v_count_bct := 1;
                                        goto stepOne;
                                    end if;
                                else
                                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                                    if v_count_zib>0 then
                                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                                        if v_count_2>0 then
                                            v_count_bct := 1;
                                            goto stepOne;
                                        end if;
                                    else
                                        v_count_bct := 1;
                                        goto stepOne;
                                    end if;
                                end if;
                            end loop;
                        end if;
                        <<stepOne>>
                        if v_count_bct>0 then
                            out_flag := 0;
                            out_msg := '该课程有可以选重修的教学班，请在“跟班重修（选课）”页签下选择！';
                            goto nextOne;
                        end if;
                    end if;
                else --不跨校区
                    select
                        count(*) into v_count
                    from
                        jw_jxrw_jxbxxb t
                    where
                        --有无任务教学班
                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
                        --是否在同一个校区
                         and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.cxbmkg ='1'
                        --有无余量
                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));

                    if v_count>0 then --有容量时，还需要判断有无上课时间冲突情况
                        select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
                            select rn,wm_concat(jxb_id) as jxb_ids from (
                                select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from (
                                    select jxb_id from jw_jxrw_jxbxxb t
                                    where
                                        --有无任务教学班
                                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
                                        --是否在同一个校区
                                        and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.cxbmkg ='1'
                                        --有无余量
                                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                                    minus
                                    select jxb_id from (
                                            select t2.jxb_id from (
                                                select a.jxb_id, b.xqj, b.zcd, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                                                where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id and a.xh_id=in_xh_id and b.xnm=v_xkxnm
                                                    and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj != '1'
                                            ) t1,
                                            (
                                                select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                                where exists (
                                                    select 'x' from jw_jxrw_jxbxxb t
                                                    --有无任务教学班
                                                    where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id
                                                    --是否在同一个校区
                                                    and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                                    --有无余量
                                                    and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0)))
                                            ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                        union
                                        select t2.jxb_id from (
                                            select sum(zc) zcd, xqj, jc from (
                                                select zc, xqj, sum(jcm) jc from (
                                                    select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b
                                                        where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        --正考学生--
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                            and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                        union all
                                                        --补考学生--
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                            and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm
                                                            and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                        and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                        and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj
                                            )
                                            group by jc, xqj
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id
                                                --是否在同一个校区
                                                and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.cxbmkg='1')
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                        union
                                        select t2.jxb_id from (
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            union all
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        ) t1,
                                        (
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        ) t2
                                        where t1.ksrq=t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                                            and exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id
                                                --是否在同一个校区
                                                and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.cxbmkg='1'
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        union
                                        select t2.jxb_id from (
                                            select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                                            where a.jxb_id=b.jxb_id and b.xh_id=in_xh_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and nvl(b.zxbj, '0')='0'
                                        ) t1,
                                        (
                                            select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                                                select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                                    select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                        from jw_pk_xlb a, jw_pk_rcmxb b
                                                        where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb   t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                            and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                        and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                        and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj, kch_id, jxb_id
                                            )
                                            group by jc, xqj, kch_id, jxb_id
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                                            and exists(
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id
                                                --是否在同一个校区
                                                and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.cxbmkg='1')
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                    )
                                )
                            )
                            group by rn
                        );

                        if v_jxb_ids1 is not null then
                            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
                            for i in 1..jxb_array.count loop
                                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                                if v_zi_jxb=1 then
                                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                                        v_count_bct := 1;
                                        goto stepTwo;
                                    end if;
                                else
                                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                                    if v_count_zib>0 then
                                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                                        if v_count_2>0 then
                                            v_count_bct := 1;
                                            goto stepTwo;
                                        end if;
                                    else
                                        v_count_bct := 1;
                                        goto stepTwo;
                                    end if;
                                end if;
                            end loop;
                        end if;
                        <<stepTwo>>
                        if v_count_bct>0 then
                            out_flag := 0;
                            out_msg := '该课程有可以选重修的教学班，请在“跟班重修（选课）”页签下选择！';
                            goto nextOne;
                        end if;
                    end if;
                end if;
            elsif in_cxbmlx='2' then --单开班重修
                if v_dkbcxkxqkg='1' then --跨校区
                    select
                        count(*) into v_count
                    from jw_jxrw_jxbxxb t
                    --有无任务教学班
                    where
                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.kklxdm='08'
                        --有可能跨校区
                        and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                        --有无余量
                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));

                    if v_count>0 then
                        select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
                            select rn,wm_concat(jxb_id) as jxb_ids from (
                                select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from  (
                                    select jxb_id from jw_jxrw_jxbxxb t
                                    --有无任务教学班
                                    where
                                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.kklxdm='08'
                                        --有可能跨校区
                                        and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                        --有无余量
                                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                                    minus
                                    select jxb_id from (
                                        select t2.jxb_id from (
                                            select a.jxb_id, b.xqj, b.zcd, b.jc
                                            from jw_xk_xsxkb a, jw_pk_kbsjb b
                                            where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id and a.xh_id=in_xh_id
                                                and b.xnm=v_xkxnm and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj != '1'
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.kklxdm='08'
                                                --有可能跨校区
                                                and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0
                                        union
                                        select t2.jxb_id from (
                                            select sum(zc) zcd, xqj, jc from (
                                                select zc, xqj, sum(jcm) jc from (
                                                    select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                           from jw_pk_xlb a,jw_pk_rcmxb b
                                                           where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        --正考学生--
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                              and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                               and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                          group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                          union all
                                                          --补考学生--
                                                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                                         where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                             and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                             and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                         group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                        and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                        and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj
                                            )
                                            group by jc, xqj
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                    --有无任务教学班
                                                where
                                                    t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.kklxdm='08'
                                                    --有可能跨校区
                                                    and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                                    --有无余量
                                                    and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                        union
                                        select t2.jxb_id from (
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                 and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            union all
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                 and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm
                                                 and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        ) t1,
                                        (
                                             select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                             from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                             where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                  and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                             group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                           ) t2
                                        where t1.ksrq=t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                                        and exists (
                                            select 'x' from jw_jxrw_jxbxxb t
                                            --有无任务教学班
                                            where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.kklxdm='08'
                                            --有可能跨校区
                                            and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                            --有无余量
                                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                        )
                                        union
                                        select t2.jxb_id from (
                                            select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                                            where a.jxb_id=b.jxb_id and b.xh_id=in_xh_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and nvl(b.zxbj, '0')='0'
                                        ) t1,
                                        (
                                            select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                                                select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                                    select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                        from jw_pk_xlb a, jw_pk_rcmxb b
                                                        where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                            and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm
                                                        and a.xqm=t3.xqm and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00'
                                                        and b.jssj > t3.kskssj || ':00' and c.qyzt='1' and t2.xnm=t3.xnm
                                                        and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj, kch_id, jxb_id
                                            )
                                            group by jc, xqj, kch_id, jxb_id
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                                            and exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and t.kklxdm='08'
                                                --有可能跨校区
                                                and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                    )
                                )
                            )
                            group by rn
                        );
                        if v_jxb_ids1 is not null then
                            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
                            for i in 1..jxb_array.count loop
                                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                                if v_zi_jxb=1 then
                                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                                        v_count_bct := 1;
                                        goto stepThree;
                                    end if;
                                else
                                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                                    if v_count_zib>0 then
                                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                                        if v_count_2>0 then
                                            v_count_bct := 1;
                                            goto stepThree;
                                        end if;
                                    else
                                        v_count_bct := 1;
                                        goto stepThree;
                                    end if;
                                end if;
                            end loop;
                        end if;
                        <<stepThree>>

                        if v_count_bct>0 then
                            out_flag := 0;
                            out_msg := '该课程有可以选重修的教学班，请在“单开班重修（选课）”页签下选择！';
                            goto nextOne;
                        end if;
                    end if;
                else
                    select
                        count(*) into v_count
                    from jw_jxrw_jxbxxb t
                    --有无任务教学班
                    where
                        t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and t.kklxdm='08'
                        --有可能跨校区
                        and exists (select 'x' from zftal_xtgl_xqdmb xqb where xqb.xqh_id=in_xqh_id and instr(xqb.kkxkxq_id||','||xqb.xqh_id, t.xqh_id) > 0)
                        --有无余量
                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));
                    if v_count>0 then
                        select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
                            select rn,wm_concat(jxb_id) as jxb_ids from (
                                select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from  (
                                    select jxb_id from jw_jxrw_jxbxxb t
                                    --有无任务教学班
                                    where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
                                        --是否在同一个校区
                                        and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt,'3')='3' and (t.kklxdm='08')
                                        --有无余量
                                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                                    minus
                                    select jxb_id from (
                                        select t2.jxb_id from (
                                            select a.jxb_id, b.xqj, b.zcd, b.jc
                                            from jw_xk_xsxkb a, jw_pk_kbsjb b
                                            where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id and a.xh_id=in_xh_id
                                                and b.xnm=v_xkxnm and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj != '1'
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id
                                                --是否在同一个校区
                                                and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.kklxdm='08')
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0
                                        union
                                        select t2.jxb_id from (
                                            select sum(zc) zcd, xqj, jc from (
                                                select zc, xqj, sum(jcm) jc from (
                                                    select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                           from jw_pk_xlb a,jw_pk_rcmxb b
                                                           where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        --正考学生--
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                              and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                               and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                          group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                          union all
                                                          --补考学生--
                                                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                                         where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                             and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                             and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                         group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm and a.xqm=t3.xqm
                                                        and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                                        and c.qyzt='1' and t2.xnm=t3.xnm and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj
                                            )
                                            group by jc, xqj
                                        ) t1,
                                        (
                                            select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                                            where exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                    --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and sjb.jxb_id=t.jxb_id
                                                    --是否在同一个校区
                                                    and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.kklxdm='08')
                                                    --有无余量
                                                    and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                                        union
                                        select t2.jxb_id from (
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                 and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            union all
                                            select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                            from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                            where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                 and t4.bkqrbj='1' and t4.xh_id=in_xh_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm
                                                 and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                            group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                        ) t1,
                                        (
                                             select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                             from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                             where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                 and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                  and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                             group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                           ) t2
                                        where t1.ksrq=t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                                        and exists (
                                            select 'x' from jw_jxrw_jxbxxb t
                                            --有无任务教学班
                                            where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id
                                            --是否在同一个校区
                                            and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.kklxdm='08')
                                            --有无余量
                                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                        )
                                        union
                                        select t2.jxb_id from (
                                            select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                                            where a.jxb_id=b.jxb_id and b.xh_id=in_xh_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and nvl(b.zxbj, '0')='0'
                                        ) t1,
                                        (
                                            select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                                                select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                                    select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                                        select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                                        from jw_pk_xlb a, jw_pk_rcmxb b
                                                        where a.xl_id=b.xl_id and b.dxqzc <> 0
                                                    ) t2,
                                                    jw_pk_rsdszb a,
                                                    jw_pk_rjcszb b,
                                                    jw_pk_rsddmb c,
                                                    (
                                                        select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                                        where t1.xnm=t2.xnm and t1.xqm=t2.xqm and t1.xnm=t3.xnm and t1.xqm=t3.xqm
                                                            and t1.sjbh_id=t3.sjbh_id and t1.ksccb_id=t2.ksccb_id and t3.jxb_id=t4.jxb_id
                                                            and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t4.xnm=v_xkxnm and t4.xqm=v_xkxqm
                                                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                                    ) t3
                                                    where a.rsdsz_id=b.rsdsz_id and a.rsd_id=c.rsd_id and a.xnm=t3.xnm
                                                        and a.xqm=t3.xqm and a.xqh_id=in_xqh_id and b.qssj < t3.ksjssj || ':00'
                                                        and b.jssj > t3.kskssj || ':00' and c.qyzt='1' and t2.xnm=t3.xnm
                                                        and t2.xqm=t3.xqm and t2.rq=t3.ksrq
                                                )
                                                group by zc, xqj, kch_id, jxb_id
                                            )
                                            group by jc, xqj, kch_id, jxb_id
                                        ) t2
                                        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                                            and exists (
                                                select 'x' from jw_jxrw_jxbxxb t
                                                --有无任务教学班
                                                where t.kch_id=v_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t2.jxb_id=t.jxb_id
                                                --是否在同一个校区
                                                and t.xqh_id=in_xqh_id and t.sfkxk='1' and t.kkzt='1' and nvl(t.shzt, '3')='3' and (t.kklxdm='08')
                                                --有无余量
                                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                                            )
                                    )
                                )
                            )
                            group by rn
                        );
                        if v_jxb_ids1 is not null then
                            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
                            for i in 1..jxb_array.count loop
                                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                                if v_zi_jxb=1 then
                                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                                        v_count_bct := 1;
                                        goto stepFour;
                                    end if;
                                else
                                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                                    if v_count_zib>0 then
                                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                                        if v_count_2>0 then
                                            v_count_bct := 1;
                                            goto stepFour;
                                        end if;
                                    else
                                        v_count_bct := 1;
                                        goto stepFour;
                                    end if;
                                end if;
                            end loop;
                        end if;
                        <<stepFour>>

                        if v_count_bct>0 then
                            out_flag := 0;
                            out_msg := '该课程有可以选重修的教学班，请在“单开班重修（选课）”页签下选择！';
                            goto nextOne;
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end if;

    FOR i IN 1..jxb_id_array.count LOOP --添加循环jxb_id  in_jxb_id修改为 jxb_id_array(i)
        select kch_id,nvl(jxbrs,0)+nvl(krrl,0) into v_kch_id,v_jxbrl from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(i);
        if v_yxzx='0' then
            if (in_cxbmlx='1' and v_gbcxcrlkg='0') or (in_cxbmlx='2' and v_dkbcxcrlkg='0')  then--跟班或者单开班需要判断容量
                select count(*) into v_yxrs from jw_xk_xsxkb where jxb_id=jxb_id_array(i) and xnm=v_xkxnm and xqm=v_xkxqm and nvl(zxbj,'0')!='1';
                if v_jxbrl<=v_yxrs then
                    out_flag := -1;
                    out_msg := '对不起，当前教学班已无余量，不可再选！';
                    goto nextOne;
                end if;
            end if;
        end if;
        select count(*) into v_count from jw_jxrw_jxbxxb a where a.jxb_id=jxb_id_array(i) and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xqh_id=in_xqh_id;
        if v_count=0 and in_yxzx='0' then
            if (in_cxbmlx='1' and v_gbcxkxqkg='0') or (in_cxbmlx='2' and v_dkbcxkxqkg='0')  then
                out_flag := -1; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
                out_msg := '对不起，您所在校区和该教学班上课校区不同，不可选！';
                goto nextOne;
            end if;
        end if;
        --再判断一次时间冲突 确认sfszbj的值
        if v_yxzx='0' then
            select count(*) into v_count
            from
            (----上课冲突
                select b.zcd, b.xqj, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id
                      and a.xh_id=in_xh_id and b.xnm=v_xkxnm
                      and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj !='1'
                union all
                ----考试冲突
                select sum(zc) zcd,xqj,jc from(
                select zc,xqj,sum(jcm) jc from (
                select t2.zc, t2.xqj, t3.xh_id, b.jcm, t3.xnm, t3.xqm, a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq
                  from (select a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b where a.xl_id=b.xl_id  and b.dxqzc <> 0 )t2,
                       jw_pk_rsdszb a,
                       jw_pk_rjcszb b,
                       jw_pk_rsddmb c,
                       (
                          --正考学生--
                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                          where t1.xnm=t2.xnm
                               and t1.xqm=t2.xqm
                               and t1.xnm=t3.xnm
                               and t1.xqm=t3.xqm
                               and t1.sjbh_id=t3.sjbh_id
                               and t1.ksccb_id=t2.ksccb_id
                               and t3.jxb_id=t4.jxb_id
                               and t4.xh_id=in_xh_id
                               and t1.xnm=v_xkxnm
                               and t1.xqm=v_xkxqm
                               and t4.xnm=v_xkxnm
                               and t4.xqm=v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm
                       union all
                       --补考学生--
                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                          where t1.xnm=t2.xnm
                               and t1.xqm=t2.xqm
                               and t1.xnm=t3.xnm
                               and t1.xqm=t3.xqm
                               and t1.sjbh_id=t3.sjbh_id
                               and t1.ksccb_id=t2.ksccb_id
                               and t3.jxb_id=t4.jxb_id
                               and t4.bkqrbj='1'
                               and t4.xh_id=in_xh_id
                               and t1.xnm=v_xkxnm
                               and t1.xqm=v_xkxqm
                               and t4.xnm=v_xkxnm
                               and t4.xqm=v_xkxqm
                          group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm
                        )t3
                    where a.rsdsz_id=b.rsdsz_id
                        and a.rsd_id=c.rsd_id
                        and a.xnm=t3.xnm
                        and a.xqm=t3.xqm
                        and a.xqh_id=in_xqh_id
                        and b.qssj < t3.ksjssj||':00' and b.jssj > t3.kskssj||':00'
                        and c.qyzt='1'
                        and t2.xnm=t3.xnm
                        and t2.xqm=t3.xqm
                        and t2.rq=t3.ksrq
                    )group by zc,xqj)group by jc,xqj
                ) t1,
                (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i) ) t2
            where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;
        else
            select count(*) into v_count from
            (----上课冲突
               select b.zcd, b.xqj, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where a.jxb_id=b.jxb_id and a.kch_id != v_kch_id
                      and a.xh_id=in_xh_id and b.xnm=v_xkxnm
                      and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zxbj !='1'
             ) t1,
            (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2
            where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;
        end if;
        if v_count > 0 then
            v_sfqzbj := '1';
        else
            v_sfqzbj := '0';
        end if;

        select count(*) into v_count from jw_jcdml_xtnzb where zdm='CXFCCKKG' and zdz='1';
        if v_count>0 then
            select count(*) into v_count from jw_cj_xscjb where xh_id=in_xh_id and kch_id=v_kch_id and bfzcj>=60;
            if v_count>0 then
               insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,sfqzbj,cxbmlx,xnm,xqm,kch_id,zxbj) values (jxb_id_array(i),in_xh_id,'1',in_bmsj,in_xh_id,1,0,'1','10','0','2',v_sfqzbj,in_cxbmlx,v_xkxnm,v_xkxqm,v_kch_id,v_yxzx);
            else
               insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,sfqzbj,cxbmlx,xnm,xqm,kch_id,zxbj) values (jxb_id_array(i),in_xh_id,'1',in_bmsj,in_xh_id,1,0,'1','10','0','1',v_sfqzbj,in_cxbmlx,v_xkxnm,v_xkxqm,v_kch_id,v_yxzx);
            end if;
        else
            insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,sfqzbj,cxbmlx,xnm,xqm,kch_id,zxbj) values (jxb_id_array(i),in_xh_id,'1',in_bmsj,in_xh_id,1,0,'1','10','0','1',v_sfqzbj,in_cxbmlx,v_xkxnm,v_xkxqm,v_kch_id,v_yxzx);
        end if;

        if i=1 then
            select count(*) into v_count from jw_jcdml_xtnzb where zdm='CXBMJFXXXS' and zdz='1';
            if v_count>0 then
                select njdm_id,zyh_id into v_njdm_id,v_zyh_id from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
                v_jfdj := fn_cx_jfdj(v_njdm_id,v_zyh_id,v_kch_id,jxb_id_array(1),in_xh_id,'2');
                select count(*) into v_count from jw_jcdml_xtnzb where zdm='SFKQBMSCDD' and zdz='1';
                if  v_count>0 then
                   insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name,order_id)
                   values('05','jw_xk_xsxkb',v_xkxnm||lpad(v_xkxqm,2,'0')||v_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc,'ZZJF'||to_char(sysdate,'yyyyMMddHHmmss')||trunc(dbms_random.value(1000,9999)));
               else
                  insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name)
                  values('05','jw_xk_xsxkb',v_xkxnm||lpad(v_xkxqm,2,'0')||v_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc);
               end if;
            end if;
        end if;
    end LOOP;
    <<nextOne>>

    if out_flag='-1' then
        rollback;
    else
        commit;
    end if;
end;

/

