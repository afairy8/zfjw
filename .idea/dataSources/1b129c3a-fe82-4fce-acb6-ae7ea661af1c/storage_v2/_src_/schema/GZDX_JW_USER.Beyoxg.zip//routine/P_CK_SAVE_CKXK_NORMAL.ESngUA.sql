create procedure p_ck_save_ckxk_normal
(
  in_xh_id in varchar2,
  in_jxb_id in varchar2,
  in_xqh_id in varchar2,
  in_bmsj in varchar2,
  in_cxbmlx in varchar2,
  in_sfqzbj in varchar2,
  in_yxzx in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
) as
  v_count number;
  v_jxbrl number;
  v_yxrs number;
  v_xf number;
  v_jfdj number;
  v_zxfs varchar2(8);
  v_njdm_id varchar2(32);
  v_zyh_id varchar2(32);
  v_kch_id varchar2(32);
  v_kcmc varchar2(100);
  v_xkxnm varchar2(5);
  v_xkxqm varchar2(2);
  v_sfqzbj varchar2(2);
  v_yxzx varchar2(2);
  v_gbckcrlkg varchar2(2);--跟班重修超容量开关
  v_dkbckcrlkg varchar2(2);--单开班重修超容量开关
  v_dkbckkxqkg varchar2(4);
  v_gbckkxqkg varchar2(4);
  jxb_id_array mytype; -- 理论带实验的 会传多个jxb_id 以逗号隔开
begin
    jxb_id_array := my_split(in_jxb_id,',');-- 初始化
    v_sfqzbj := in_sfqzbj;
    v_yxzx := in_yxzx;
    out_flag := 1;
    if in_yxzx is null then
        v_yxzx := '0';
    end if;

    /*select count(*) into v_count from jw_bygl_bysfzxxb where xh_id = in_xh_id;
    if v_count >0 then
       out_flag := -1;
       out_msg := '对不起，毕业班的学生不建议跟班选课，请在重组报名页签报名，如有需要，请与管理员联系！';
       goto nextOne;
    end if;*/
    select count(*) into v_count from jw_cj_ckbmszb where zt = '1' and sysdate between kssj and jssj;
    if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，重修选课时间已过，不可再选！';
        goto nextOne;
    end if;

    select
        xnm,xqm,gbckcrlkg,dkbckcrlkg,dkbckkxqkg,gbckkxqkg
        into
        v_xkxnm,v_xkxqm,v_gbckcrlkg,v_dkbckcrlkg,v_dkbckkxqkg,v_gbckkxqkg
    from jw_cj_ckbmszb where zt = '1';

    select kch_id into v_kch_id from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=jxb_id_array(1);
    select nvl(t1.xf,0),kcmc into v_xf,v_kcmc from jw_jh_kcdmb t1 where t1.kch_id = v_kch_id;

    FOR i IN 1..jxb_id_array.count LOOP --添加循环jxb_id  in_jxb_id修改为 jxb_id_array(i)
        select kch_id,nvl(jxbrs,0)+nvl(krrl,0) into v_kch_id,v_jxbrl from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(i);
        if v_yxzx = '0' then
            if (in_cxbmlx='1' and v_gbckcrlkg='0') or (in_cxbmlx='2' and v_dkbckcrlkg='0')  then--跟班或者单开班需要判断容量
                select count(*) into v_yxrs from jw_xk_xsxkb where jxb_id=jxb_id_array(i) and xnm=v_xkxnm and xqm=v_xkxqm and nvl(zxbj,'0')!='1';
                if v_jxbrl<=v_yxrs then
                    out_flag := -1;
                    out_msg := '对不起，当前教学班已无余量，不可再选！';
                    goto nextOne;
                end if;
            end if;
        end if;
        select count(*) into v_count from jw_jxrw_jxbxxb a where a.jxb_id=jxb_id_array(i) and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xqh_id=in_xqh_id;
        if v_count=0 and in_yxzx = '0' then
            if (in_cxbmlx='1' and v_gbckkxqkg='0') or (in_cxbmlx='2' and v_dkbckkxqkg='0')  then
                out_flag := -1; --注意 flag 不能设置为2 因为在外面业务中2已经被占用
                out_msg := '对不起，您所在校区和该教学班上课校区不同，不可选！';
                goto nextOne;
            end if;
        end if;
        --再判断一次时间冲突 确认sfszbj的值
        if v_yxzx = '0' then
            select count(*) into v_count
            from
            (----上课冲突
                select b.zcd, b.xqj, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where a.jxb_id = b.jxb_id and a.kch_id != v_kch_id
                      and a.xh_id = in_xh_id and b.xnm = v_xkxnm
                      and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm and a.zxbj !='1'
                union all
                ----考试冲突
                select sum(zc) zcd,xqj,jc from(
                select zc,xqj,sum(jcm) jc from (
                select t2.zc, t2.xqj, t3.xh_id, b.jcm, t3.xnm, t3.xqm, a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq
                  from (select a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b where a.xl_id = b.xl_id  and b.dxqzc <> 0 )t2,
                       jw_pk_rsdszb a,
                       jw_pk_rjcszb b,
                       jw_pk_rsddmb c,
                       (
                          --正考学生--
                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                          where t1.xnm = t2.xnm
                               and t1.xqm = t2.xqm
                               and t1.xnm = t3.xnm
                               and t1.xqm = t3.xqm
                               and t1.sjbh_id = t3.sjbh_id
                               and t1.ksccb_id = t2.ksccb_id
                               and t3.jxb_id = t4.jxb_id
                               and t4.xh_id = in_xh_id
                               and t1.xnm = v_xkxnm
                               and t1.xqm = v_xkxqm
                               and t4.xnm = v_xkxnm
                               and t4.xqm = v_xkxqm group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm
                       union all
                       --补考学生--
                          select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                          from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                          where t1.xnm = t2.xnm
                               and t1.xqm = t2.xqm
                               and t1.xnm = t3.xnm
                               and t1.xqm = t3.xqm
                               and t1.sjbh_id = t3.sjbh_id
                               and t1.ksccb_id = t2.ksccb_id
                               and t3.jxb_id = t4.jxb_id
                               and t4.bkqrbj = '1'
                               and t4.xh_id = in_xh_id
                               and t1.xnm = v_xkxnm
                               and t1.xqm = v_xkxqm
                               and t4.xnm = v_xkxnm
                               and t4.xqm = v_xkxqm
                          group by t2.ksrq, t2.kskssj, t2.ksjssj, t4.xh_id, t1.xnm, t1.xqm
                        )t3
                    where a.rsdsz_id = b.rsdsz_id
                        and a.rsd_id = c.rsd_id
                        and a.xnm = t3.xnm
                        and a.xqm = t3.xqm
                        and a.xqh_id = in_xqh_id
                        and b.qssj < t3.ksjssj||':00' and b.jssj > t3.kskssj||':00'
                        and c.qyzt = '1'
                        and t2.xnm = t3.xnm
                        and t2.xqm = t3.xqm
                        and t2.rq = t3.ksrq
                    )group by zc,xqj)group by jc,xqj
                ) t1,
                (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i) ) t2
            where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;
        else
            select count(*) into v_count from
            (----上课冲突
               select b.zcd, b.xqj, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where a.jxb_id = b.jxb_id and a.kch_id != v_kch_id
                      and a.xh_id = in_xh_id and b.xnm = v_xkxnm
                      and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm and a.zxbj !='1'
             ) t1,
            (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2
            where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;
        end if;
        if v_count > 0 then
            v_sfqzbj := '1';
        else
            v_sfqzbj := '0';
        end if;

        insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,sfqzbj,cxbmlx,xnm,xqm,kch_id,zxbj,bklx_id)
		values
		(
			jxb_id_array(i),in_xh_id,'1',in_bmsj,in_xh_id,1,0,'1','10','0','2',v_sfqzbj,in_cxbmlx,v_xkxnm,v_xkxqm,v_kch_id,v_yxzx,
			(select nvl(max(n.bklx_id),'0') from jw_jxrw_jxbhbxxb m,jw_jxrw_bkxxb n where m.bkxxb_id=n.bkxxb_id and m.jxb_id=jxb_id_array(i))
		);
		update jw_jxrw_jxbxxb set yxzrs=(select count(*) from jw_xk_xsxkb t2 where jxb_id=jxb_id_array(i) and nvl(zxbj,'0')='0') where jxb_id=jxb_id_array(i);
        if i=1 then
            select count(*) into v_count from jw_jcdml_xtnzb where zdm='CKBMJFXXXS' and zdz='1';
            if v_count>0 then
                select njdm_id,zyh_id into v_njdm_id,v_zyh_id from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
                v_jfdj := fn_cx_jfdj(v_njdm_id,v_zyh_id,v_kch_id,jxb_id_array(1),in_xh_id,'2');
                insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name)
                values('05','jw_xk_xsxkb',v_xkxnm||lpad(v_xkxqm,2,'0')||v_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc);
            end if;
        end if;
    end LOOP;
    <<nextOne>>

    if out_flag = '-1' then
        rollback;
    else
        commit;
    end if;
end;

/

