create procedure p_xk_choose_zykc_3
(
  in_rwlx in varchar2,
  in_kklxdm in varchar2,
  in_ids in varchar2,
  in_xsbxfs in varchar2,
  in_rlkz in varchar2,
  in_rlzlkz in varchar2,
  in_xh_id in varchar2,
  in_njdm_id in varchar2,
  in_zyh_id in varchar2,
  in_xkxnm in varchar2,
  in_xkxqm in varchar2,
  in_xklc in varchar2,
  in_cxbj in varchar2,
  in_xxkbj in varchar2,
  in_kch_id in varchar2,
  in_xkkz_id in varchar2,
  in_qz in varchar2,
  in_sxbj in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
) as
    v_wyljxbxx varchar2(200);
    sqlStr varchar2(2000);
    v_count number;
    v_total_kc float;
    v_total_xf float;
    v_zdzys number;
    v_zy_count number;
    v_lnzgxkmc number;
    v_lnzgxkxf number;
    v_bxqzgxkmc number;
    v_bxqzgxkxf number;
    v_xkzgmc number;
    v_xkzgxf number;
    v_jzxk varchar2(1);
    v_sfzyxk varchar2(1);
    v_kklxmc varchar2(20);
    v_fxbj varchar2(1);
    v_cxbj varchar2(1);
    v_bklx_id varchar2(32);
    v_kkbk varchar2(1);
    v_kkbkdj varchar2(1);
    v_xzjxbCount number;
    v_xsmc varchar2(20);
    v_xsdm varchar2(40);
    isfjxb varchar2(40);
    v_msg varchar2(2000);
    v_sfkzyxk varchar2(1);
    v_kklxdm varchar2(5);
    v_kklxdm_1 varchar2(5);
    v_xkkz_id varchar2(32);
    v_xf float;
    v_jxbrs number;
    v_krrl number;
    v_yxzrs number;
    v_bxrs number;
    s_bxrs number;
    v_yl number;
    v_rwyxzrs number;
    v_sfznkx varchar2(1);
    v_zdkxms number;
    v_xxdm varchar2(10);
    v_cyxktjkz varchar2(1);
    v_txbsfrl varchar2(1);
    v_xkydjc varchar2(1);
    v_sfkknj  JW_XK_XKKZXMB.sfkknj%type;
    v_sfkkzy  JW_XK_XKKZXMB.sfkkzy%type;
    wyljxb_id_array mytype;
    jxb_id_array mytype;
    xsbxf_array mytype;
    /*cursor cursor_xsxk(v_xh_id varchar2,v_xnm varchar2,v_xqm varchar2,v_kch_id varchar2) is
           select jxb_id,rownum rwn from (
                 select a.jxb_id from JW_XK_XSXKB a,jw_jxrw_jxbxxb b
                 where a.jxb_id=b.jxb_id and a.xnm=v_xnm and a.xqm=v_xqm and a.xh_id=v_xh_id
                       and a.zy>0 and b.kch_id=v_kch_id and b.xnm=v_xnm and b.xqm=v_xqm and b.fjxb_id is null
                 order by a.zy);*/
begin
    out_flag := '1';
    v_xsdm := '01';
    v_xsmc := '讲课';
    v_fxbj := '0';
    if in_cxbj is null or in_cxbj = '' then
       v_cxbj := '0';
    else
       v_cxbj := in_cxbj;
    end if;
    v_zy_count := 0;
    v_bklx_id := '0';
    v_wyljxbxx := '';--初始化
    jxb_id_array := my_split(in_ids,',');
    xsbxf_array := my_split(in_xsbxfs,',');

    v_kklxdm_1 := in_kklxdm;
    v_xkkz_id := in_xkkz_id;

    select xxdm into v_xxdm from zftal_xtgl_xxxxszb;

    if v_xxdm = '10511' then--华中师范
        select kklxdm into v_kklxdm_1 from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(1);
        select count(*) into v_count from jw_xk_xkkzb where kklxdm=v_kklxdm_1 and njdm=in_njdm_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between xkkssj and xkjssj;
        if v_count=1 then
            select xkkz_id into v_xkkz_id from jw_xk_xkkzb where kklxdm=v_kklxdm_1 and njdm=in_njdm_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between xkkssj and xkjssj;
        end if;
    end if;

    if v_kklxdm_1='04' then
       v_fxbj := '1';
    elsif v_kklxdm_1='02' then
       v_fxbj := '2';
    elsif v_kklxdm_1='03' then
       v_fxbj := '3';
    end if;

    if v_xxdm = '10511' then--华中师范
       --辅修标记fxbj判断(根据辅修报名关联查询计划课程)
       select count(1) into v_count from jw_jh_jxzxjhkcxxb a where a.fxbj='1' and a.kch_id = in_kch_id and exists(select 'x' from jw_fx_fxezybmb b where a.njdm_id = b.njdm_id and a.zyh_id = b.zyh_id and b.xh_id = in_xh_id and b.zzshjg = '3');
       if v_count >0 then
          v_fxbj := '1';
       end if;
       --重修标记cxbj判断
       select count(1) into v_count from jw_xk_xsxkb where xh_id = in_xh_id and kch_id = in_kch_id;
       if v_count >0 then
          v_cxbj := '1';
       end if;
    end if;

    --判断该课程学生是否已选过
    select count(*) into v_count from jw_xk_xsxkb a where xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    if v_count > 0 then
       out_flag := '1';--该教学班该学生已选过
       goto nextOne; --跳出循环
    end if;

    --判断当前是否在选课时间内
    select count(*) into v_count from JW_XK_XKKZB a,jw_xjgl_xsxjxxb b where a.xkkz_id=v_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj and b.xh_id=in_xh_id and b.xnm =in_xkxnm and b.xqm =in_xkxqm;
    if v_count = '0' then
       out_flag := '0';--不在选课时间内
       out_msg := '选课时间已过，不可再选！';
       goto nextOne; --跳出循环
    end if;

    --查找可能要用到的选课规则设置项
    --select b.sfzyxk,nvl(b.zdzys,1),nvl(b.sfrxtgkcxd,'0'),nvl(tykczgxdcs,3) into v_sfzyxk,v_zdzys,v_sfrxtgkcxd,v_tykczgxdcs from JW_XK_XKKZB a,JW_XK_XKKZXMB b where a.xkkz_id=b.xkkz_id and a.xkkz_id=v_xkkz_id;
    select kklxmc into v_kklxmc from jw_jcdm_kklxdmb where kklxdm=v_kklxdm_1;
    select
           b.sfzyxk,case when b.sfzyxk='1' then nvl(b.zdzys,1) else 1 end,nvl(b.lnzgxkmc,0),nvl(b.lnzgxkxf,0),nvl(b.bxqzgxkmc,0),nvl(b.bxqzgxkxf,0),b.sfznkx,nvl(b.zdkxms,1),nvl(b.kkbk,'0'),nvl(b.kkbkdj,'0'),nvl(b.cyxktjkz,'0'),nvl(b.txbsfrl,'0'),nvl(b.xkydjc,'0'),nvl(b.sfkknj,'0'),nvl(b.sfkkzy,'0')
    into
           v_sfzyxk,v_zdzys,v_lnzgxkmc,v_lnzgxkxf,v_bxqzgxkmc,v_bxqzgxkxf,v_sfznkx,v_zdkxms,v_kkbk,v_kkbkdj,v_cyxktjkz,v_txbsfrl,v_xkydjc,v_sfkknj,v_sfkkzy
    from JW_XK_XKKZXMB b where b.xkkz_id=v_xkkz_id;
    select count(*) into v_count from zftal_xtgl_xtszb where zdm = 'XKLY' and zdz = '1';
  if v_count > 0 and v_kklxdm_1 = '01' then
  ------------是否可跨年级选课
  if v_sfkknj='0' then
    select count(*) into v_count from jw_jxrw_jxbhbxxb a where a.jxb_id=jxb_id_array(1) and a.njdm_id=in_njdm_id;
    if v_count='0' then
           out_flag := '0';
           out_msg := '不可跨年级选课！';
           goto nextOne; --跳出循环
    end if;
  end if;
  ------------是否可跨专业选课
  if v_sfkkzy='0' then
    select count(*) into v_count from jw_jxrw_jxbhbxxb a where a.jxb_id=jxb_id_array(1) and a.zyh_id = in_zyh_id;
    if v_count='0' then
           out_flag := '0';
           out_msg := '不可跨专业选课！';
           goto nextOne; --跳出循环
    end if;
  end if;
      end if;
    --最大志愿数判断
    --if v_sfzyxk='1' then
       select count(*) into v_count from jw_jxrw_jxbxxb a,jw_xk_xsxkb b where a.jxb_id=b.jxb_id and a.fjxb_id is null and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.kch_id=in_kch_id and b.xh_id=in_xh_id;
       v_zy_count := v_count;
       if v_count >= v_zdzys then
           out_flag := '0';
           if v_sfzyxk='1' then
              out_msg := '超过最大志愿数限制，不可再选！';
           else
              out_msg := '一门课程只能选一个教学班，不可再选！';
           end if;
           goto nextOne; --跳出循环
       end if;
   --end if;

    --最大跨选门数判断
    if v_sfznkx='1' then
       --判断选择的课程是夸选课程
       select count(d.kch_id) into v_count from jw_jh_jxzxjhxxb b,jw_jh_jxzxjhxfyqxxb c,jw_jh_jxzxjhkcxxb d
        where b.jxzxjhxx_id = c.jxzxjhxx_id and c.xfyqjd_id = d.xfyqjd_id and d.kch_id = in_kch_id and b.njdm_id = in_njdm_id and b.zyh_id = in_zyh_id;
       if v_count = 0 then
       select count(distinct kch_id) into v_count from (
          select t1.kch_id from jw_xk_xsxkb a,jw_jxrw_jxbxxb t1
            where a.xh_id=in_xh_id and a.jxb_id=t1.jxb_id and t1.xnm=in_xkxnm and t1.xqm=in_xkxqm and t1.sfzjxb='1' and t1.kklxdm='01'
          minus
           select t1.kch_id from jw_xk_xsxkb a,jw_jxrw_jxbxxb t1,jw_jh_jxzxjhxxb b,jw_jh_jxzxjhxfyqxxb c,jw_jh_jxzxjhkcxxb d
            where a.xh_id=in_xh_id and a.jxb_id=t1.jxb_id and t1.xnm=in_xkxnm and t1.xqm=in_xkxqm and t1.sfzjxb='1' and t1.kklxdm='01' and b.jxzxjhxx_id = c.jxzxjhxx_id
              and c.xfyqjd_id = d.xfyqjd_id and d.kch_id = t1.kch_id and b.njdm_id = in_njdm_id and b.zyh_id = in_zyh_id);
           if v_count >= v_zdkxms then
               out_flag := '0';
               out_msg := '超过最大跨选门数，不可再选！';
               goto nextOne; --跳出循环
           end if;
        end if;
    end if;

    select t.xf into v_xf from jw_jxrw_jxbxxb t where jxb_id=jxb_id_array(1);

    --其他选课规则的最高选课门次、最高选课学分、是否禁止选课
	select count(*) into v_count from JW_XK_QTXKGZB where xnm = in_xkxnm and xqm = in_xkxqm and xh_id in (in_xh_id,'tongyi');
	if v_count>0 then
		select nvl(xkzgxf,9999),nvl(xkzgmc,9999),nvl(jzxk,'0') into v_xkzgxf,v_xkzgmc,v_jzxk from (
			select xkzgxf,xkzgmc,jzxk from JW_XK_QTXKGZB
			where xnm = in_xkxnm and xqm = in_xkxqm and xh_id in (in_xh_id,'tongyi')
			order by case when xh_id = 'tongyi' then 1 else 0 end
		) where rownum = 1;
		if v_jzxk='1' then
			out_flag := '0';
			out_msg := '对不起，您当前不可选课！';
			goto nextOne; --跳出循环
		else
			select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb t2,jw_xk_xsxkb t3 where t1.kch_id=t2.kch_id and t2.jxb_id=t3.jxb_id and t2.xnm=in_xkxnm and t2.xqm=in_xkxqm and t3.xnm=in_xkxnm and t3.xqm=in_xkxqm and t3.xh_id=in_xh_id);
			if (v_total_xf+v_xf) > v_xkzgxf and v_zy_count=0 then
				out_flag := '0';
				out_msg := '超过本学期最高选课学分限制，不可选！';
				goto nextOne; --跳出循环
			elsif v_total_kc >= v_xkzgmc and v_zy_count=0 then
				out_flag := '0';
				out_msg := '超过本学期最高选课门次限制，不可选！';
				goto nextOne; --跳出循环
			end if;
		end if;
	end if;

    --历年最高选课门次、最高选课学分
    if v_lnzgxkmc > 0 or v_lnzgxkxf > 0 then
       select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb a,jw_xk_xsxkb b where t1.kch_id=a.kch_id and a.jxb_id=b.jxb_id and a.kklxdm=v_kklxdm_1 and a.xnm=b.xnm and a.xqm=b.xqm and a.xnm||lpad(a.xqm,3,'0') <= in_xkxnm||lpad(in_xkxqm,3,'0') and b.xh_id=in_xh_id);
       if v_lnzgxkmc > 0 and v_total_kc >= v_lnzgxkmc and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'历年最高选课门次限制，不可选！';
          goto nextOne; --跳出循环
       end if;
       if v_lnzgxkxf > 0 and (v_total_xf+v_xf) > v_lnzgxkxf and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'历年最高选课学分限制，不可选！';
          goto nextOne; --跳出循环
       end if;
    end if;

   	--本学期最高选课门次、最高选课学分
    if v_bxqzgxkmc > 0 or v_bxqzgxkxf > 0 then
       select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb t2,jw_xk_xsxkb t3 where t1.kch_id=t2.kch_id and t2.jxb_id=t3.jxb_id and t2.kklxdm=v_kklxdm_1 and t2.xnm=in_xkxnm and t2.xqm=in_xkxqm and t3.xnm=in_xkxnm and t3.xqm=in_xkxqm and t3.xh_id=in_xh_id);
       if v_bxqzgxkmc > 0 and v_total_kc >= v_bxqzgxkmc and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课门次限制，不可选！';
          goto nextOne; --跳出循环
       end if;
       if v_bxqzgxkxf > 0 and (v_total_xf+v_xf) > v_bxqzgxkxf and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课学分限制，不可选！';
          goto nextOne; --跳出循环
       end if;
    end if;

    --判断是否允许通过课程修读(不允许时，除了修读课程合格的不允许之外，在修还未出成绩的也不允许)
    --select count(*) into v_count from jw_cj_xscjb where xh_id=in_xh_id and kch_id=in_kch_id and bfzcj>=60;
    --if v_sfrxtgkcxd='0' then
       --if v_count>0 then
          --out_flag := '0';
          --out_msg := '该课程已修读合格，不可再选！';
          --goto nextOne; --跳出循环
       --else
          --select count(*) into v_count from jw_xk_xsxkb t1 where t1.xh_id=in_xh_id and t1.kch_id=in_kch_id and xnm||xqm!=in_xkxnm||in_xkxqm and not exists(select 1 from jw_cj_xscjb t2 where t2.jxb_id=t1.jxb_id and t2.xh_id=t1.xh_id);
          --if v_count>0 then
            --out_flag := '0';
            --out_msg := '该课程已在修读，不可再选！';
            --goto nextOne; --跳出循环
          --end if;
       --end if;
    --elsif v_count>=v_tykczgxdcs then
         --out_flag := '0';
         --out_msg := '该课程修读次数已不少于'||v_tykczgxdcs||'次，不可再选！';
         --goto nextOne; --跳出循环
    --end if;

    if in_xxkbj='1' then
        select nvl((select sfkzyxk from jw_xk_qtxkgzb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id='tongyi'),'0') into v_sfkzyxk from dual;
        if v_sfkzyxk='1' then --判断先行课（预修课）控制是否设置为控制
            select count(b.jxb_id) into v_count from jw_jh_kcyxyqb a,jw_xk_xsxkb b where a.yxkch_id=b.kch_id and b.xnm||b.xqm!=in_xkxnm||in_xkxqm and b.xh_id = in_xh_id and a.kch_id = in_kch_id;
            if v_count = 0 then
               out_flag := '0';
               out_msg :='该课程的先行课未修，不可选！';
               goto nextOne; --跳出检验
            end if;
        end if;
    end if;
    --判断学生是否已选体育课
    --if v_kklxdm_1='10' then
     select count(jxb_id) into v_count from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(1) and kklxdm = '05';
      if v_count > 0 then
        select count(a.jxb_id) into v_count from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != in_kch_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.xh_id = in_xh_id;
        if v_count >= v_zdzys then
           out_flag := '0';
           if v_sfzyxk='1' then
              out_msg :='超过最大志愿数限制，不可再选！';
           else
              out_msg :='您已选过体育课，不可再选！';
           end if;
           goto nextOne; --跳出循环
        end if;
      end if;
    --end if;

    --板块课同一个课组只能选一门课程
    if v_kklxdm_1='06' then
       --该课程是否为某课组内课程
       --select nvl((select bklx_id from view_xk_bkkkzb a where xnm=in_xkxnm and xqm=in_xkxqm and kch_id=in_kch_id and njdm_id=in_njdm_id and exists (select 1 from jw_xjgl_xsbklxcjb b where a.bklx_id = b.bklx_id and b.xh_id = in_xh_id)),'0') into v_bklx_id from dual;
       select nvl(bklx_id,'0') into v_bklx_id from JW_XK_XKKZB where xkkz_id=v_xkkz_id;
       if v_bklx_id != '0' then
          ----判断跨板块等级问题
          sqlStr := 'select count(*) from jw_xjgl_xsbklxcjb t1,jw_jxrw_bkxxb t2,jw_jxrw_jxbhbxxb t3';
          if v_kkbk!='1' then
            sqlStr := sqlStr||',jw_jxrw_bkzybjdzb t4';
          end if;
          sqlStr := sqlStr||' where t1.bklx_id=t2.bklx_id and t1.xh_id='''||in_xh_id||''' and t2.xnm='''||in_xkxnm||''' and t2.xqm='''||in_xkxqm||''' and t2.bklx_id='''||v_bklx_id||''' and t3.jxb_id in ('''||replace(in_ids,',',''',''')||''')';
          if v_kkbk!='1' then
            sqlStr := sqlStr||' and t4.bkxxb_id=t2.bkxxb_id and t4.bkxxb_id=t3.bkxxb_id and t4.zyh_id='''||in_zyh_id||''' and t4.njdm_id='''||in_njdm_id||'''';
          else
            sqlStr := sqlStr||' and t2.bkxxb_id=t3.bkxxb_id';
          end if;
          if v_kkbkdj!='1' then
            sqlStr := sqlStr||' and t1.bklxdjb_id=t3.bklxdjb_id';
          end if;
          Execute Immediate sqlStr into v_count;--满足条件的记录个数
          if v_count = 0 then
             out_flag := '0';
             out_msg := '跨板块或等级选课冲突！';
             goto nextOne; --跳出循环
          end if;
          --判断同板块同课组只能选一门课
          select count(*) into v_count from jw_xk_xsxkb a,view_xk_bkkkzb b,jw_jxrw_bkxxb c,jw_jxrw_jxbhbxxb hb
          where a.kch_id=b.kch_id and a.kch_id != in_kch_id and a.xnm=b.xnm and a.xqm=b.xqm
            and a.jxb_id=hb.jxb_id and hb.bkxxb_id=c.bkxxb_id and c.bklx_id=b.bklx_id and b.njdm_id=in_njdm_id
            and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.xh_id=in_xh_id and b.bklx_id=v_bklx_id;
          if v_count > 0 then
             out_flag := '0';
             out_msg :='您已选过该课程所在课组的其他课程，不可再选！';
             goto nextOne; --跳出循环
          end if;
       end if;
    end if;

    sqlStr := 'select count(*) from (select a.jxb_id,b.xqj,b.zcd,b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b where nvl(a.zxbj,''0'')!=''1'' and a.jxb_id = b.jxb_id and a.kch_id != '''||in_kch_id||''' and a.xh_id = '''||in_xh_id||''' and b.xnm = '''||in_xkxnm||''' and b.xqm = '''||in_xkxqm||''' and a.xnm = '''||in_xkxnm||''' and a.xqm = '''||in_xkxqm||''') t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
    Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
    if v_count > 0 then
       out_flag := '0';
       out_msg := '所选教学班的上课时间与其他教学班有冲突！';
       goto nextOne; --跳出循环
    end if;


    if v_cyxktjkz != '0' then
      --判断课程条件设置
      for i in 1..jxb_id_array.count loop
           sqlStr := 'select get_jxbxktjzt('''||in_xkxnm||''','''||in_xkxqm||''','''||jxb_id_array(i)||''','''||in_xh_id||''') from dual';
           Execute Immediate sqlStr into v_msg;--返回的信息
           if v_msg != '1' then
               out_flag := '0';
               out_msg := '成绩不满足以下条件： {'||subStr(v_msg,instr(v_msg,'|')+1,length(v_msg)-instr(v_msg,'|'))||'}';
               goto nextOne; --跳出循环
           end if;
      end loop;
      --判断男女生容量是否已满
      for i in 1..jxb_id_array.count loop
           sqlStr := 'select get_jxbxknntj('''||in_xkxnm||''','''||in_xkxqm||''','''||jxb_id_array(i)||''','''||in_xh_id||''') from dual';
           Execute Immediate sqlStr into v_msg;--返回的信息
           if v_msg != '1' then
               out_flag := '0';
               out_msg := subStr(v_msg,instr(v_msg,'|')+1,length(v_msg)-instr(v_msg,'|'));
               goto nextOne; --跳出循环
           end if;
      end loop;
    end if;

    sqlStr := 'select count(*) from(
     select t1.jxb_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
     where t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t1.jxb_id = xk.jxb_id and xk.xh_id = '''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||'''
     union all
     select t1.jxb_id from jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
     where t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||'''))';
    Execute Immediate sqlStr into v_count;--学生已选任务已排考或待选任务已排考，需要判断冲突
    if v_count > 0 then
       sqlStr := 'select count(*) from (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_xk_xsxkb xk, jw_pk_kbsjb kb where nvl(xk.zxbj,''0'')!=''1'' and kb.jxb_id = xk.jxb_id and xk.xh_id = '''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxsk,
       (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id = rjc.rsdsz_id and rsd.xnm = t1.xnm and rsd.xqm = t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id = (select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
       from jw_pk_xlb t4,jw_pk_rcmxb t5,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
       where t4.xl_id = t5.xl_id and t4.xnm = t1.xnm and t5.dxqm = t1.xqm and t5.rq = t3.ksrq and t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
       where yxsk.xqj = dxks.xqj and bitand(yxsk.zcd, dxks.zcd) > 0 and bitand(yxsk.jc, dxks.jc) > 0';
       Execute Immediate sqlStr into v_count;--考试与上课冲突个数
       if v_count > 0 then
          out_flag := '0';
          out_msg := '所选教学班的考试时间与其他教学班上课时间有冲突！';
          goto nextOne; --跳出循环
       end if;

       sqlStr := 'select count(*) from(select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
       where t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t1.jxb_id = xk.jxb_id and xk.xh_id = '''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxks,
       (select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
       where t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
       where yxks.ksrq=dxks.ksrq and yxks.ksjssj >= dxks.kskssj and yxks.kskssj <= dxks.ksjssj';
       Execute Immediate sqlStr into v_count;--考试与考试冲突个数
       if v_count > 0 then
          out_flag := '0';
          out_msg := '所选教学班的考试时间与其他教学班考试时间有冲突！';
          goto nextOne; --跳出循环
       end if;

       sqlStr := 'select count(*) from (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id = rjc.rsdsz_id and rsd.xnm = t1.xnm and rsd.xqm = t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id = (select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
       from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3,jw_pk_xlb t4,jw_pk_rcmxb t5 where t1.ksmcdmb_id = t2.ksmcdmb_id and t1.sjbh_id = t2.sjbh_id and t2.ksccb_id = t3.ksccb_id and t4.xl_id = t5.xl_id and t4.xnm = t1.xnm and t5.dxqm = t1.xqm and t5.rq = t3.ksrq and t1.jxb_id = xk.jxb_id and xk.xh_id = '''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxks,
       (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_pk_kbsjb kb where kb.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxsk where yxks.xqj = dxsk.xqj and bitand(yxks.zcd, dxsk.zcd) > 0 and bitand(yxks.jc, dxsk.jc) > 0';
       Execute Immediate sqlStr into v_count;--上课与考试冲突个数
       if v_count > 0 then
          out_flag := '0';
          out_msg := '所选教学班的上课时间与其他教学班考试时间有冲突！';
          goto nextOne; --跳出循环
       end if;
    end if;
    --检测全部合格时将教学班加入学生的选课表中
    FOR i IN 1..jxb_id_array.count LOOP
      if i=1 and in_qz='0' then
        select count(*) into v_count from view_xk_tykdzb where kch_id=in_kch_id;
            --一门课程可能有多个可选教学班志愿，新加一个志愿时，要排在已选志愿的最后面
        if v_count=0 then
            --非体育课
            select count(a.jxb_id)+1 into v_xzjxbCount from JW_XK_XSXKB a,jw_jxrw_jxbxxb b where a.jxb_id=b.jxb_id and a.xh_id=in_xh_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.zy>0 and b.kch_id=in_kch_id and b.xnm=in_xkxnm and b.xqm=in_xkxqm and b.fjxb_id is null;
        else
            --体育课
            select count(a.jxb_id)+1 into v_xzjxbCount from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != in_kch_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.xh_id = in_xh_id and a.zy>0;
        end if;
        /*if v_xzjxbCount > 1 then
            for p_xsxk in cursor_xsxk(in_xh_id,in_xkxnm,in_xkxqm,in_kch_id) loop
                update JW_XK_XSXKB set zy=p_xsxk.rwn where jxb_id=p_xsxk.jxb_id and xh_id=in_xh_id;
            end loop;
        end if;*/
      elsif i=1 then
        v_xzjxbCount := 0;
      end if;

      select nvl(fjxb_id,'0'),nvl(a.jxbrs,0) jxbrs,nvl(a.krrl,0) krrl,kklxdm,yxzrs
         into isfjxb,v_jxbrs,v_krrl,v_kklxdm,v_yxzrs
      from jw_jxrw_jxbxxb a where a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.jxb_id=jxb_id_array(i);

      --统计该教学班已选人数
      if v_txbsfrl = '0' then
      select count(xh_id) into v_yxzrs from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i) and nvl(zxbj,'0')!='1';
      --select njdm_id,zyh_id into v_njdm_id,v_zyh_id from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;
      end if;
      v_bxrs := 0;
      s_bxrs := 0;
      if v_kklxdm = '01' then
          select count(distinct m.xh_id) into v_bxrs from jw_xk_xsxkb m,JW_XJGL_XSXJXXB n,jw_jxrw_jxbhbxxb o
          where nvl(m.zxbj,'0') != '1' and o.jxb_id=m.jxb_id and n.xh_id=m.xh_id and n.zyh_id=o.zyh_id
                and n.njdm_id=o.njdm_id and m.jxb_id=jxb_id_array(i)
                and n.xnm=in_xkxnm and n.xqm=in_xkxqm
                and m.xnm=in_xkxnm and m.xqm=in_xkxqm;
          if xsbxf_array(i)='1' then
             s_bxrs := v_bxrs + 1;
          else
             s_bxrs := v_bxrs;
          end if;
      end if;

      --父教学班有排志愿的需要，而子教学班统一将志愿字段设为０
      if isfjxb != '0' then
         v_xzjxbCount := 0;

      end if;

      if in_rlkz!='1' and nvl(in_rlzlkz,'0')!='1' then
         v_yl := 1;
      elsif in_rwlx='1' and in_rlkz='1' and xsbxf_array(i)='1' then
         v_yl := v_jxbrs - v_bxrs;
      elsif in_rwlx='1' and in_rlkz='1' and xsbxf_array(i)='0' then
         v_yl := v_krrl - (v_yxzrs - v_bxrs);
      else
         v_yl := v_jxbrs + v_krrl - v_yxzrs;
      end if;

      if v_yl > 0 then
        if nvl(in_rlzlkz,'0') = '1' then
           insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj)
           select jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,v_cxbj,in_xkxnm,in_xkxqm,in_kch_id,v_bklx_id,v_xkydjc from jw_jxrw_jxbxxb t1 where t1.jxb_id=jxb_id_array(i) and (t1.jxbrs+nvl(t1.krrl,0))>(select count(xh_id) from jw_xk_xsxkb t2 where nvl(t2.zxbj,'0')!='1' and t2.jxb_id=jxb_id_array(i) and xnm=in_xkxnm and xqm=in_xkxqm);
        else
           --xkbj=10(学生自选)，20(配课生成)，30(管理员调课生成)
           insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj) values (jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,v_cxbj,in_xkxnm,in_xkxqm,in_kch_id,v_bklx_id,v_xkydjc);
        end if;
        update jw_jxrw_jxbxxb set yxzrs=v_yxzrs+1,bxrs=s_bxrs where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i);

        if nvl(in_rlzlkz,'0') = '1' then
           select count(xh_id) into v_count from JW_XK_XSXKB where nvl(zxbj,'0') !='1' and xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i) and xh_id=in_xh_id;
           if v_count=0 then
              select (jxbrs+nvl(krrl,0)) into v_yxzrs from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i);
              out_flag := '-1';
              if i=0 then
                 out_msg := '0'||','||jxb_id_array(i)||','||v_yxzrs||','||v_bxrs;
              else
                 out_msg := '1'||','||jxb_id_array(i)||','||v_yxzrs||','||v_bxrs;
              end if;
              goto nextOne; --跳出循环
           end if;
        end if;
      else
          out_flag := '-1';
          if i=0 then
             out_msg := '0'||','||jxb_id_array(i)||','||v_yxzrs||','||v_bxrs;
          else
             out_msg := '1'||','||jxb_id_array(i)||','||v_yxzrs||','||v_bxrs;
          end if;
          v_wyljxbxx := v_wyljxbxx ||','|| jxb_id_array(i);--记录无余量教学班id
          goto nextOne; --跳出循环
      end if;
    end LOOP;

    <<nextOne>>

    if out_flag = '-1' then
       rollback;
       wyljxb_id_array := my_split(v_wyljxbxx,',');
       for k in 2..wyljxb_id_array.count loop
         select yxzrs into v_rwyxzrs from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
         select count(xh_id) into v_yxzrs from jw_xk_xsxkb where nvl(zxbj,'0') !='1' and xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
         if v_rwyxzrs != v_yxzrs then
      if v_txbsfrl = '0' then
             update jw_jxrw_jxbxxb set yxzrs=v_yxzrs where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
      end if;
         end if;
       end loop;
       commit;
    else
       commit;
    end if;
end;

/

