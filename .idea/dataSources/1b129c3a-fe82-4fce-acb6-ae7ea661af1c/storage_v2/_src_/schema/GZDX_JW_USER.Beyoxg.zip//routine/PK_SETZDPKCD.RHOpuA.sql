create procedure PK_SETZDPKCD(
      vJxb_id in varchar2,
      nJsxx in number,
      nJssx in number,
      nJsyl in number,
      vBj out varchar2
      )
      as

      sXnm  varchar2(4);
      sXqm  varchar2(2);
      sXqh_id  varchar2(32);
      sNjZyh_ids  varchar2(1000);
      sCdlb_id  varchar2(64);
      nJxbrs  number;


      sCd_id varchar2(500);
      sLh varchar2(500);
      sLch varchar2(500);

      sYycd_ids varchar2(500);
      sYylchs varchar2(500);
      sYylhs varchar2(500);

      sCd_idjg varchar2(32);
      sCdejlb_id varchar2(32);

      nXqj number;
      nRsdm number;
      i number;

      cursor Get_kbsjxx is     ----取排场地时间。----游标---
      select xqj,rsdm from (
      select distinct t1.xqj,nvl(t2.rsdm,0) rsdm,
             fn_jszs(get_bitorsunion(wm_concat(t1.jc) over (partition by t1.xqj,t2.rsdm))) gs from jw_pk_kbsjb t1,
              (select b.rsdm,b.jcm from jw_pk_rsdszb a, jw_pk_rjcszb b where
              a.rsdsz_id = b.rsdsz_id and  a.xnm = sXnm and a.xqm = sXqm and a.xqh_id = sXqh_id
              ) t2 where  jxb_id = vJxb_id and bitand(t1.jc,t2.jcm) > 0) order by gs desc,xqj;
      Cur_kbsjxx Get_kbsjxx%rowtype;
begin
      vBj := '';
      i := 1;
      select xnm,xqm,xqh_id,cdlb_id,cdejlb_id,jxbrs,njzy_ids into sXnm,sXqm,sXqh_id,sCdlb_id,sCdejlb_id,nJxbrs,sNjZyh_ids  from (
      select distinct a.xnm,a.xqm,a.xqh_id,a.cdlb_id,a.cdejlb_id ,a.jxbrs ,
               wm_concat(b.njdm_id||b.zyh_id) over (partition by 1) njzy_ids from
      jw_jxrw_jxbxxb a ,jw_jxrw_jxbhbxxb b where a.jxb_id = b.jxb_id  and a.jxb_id = vJxb_id );



  open Get_kbsjxx;
  loop
    fetch Get_kbsjxx into Cur_kbsjxx;
     exit when Get_kbsjxx%notfound;
     nXqj  := Cur_kbsjxx.Xqj;
     nRsdm := Cur_kbsjxx.Rsdm;
          begin
          ---同一推荐课表下，同一星期同一时段内最好同一教室如果不是同一层，如果不是同一楼，如果不是楼宇间距最小
            select cd_ids,lhlchs,lhs into sCd_id,sLch,sLh from
            (select distinct wm_concat(a.cd_id) over (partition by 1) cd_ids,
                             wm_concat(c.lh||c.lch) over (partition by 2 ) lhlchs,
                             wm_concat(c.lh) over (partition by 3) lhs  from --,b.xnm,b.xqm,a.zcd,b.xqj,a.jc
                                               jw_pk_kbcdb a,jw_pk_kbsjb b,jw_jcdm_cdxqxxb c,jw_pk_tjkbjgb e where
                                                     b.xnm = sXnm and b.xqm = sXqm and a.kb_id = b.kb_id and
                                                     b.jxb_id = e.jxb_id and instr(sNjZyh_ids,e.njdm_id||e.zyh_id) >0 and
                                                     b.xnm = c.xnm and b.xqm = c.xqm and a.cd_id = c.cd_id and
                                                     exists(select 'X' from
                                                             (select distinct t1.*,nvl(t2.rsdm,0) rsdm  from jw_pk_kbsjb t1,
                                                               (select b.rsdm,b.jcm from jw_pk_rsdszb a, jw_pk_rjcszb b where
                                                                         a.rsdsz_id = b.rsdsz_id and  a.xnm = sXnm and
                                                                          a.xqm = sXqm and a.xqh_id = sXqh_id
                                                                 ) t2 where t1.xqj = nxqj and bitand(t1.jc,t2.jcm) > 0 and
                                                                             nvl(t2.rsdm,0) = nRsdm
                                                               ) d where   b.xnm = d.xnm and
                                                                           bitand(b.xqm,d.xqm) > 0  and
                                                                           b.xqj = d.xqj and
                                                                           bitand(a.zcd,d.zcd) > 0 and
                                                                           bitand(b.jc,d.jc) = 0 and  d.jxb_id = vJxb_id
                                                             )
              );
         exception
                When others then
               sCd_id := '';
               sLch := '';
               sLh := '';
         end;

         begin
         select Yycd_ids,Yylchs,Yylhs into sYycd_ids,sYylchs,sYylhs from
                (select distinct wm_concat(b.cd_id) over (partition by 1) Yycd_ids,
                                 wm_concat(c.lh||c.lch) over (partition by 2 ) Yylchs,
                                 wm_concat(c.lh) over (partition by 3) Yylhs from
                                 jw_pk_kbsjb a ,jw_pk_kbcdb b,jw_jcdm_cdxqxxb c where
                                                            a.kb_id = b.kb_id and a.jxb_id = vJxb_id and
                                                            b.cd_id = c.cd_id and c.xnm = sXnm and c.xqm = sXqm
                                                            );

         exception
             When others then
               sYycd_ids := '';
               sYylchs := '';
               sYylhs := '';
         end;

         begin
          select cd_id into sCd_idjg from (
            select a.cd_id,a.lch,a.lh,
                   (select b.pkyxj from jw_jcdm_jxldmb b where b.jxldm = a.lh ) pkyxj,
            ----------------------------------------------
            case when  instr(sYycd_ids,a.cd_id) > 0 then '1'
                 when  instr(sCd_id,a.cd_id) > 0 then '2'
                 when  instr(sYylchs,a.lh||a.lch) > 0 then '3'
                 when  instr(sLch,a.lh||a.lch) > 0 then '4'
                 when  instr(sYylhs,a.lh) > 0 then '5'
                 when  instr(sLh,a.lh) > 0 then '6'
                 else '7'||(select min(xljj) from jw_jcdm_jxljjb where
                   (instr(sLh, jxldm) > 0 and a.lh = xljxldm) or (instr(sLh,xljxldm) > 0 and a.lh = jxldm)) end yxj
            ----------------------------------------------
               from (
            select cd_id,lh,lch from jw_jcdm_cdxqxxb where
            xnm = sXnm and xqm = sXqm and  instr(nvl(cdlb_id,'*')||'*', nvl(sCdlb_id,'*')) >0 and
            instr(nvl(cdejlb_id,'*')||'*' , nvl(sCdejlb_id,'*')) >0  and
            (nJxbrs*nJsxx + nJsyl) <= zws and zws <= (nJxbrs*nJssx+nJsyl)

            minus
            (
            -----场地信息限制排课时间----------------------------------------------------------------------------------
            select a.dm,c.lh,c.lch from --,a.xnm,a.xqm,a.xqh_id,a.lb,b.zcd,b.xqj,b.jc
            jw_pk_pksjxzb a ,jw_pk_pksjxzzb b ,jw_jcdm_cdxqxxb c where
             a.pksjxz_id = b.pksjxz_id  and
             a.xnm = c.xnm and a.xqm = c.xqm and a.xqh_id = c.xqh_id and
             a.lb = 5 and
             a.dm = (case when lb = 5 then c.cd_id end)
            -----场地信息限制排课时间----------------------------------------------------------------------------------
            and
               exists(select 'X' from
                       (select distinct t1.*,nvl(t2.rsdm,0) rsdm  from jw_pk_kbsjb t1,
                                                               (select b.rsdm,b.jcm from jw_pk_rsdszb a, jw_pk_rjcszb b where
                                                                         a.rsdsz_id = b.rsdsz_id and  a.xnm = sXnm and
                                                                          a.xqm = sXqm and a.xqh_id = sXqh_id
                                                                 ) t2 where t1.xqj = nxqj and bitand(t1.jc,t2.jcm) > 0 and
                                                                             nvl(t2.rsdm,0) = nRsdm
                        ) d where
                 a.xnm = d.xnm and
                 bitand(a.xqm,d.xqm) > 0  and
                 b.xqj = d.xqj and
                 bitand(b.zcd,d.zcd) > 0 and
                 bitand(b.jc,d.jc) > 0 and
                 d.jxb_id = vJxb_id  )
            -----场地冲突判断--begin-------------------------------------------------------------------------------------
            union all
            select a.cd_id,c.lh,c.lch from --,b.xnm,b.xqm,a.zcd,b.xqj,a.jc
                                               jw_pk_kbcdb a,jw_pk_kbsjb b,jw_jcdm_cdxqxxb c where
                                                     b.xnm = sXnm and b.xqm = sXqm and a.kb_id = b.kb_id and
                                                     b.xnm = c.xnm and b.xqm = c.xqm and a.cd_id = c.cd_id and
                                                     exists(select 'X' from
                                                             (select distinct t1.*,nvl(t2.rsdm,0) rsdm  from jw_pk_kbsjb t1,
                                                               (select b.rsdm,b.jcm from jw_pk_rsdszb a, jw_pk_rjcszb b where
                                                                         a.rsdsz_id = b.rsdsz_id and  a.xnm = sXnm and
                                                                          a.xqm = sXqm and a.xqh_id = sXqh_id
                                                                  ) t2 where t1.xqj = nxqj and bitand(t1.jc,t2.jcm) > 0 and
                                                                             nvl(t2.rsdm,0) = nRsdm) d where
                                                                           b.xnm = d.xnm and
                                                                           bitand(b.xqm,d.xqm) > 0  and
                                                                           b.xqj = d.xqj and
                                                                           bitand(b.zcd,d.zcd) > 0 and
                                                                           bitand(b.jc,d.jc) > 0 and
                                                                           d.jxb_id = vJxb_id )







            )
            --union all
            ----
            --平行班
            ---
            -----场地冲突判断----end-------------------------------------------------------------------------------------
            ) a ) where rownum <= 1 order by to_number(yxj),pkyxj;

            exception
            When others then
              sCd_idjg := '';
            end;


          if sCd_idjg is not null  then
          insert into jw_pk_kbcdb(kb_id,cd_id,zcd,jc)
          select distinct t1.kb_id,sCd_idjg,t1.zcd,t1.jc from jw_pk_kbsjb t1,
              (select b.rsdm,b.jcm from jw_pk_rsdszb a, jw_pk_rjcszb b where
              a.rsdsz_id = b.rsdsz_id and  a.xnm = sXnm and a.xqm = sXqm and a.xqh_id = sXqh_id
              ) t2 where  jxb_id = vJxb_id and bitand(t1.jc,t2.jcm) > 0 and t1.xqj = nXqj and nvl(t2.rsdm,0) = nRsdm;


          commit;
            if vBj is null then
               vBj := i||'排场地成功';
             else
               vBj := vBj||i||'排场地成功';
            end if;
          else
            if vBj is null then
               vBj := i||'无可用场地';
               else
               vBj := vBj||i||'无可用场地';
            end if;
          end if;
      i := i +1;
    end loop;
  close Get_kbsjxx;

end;


/

