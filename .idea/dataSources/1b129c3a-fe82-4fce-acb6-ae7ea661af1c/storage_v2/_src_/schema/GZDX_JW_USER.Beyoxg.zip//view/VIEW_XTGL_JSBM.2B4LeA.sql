create view VIEW_XTGL_JSBM as
  select t.jg_id as jsbm_id,
       t.lssjjgid,
       t.jgdm as jsbmdm,
       t.jgmc as jsbmmc,
       t.jgywmc as jsbmywmc,
       t.jgjc   as jsbmjc,
       t.jgjp   as jsbmjp,
       t.jgdz   as jsbmjz,
       t.lsxqid,
       t.sfjxbm,
       t.sfst,
       t.kkxy
  from zftal_xtgl_jgdmb t
 where t.jgyxbs = '1'
/

