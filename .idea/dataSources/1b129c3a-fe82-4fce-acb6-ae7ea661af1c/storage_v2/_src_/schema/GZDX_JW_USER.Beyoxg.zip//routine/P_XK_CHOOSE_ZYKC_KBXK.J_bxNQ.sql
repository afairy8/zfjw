create procedure p_xk_choose_zykc_kbxk(
    in_ids in varchar2,
    in_xh_id in varchar2,
    in_bklx_id in varchar2,
    in_qz in varchar2,
    in_cxbj in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
)as
    v_count number;
    v_zy_count number;
    v_fxcxrlkg number;
    v_xkxnm varchar2(8);
    v_xkxqm varchar2(3);
    v_xnm varchar2(10);
    v_xqm varchar2(10);
    v_xxdm varchar2(8);
    v_xkkz_id varchar2(32);
    v_kklxdm varchar2(3);
    v_njdm_id varchar2(32);
    v_zyh_id varchar2(32);
    v_bh_id varchar2(32);
    v_zyfx_id varchar2(32);
    v_sfkxk varchar2(1);
    v_sfzyxk varchar2(1);
    v_jzxk varchar2(1);
    v_zdzys number;
    v_xkzgxf number;
    v_xkzgmc number;
    v_lnzgxkmc number;
    v_lnzgxkxf number;
    v_bxqzgxkmc number;
    v_bxqzgxkxf number;
    v_sfznkx varchar2(1);
    v_zdkxms number;
    v_xf number;
    v_xklc number;
    v_total_xf number;
    v_total_kc number;
    v_xs_sfzx varchar2(1);
    v_gz_sfzx varchar2(1);
    v_kkbk varchar2(1);
    v_kkbkdj varchar2(1);
    v_cyxktjkz varchar2(1);
    v_txbsfrl varchar2(1);
    v_xkydjc varchar2(1);
    v_sfkknj varchar2(1);
    v_sfkkzy varchar2(1);
    v_rlkz varchar2(1);
    v_rlzlkz varchar2(1);
    v_xkly varchar2(1);
    v_cxkctxs number;
    v_sfkzyxk varchar2(1);
    v_kch_id varchar2(32);
    v_fxbj varchar2(1);
    v_bdzcbj varchar2(1);
    v_zckz varchar2(1);
    v_pjkz varchar2(1);
    v_jfkz varchar2(1);
    v_bczcbj varchar2(1);
    v_jxb_id_2 varchar2(40);
    v_jxb_id_3 varchar2(40);
    v_jxb_id_4 varchar2(40);
    v_msg varchar2(2000);
    jxb_id_array mytype;
    v_kklxmc jw_jcdm_kklxdmb.kklxmc%type;
begin
    out_flag := '1';
    jxb_id_array := my_split(in_ids,',');
    select xnm,xqm,kklxdm,kch_id,xf into v_xkxnm,v_xkxqm,v_kklxdm,v_kch_id,v_xf from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(1);

    select count(*) into v_count from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
    if v_count=0 then
        out_flag:='0';
        out_msg:='对不起，您在当前时间不可选课！';
        goto EndPoint;
    end if;

    select njdm_id,zyh_id,bh_id,nvl(zyfx_id,'wfx'),nvl(sfzx,'0'),nvl(bdzcbj,'0') into v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,v_xs_sfzx,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;

    select max(xkkz_id) into v_xkkz_id from jw_xk_xkkzb where xnm=v_xkxnm and xqm=v_xkxqm and kklxdm=v_kklxdm and nvl(bklx_id,'0')=nvl(in_bklx_id,'0')
        and njdm=(select njdm from zftal_xtgl_njdmb where njdm_id=v_njdm_id) and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between xkkssj and xkjssj;
    if nvl(v_xkkz_id,'0')='0' then
        out_flag:='0';
        out_msg:='对不起，当前时间不可选课！';
        goto EndPoint;
    end if;

	--判断该课程学生是否已选过
    select count(*) into v_count from jw_xk_xsxkb a where xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    if v_count > 0 then
        out_flag := '1';--该教学班该学生已选过
        goto EndPoint; --跳出循环
    end if;

    select count(*) into v_count from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and fjxb_id=jxb_id_array(1);
    if v_count>0 and jxb_id_array.count=1 then
        out_flag := '0';--子教学班未传入时
        out_msg := '请刷新页面重新选择！';
        goto EndPoint; --跳出循环
    end if;

    select count(*) into v_count from jw_kw_bkmdb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and kch_id=v_kch_id and bkqrbj='1';
    if v_count>0 then
        out_flag := '0';--已确认补考
        out_msg := '该门课程已确认补考，不可再选！';
        goto EndPoint; --跳出循环
    end if;

    select
        nvl(sfkxk,'0'),b.sfzyxk,nvl(b.zdzys,1),nvl(b.lnzgxkmc,0),nvl(b.lnzgxkxf,0),nvl(b.bxqzgxkmc,0),
        nvl(b.bxqzgxkxf,0),b.sfznkx,nvl(b.zdkxms,1),nvl(b.kkbk,'0'),nvl(b.kkbkdj,'0'),nvl(b.cyxktjkz,'0'),
        nvl(b.txbsfrl,'0'),nvl(b.xkydjc,'0'),nvl(b.sfkknj,'0'),nvl(b.sfkkzy,'0'),nvl(rlkz,'0'),
        nvl(rlzlkz,'0'),nvl(xkly,'1'),nvl(cxkctxs,'0'),nvl(pjkz,'0'),nvl(jfkz,'0'),nvl(sfzx,'0'),nvl(zckz,'0')
    into
        v_sfkxk,v_sfzyxk,v_zdzys,v_lnzgxkmc,v_lnzgxkxf,v_bxqzgxkmc,v_bxqzgxkxf,v_sfznkx,v_zdkxms,v_kkbk,
        v_kkbkdj,v_cyxktjkz,v_txbsfrl,v_xkydjc,v_sfkknj,v_sfkkzy,v_rlkz,v_rlzlkz,v_xkly,v_cxkctxs,v_pjkz,v_jfkz,v_gz_sfzx,v_zckz
    from JW_XK_XKKZXMB b where b.xkkz_id=v_xkkz_id;

    if v_sfkxk='0' then
        out_flag:='0';
        out_msg:='对不起，当前时间未开放选课！';
        goto EndPoint;
    end if;

    if v_gz_sfzx='1' and v_xs_sfzx='0' then
        out_flag:='0';
        out_msg:='对不起，您当前学籍状态为不在校，不可选此类课程！';
        goto EndPoint;
    end if;

    if v_zckz='1' and v_bczcbj not in ('2','3') then
        out_flag:='0';
        out_msg:='对不起，您的学籍处于未注册状态，不可选此类课程！';
        goto EndPoint;
    end if;

    if v_pjkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDPJXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDPJXQM';
        select count(*) into v_count from jw_pj_xspjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id and ztbj='1';
        if v_count=0 then
            out_flag:='0';
            select xnmc into v_xnm from jw_jcdm_xnb where xnm=v_xnm;
            select mc into v_xqm from zftal_xtgl_jcsjb where lx='0001' and dm=v_xqm;
            out_msg:='对不起，'||v_xnm||'学年'||v_xqm||'学期评价未完成，不可选此类课程！';
            goto EndPoint;
        else
            select xxdm into v_xxdm from zftal_xtgl_xxxxszb;
            if v_xxdm='10290' then
                select count(*) into v_count from jw_pj_xskcwjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id and ztbj='1';
                if v_count=0 then
                    out_flag:='0';
                    select xnmc into v_xnm from jw_jcdm_xnb where xnm=v_xnm;
                    select mc into v_xqm from zftal_xtgl_jcsjb where lx='0001' and dm=v_xqm;
                    out_msg:='对不起，'||v_xnm||'学年'||v_xqm||'学期评价未完成，不可选此类课程！';
                    goto EndPoint;
                end if;
            end if;
        end if;
    end if;

    if v_jfkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDJFXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDJFXQM';
        select count(*) into v_count from jw_xjgl_xsxqjfztb where xh_id=in_xh_id and xnm=v_xnm and decode(xqm,'0',v_xqm,xqm)=v_xqm and jfzt ='1';
        if v_count=0 then
            out_flag:='0';
            select xnmc into v_xnm from jw_jcdm_xnb where xnm=v_xnm;
            select mc into v_xqm from zftal_xtgl_jcsjb where lx='0001' and dm=v_xqm;
            out_msg:='对不起，'||v_xnm||'学年'||v_xqm||'学期未完成缴费，不可选此类课程！';
            goto EndPoint;
        end if;
    end if;

    if v_xkly='1' and v_kklxdm='01' then
        if v_sfkknj='0' then --是否可跨年级选课
            select count(*) into v_count from jw_jxrw_jxbhbxxb a where a.jxb_id=jxb_id_array(1) and a.njdm_id=v_njdm_id;
            if v_count='0' then
                out_flag := '0';
                out_msg := '不可跨年级选课！';
                goto EndPoint; --跳出循环
            end if;
        end if;
        if v_sfkkzy='0' then --是否可跨专业选课
            select count(*) into v_count from jw_jxrw_jxbhbxxb a where a.jxb_id=jxb_id_array(1) and a.zyh_id=v_zyh_id;
            if v_count='0' then
                out_flag := '0';
                out_msg := '不可跨专业选课！';
                goto EndPoint; --跳出循环
            end if;
        end if;
    end if;

    if v_xkly='2' then
        select count(*) into v_count from jw_jxrw_jxbxxb m where exists
        (
            select 1 from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2
            where m.kch_id=t1.kch_id and nvl(m.sksj,'x')=nvl(t1.sksj,'x') and t1.jxb_id=t2.jxb_id and t1.sfzjxb='1'
                and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t2.zyh_id=v_zyh_id and t2.njdm_id=v_njdm_id
                and t2.bh_id in ('wbj',v_bh_id) and t2.zyfx_id in ('wfx',v_zyfx_id)
        ) and m.jxb_id=jxb_id_array(1);
        if v_count=0 then
            out_flag := '0';
            out_msg := '所选教学班不在推荐课表指定范围内（同课程同上课时间）！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    select count(*) into v_count from view_xk_tykdzb where kch_id=v_kch_id;
    --一门课程可能有多个可选教学班志愿，新加一个志愿时，要排在已选志愿的最后面
    if v_count=0 then --非体育课
        select count(a.jxb_id)+1 into v_zy_count from JW_XK_XSXKB a,jw_jxrw_jxbxxb b where a.jxb_id=b.jxb_id and a.xh_id=in_xh_id and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.zy>0 and b.kch_id=v_kch_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and b.fjxb_id is null;
    else --体育课
        select count(a.jxb_id)+1 into v_zy_count from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != v_kch_id and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xh_id=in_xh_id and a.zy>0;
    end if;

    if v_sfzyxk='1' then
        if v_zy_count > v_zdzys then
            out_flag := '0';
            out_msg := '超过最大志愿数限制，不可再选！';
            goto EndPoint; --跳出循环
        end if;
    elsif v_zy_count > 1 then
        out_flag := '0';
        if v_count=0 then
            out_msg := '一门课程只能选一个教学班，不可再选！';
        else
            out_msg :='您已选过体育课，不可再选！';
        end if;
        goto EndPoint; --跳出循环
    end if;

    select count(*) into v_count from JW_XK_QTXKGZB where xnm=v_xkxnm and xqm=v_xkxqm and xh_id in (in_xh_id,'tongyi');
    if v_count>0 then
        select nvl(xkzgxf,9999),nvl(xkzgmc,9999),nvl(jzxk,'0') into v_xkzgxf,v_xkzgmc,v_jzxk from (
            select xkzgxf,xkzgmc,jzxk from JW_XK_QTXKGZB
            where xnm=v_xkxnm and xqm=v_xkxqm and xh_id in (in_xh_id,'tongyi')
            order by case when xh_id='tongyi' then 1 else 0 end
        ) where rownum=1;
        if v_jzxk='1' then
            out_flag := '0';
            out_msg := '对不起，您当前不可选课！';
            goto EndPoint; --跳出循环
        end if;

        select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_xk_xsxkb t2 where t1.kch_id=t2.kch_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.xh_id=in_xh_id);
        if (v_total_xf+v_xf) > v_xkzgxf and v_zy_count=0 then
            out_flag := '0';
            out_msg := '超过本学期最高选课学分限制，不可选！';
            goto EndPoint; --跳出循环
        end if;
        if v_total_kc >= v_xkzgmc and v_zy_count=0 then
            out_flag := '0';
            out_msg := '超过本学期最高选课门次限制，不可选！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    select kklxmc into v_kklxmc from jw_jcdm_kklxdmb where kklxdm=v_kklxdm;

    --历年最高选课门次、最高选课学分
    if v_lnzgxkmc > 0 or v_lnzgxkxf > 0 then
        select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb a,jw_xk_xsxkb b where t1.kch_id=a.kch_id and a.jxb_id=b.jxb_id and a.kklxdm=v_kklxdm and a.xnm=b.xnm and a.xqm=b.xqm and a.xnm||lpad(a.xqm,3,'0') <= v_xkxnm||lpad(v_xkxqm,3,'0') and b.xh_id=in_xh_id);
        if v_lnzgxkmc > 0 and v_total_kc >= v_lnzgxkmc and v_zy_count=0 then
            out_flag := '0';
            out_msg := '超过'||v_kklxmc||'历年最高选课门次限制，不可选！';
            goto EndPoint; --跳出循环
        end if;
        if v_lnzgxkxf > 0 and (v_total_xf+v_xf) > v_lnzgxkxf and v_zy_count=0 then
            out_flag := '0';
            out_msg := '超过'||v_kklxmc||'历年最高选课学分限制，不可选！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    --本学期最高选课门次、最高选课学分
    if v_bxqzgxkmc > 0 or v_bxqzgxkxf > 0 then
       select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb t2,jw_xk_xsxkb t3 where t1.kch_id=t2.kch_id and t2.jxb_id=t3.jxb_id and t2.kklxdm=v_kklxdm and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and t3.xh_id=in_xh_id);
       if v_bxqzgxkmc > 0 and v_total_kc >= v_bxqzgxkmc and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课门次限制，不可选！';
          goto EndPoint; --跳出循环
       end if;
       if v_bxqzgxkxf > 0 and (v_total_xf+v_xf) > v_bxqzgxkxf and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课学分限制，不可选！';
          goto EndPoint; --跳出循环
       end if;
    end if;

    select count(*) into v_count from jw_jh_kcyxyqb where kch_id=v_kch_id and rownum=1;
    if v_count=1 then --有预修课
        select max(sfkzyxk) into v_sfkzyxk from jw_xk_qtxkgzb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id='tongyi';
        if nvl(v_sfkzyxk,'0')='1' then
            select count(b.jxb_id) into v_count from jw_jh_kcyxyqb a,jw_xk_xsxkb b where a.yxkch_id=b.kch_id and b.xnm||b.xqm!=v_xkxnm||v_xkxqm and b.xh_id=in_xh_id and a.kch_id=v_kch_id;
            if v_count=0 then
                out_flag := '0';
                out_msg :='该课程的先行课未修，不可选！';
                goto EndPoint; --跳出检验
            end if;
        end if;
    end if;

    --最大跨选门数判断
    if nvl(v_sfznkx,'0')='1' then
        --判断选择的课程是否是跨选课程
        select count(d.kch_id) into v_count from jw_jh_jxzxjhxfyqxxb c,jw_jh_jxzxjhkcxxb d where c.xfyqjd_id=d.xfyqjd_id
            and d.kch_id=v_kch_id and d.njdm_id=v_njdm_id and d.zyh_id=v_zyh_id and c.zyfx_id in ('wfx',v_zyfx_id);
        if v_count=0 then --是跨选课程
            select count(distinct kch_id) into v_count from
            (
                select
                    t1.kch_id from jw_xk_xsxkb a,jw_jxrw_jxbxxb t1
                where
                    a.xh_id=in_xh_id and a.jxb_id=t1.jxb_id and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.sfzjxb='1' and t1.kklxdm='01'
                    and not exists(
                        select 1 from jw_jh_jxzxjhxfyqxxb c,jw_jh_jxzxjhkcxxb d
                        where d.kch_id=t1.kch_id and c.xfyqjd_id=d.xfyqjd_id and d.njdm_id=v_njdm_id
                            and d.zyh_id=v_zyh_id and c.zyfx_id in ('wfx',v_zyfx_id)
                    )
            );
            if v_count >= v_zdkxms then
                out_flag := '0';
                out_msg := '超过最大跨选门数，不可再选！';
                goto EndPoint; --跳出循环
            end if;
        end if;
    end if;

    if jxb_id_array.count>=2 then
       v_jxb_id_2:=jxb_id_array(2);
    else
       v_jxb_id_2:='wjxb2';
    end if;
    if jxb_id_array.count>=3 then
       v_jxb_id_3:=jxb_id_array(3);
    else
       v_jxb_id_3:='wjxb3';
    end if;
    if jxb_id_array.count>=4 then
       v_jxb_id_4:=jxb_id_array(4);
    else
       v_jxb_id_4:='wjxb4';
    end if;

    --板块课同一个课组只能选一门课程
    if nvl(in_bklx_id,'0') != '0' then
        /*主要为了防止有两个学生用同一台电脑同一个浏览器，前一学生A的选课页面未关闭，后一学生B直接在该页面选课，而导致的学生B选了学生A的板块课程
        if v_kkbk='0' and v_kkbkdj='0' then --不跨板块，不跨等级
            select count(*) into v_count from jw_xjgl_xsbklxcjb t1,jw_jxrw_bkxxb t2,jw_jxrw_jxbhbxxb t3,jw_jxrw_bkzybjdzb t4
            where t1.bklx_id=t2.bklx_id and t4.bkxxb_id=t2.bkxxb_id and t4.bkxxb_id=t3.bkxxb_id and t1.bklxdjb_id=t3.bklxdjb_id
                and t1.xh_id=in_xh_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.bklx_id=in_bklx_id
                and t3.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4) and t4.zyh_id=v_zyh_id and t4.njdm_id=v_njdm_id;
        elsif v_kkbk='1' and v_kkbkdj='0' then --跨板块，不跨等级
            select count(*) into v_count from jw_xjgl_xsbklxcjb t1,jw_jxrw_bkxxb t2,jw_jxrw_jxbhbxxb t3
            where t1.bklx_id=t2.bklx_id and t2.bkxxb_id=t3.bkxxb_id and t1.bklxdjb_id=t3.bklxdjb_id
                and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t1.xh_id=in_xh_id and t2.bklx_id=in_bklx_id
                and t3.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        elsif v_kkbk='0' and v_kkbkdj='1' then --不跨板块，跨等级
            select count(*) into v_count from jw_xjgl_xsbklxcjb t1,jw_jxrw_bkxxb t2,jw_jxrw_jxbhbxxb t3,jw_jxrw_bkzybjdzb t4
            where t1.bklx_id=t2.bklx_id and t4.bkxxb_id=t2.bkxxb_id and t4.bkxxb_id=t3.bkxxb_id
                and t1.xh_id=in_xh_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.bklx_id=in_bklx_id and t4.zyh_id=v_zyh_id
                and t4.njdm_id=v_njdm_id and t3.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        else --跨板块、跨等级
            select count(*) into v_count from jw_xjgl_xsbklxcjb t1,jw_jxrw_bkxxb t2,jw_jxrw_jxbhbxxb t3
            where t1.bklx_id=t2.bklx_id and t2.bkxxb_id=t3.bkxxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                and t2.bklx_id=in_bklx_id and t1.xh_id=in_xh_id and t3.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        end if;

        if v_count=0 then
            out_flag := '0';
            out_msg := '跨板块或等级选课冲突！';
            goto EndPoint; --跳出循环
        end if;
        */
        --判断同板块同课组只能选一门课
        select count(*) into v_count from jw_xk_xsxkb a,view_xk_bkkkzb b,jw_jxrw_bkxxb c,jw_jxrw_jxbhbxxb hb
        where a.kch_id=b.kch_id and a.kch_id != v_kch_id and a.jxb_id=hb.jxb_id and hb.bkxxb_id=c.bkxxb_id
            and c.bklx_id=in_bklx_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and b.njdm_id=v_njdm_id
            and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xh_id=in_xh_id and b.bklx_id=in_bklx_id;
        if v_count > 0 then
            out_flag := '0';
            out_msg :='您已选过该课程所在课组的其他课程，不可再选！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    if in_cxbj='1' and to_number(v_cxkctxs)>0 then
        select max(ctxs) into v_count from (
            select zcd,sum(gs) ctxs from (
                select t.zcd,t.xqj,t.jc,count(t.kch_id)-1 gs from (
                    select distinct t3.kch_id,t4.rn zcd,t3.xqj,t5.rn jc from (
                            select
                                t1.kch_id,t2.zcd,t2.xqj,t2.jc
                            from
                                jw_xk_xsxkb t1,jw_pk_kbsjb t2
                            where
                                t1.jxb_id=t2.jxb_id and t1.kch_id != v_kch_id and t1.xh_id=in_xh_id and t2.xnm=v_xkxnm
                                and t2.xqm =v_xkxqm and t1.xnm =v_xkxnm and t1.xqm=v_xkxqm and t1.zxbj != '1'
                            union all
                            select
                                v_kch_id kch_id,t1.zcd,t1.xqj,t1.jc
                            from
                                jw_pk_kbsjb t1
                            where jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                        ) t3,
                        (select power(2, rownum - 1) rn from zftal_xtgl_jcsjlxb) t4,
                        (select power(2, rownum - 1) rn from zftal_xtgl_jcsjlxb) t5
                    where bitand(t3.zcd, t4.rn) > 0 and bitand(t3.jc, t5.rn) > 0
                ) t group by t.zcd,t.xqj,t.jc having count(t.kch_id)>1
            ) group by zcd
        );
        if v_count > to_number(v_cxkctxs) then
            out_flag := '0';
            out_msg := '重修课只允许'||v_cxkctxs||'个学时的上课时间冲突！';
            goto EndPoint; --跳出循环
        end if;
    else
        select count(*) into v_count from
            (
                select a.jxb_id,b.xqj,b.zcd,b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                where nvl(a.zxbj,'0')!='1' and a.jxb_id=b.jxb_id and a.kch_id != v_kch_id
                and a.xh_id=in_xh_id and b.xnm=v_xkxnm and b.xqm=v_xkxqm and a.xnm=v_xkxnm and a.xqm=v_xkxqm
            ) t1,
            (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)) t2
        where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0;
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的上课时间与其他教学班有冲突！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    if v_cyxktjkz != '0' then
        --判断课程条件设置
        for i in 1..jxb_id_array.count loop
            v_msg := get_jxbxktjzt(v_xkxnm,v_xkxqm,jxb_id_array(i),in_xh_id);
            if v_msg != '1' then
                out_flag := '0';
                out_msg := '成绩不满足以下条件： {'||subStr(v_msg,instr(v_msg,'|')+1,length(v_msg)-instr(v_msg,'|'))||'}';
                goto EndPoint; --跳出循环
            end if;
        end loop;
        --判断男女生容量是否已满
        for i in 1..jxb_id_array.count loop
            v_msg:= get_jxbxknntj(v_xkxnm,v_xkxqm,jxb_id_array(i),in_xh_id);
            if v_msg != '1' then
                out_flag := '0';
                out_msg := subStr(v_msg,instr(v_msg,'|')+1,length(v_msg)-instr(v_msg,'|'));
                goto EndPoint; --跳出循环
            end if;
        end loop;
    end if;

    select count(*) into v_count from (
        select
            t1.jxb_id
        from
            jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
        where
            t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id
            and t1.jxb_id=xk.jxb_id and xk.xh_id=in_xh_id and xk.xnm=v_xkxnm and xk.xqm=v_xkxqm
        union all
        select
            t1.jxb_id
        from
            jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
        where
            t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id
            and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
    );

    if v_count>0 then --安排了考试信息
        select
            count(*) into v_count
        from
            (
                select
                    kb.jxb_id,kb.xqj,kb.zcd,kb.jc
                from
                    jw_xk_xsxkb xk, jw_pk_kbsjb kb
                where
                    nvl(xk.zxbj,'0')!='1' and kb.jxb_id=xk.jxb_id and xk.kch_id != v_kch_id
                    and xk.xh_id=in_xh_id and xk.xnm=v_xkxnm and xk.xqm=v_xkxqm
            ) yxsk,
            (
                select
                    power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(
                    select sum(rjc.jcm)
                        from
                            jw_pk_rsdszb rsd,jw_pk_rjcszb rjc
                        where
                            rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj
                            and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)
                    ) jc
                from
                    jw_pk_xlb t4,jw_pk_rcmxb t5,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
                where
                    t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq and t1.ksmcdmb_id=t2.ksmcdmb_id
                    and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
            ) dxks
        where
            yxsk.xqj=dxks.xqj and bitand(yxsk.zcd, dxks.zcd) > 0 and bitand(yxsk.jc, dxks.jc) > 0;
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的考试时间与其他教学班上课时间有冲突！';
            goto EndPoint; --跳出循环
        end if;

        select
            count(*) into v_count
        from
            (
                select
                    t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj
                from
                    jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
               where
                    t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id=xk.jxb_id
                    and xk.kch_id!=v_kch_id and xk.xh_id=in_xh_id and xk.xnm=v_xkxnm and xk.xqm=v_xkxqm
            ) yxks,
            (
                select
                    t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj
                from
                    jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
                where
                    t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id
                    and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
            ) dxks
        where
            yxks.ksrq=dxks.ksrq and yxks.ksjssj >= dxks.kskssj and yxks.kskssj <= dxks.ksjssj;
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的考试时间与其他教学班考试时间有冲突！';
            goto EndPoint; --跳出循环
        end if;

        select
            count(*) into v_count
        from
            (
                select
                    power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(
                        select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm
                        and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj
                        and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)
                    ) jc
                from
                    jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3,jw_pk_xlb t4,jw_pk_rcmxb t5
                where
                    t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id
                    and t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq
                    and t1.jxb_id=xk.jxb_id and xk.kch_id != v_kch_id and xk.xh_id=in_xh_id and xk.xnm=v_xkxnm and xk.xqm=v_xkxqm
            ) yxks,
            (
                select
                    kb.jxb_id,kb.xqj,kb.zcd,kb.jc
                from
                    jw_pk_kbsjb kb
                where
                    kb.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
            ) dxsk
        where
            yxks.xqj=dxsk.xqj and bitand(yxks.zcd, dxsk.zcd) > 0 and bitand(yxks.jc, dxsk.jc) > 0;
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的上课时间与其他教学班考试时间有冲突！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    select to_char(count(1)) into v_fxbj from jw_jh_jxzxjhkcxxb a where a.fxbj='1' and a.kch_id=v_kch_id and exists(select 'x' from jw_fx_fxezybmb b where a.njdm_id=b.njdm_id and a.zyh_id=b.zyh_id and b.xh_id=in_xh_id and b.zzshjg='3') and rownum=1;

    select count(*) into v_fxcxrlkg from jw_jcdml_xtnzb where zdm='FXCXRLKG' and zdz='1' and rownum=1;

    select xklc into v_xklc from jw_xk_xkkzb where xkkz_id=v_xkkz_id;

    if v_rlkz='0' and v_rlzlkz='0' then --不控制容量
        insert into
            JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
        select
            jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
            v_zy_count,in_qz,'0','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
        from
            jw_jxrw_jxbxxb
        where
            xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
    elsif v_rlzlkz='1' then --控制总容量
        if v_txbsfrl='0' then --实时释放容量
            insert into
                JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
            select
                jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
            from
                jw_jxrw_jxbxxb
            where
                xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                and (
                    select
                        count(*)
                    from
                        jw_jxrw_jxbxxb t2
                    where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                        and (t2.jxbrs+nvl(t2.krrl,0)+nvl(t2.fxrl,0)+nvl(t2.cxrl,0))<=(select count(*) from jw_xk_xsxkb t3 where t2.jxb_id=t3.jxb_id and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and nvl(zxbj,'0')!='1')
                )=0;
        else --退选时不释放容量
            insert into
                JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
            select
                jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
            from
                jw_jxrw_jxbxxb
            where
                xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                and (
                    select
                        count(*)
                    from
                        jw_jxrw_jxbxxb t2
                    where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                        and (t2.jxbrs+nvl(t2.krrl,0)+nvl(t2.fxrl,0)+nvl(t2.cxrl,0))<=(nvl(t2.yxzrs,0)+nvl(t2.fxrs,0)+nvl(t2.cxrs,0))
                )=0;
        end if;
    else --分类控制容量
        if v_txbsfrl='0' then --实时释放容量
            if v_fxbj='1' then --辅修
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and nvl(t2.fxrl,0)<=(select count(*) from jw_xk_xsxkb t3 where t2.jxb_id=t3.jxb_id and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and nvl(zxbj,'0')!='1' and nvl(fxbj,'0')!='0')
                    )=0;
            elsif in_cxbj='1' then --重修
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and nvl(t2.cxrl,0)<=(select count(*) from jw_xk_xsxkb t3 where t2.jxb_id=t3.jxb_id and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and nvl(zxbj,'0')!='1' and nvl(cxbj,'0')!='0')
                    )=0;
            else
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and (nvl(t2.jxbrs,0)+nvl(t2.krrl,0))<=(select count(*) from jw_xk_xsxkb t3 where t2.jxb_id=t3.jxb_id and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and nvl(zxbj,'0')!='1' and nvl(fxbj,'0')='0' and nvl(cxbj,'0')='0')
                    )=0;
            end if;
        else --退选时不释放容量
            if v_fxbj='1' then --辅修
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and nvl(t2.fxrl,0)<=nvl(t2.fxrs,0)
                    )=0;
            elsif in_cxbj='1' then --重修
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and nvl(t2.cxrl,0)<=nvl(t2.cxrs,0)
                    )=0;
            else
                insert into
                    JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,jcytbj,kklxdm)
                select
                    jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,
                    v_zy_count,in_qz,'1','10',v_fxbj,in_cxbj,v_xkxnm,v_xkxqm,v_kch_id,in_bklx_id,v_xkydjc,kklxdm
                from
                    jw_jxrw_jxbxxb
                where
                    xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                    and (
                        select
                            count(*)
                        from
                            jw_jxrw_jxbxxb t2
                        where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=v_kch_id and t2.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                            and (t2.jxbrs+nvl(t2.krrl,0))<=nvl(t2.yxzrs,0)
                    )=0;
            end if;
        end if;
    end if;

    select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    --选课成功
    if v_count>0 then
        if v_fxbj='1' and v_fxcxrlkg=1 then --分辅修重修时，更新fxrs
            update jw_jxrw_jxbxxb set fxrs=nvl(fxrs,0)+1 where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        elsif in_cxbj='1' and v_fxcxrlkg=1 then --分辅修重修时，更新cxrs
            update jw_jxrw_jxbxxb set cxrs=nvl(cxrs,0)+1 where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        else --更新yxzrs
            update jw_jxrw_jxbxxb set yxzrs=nvl(yxzrs,0)+1 where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
        end if;
    else
        out_flag := '-1';
    end if;

    <<EndPoint>>

    if out_flag='-1' then --说明控制了容量，所以会选课不成功
        rollback;
        if v_txbsfrl='0' then --实时释放容量时，如果分重修辅修，则选课人数分开统计
            if v_fxbj='1' and v_fxcxrlkg=1 then
                update jw_jxrw_jxbxxb t1 set fxrs=(
                   select count(xh_id) from jw_xk_xsxkb t2 where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.jxb_id=t1.jxb_id and nvl(t2.zxbj,'0')!='1' and nvl(t2.fxbj,'0')!='0'
                )
                where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
            elsif in_cxbj='1' and v_fxcxrlkg=1 then --分辅修重修时，更新cxrs
                update jw_jxrw_jxbxxb t1 set cxrs=(
                   select count(xh_id) from jw_xk_xsxkb t2 where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.jxb_id=t1.jxb_id and nvl(t2.zxbj,'0')!='1' and nvl(t2.cxbj,'0')!='0'
                )
                where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
            elsif v_fxcxrlkg=1 then --分辅修重修时，yxzrs=非辅修非重修的人数
                update jw_jxrw_jxbxxb t1 set yxzrs=(
                   select count(xh_id) from jw_xk_xsxkb t2 where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.jxb_id=t1.jxb_id and nvl(t2.zxbj,'0')!='1' and nvl(t2.fxbj,'0')='0' and nvl(t2.cxbj,'0')='0'
                )
                where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
            else --其他情况只需要更新yxzrs=总的选课人数
                update jw_jxrw_jxbxxb t1 set yxzrs=(
                   select count(xh_id) from jw_xk_xsxkb t2 where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.jxb_id=t1.jxb_id and nvl(t2.zxbj,'0')!='1'
                )
                where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4);
            end if;
            commit;
        end if;

        --查询数据返回到页面上时，要分是否分类控制容量、
        if v_fxbj='1' and v_rlkz='1' then --分类控制容量，且辅修容量超出
            select
                (case when fjxb_id is null then '0' else '1' end)||','||jxb_id||','||fxrs into out_msg
            from
                jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                  and nvl(t1.fxrl,0)<=t1.fxrs and rownum=1;
        elsif in_cxbj='1' and v_rlkz='1' then --分类控制容量，且重修容量超出
            select
                (case when fjxb_id is null then '0' else '1' end)||','||jxb_id||','||cxrs into out_msg
            from
                jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                  and nvl(t1.cxrl,0)<=t1.cxrs and rownum=1;
        elsif v_rlkz='1' then --分类控制容量，非重修非辅修的容量超出
            select
                (case when fjxb_id is null then '0' else '1' end)||','||jxb_id||','||yxzrs into out_msg
            from
                jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                  and jxbrs+nvl(t1.krrl,0)<=t1.yxzrs and rownum=1;
        else --只控制容量总量
            select
                (case when fjxb_id is null then '0' else '1' end)||','||jxb_id||','||(yxzrs+fxrs+cxrs) into out_msg
            from
                jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=v_kch_id and t1.jxb_id in (jxb_id_array(1),v_jxb_id_2,v_jxb_id_3,v_jxb_id_4)
                  and (t1.jxbrs+nvl(t1.krrl,0)+nvl(t1.fxrl,0)+nvl(t1.cxrl,0))<=(t1.yxzrs+t1.fxrs+t1.cxrs) and rownum=1;
        end if;
    else
        commit;
    end if;
end;

/

