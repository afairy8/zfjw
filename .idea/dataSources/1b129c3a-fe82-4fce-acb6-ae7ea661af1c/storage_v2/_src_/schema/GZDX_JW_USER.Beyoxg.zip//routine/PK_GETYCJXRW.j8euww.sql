create Procedure Pk_GetYcjxrw(vXnm in varchar2,vXqm in varchar2)
as
  i number;     ----定义数值型变量----i---
  v_jls number; ----记录数

  cursor Get_YcJxrwxx is     ----取异常教学任务信息。----游标---
  select count(a.xnm) jls From jw_pk_jxrwlsb a,jw_pk_jxrwyclsb c
                                   where a.xnm =c.xnm
                                     and a.xqm = c.xqm
                                     and a.jxb_id = c.jxb_id
                                     and c.xnm = vXnm
                                     and c.dxqm = vXqm
                                     and not exists
                                     (select 'X' from jw_pk_jxrwyclsb b
                                                where a.njdm_id = b.njdm_id
                                                  and a.zyh_id = b.zyh_id
                                                  and a.bh_id = b.bh_id
                                                  and b.xnm = vXnm
                                                  and b.dxqm = vXqm)
                                     and a.xnm  = vXnm
                                     and a.dxqm = vXqm
                                     and rownum = 1;
  Cur_YcJxrwxx Get_YcJxrwxx%rowtype;
 --------------------------------------------------------------------------------
begin
  -------------------------------------------------------------------------------
  --初始化---全部数据
  delete from jw_pk_jxrwyclsb a Where a.xnm  = vXnm
                                  and a.dxqm = vXqm;
  ---------------------------去除任务信息没有但推荐课表存在的数据信息---------------------
  delete from jw_pk_tjkbjgb a where a.xnm = vXnm
                                and a.dxqm =vXqm
                                and not exists
                                (select 'X' from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2
                                           where t1.jxb_id = t2.jxb_id
                                             and t1.jxb_id = a.jxb_id
                                             and t2.njdm_id = a.njdm_id
                                             and t2.zyh_id = a.zyh_id
                                             and t2.bh_id = a.bh_id
                                             and nvl(t2.zyfx_id,'wfx') = nvl(a.zyfx_id,'wfx')
                                             and t1.xnm = vXnm
                                             and t1.xqm =vXqm );


	delete from jw_pk_tjxsrsb a Where a.xnm=vXnm
                                and a.dxqm = vXqm
/*                                and not exists
                                (select 'X' from jw_pk_tjkbjgb b
                                           where a.njdm_id = b.njdm_id
                                             and a.zyh_id = b.zyh_id
                                             and a.bh_id = b.bh_id
                                             and b.xnm=vXnm
                                             and b.dxqm=vXqm )*/;

  delete from jw_pk_jxrwlsb where xnm = vXnm and xqm = vXqm;
  commit;
  insert into jw_pk_jxrwlsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs)
              select a.xnm,(select max(to_number(dm)) from zftal_xtgl_jcsjb where lx = '0001' and bitand(dm,a.xqm) > 0) as dxqm,
                     a.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.zyfx_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,b.rs from
              jw_jxrw_jxbxxb a, jw_jxrw_jxbhbxxb b,jw_jh_kcdmb d
              where a.xnm=vXnm
                and a.xqm =vXqm
                and a.jxb_id = b.jxb_id
                and a.kch_id = d.kch_id
                and a.kkzt = '1'
                and a.kklxdm = '01'
				        and nvl(a.BPKBJ,'0') = '0';
  commit;

  -------学生人数-----------------------------------
  insert into jw_pk_tjxsrsb(xnm,dxqm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs)
              select t1.xnm,(select max(to_number(dm)) from zftal_xtgl_jcsjb where lx = '0001' and bitand(dm,t1.xqm) > 0) dxqm,
                     t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t1.rs from
              (select jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs,
                      rank() over (partition by jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id order by bj) rn from
               (select jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,sum(rs) rs,'1' bj from
                  (select t2.jxzxjhxx_id,t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id, case when t2.rwbj  = '1' then 'wbj' else  bh_id end bh_id,
                          'wfx' as zyfx_id,count(distinct t1.xh_id) rs from
                           jw_xjgl_xsxjxxb t1,jw_jh_jxzxjhxxb t2
                           where t1.njdm_id = t2.njdm_id
                             and t1.zyh_id = t2.zyh_id
                             and t1.xnm = vXnm
                             and t1.xqm = vXqm
                             and t1.sfzx = '1'
                             and t1.bh_id is not null
                             and t1.zyh_id is not null
                             and t1.njdm_id is not null
                             and t2.rwbj = '2'
                         group by t2.jxzxjhxx_id,t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t2.rwbj
                   ) group by jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id
                 union all
                select t2.jxzxjhxx_id,vXnm xnm,vXqm xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,
                           'wfx' zyfx_id,to_number(nvl(t1.zxrs,0)) rs,'2' bj from
                           zftal_xtgl_bjdmb t1,jw_jh_jxzxjhxxb t2
                           where t1.njdm_id = t2.njdm_id
                             and t1.zyh_id = t2.zyh_id
                             and t2.rwbj = '2'
              )
            ) t1  where t1.rn = '1'
                    and t1.rs <> 0
                    and exists(select 'X' from jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhkcxxb b,jw_jh_jxzxjhkcyxxdxnxqb c
                                 where a.xfyqjd_id = b.xfyqjd_id
                                   and b.jxzxjhkcxx_id = c.jxzxjhkcxx_id
                                   and a.jxzxjhxx_id = t1.jxzxjhxx_id
                                   and c.yxkkxnm = vXnm
                                   and c.yxkkxqm =vXqm
                               )
                    and not exists(select 'X' from jw_pk_tjxsrsb t3
                                      where t3.xnm=vXnm
                                        and t3.dxqm= vXqm
                                        and t3.njdm_id = t1.njdm_id
                                        and t3.zyh_id = t1.zyh_id
                                        and t3.bh_id = t1.bh_id
                                        and nvl(t3.zyfx_id,'wfx') = nvl(t1.zyfx_id,'wfx')
                               );

   insert into jw_pk_tjxsrsb(xnm,dxqm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs)
              select t1.xnm,(select max(to_number(dm)) from zftal_xtgl_jcsjb where lx = '0001' and bitand(dm,t1.xqm) > 0) dxqm,
                     t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t1.rs from
              (select jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs,
                      rank() over (partition by jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id order by bj) rn from
               (select jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,sum(rs) rs,'1' bj from
                  (select t2.jxzxjhxx_id,t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id, case when t2.rwbj  = '1' then 'wbj' else  bh_id end bh_id,
                          nvl(t1.zyfx_id,'wfx') zyfx_id,count(distinct t1.xh_id) rs from
                           jw_xjgl_xsxjxxb t1,jw_jh_jxzxjhxxb t2
                           where t1.njdm_id = t2.njdm_id
                             and t1.zyh_id = t2.zyh_id
                             and t1.xnm = vXnm
                             and t1.xqm = vXqm
                             and t1.sfzx = '1'
                             and t1.bh_id is not null
                             and t1.zyh_id is not null
                             and t1.njdm_id is not null
                             and t2.rwbj = '2'
                             and nvl(t1.zyfx_id,'wfx') != 'wfx'
                         group by t2.jxzxjhxx_id,t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t2.rwbj
                   ) group by jxzxjhxx_id,xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id
                 )
            ) t1  where t1.rn = '1'
                    and t1.rs <> 0
                    and exists(select 'X' from jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhkcxxb b,jw_jh_jxzxjhkcyxxdxnxqb c
                                 where a.xfyqjd_id = b.xfyqjd_id
                                   and b.jxzxjhkcxx_id = c.jxzxjhkcxx_id
                                   and a.jxzxjhxx_id = t1.jxzxjhxx_id
                                   and c.yxkkxnm = vXnm
                                   and c.yxkkxqm =vXqm
                               )
                    and not exists(select 'X' from jw_pk_tjxsrsb t3
                                      where t3.xnm=vXnm
                                        and t3.dxqm= vXqm
                                        and t3.njdm_id = t1.njdm_id
                                        and t3.zyh_id = t1.zyh_id
                                        and t3.bh_id = t1.bh_id
                                        and nvl(t3.zyfx_id,'wfx') = nvl(t1.zyfx_id,'wfx')
                               );

   insert into jw_pk_tjxsrsb(xnm,dxqm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs)
               select t1.xnm,(select max(to_number(dm)) from zftal_xtgl_jcsjb where lx = '0001' and bitand(dm,t1.xqm) > 0) dxqm,
                      t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t1.rs from
               (select  t2.xnm,t2.xqm,(select jg_id from zftal_xtgl_zydmb where zyh_id = t2.zyh_id) jg_id,
                        t2.njdm_id,t2.zyh_id,'wbj' bh_id,t2.zyfx_id,t2.rs,
                        rank() over (partition by t2.xnm,t2.xqm, t2.njdm_id,t2.zyh_id
                                         order by ( case when zyfx_id = 'wfx' then 2 else 1 end)) rn from
                       jw_jh_jxzxjhxxb t1, jw_jh_zyrsjhb t2
                       where t1.jxzxjhxx_id = t2.jxzxjhxx_id
                         and t2.xnm = vXnm
                         and t2.xqm = vXqm
                         and t1.rwbj = '1'
                         and  exists(select 'X' from jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhkcxxb b,jw_jh_jxzxjhkcyxxdxnxqb c
                                           where a.xfyqjd_id = b.xfyqjd_id
                                             and a.jxzxjhxx_id = t1.jxzxjhxx_id
                                             and b.jxzxjhkcxx_id = c.jxzxjhkcxx_id
                                             and c.yxkkxnm = vXnm
                                             and c.yxkkxqm = vXqm
                                     )
               ) t1
               where rn = '1'
                 and not exists(select 'X' from jw_pk_tjxsrsb t3
                                     where t3.xnm=vXnm
                                       and t3.dxqm= vXqm
                                       and t3.njdm_id = t1.njdm_id
                                       and t3.zyh_id = t1.zyh_id
                                       and t3.bh_id = t1.bh_id
                                       and nvl(t3.zyfx_id,'wfx') = nvl(t1.zyfx_id,'wfx')
                                 );
  -------学生人数-----------------------------------

     delete from jw_pk_tjxsbrsb where xnm = vXnm
                                  and xqm = vXqm;
     insert into jw_pk_tjxsbrsb(xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,rs)
      select t1.xnm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.zyfx_id,t1.rs-t2.tjrs rs from (
      select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,rs from jw_pk_tjxsrsb where xnm = vXnm
                                                                               and dxqm = vXqm
      ) t1,
      (select xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id,sum(rs) tjrs from
          (select distinct xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id,tjkbzdm,tjkbzxsdm,rs
            from jw_pk_tjkbjgb where xnm  = vXnm
                                 and dxqm = vXqm

       ) group by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id
      ) t2
      where t1.njdm_id = t2.njdm_id
        and t1.zyh_id = t2.zyh_id
        and t1.bh_id = t2.bh_id
        and t1.zyfx_id = t2.zyfx_id
        and t1.rs > t2.tjrs;
  commit;
  --end;
  --初始化---第一次异常数据----begin---


  --1---任务人数与学生人数比较存在任务人数小于学生人数的情况(以年级专业为例)------begin--------
    insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
    select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'1','课程任务人数小于学生人数的情况' from
            jw_pk_jxrwlsb t1 where
               exists
                (select 'X' from
                (select xnm,xqm,njdm_id,zyh_id,bh_id,kch_id from
                (select a.xnm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.rs ,a.min_rs,a.max_rs rwrs,nvl(b.rs,a.rs) xsrs from
                (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,rs
                        ,max(rs) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id) max_rs
                        ,min(rs) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id) min_rs from
                 (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,sum(rs) rs from jw_pk_jxrwlsb
                     where zyfx_id = 'wfx'
                       and fjxb_id is null
                       and xnm= vXnm
                       and dxqm = vXqm
                     group by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id
                  )
                 ) a
                 left join
                 (select xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,sum(rs) rs from-----学生信息------------begin---------
                         jw_pk_tjxsrsb where xnm = vXnm and dxqm = vXqm
                         group by xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id       ----学生信息---------------end---------
                  ) b
                  on
                 --(a.xnm = b.xnm and a.xqm = b.xqm and a.njdm_id = b.njdm_id and a.zyh_id = b.zyh_id and a.bh_id = b.bh_id)
                 (a.xnm||a.njdm_id||a.zyh_id||a.bh_id||a.zyfx_id =b.xnm||b.njdm_id||b.zyh_id||b.bh_id||b.zyfx_id and bitand(a.xqm,b.xqm) > 0 )
                 where not exists(select 'X' from jw_jh_kcyxrstjb tjb where a.xnm = tjb.xnm and a.xqm = tjb.xqm and a.kch_id = tjb.kch_id and a.njdm_id = tjb.njdm_id and a.zyh_id = tjb.zyh_id and a.bh_id = tjb.bh_id)
                 ) where rwrs < xsrs
                 ) t2 where t1.njdm_id = t2.njdm_id
                        and t1.zyh_id = t2.zyh_id
                        and t1.bh_id = t2.bh_id
                        and t1.kch_id = t2.kch_id
                 )
               and exists(select 'X' from jw_pk_tjxsbrsb t3 where
                        t1.xnm||t1.njdm_id||t1.zyh_id||t1.bh_id =t3.xnm||t3.njdm_id||t3.zyh_id||t3.bh_id and bitand(t1.xqm,t3.xqm) > 0
                         )
               and t1.xnm= vXnm
               and t1.dxqm =  vXqm;
    --1---任务人数与学生人数比较存在任务人数小于学生人数的情况--------end--------

    --2---任务人数与学生人数比较存在任务人数小于学生人数的情况(以年级专业为例)------begin--------
    insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
    select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'2','有方向课程任务人数小于有方向学生人数的情况' from
      jw_pk_jxrwlsb t1 where
         exists(select 'X' from
                (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id from
                 (select a.xnm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.rs,a.min_rs,a.max_rs rwrs,nvl(b.rs,a.rs) xsrs from
                   (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,rs
                          ,max(rs) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id) max_rs
                          ,min(rs) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id) min_rs from
                  (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,sum(rs) rs from jw_pk_jxrwlsb
                     where zyfx_id <> 'wfx'
                       and fjxb_id is null
                       and xnm= vXnm
                       and dxqm = vXqm
                     group by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id
                   )
                   ) a
                  left join
                  jw_pk_tjxsrsb b
                 on
                 (a.xnm=b.xnm
                  and a.xqm = b.xqm
                  and a.njdm_id = b.njdm_id
                  and a.zyh_id = b.zyh_id
                  and a.bh_id = b.bh_id
                  and a.zyfx_id = b.zyfx_id )
                  where not exists(select 'X' from jw_jh_kcyxrstjb tjb where a.xnm = tjb.xnm and a.xqm = tjb.xqm and a.kch_id = tjb.kch_id and a.njdm_id = tjb.njdm_id and a.zyh_id = tjb.zyh_id and a.bh_id = tjb.bh_id)
                ) where rwrs < xsrs
               ) t2 where t1.njdm_id = t2.njdm_id
                      and t1.zyh_id = t2.zyh_id
                      and t1.bh_id = t2.bh_id
                      and t1.zyfx_id = t2.zyfx_id
                      and t1.kch_id = t2.kch_id
               )
          and  exists(select 'X' from jw_pk_tjxsbrsb t3 where
          t1.xnm||t1.njdm_id||t1.zyh_id||t1.bh_id||t1.zyfx_id =t3.xnm||t3.njdm_id||t3.zyh_id||t3.bh_id||t3.zyfx_id and bitand(t1.xqm,t3.xqm) > 0
                    )
         and t1.xnm = vXnm
         and t1.dxqm = vXqm;
    --2---任务人数与学生人数比较存在任务人数小于学生人数的情况--------end--------

    --3---无方向的主教学班任务人数与分项学时教学班总人数不一致的情况----begin------
    delete from jw_pk_jxrwycb_temp;
    commit;
    insert into jw_pk_jxrwycb_temp(xnm,xqm,njdm_id,zyh_id,bh_id,jxb_id)
    select xnm,xqm,njdm_id,zyh_id,bh_id,jxb_id from
                          (select a.xnm,a.xqm,a.njdm_id,a.zyh_id,a.kch_id,a.jxb_id,a.fjxb_id,a.bh_id,a.xsdm,a.rs zrs,b.xsdm,b.rs crs from
                           (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id ,kch_id,jxb_id,fjxb_id,xsdm,rs from
                             jw_pk_jxrwlsb where zyfx_id = 'wfx'
                                             and fjxb_id is null
                                             and xnm= vXnm
                                             and dxqm = vXqm
                           ) a ------无方向的主教学班任务---
                          inner join
                          (select xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,fjxb_id,xsdm,sum(rs) rs from
                                 jw_pk_jxrwlsb where zyfx_id ='wfx'
                                                 and fjxb_id is not null
                                                 and xnm= vXnm
                                                 and dxqm = vXqm
                           group by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,fjxb_id,xsdm
                          ) b -----无方向分项学时教学班及课程人数-----
                          on
                         (
                         a.njdm_id = b.njdm_id and
                         a.zyh_id = b.zyh_id and
                         a.bh_id = b.bh_id and
                         a.kch_id = b.kch_id and
                         a.jxb_id = b.fjxb_id
                         --  a.xnm||a.xqm||a.njdm_id||a.zyh_id||a.bh_id||a.kch_id||a.jxb_id
                         -- = b.xnm||b.xqm||b.njdm_id||b.zyh_id||b.bh_id||b.kch_id||b.fjxb_id
                         )
                         ) where zrs <> crs;

        commit;
    insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
      select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'3','无方向的主教学班任务人数与分项学时教学班总人数不一致的情况' from
          jw_pk_jxrwlsb t1
          where exists (select 'X' from
                         jw_pk_jxrwycb_temp t2 where t2.xnm = vXnm
                               and t2.xqm = vXqm
                               and t1.njdm_id = t2.njdm_id
                               and t1.zyh_id = t2.zyh_id
                               and t1.bh_id = t2.bh_id
                               and t1.jxb_id = t2.jxb_id
                      )
            and t1.xnm = vXnm
            and t1.dxqm = vXqm;

   insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
     select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'3','无方向的主教学班任务人数与分项学时教学班总人数不一致的情况' from
          jw_pk_jxrwlsb t1 where t1.xnm  = vXnm
                             and t1.dxqm = vXqm
                             and t1.fjxb_id is not null
                             and exists(select 'X' from  jw_pk_jxrwyclsb t2 where t1.fjxb_id = t2.jxb_id
                                                                              and t2.xnm = vXnm
                                                                              and t2.dxqm = vXqm
                                                                              and bj = '3');
    --3---无方向的主教学班任务人数与分项学时教学班总人数不一致的情况------end------


    --4---有方向的主教学班任务人数与分项学时教学班总人数不一致的情况----begin------
     delete from jw_pk_jxrwycb_temp;
     commit;
     insert into jw_pk_jxrwycb_temp(xnm,xqm,njdm_id,zyh_id,bh_id,jxb_id)
     select xnm,xqm,njdm_id,zyh_id,bh_id,jxb_id  from --,zyfx_id,kch_id,jxb_id ,fjxb_id,zrs,crs
                               (select a.xnm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.jxb_id ,a.fjxb_id ,a.xsdm ,a.rs zrs,b.xsdm,b.rs crs from
                                (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs from
                                     jw_pk_jxrwlsb where zyfx_id <> 'wfx'
                                                     and fjxb_id is null
                                                     and xnm = vXnm
                                                     and dxqm = vXqm
                                ) a -----有方向教务班主任务-----
                                inner join
                                (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,fjxb_id,xsdm,sum(rs) rs from
                                       jw_pk_jxrwlsb where zyfx_id <> 'wfx'
                                                       and fjxb_id is not null
                                                       and xnm= vXnm
                                                       and dxqm = vXqm
                                     group by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,fjxb_id,xsdm
                                ) b -----有方向分项学时教学班任务-------
                               on
                               (  a.njdm_id = b.njdm_id
                                and a.zyh_id = b.zyh_id
                                and a.zyfx_id = b.zyfx_id
                                and a.bh_id = b.bh_id
                                and a.kch_id = b.kch_id
                                and a.jxb_id = b.fjxb_id )
                               ) where zrs <> crs;
     commit;
    insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
      select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'4','有方向的主教学班任务人数与分项学时教学班总人数不一致的情况' from
       jw_pk_jxrwlsb t1 where exists
                              (select 'X' from
                              jw_pk_jxrwycb_temp t2 where t2.xnm = vXnm
                                     and t2.xqm = vXqm
                                     and t1.njdm_id = t2.njdm_id
                                     and t1.zyh_id = t2.zyh_id
                                     and t1.bh_id = t2.bh_id
                                     and t1.jxb_id = t2.jxb_id
                             )
                           and t1.xnm = vXnm
                           and t1.dxqm = vXqm;

     insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
      select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'4','有方向的主教学班任务人数与分项学时教学班总人数不一致的情况' from
       jw_pk_jxrwlsb t1 where t1.xnm = vXnm
                          and t1.xqm = vXqm
                          and t1.fjxb_id is not null
                          and exists(select 'X' from  jw_pk_jxrwyclsb t2 where t1.fjxb_id = t2.jxb_id
                                                                           and t2.xnm = vXnm
                                                                           and t2.dxqm = vXqm
                                                                           and bj = '4');
    --4---有方向的主教学班任务人数与分项学时教学班总人数不一致的情况------end------


    --5--同一教学班内不能存在同一年级专业下即是无方向课程又是有方向的课程情况---begin---
    insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
    select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,'5','同一教学班内不能存在同一年级专业下即是无方向课程又是有方向的课程情况' from
           (SELECT  xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs
           ,
                   count(distinct zyfx_id) over (partition by xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,jxb_id ) rn,
                   max(case when zyfx_id = 'wfx' then 1 else 0 end) over (partition by xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,jxb_id ) rn1

                     FROM
                     jw_pk_jxrwlsb a where a.xnm= vXnm
                                       and a.dxqm = vXqm
            ) a where rn >1 and rn1 = 1;
    --5--同一教学班内不能存在同一年级专业下即是无方向课程又是有方向的课程情况-----end---
    commit;
  -------------------------------------------------------------------------------
  <<NextReCord>>
  v_jls:=0;
  open Get_YcJxrwxx;
  loop
    fetch Get_YcJxrwxx into Cur_YcJxrwxx;
     exit when Get_YcJxrwxx%notfound;
     v_jls:=Cur_YcJxrwxx.jls;
     i := 9;
     if v_jls > 0 then
       begin
       -------------------------------------------------------
       insert into jw_pk_jxrwyclsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,bj,bjms)
                select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.rs, i,'被影响数据' From
                 jw_pk_jxrwlsb a ,jw_pk_jxrwyclsb c where a.jxb_id = c.jxb_id
                                                      and c.xnm  = vXnm
                                                      and c.dxqm = vXqm
                                                      and not exists(select 'X' from jw_pk_jxrwyclsb b
                                                                                    where a.njdm_id = b.njdm_id
                                                                                      and a.zyh_id = b.zyh_id
                                                                                      and a.bh_id = b.bh_id
                                                                                      and b.xnm = vXnm
                                                                                      and b.dxqm =  vXqm  )
                                                      and a.xnm = vXnm
                                                      and a.dxqm = vXqm ;
       -------------------------------------------------------
        commit;

      exception
        When others then
          Rollback;
          Goto Exend;
      end;
     else
       Goto Exend;
     end if;
  end loop;
  close Get_YcJxrwxx;
  Goto NextReCord;
  <<Exend>>

  begin
    --------学生人数与推荐课表内人数存在差额情况需要补人数到推荐课表内----
    delete from jw_pk_cshztb where xnm = vXnm and dxqm = vXqm;
    /*insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,3 bj from jw_pk_jxrwlsb t1 -----已排状态
           where t1.xnm = vXnm
             and t1.dxqm = vXqm
             and exists(select 'X' from jw_pk_kbsjb t2
                                where t1.jxb_id = t2.jxb_id
                                and  t2.xnm = t1.xnm
                                and t2.xqm = t1.xqm
                                and t2.xnm = vXnm
                                and bitand(t2.xqm ,vXqm) > 0
                        );*/
    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,2 bj from jw_pk_jxrwlsb t1 -----已初始但有新教学任务状态
           where t1.xnm = vXnm
             and t1.dxqm = vXqm
             --and t1.fjxb_id is null
             and not exists (select 'X' from jw_pk_tjkbjgb t2
                                   where t1.jxb_id = t2.jxb_id
                                     and t1.njdm_id = t2.njdm_id
                                     and t1.zyh_id = t2.zyh_id
                                     and t1.bh_id = t2.bh_id
                                     and t2.xnm = vXnm
                                     and t2.dxqm = vXqm
                            );

    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,1 bj from jw_pk_tjkbjgb    -----已初始化状态
    where xnm = vXnm and dxqm = vXqm;

    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,0 bj from jw_pk_jxrwyclsb  -----教学任务异常状态
                  where xnm = vXnm
                    and dxqm = vXqm;
    commit;
  end;
  null;
-----------------------------------------------------------------------------------------------------------------------
end;

/

