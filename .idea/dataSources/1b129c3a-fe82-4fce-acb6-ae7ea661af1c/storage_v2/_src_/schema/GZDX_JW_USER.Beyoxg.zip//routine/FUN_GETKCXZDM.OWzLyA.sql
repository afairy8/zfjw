create function fun_getkcxzdm(vXh_id varchar2,vKch_id varchar2,vbj varchar2) return varchar2
as
   sNjdm_id varchar2(32);
   sZyh_id varchar2(32);
   sKcxzdm varchar2(32);
   sXf varchar2(32);
begin
 begin
  select njdm_id,zyh_id into sNjdm_id,sZyh_id from jw_xjgl_xsjbxxb xs where xs.xh_id=vXh_id;


  /*select max(t3.kcxzdm) into sKcxzdm from jw_jh_pyfasynjb t, jw_jh_pyfaxxb t1,jw_jh_pyfaxfyqxxb t2,jw_jh_pyfakcxxb t3 ,jw_cj_xsgrjhdtb t4
        where t.pyfaxx_id = t1.pyfaxx_id
          and t1.pyfaxx_id = t2.pyfaxx_id
          and t2.xfyqjd_id = t3.xfyqjd_id
          and t3.kch_id = t4.kch_id
          and t4.kcthzh_id = vKcthzh_id
          and t4.xh_id = vXh_id
          and t.njdm_id = sNjdm_id
          and t1.zyh_id = sZyh_id;*/
  if vbj = 'kcxz' then
  select max(t3.kcxzdm) into sKcxzdm from jw_jh_pyfasynjb t, jw_jh_pyfaxxb t1,jw_jh_pyfaxfyqxxb t2,jw_jh_pyfakcxxb t3
        where t.pyfaxx_id = t1.pyfaxx_id
          and t1.pyfaxx_id = t2.pyfaxx_id
          and t2.xfyqjd_id = t3.xfyqjd_id
          and t3.kch_id = vKch_id
          and t.njdm_id = sNjdm_id
          and t1.zyh_id = sZyh_id;

  return sKcxzdm ;
  end if;

  if vbj = 'xf' then
  select max(t3.xf) into sXf from jw_jh_pyfasynjb t, jw_jh_pyfaxxb t1,jw_jh_pyfaxfyqxxb t2,jw_jh_pyfakcxxb t3
        where t.pyfaxx_id = t1.pyfaxx_id
          and t1.pyfaxx_id = t2.pyfaxx_id
          and t2.xfyqjd_id = t3.xfyqjd_id
          and t3.kch_id = vKch_id
          and t.njdm_id = sNjdm_id
          and t1.zyh_id = sZyh_id;

  return sXf ;
  end if;
    exception
        When others then
         return null;
    end;
end fun_getkcxzdm;
/

