create Procedure Pk_SetTjkbJz--(sTjkbdm in varchar2,Syhm in varchar2,iBj out varchar2)
as
  i number;     ----定义数值型变量----i---
  v_jls number; ----记录数
  v_zjls number; ----子记录数
  v_wzjls number;----无子记录数
  v_tjkbdm varchar2(10); ----推荐课表代码----
  v_ztjkbdm varchar2(10); ----子推荐课表代码----
  cursor get_RwKbxx is     ----取排课任务信息，除子学时任务信息。----游标---
   select count(*) jls From jw_pk_jxrwb Where fjxb_id is null and rs<>'0';
  Cur_RwKbxx get_RwKbxx%rowtype;
  ------------------------------------------------------------------------------
 cursor get_Rwkbzxx is     ----取排课任务信息，除子学时任务信息。----游标---
   select count(*) zjls From jw_pk_tjkbdmb Where
                                               jxb_id in
                                               (
                                               select fjxb_id from  jw_pk_jxrwb where
                                                                                       fjxb_id is not null
                                                                                       and  rs <> 0
                                                ) and
                                                rs<>'0';
  Cur_Rwkbzxx get_Rwkbzxx%rowtype;
  ------------------------------------------------------------------------------
  cursor get_Rwkbwzxx is     ----取排课任务信息，除子学时任务信息。----游标---
   select count(*) wzjls From jw_pk_tjkbdmb Where rs = '0';
  Cur_Rwkbwzxx get_Rwkbwzxx%rowtype;
 --------------------------------------------------------------------------------
begin
  i:=1;
  v_wzjls:=0;
  <<NextReCord>>
  v_jls:=0;
  open get_RwKbxx;
  loop
    fetch get_RwKbxx into Cur_RwKbxx;
     exit when get_RwKbxx%notfound;
     v_jls:=Cur_RwKbxx.jls;
     if v_jls > 0 then
      v_tjkbdm:=to_char(i);
       delete from jw_pk_tjkbjglsb;
       commit;
      begin
        insert into jw_pk_tjkbjglsb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,xsdm,zyfx_id,rs)
        --取出各课程最大教学班人数后按其中取出列表人数--begin-----
         select xnm,xqm,njdm_id,zyh_id,bh_id,v_tjkbdm,kch_id,jxb_id,xsdm,zyfx_id,
                min(to_number(rs)) over(partition by xnm,xqm,njdm_id,zyh_id,bh_id) tjrs   ---按最小人数分别显示在各教学班列表人数--（tjrs:推荐人数）--
                from  (
                       --无方向课程与有方向课程合并----begin-------------
                     select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,
                            row_number()over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id order by to_number(rs) desc ) rn --各课程中的教学班人数倒序排序rn
                     FROM jw_pk_jxrwb where
                                     fjxb_id is null and --列表信息内不包涵学时类型的教学班信息（如实验课、上机课等分学时类型的教学班）
                                     zyfx_id = 'wfx' and --取出无方向课程
                                      rs <> 0               --人数不为零判断（过滤掉分配推荐课表已经完成的教学任务信息，见下面更新人数）

                    union all
                    --------------------------------------------------
                    select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,--zrs,
                           rank() over(partition by xnm||xqm||njdm_id||zyh_id||bh_id||rn1||rn  order by zyfx_id ) rn
                           from (
                                 select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,zrs,
                                 rank() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id  order by to_number(zrs) desc ) rn1,
                                   row_number()over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id order by to_number(zrs) desc  ) rn  --取出各方向中课程的教学班人数倒序排序rn
                                    from
                                         (
                                           select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,
                                                  sum(rs) over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id) zrs
                                                FROM jw_pk_jxrwb where
                                                   fjxb_id is null and    --列表信息内不包涵学时类型的教学班信息（如实验课、上机课等分学时类型的教学班）
                                                   zyfx_id <> 'wfx' and  --取出有方向课程
                                                    rs <> 0                 --人数不为零判断（过滤掉分配推荐课表已经完成的教学任务信息，见下面更新人数）
                                          )
                                 ) where rn1 = '1' and rn = '1'             --取出各方向中某一课程的教学班最大人数的信息列表
                      --无方向课程与有方向课程合并-------end---------
                 ) where
                 rn = '1';
      --取出各课程最大教学班人数后按其中取出列表人数--end----
        --commit;
-------------------------------------------------------------------------------------------------------------------------------
     --拆分后的小课表数据插入到推荐课表代码表内--begin--
     insert into jw_pk_tjkbdmb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                        select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from jw_pk_tjkbjglsb;
       --commit;
     --拆分后的小课表数据插入到推荐课表代码表内--begin--
-------------------------------------------------------------------------------------------------------------------------------
      --更新排课任务中的已拆分出小课表的数据，人数要在原排课任务中剪掉--begin--------------
      UPDATE jw_pk_jxrwb A SET
                               RS = RS -
                               (
                                SELECT rs FROM jw_pk_tjkbjglsb B
                                WHERE
                                   a.xnm = b.xnm and
                                   a.xqm = b.xqm and
                                   a.njdm_id = b.njdm_id and
                                   a.zyh_id = b.zyh_id and
                                   a.bh_id = b.bh_id and
                                   a.kch_id = b.kch_id and
                                   a.jxb_id = b.jxb_id and
                                   a.zyfx_id = b.zyfx_id
                               )
                          WHERE
                              EXISTS (
                                      SELECT 'x' FROM jw_pk_tjkbjglsb C
                                      WHERE
                                           a.xnm = c.xnm and
                                           a.xqm = c.xqm and
                                           a.njdm_id = c.njdm_id and
                                           a.zyh_id = c.zyh_id and
                                           a.bh_id = c.bh_id and
                                           a.kch_id = c.kch_id and
                                           a.jxb_id = c.jxb_id and
                                           a.zyfx_id = c.zyfx_id
                                      );

      --更新排课任务中的已拆分出小课表的数据，人数要在原排课任务中剪掉----end--------------
        commit;
      exception
        When others then
          Rollback;
          Goto Exend;
      end;
     else
       Goto Exend;
     end if;
  end loop;
  close get_RwKbxx;
  i:=i+1;
  Goto NextReCord;
  <<Exend>>
  null;

  -------------------------------------------------------------------------------------------

  -------------------------------------第二步处理--------------------------------------------

   i:=1;
  <<NextSecReCord>> --第二记录集----
  v_zjls:=0;
  open get_RwKbzxx; --任务课表子信息课表---
  loop
    fetch get_RwKbzxx into Cur_RwKbzxx;
     exit when get_RwKbzxx%notfound;
     v_zjls:=Cur_RwKbzxx.zjls;
     if v_zjls > 0 then
      v_ztjkbdm:=to_char(i);
      delete from jw_pk_tjkbjglsb;
      delete from jw_pk_tjkbdmlsb;
      commit;

      begin
        ----------------------------------------------------------------------------------------------------------
        insert into jw_pk_tjkbdmlsb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn)
        select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn from
                                         (
                                         select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs ,
                                         row_number() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id order by to_number(rs) desc ) rn
                                        from jw_pk_tjkbdmb a
                                        where a.rs <> '0' and
                                             exists(
                                                     select 'X' from  jw_pk_jxrwb b where b.fjxb_id is not null and b.rs <> 0 and a.jxb_id = b.fjxb_id
                                                    )
                                             and
                                             exists(
                                                    select 'X' from (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,max(tjkbzdm) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id) tjkbzdm from
                                                    (select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                                                     row_number() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id order by to_number(rs) desc ) rn
                                                     from jw_pk_tjkbdmb a
                                                          where a.rs <> '0' and
                                                                exists(
                                                                       select 'X' from  jw_pk_jxrwb b where b.fjxb_id is not null and b.rs <> 0 and a.jxb_id = b.fjxb_id
                                                                       )
                                                      ) where rn = '1'  ) c
                                                      where a.xnm = c.xnm and a.xqm = c.xqm and a.njdm_id = c.njdm_id and a.zyh_id = c.zyh_id and a.bh_id = c.bh_id and a.zyfx_id = c.zyfx_id and a.tjkbzdm = c.tjkbzdm
                                                    )
                                        )  where rn = '1';
        -------------------------------------------------------------------------------------
        insert into jw_pk_tjkbjglsb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
        select xnm,xqm,njdm_id,zyh_id,bh_id,
               max(to_number(tjkbzdm)) over(partition by xnm,xqm,njdm_id,zyh_id,bh_id) tjkbzdm,
               v_ztjkbdm tjkbzxsdm,kch_id,jxb_id, fjxb_id, xsdm,zyfx_id,
               min(to_number(rs)) over(partition by xnm,xqm,njdm_id,zyh_id,bh_id) tjrs
               from (
                     select xnm,xqm,njdm_id,zyh_id,bh_id, 0 tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                            row_number() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id,xsdm order by to_number(rs) desc ) rn
                            from  jw_pk_jxrwb a where a.fjxb_id is not null and a.rs <> 0
                            ---------------------------------------------------------
                            --------只能取出在最大人数对应的课程教学班---------与下面UNION ALL教学任务有关------
                            and exists(
                                       select 'X' from jw_pk_tjkbdmlsb b where
                                       a.xnm= b.xnm and a.xqm =b.xqm and a.njdm_id = b.njdm_id and a.zyh_id= b.zyh_id and a.bh_id =b.bh_id and a.zyfx_id = b.zyfx_id and a.fjxb_id = b.jxb_id
                                       )
                            ---------------------------------------------------------
                     union all

                     select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn
                           from (
                                 select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs ,
                                        row_number() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id order by to_number(rs) desc ) rn
                                        from jw_pk_tjkbdmb a
                                        where a.rs <> '0' and
                                             exists (
                                                    select 'X' from  jw_pk_jxrwb b where b.fjxb_id is not null and b.rs <> 0 and a.jxb_id = b.fjxb_id
                                                    )

                             ----------------------------------------------------------------------------------
                              ----------------------------取最大人数的主教学班所对应的推荐课表子代码-------
                                            and
                                            exists (
                                                    select 'X' from
                                                    (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,max(tjkbzdm) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id) tjkbzdm from
                                                     (
                                                       select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs ,
                                                            row_number() over(partition by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id order by to_number(rs) desc ) rn
                                                           from jw_pk_tjkbdmb a
                                                               where a.rs <> '0' and
                                                                    exists (
                                                                            select 'X' from  jw_pk_jxrwb b where b.fjxb_id is not null and b.rs <> 0 and a.jxb_id = b.fjxb_id
                                                                            )
                                                       ) where rn = '1'
                                                      ) c
                                                      where
                                                      a.xnm = c.xnm and a.xqm = c.xqm and a.njdm_id = c.njdm_id and a.zyh_id = c.zyh_id and a.bh_id = c.bh_id and a.zyfx_id = c.zyfx_id and a.tjkbzdm = c.tjkbzdm
                                                    )
                             -----------------------------------------------------------------------------------
                                 )
                                 where rn = '1'

                   )
                   where rn = '1'; --order by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id;
-------------------------------------------------------------------------------

  insert into jw_pk_tjkbjgb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                          select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from jw_pk_tjkbjglsb;

------------------------------------------------------------------------------------------------------------------------------
       UPDATE jw_pk_jxrwb A
             SET RS = RS -
                (
                 SELECT rs FROM jw_pk_tjkbjglsb B
                                            WHERE
                                                  a.xnm = b.xnm and
                                                  a.xqm = b.xqm and
                                                  a.njdm_id = b.njdm_id and
                                                  a.zyh_id = b.zyh_id and
                                                  a.bh_id = b.bh_id and
                                                  a.kch_id = b.kch_id and
                                                  a.jxb_id = b.jxb_id and
                                                  a.zyfx_id = b.zyfx_id  )
                             WHERE fjxb_id is not null and
                                   EXISTS (SELECT 'x' FROM jw_pk_tjkbjglsb C
                                                                        WHERE
                                                                              a.xnm = c.xnm and
                                                                              a.xqm = c.xqm and
                                                                              a.njdm_id = c.njdm_id and
                                                                              a.zyh_id = c.zyh_id and
                                                                              a.bh_id = c.bh_id and
                                                                              a.kch_id = c.kch_id and
                                                                              a.jxb_id = c.jxb_id and
                                                                              a.zyfx_id = c.zyfx_id
                                           );

----------------------------------------------------------------------------------------------------------------------------------
       UPDATE jw_pk_tjkbdmb A
             SET RS = RS -
                 (
                   SELECT rs FROM jw_pk_tjkbjglsb B WHERE
                                                         a.xnm = b.xnm and
                                                         a.xqm = b.xqm and
                                                         a.njdm_id = b.njdm_id and
                                                         a.zyh_id = b.zyh_id and
                                                         a.bh_id = b.bh_id and
                                                         a.tjkbzdm = b.tjkbzdm and
                                                         a.kch_id = b.kch_id and
                                                         a.jxb_id = b.jxb_id and
                                                         a.zyfx_id = b.zyfx_id  )
                              WHERE fjxb_id is null and
                                    EXISTS (SELECT 'x' FROM jw_pk_tjkbjglsb C
                                                                       WHERE
                                                                              a.xnm = c.xnm and
                                                                              a.xqm = c.xqm and
                                                                              a.njdm_id = c.njdm_id and
                                                                              a.zyh_id = c.zyh_id and
                                                                              a.bh_id = c.bh_id and
                                                                              a.tjkbzdm = c.tjkbzdm  and
                                                                              a.kch_id = c.kch_id and
                                                                              a.jxb_id = c.jxb_id and
                                                                              a.zyfx_id = c.zyfx_id
                                            );

        commit;
      exception
        When others then
          Rollback;
          Goto ExSecend;
      end;
     else
       Goto ExSecend;
     end if;
  end loop;
  close get_RwKbzxx;
  i:=i+1;
  Goto NextSecReCord;
  <<ExSecend>>
  null;

  -------------------------------------------------------------------------------------------

  -------------------------------------第三部处理--------------------------------------------

  open get_RwKbwzxx;
  fetch get_RwKbwzxx into Cur_RwKbwzxx;
   v_wzjls:=Cur_RwKbwzxx.wzjls;
  if v_wzjls = 0 then
     insert into jw_pk_tjkbjgb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                        select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,0 tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from jw_pk_tjkbdmb;
     commit;

     close get_RwKbwzxx;
     else
         insert into jw_pk_tjkbjgb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                select distinct b.xnm,b.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.tjkbzdm,a.tjkbzxsdm,b.kch_id,b.jxb_id,b.fjxb_id,b.xsdm,b.zyfx_id,a.rs
                       from  jw_pk_tjkbjgb a ,jw_pk_tjkbdmb b where
                                                                b.rs <> '0' and
                                                                a.fjxb_id is null and
                                                                a.kch_id <> b.kch_id and
                                                                a.xnm = b.xnm and
                                                                a.xqm = b.xqm and
                                                                a.njdm_id = b.njdm_id and
                                                                a.zyh_id = b.zyh_id and
                                                                a.bh_id = b.bh_id and
                                                                a.tjkbzdm = b.tjkbzdm
                                                                order by b.xnm,b.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.tjkbzdm,a.tjkbzxsdm,b.kch_id;


        insert into jw_pk_tjkbjgb(xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
        select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,00,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from jw_pk_tjkbdmb a where
          exists
          (select 'X' from
           (
            select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,zyfx_id from jw_pk_tjkbdmb where rs <> 0
            minus
            select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,zyfx_id from jw_pk_tjkbjgb where fjxb_id is null
           ) b where a.xnm = b.xnm and a.xqm = b.xqm and a.njdm_id = b.njdm_id and a.zyh_id = b.zyh_id and
             a.bh_id = b.bh_id and a.tjkbzdm = b.tjkbzdm and a.kch_id = b.kch_id and a.jxb_id = b.jxb_id and a.zyfx_id = b.zyfx_id );

        commit;
      ----------------------------------------------------------------------------------------------------------------------
   end if;
-----------------------------------------------------------------------------------------------------------------------
end;


/

