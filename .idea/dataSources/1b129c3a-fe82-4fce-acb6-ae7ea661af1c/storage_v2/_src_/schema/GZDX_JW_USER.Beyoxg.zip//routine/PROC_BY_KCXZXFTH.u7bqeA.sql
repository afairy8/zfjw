create procedure proc_by_kcxzxfth(v_xh_id  varchar2) --毕业正审核 课程性质替代的相关处理
as
    resultInfo        varchar2(32);  --返回结果信息
    iKcxzxfthb_id     varchar2(32);  --存放课程性质替代表   主键ID
    ikcxzNum          varchar2(32);  --存放课程性质替代表   数量
    iThkcxzdm         varchar2(32);  --存放课程性质替代表     替代的课程性质
    iBthkcxzdm        varchar2(32);  --存放课程性质替代表   被替代的课程性质
    iTdkcxzdm_num     varchar2(32);  --存放学生计划节点中 跟  替代课程性质相匹配的 数量
    iBtdkcxzdm_num    varchar2(32);  --存放学生计划节点中 跟被替代课程性质相匹配的 数量
    iCcjdxf_subentry   varchar2(32); --超出学分 分项
    iCcjdxf_total      varchar2(32); --超出学分 总计
    IQsjdxf_subentry   varchar2(32); --缺失学分 分项
    IQsjdxf_total      varchar2(32); --缺失学分 总计
    IdataBottle        varchar2(32); --数据交换 瓶子
    ITempXsjxzxjhxfyqxxb_id  varchar2(32); --学生教学执行计划学分要求信息表ID
    ipm                varchar2(32);  --序列
    iMaxjb             number;        --计算修读层级最大值
    sQtqyxfjd          varchar2(100); --其他修读要求对应特殊处理的修读要求学分节点ID
    sXxdm              varchar2(20);  --学校代码
begin
  begin
     select max(xxdm) into sXxdm from zftal_xtgl_xxxxszb where xxdm = '10248';
     if sXxdm = '10248' then
       select max(jb),nvl(max(case when xfyqjdmc = (select zdz from zftal_xtgl_xtszb where zdm = 'JHWKCGSJDMC') then xfyqjd_id else null end ),'-1')
              into iMaxjb,sQtqyxfjd from JW_JH_xsJXZXJHXFYQXXB where xh_id = v_xh_id;
       for x in 2 .. iMaxjb loop
       ---------------与关系只处理末节点-----------------
         update jw_jh_xsjxzxjhxfyqxxb a set (a.hdxf,a.KCXZTHXF) =
         (select hdxf-a,-a from
         (select xfyqjd_id,xfyqjdmc,fxfyqjd_id,yqzdxf,hdxf,
     nvl(case when rn <=1 and syxf >= fsyxf
       then fsyxf
     when sum(case when rn <=2-1 then syxf else 0 end) over(partition by fxfyqjd_id) <fsyxf
          and rn <=2 and sum(syxf) over(partition by fxfyqjd_id) >= fsyxf
        then (case when rn = 2 then (fsyxf- sum(case when rn <=2-1 then syxf else 0 end) over(partition by fxfyqjd_id) ) else syxf end)
     when sum(case when rn <=3-1 then syxf else 0 end) over(partition by fxfyqjd_id) <fsyxf
          and rn <=3 and sum(syxf) over(partition by fxfyqjd_id) >= fsyxf
        then (case when rn = 3 then (fsyxf- sum(case when rn <=3-1 then syxf else 0 end) over(partition by fxfyqjd_id) ) else syxf end)
     when sum(case when rn <=4-1 then syxf else 0 end) over(partition by fxfyqjd_id) <fsyxf
          and rn <=4 and sum(syxf) over(partition by fxfyqjd_id) >= fsyxf
        then (case when rn = 4 then (fsyxf- sum(case when rn <=4-1 then syxf else 0 end) over(partition by fxfyqjd_id) ) else syxf end)
     when sum(case when rn <=5-1 then syxf else 0 end) over(partition by fxfyqjd_id) <fsyxf
          and rn <=5 and sum(syxf) over(partition by fxfyqjd_id) >= fsyxf
        then (case when rn = 5 then (fsyxf- sum(case when rn <=5-1 then syxf else 0 end) over(partition by fxfyqjd_id) ) else syxf end)
     when sum(case when rn <=6-1 then syxf else 0 end) over(partition by fxfyqjd_id) <fsyxf
          and rn <=6 and sum(syxf) over(partition by fxfyqjd_id) >= fsyxf
        then (case when rn = 6 then (fsyxf- sum(case when rn <=6-1 then syxf else 0 end) over(partition by fxfyqjd_id) ) else syxf end)
     end,0) a
   from (
      select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
             case when t1.hdxf - t1.yqzdxf <=0 then null else row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf - t1.yqzdxf desc) end rn
       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
       where t1.xh_id = t2.xh_id and t1.xh_id = v_xh_id
         and t1.fxfyqjd_id = t2.xfyqjd_id
         and t1.jb =  x+1
         and t1.sfmjd = '1'
        -- and t1.fxfyqjd_id = '12612201608060640tsk'
         and t2.xfyqzjdgx = '1'
       ) ) b where a.xfyqjd_id = b.xfyqjd_id and a.xh_id = v_xh_id)
   where exists(select 'X' from (
      select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
             case when t1.hdxf - t1.yqzdxf <=0 then null else row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf - t1.yqzdxf desc) end rn
       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
       where t1.xh_id = t2.xh_id and t1.xh_id = v_xh_id
         and t1.fxfyqjd_id = t2.xfyqjd_id
         and t1.jb =  x+1
         and t1.sfmjd = '1'
        -- and t1.fxfyqjd_id = '12612201608060640tsk'
         and t2.xfyqzjdgx = '1'
       ) c where a.xfyqjd_id = c.xfyqjd_id )
       and a.xh_id = v_xh_id
       and a.xfyqjd_id != sQtqyxfjd;



       update jw_jh_xsjxzxjhxfyqxxb a set a.hdxf = a.hdxf+a.syxf
   where exists(select 'X' from (
      select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
             case when t1.hdxf - t1.yqzdxf <=0 then null else row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf - t1.yqzdxf desc) end rn
       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
       where t1.xh_id = t2.xh_id and t1.xh_id = v_xh_id
         and t1.fxfyqjd_id = t2.xfyqjd_id
         and t1.jb =  x+1
         and t1.sfmjd = '1'
        -- and t1.fxfyqjd_id = '12612201608060640tsk'
         and t2.xfyqzjdgx = '1'
         and t1.kcxzthxf > 0
       ) c where a.xfyqjd_id = c.fxfyqjd_id )
       and a.xh_id = v_xh_id
       and a.xfyqzjdgx = '1'
       and a.jb = x;

      ---------------或1关系只处理末节点-----------------
      update jw_jh_xsjxzxjhxfyqxxb a set (a.hdxf,a.KCXZTHXF) =
      (select case when rn = 1 then hdxf -a else hdxf end, -a from
      (select xfyqjd_id,xfyqjdmc,yqzdxf,hdxf,syxf,rn,
       nvl(case when rn = 1 then fsyxf
            when rn >1 and hdxf > 0 then  hdxf end,0) a from
      (select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
              row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf desc) rn
       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
       where t1.xh_id = t2.xh_id and t1.xh_id = v_xh_id
         and t1.fxfyqjd_id = t2.xfyqjd_id
         and t1.jb = x+1
         and t1.sfmjd = '1'
        -- and t1.fxfyqjd_id = '1261220160806065052'
         and t2.xfyqzjdgx = '0'
       ) ) b where a.xfyqjd_id = b.xfyqjd_id)
      where exists( select 'X' from
                    (select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
                            row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf desc) rn
                       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
                       where t1.xh_id = t2.xh_id and t1.xh_id =v_xh_id
                         and t1.fxfyqjd_id = t2.xfyqjd_id
                         and t1.jb = x+1
                         and t1.sfmjd = '1'
                         --and t1.fxfyqjd_id = '1261220160806065052'
                         and t2.xfyqzjdgx = '0'
                      ) c where a.xfyqjd_id = c.xfyqjd_id
                      )
         and a.xh_id = v_xh_id
         and a.xfyqjd_id != sQtqyxfjd;

        update jw_jh_xsjxzxjhxfyqxxb a set a.hdxf = a.hdxf+a.syxf
         where exists(select 'X' from
                     (select t1.xfyqjd_id,t1.xfyqjdmc,t1.fxfyqjd_id,t1.yqzdxf,t1.hdxf,t1.sjhdxf,t1.hdxf - t1.yqzdxf syxf,-t2.syxf as fsyxf,
                            row_number() over (partition by t1.fxfyqjd_id order by t1.hdxf desc) rn
                       from jw_jh_xsjxzxjhxfyqxxb t1,jw_jh_xsjxzxjhxfyqxxb t2
                       where t1.xh_id = t2.xh_id and t1.xh_id =v_xh_id
                         and t1.fxfyqjd_id = t2.xfyqjd_id
                         and t1.jb = x+1
                         and t1.sfmjd = '1'
                         --and t1.fxfyqjd_id = '1261220160806065052'
                         and t2.xfyqzjdgx = '0'
                         and t1.kcxzthxf > 0
                        ) c where a.xfyqjd_id = c.fxfyqjd_id )
             and a.xh_id = v_xh_id
             and a.xfyqzjdgx = '0'
             and a.jb = x;

       end loop;
      else
        /*查看 课程性质 替代 关系表中是否有数据*/
        select count(1) into ikcxzNum from jw_jh_kcxzxfthb;
         /*1.如果存在课程性质替代数据*/
         if to_number(ikcxzNum) > 0 and v_xh_id is not null then
             /*2.开始循环*/
            for x in 1 .. ikcxzNum loop
                /*查询当前 替代课程性质  被替代课程性质  还有课程性质主键ID*/
                select kcxzxfthb_id,kcxzdm,thkcxzdm,pm  into iKcxzxfthb_id,iThkcxzdm,iBthkcxzdm,ipm
                from (select  kcxzxfthb_id,kcxzdm,thkcxzdm,row_number() OVER(ORDER BY to_number(nvl(yxj, 0)) asc) as pm
                    from jw_jh_kcxzxfthb)   where pm = x;

                /*查询当前学分要求信息表中 符合要求的课程性质代码节点 有几个 */
                select count(1) into iTdkcxzdm_num    from JW_JH_xsJXZXJHXFYQXXB where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm ;
                select count(1) into iBtdkcxzdm_num   from JW_JH_xsJXZXJHXFYQXXB where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;

                   /*3.判断替代和被替代的课程性质节点  均必满足 各自至少有一个 */
                   if  to_number(iTdkcxzdm_num) > 0  and to_number(iBtdkcxzdm_num) > 0 then

                       /*替代节点课程性质 总共可用的学分*/
                       select hdxf - yqzdxf  into iCcjdxf_total
                       from (select sum(yqzdxf)yqzdxf,sum(hdxf)hdxf
                             from JW_JH_xsJXZXJHXFYQXXB
                             where fxfyqjd_id is not null and  xh_id = v_xh_id and kcxzdm = iThkcxzdm and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0));

                      /*被替代节点课程性质 总共缺失的学分*/
                      select yqzdxf - hdxf into IQsjdxf_total
                      from (select sum(yqzdxf) yqzdxf,sum(hdxf)hdxf
                            from JW_JH_xsJXZXJHXFYQXXB
                            where fxfyqjd_id is not null and  xh_id = v_xh_id and kcxzdm = iBthkcxzdm and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0));

                       /*4.使用三段分支的方式来处理数据*/
                          /*第一段 如所有节点 替代多出的学分 等于= 被替代缺失的学分  将 替代的相应节点的获得学分的值 更新为跟要求最低学分 的值相等*/
                          /*第二段 如所有节点 替代多出的学分 大于> 被替代缺失的学分  将 替代的相应节点的获得学分的值 减少到被替代学分缺失学分的和 并将所有被替代学分节点 获得学分 等值于要求最低学分*/
                          /*第三段 如所有节点 替代多出的学分 小于< 被替代缺失的学分  将 替代的相应节点的获得学分的值 更新为跟要求最低学分 的值相等  并将 被替代节点学分 增加 替代学分的和个学分*/
                      if  to_number(iCcjdxf_total)= to_number(IQsjdxf_total) then
                        /*a、处理替代课程性质 节点的获得学分*/
                        update (select * from JW_JH_xsJXZXJHXFYQXXB order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = (hdxf - yqzdxf)*-1 where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm;
                        /*b、处理被替代课程性质 节点的获得学分*/
                        update (select * from JW_JH_xsJXZXJHXFYQXXB order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = yqzdxf - hdxf where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;
                      elsif  to_number(iCcjdxf_total) > to_number(IQsjdxf_total) then
                         /*a、处理替代课程性质 节点的获得学分*/
                           /*初始化瓶子*/
                           IdataBottle := IQsjdxf_total;
                           /*开始循环 要求处理的节点个数 次*/
                           for p in 1 .. iTdkcxzdm_num loop
                              /*始终保持瓶子里面有值*/
                              if to_number(IdataBottle) > 0  then
                                 /*获取 临时需要减掉的值（替代节点多出的 已经给出去的学分） 和主键ID*/
                                  select hdxf-yqzdxf,xsjxzxjhxfyqxxb_id into iCcjdxf_subentry,ITempXsjxzxjhxfyqxxb_id
                                  from (select xxb.xsjxzxjhxfyqxxb_id,xxb.yqzdxf,xxb.hdxf,row_number() OVER(PARTITION BY  kcxzdm ORDER BY kcxzdm, yqzdxf, xfyqjdmc, px desc) as line
                                        from JW_JH_xsJXZXJHXFYQXXB xxb
                                        where xh_id = v_xh_id
                                          and fxfyqjd_id is not null
                                          and nvl(to_number(yqzdxf),0) < nvl(hdxf+kcxzthxf*-1,0)
                                          and kcxzdm = iThkcxzdm
                                          )
                                  where line = p;
                                 /*使用三段分支的方式来处理数据*/
                                 if to_number(iCcjdxf_subentry) = to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf-IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle*-1 where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(iCcjdxf_subentry) > to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf-IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle*-1 where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(iCcjdxf_subentry) < to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf-iCcjdxf_subentry,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = iCcjdxf_subentry*-1  where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*更新瓶子值*/
                                    IdataBottle := IdataBottle-iCcjdxf_subentry;
                                 end if;
                              end if;
                           end loop;

                        /*b、处理被替代课程性质 节点的获得学分*/
                        update (select * from JW_JH_xsJXZXJHXFYQXXB order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = yqzdxf - hdxf where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;

                      elsif  to_number(iCcjdxf_total) < to_number(IQsjdxf_total) then
                        /*a、处理替代课程性质 节点的获得学分*/
                        update (select * from JW_JH_xsJXZXJHXFYQXXB order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = (hdxf - yqzdxf)*-1 where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm ;

                        /*b、处理被替代课程性质 节点的获得学分*/
                           /*初始化瓶子*/
                           IdataBottle := iCcjdxf_total;
                           /*开始循环 要求处理的节点个数 次*/
                           for p in 1 .. iBtdkcxzdm_num loop
                              /*始终保持瓶子里面有值*/
                              if to_number(IdataBottle) > 0  then
                                 /*获取 临时需要缺失的值（被替代节点缺少 需要替代补上的） 和主键ID*/
                                  select yqzdxf - hdxf,xsjxzxjhxfyqxxb_id into IQsjdxf_subentry,ITempXsjxzxjhxfyqxxb_id
                                  from (select xxb.xsjxzxjhxfyqxxb_id,xxb.yqzdxf,xxb.hdxf,row_number() OVER(PARTITION BY  kcxzdm ORDER BY kcxzdm, yqzdxf, xfyqjdmc, px desc) as line
                                        from JW_JH_xsJXZXJHXFYQXXB xxb
                                        where xh_id = v_xh_id
                                           and fxfyqjd_id is not null
                                           and nvl(to_number(yqzdxf),0) > nvl(hdxf-kcxzthxf,0)
                                           and kcxzdm = iBthkcxzdm
                                           )
                                  where line = p;
                                 /*使用三段分支的方式来处理数据*/
                                 if to_number(IQsjdxf_subentry) = to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf+IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(IQsjdxf_subentry) > to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf+IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(IQsjdxf_subentry) < to_number(IdataBottle) then
                                    update JW_JH_xsJXZXJHXFYQXXB set hdxf = hdxf+IQsjdxf_subentry,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IQsjdxf_subentry  where xsjxzxjhxfyqxxb_id = ITempXsjxzxjhxfyqxxb_id;
                                    /*更新瓶子值*/
                                    IdataBottle := IdataBottle-IQsjdxf_subentry;
                                 end if;
                              end if;
                           end loop;
                      end if;
                   else
                     goto next;
                   end if;
                   <<next>>
                    null;
            end loop;
         end if;
     end if;
exception
  When others then
    resultInfo := '出现了错误!';
end;
end;

/

