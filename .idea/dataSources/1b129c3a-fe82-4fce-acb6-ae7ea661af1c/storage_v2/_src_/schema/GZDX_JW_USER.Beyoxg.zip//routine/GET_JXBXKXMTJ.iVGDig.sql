create function get_jxbxkxmtj(vTj    varchar2,
                                         vXnm    varchar2,
                                         vXqm    varchar2,
                                         vJxb_id varchar2,
                                         vXh_id  varchar2) ---教学班选课等级考试项目条件
 Return varchar2 as
  sSql      varchar2(2000);
  sxmtj     varchar2(50);
  scjxxtj     varchar2(50);
  scjsxtj     varchar2(50);
  tj        number;
  icount    number;
begin
  tj   := 0;
  select max(decode(xmtj,xmtj,xmtj)),max(decode(cjxxtj,cjxxtj,cjxxtj)),max(decode(cjsxtj,cjsxtj,cjsxtj))
      into sxmtj,scjxxtj,scjsxtj
      from jw_xk_jxbxktjb
     where xnm = vXnm
       and xqm = vXqm
       and jxb_id = vJxb_id
       and tj_id = vTj;
    if sxmtj is null then
      tj := 1;
    else
      if scjxxtj is null and scjsxtj is null then
        tj:=0;
      else
        sSql    := 'select count(*) from (select max(to_number(case when (select dzb.dyf from jw_xmgl_xmcjdzb dzb,  jw_xmgl_xmjzdmb jzb where t2.jfzdm = jzb.xmjzdm and jzb.xmjzdm = dzb.xmjzdm  and dzb.xmcjmc = t1.xmcj) is null then t1.xmcj else (select dzb.dyf from jw_xmgl_xmcjdzb dzb,  jw_xmgl_xmjzdmb jzb where t2.jfzdm = jzb.xmjzdm and jzb.xmjzdm = dzb.xmjzdm  and dzb.xmcjmc = t1.xmcj) end )) over (partition by 1) zzcj,t1.* from
         Jw_Xmgl_Xmxsbmqkb t1,JW_XMGL_XMBMSZB t2 where t1.xmbmsz_id = t2.xmbmsz_id
				and t1.xh_id =''' ||vXh_id || ''' and t2.xmdm = ''' || sXmtj || '''';

        sSql    := sSql||' ) where 1=1 ';
        if scjxxtj is not null then
           sSql := sSql||' and to_number(zzcj) >= to_number(' || scjxxtj || ')';
        end if;
        if scjsxtj is not null then
           sSql := sSql||' and to_number(zzcj) <= to_number(' || scjsxtj || ')';
        end if;

        Execute Immediate sSql into icount;
        if icount > 0 then
          tj := 1;
        end if;

        if scjxxtj is null and scjsxtj is not null and icount <= 0 then ----当成绩小于时，如果学生没考过等级考试的也可以报名
          sSql    := 'select count(*) from Jw_Xmgl_Xmxsbmqkb t1,JW_XMGL_XMBMSZB t2 where t1.xmbmsz_id = t2.xmbmsz_id
          and t1.xh_id =''' ||vXh_id || ''' and t2.xmdm = ''' || sXmtj || '''';
          Execute Immediate sSql into icount;
          if icount <= 0 then
            tj := 1;
          end if;
        end if;

      end if;
    end if;
    Return to_char(tj);
end;

/

