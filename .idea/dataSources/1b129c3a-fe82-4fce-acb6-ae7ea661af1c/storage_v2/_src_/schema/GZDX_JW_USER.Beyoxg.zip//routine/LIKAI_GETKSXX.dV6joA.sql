create function likai_getksxx(v_ksrq   JW_KW_KSCCB.ksrq%TYPE, V_KSKSSJ JW_KW_KSCCB.KSKSSJ%TYPE,
                              V_KSJSSJ JW_KW_KSCCB.KSJSSJ%TYPE, V_CD_ID JW_JCDM_CDXQXXB.CD_ID%TYPE, V_SIGN VARCHAR2)
  RETURN
  VARCHAR2 IS
  lower_sign varchar2(255);
  V_RES VARCHAR2(2000);
  BEGIN
    lower_sign:=lower(v_sign);
    IF lower_sign='sjbh_id'
    THEN
      select
        wm_concat(t.sjbh_id) into v_res
--         t.kshkbj_id,
--         t.ksdd_id,
--         t.kch_id,
--         WM_CONCAT(t.jxbmc) jxbmc
      from
        (select distinct
           sjb.SJBH_ID
--            dzb.KSHKBJ_ID,
--            ddb.KSDD_ID,
--            jxb.KCH_ID,
--            jxb.jxbmc jxbmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.sjbh_id;
    END IF;
    if V_SIGN='kshkbj_id' then
      select
--        wm_concat(t.sjbh_id)
         wm_concat(t.kshkbj_id) into v_res
--         t.ksdd_id,
--         t.kch_id,
--         WM_CONCAT(t.jxbmc) jxbmc
      from
        (select distinct
           --sjb.SJBH_ID
            dzb.KSHKBJ_ID
--            ddb.KSDD_ID,
--            jxb.KCH_ID,
--            jxb.jxbmc jxbmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.kshkbj_id;
    end if;
    if V_SIGN='ksdd_id' then
      select
--        wm_concat(t.sjbh_id)
         --t.kshkbj_id) into v_res
         wm_concat(t.ksdd_id) into v_res
--         t.kch_id,
--         WM_CONCAT(t.jxbmc) jxbmc
      from
        (select distinct
           --sjb.SJBH_ID
            --dzb.KSHKBJ_ID
            ddb.KSDD_ID
--            jxb.KCH_ID,
--            jxb.jxbmc jxbmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.ksdd_id;
    end if;
    if V_SIGN='kch' then
      select
--        wm_concat(t.sjbh_id)
         --t.kshkbj_id) into v_res
--         wm_concat(t.ksdd_id) into v_res
         WM_CONCAT(t.kch) into V_RES
--         WM_CONCAT(t.jxbmc) jxbmc
      from
        (select distinct
           --sjb.SJBH_ID
            --dzb.KSHKBJ_ID
            --ddb.KSDD_ID
            kc.kcmc||'('||kc.kch||')' kch
--            jxb.jxbmc jxbmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb,jw_jh_kcdmb kc
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and jxb.kch_id=kc.kch_id
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.kch;
    end if;
    if V_SIGN='jxbmc' then
      select
--        wm_concat(t.sjbh_id)
         --t.kshkbj_id) into v_res
--         wm_concat(t.ksdd_id) into v_res
--         WM_CONCAT(t.kch_id) into V_RES
         WM_CONCAT(t.jxbmc) into v_res
      from
        (select distinct
           --sjb.SJBH_ID
            --dzb.KSHKBJ_ID
            --ddb.KSDD_ID
--            jxb.KCH_ID
            jxb.jxbmc jxbmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.jxbmc;
    end if;
        if V_SIGN='jkjgmc' then
      select
--        wm_concat(t.sjbh_id)
         --t.kshkbj_id) into v_res
--         wm_concat(t.ksdd_id) into v_res
--         WM_CONCAT(t.kch_id) into V_RES
         WM_CONCAT(t.jgmc) into v_res
      from
        (select distinct
           --sjb.SJBH_ID
            --dzb.KSHKBJ_ID
            --ddb.KSDD_ID
--            jxb.KCH_ID
            jg.jgmc
         from JW_KW_KSCCB ccb, JW_KW_KSSJB sjb, JW_KW_KSDDBJDZB dzb, JW_KW_KSDDB ddb, JW_JXRW_JXBXXB jxb,zftal_xtgl_jgdmb jg
         where ccb.XNM = sjb.XNM
               and ccb.XQM = sjb.XQM
               and ccb.KSMCDMB_ID = sjb.KSMCDMB_ID
               and ccb.KSCCB_ID = sjb.KSCCB_ID
               and sjb.SJBH_Id = dzb.SJBH_ID
               and sjb.XNM = dzb.XNM
               and sjb.xqm = dzb.XQM
               and dzb.XNM = ddb.XNM
               and dzb.XQM = ddb.XQM
               and dzb.KSHKBJ_ID = ddb.KSHKBJ_ID
               and dzb.JXB_ID = jxb.JXB_ID
               and ddb.jg_id=jg.jg_id(+)
               and ccb.KSRQ = nvl(v_ksrq, '2019-01-11') and ccb.KSKSSJ = nvl(v_kskssj, '14:00') and KSJSSJ = nvl(v_ksjssj, '16:00') and ddb.CD_ID = nvl(v_cd_id, '1011230')) t
      ;--group by t.jgmc;
    end if;
    return v_res;
  END;
/

