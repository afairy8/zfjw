create function get_xscjtjxx(
  vXnm   varchar2, --学年码
  vXqm   varchar2, --学期码
  vXh_id varchar2, --学号
  vYlxx1 varchar2, --预留信息1
  vYlxx2 varchar2, --预留信息2
  vYlxx3 varchar2, --预留信息3
  vYlxx4 varchar2, --预留信息4
  vBj    varchar2
)
  return varchar2 is
  hdxfzb varchar2(100);
  sJgxx  varchar2(500);
  sXnm   varchar2(10);
  sXqm   varchar2(10);
  begin
    begin
      if vBj = 'zhcjhdxf_dxq'
      then ---最后成绩获得学分(单学期)

        select xnm, xqm into sXnm, sXqm from jw_cj_xyyjtjfwb where xyyjtjsz_id = vYlxx1;

        select (case
                  when sum(xf) > 0 then to_char(round(sum(hdxf) / sum(xf), 2) * 100, '9990.99')
                  else '0' end) into hdxfzb
        from (select a.xnm,
                     a.xqm,
                     a.XH_ID,
                     a.sskch_id,
                     a.KCH_ID,
                     a.CJ,
                     a.BFZCJ,
                     a.JD,
                     a.cjbz,
                     a.xf,
                     (case when nvl(bfzcj, 0) >= 60 then xf else '0' end)                                                              hdxf,
                     row_number() over (partition by a.xh_id, nvl(a.sskch_id, a.kch_id) order by a.xnm || lpad(a.xqm, 2,
                                                                                                               '0') desc, a.czsj desc) rn
              from jw_cj_xscjb a
              where a.xh_id = vXh_id)
        where rn = 1
          and xnm = sXnm
          and xqm = sXqm
        group by xh_id;
        return hdxfzb;
      end if;

      if vBj = 'zhcjpjxfjd'
      then ---最后成绩平均学分绩点
        select case
                 when nvl(sum(xf), 0) = 0 then null
                 else to_char(sum(fn_jdjs(xnm, xqm, sskch_id, kch_id, null, jxb_id, xh_id, kcxzdm, kclbdm, cjxzm, kcbj,
                                          null, cjbz, jd, bfzcj, 'cjb', 'tj', '0') * xf)
                                / sum(xf), '990.99') end into sJgxx
        from (select xnm, xqm, xh_id, sskch_id, kch_id, jxb_id, kcxzdm, kclbdm, cjxzm, kcbj, cj, bfzcj, jd, cjbz, xf
              from (select a.xnm,
                           a.xqm,
                           a.XH_ID,
                           a.sskch_id,
                           a.KCH_ID,
                           a.jxb_id,
                           a.kcxzdm,
                           a.kclbdm,
                           a.cjxzm,
                           a.kcbj,
                           a.CJ,
                           a.BFZCJ,
                           case when a.kcxzdm in ('01', '02') then a.JD else null end as jd,
                           a.cjbz,
                           case when a.kcxzdm in ('01', '02') then a.xf else null end as xf,
                           row_number() over (partition by a.xh_id, nvl(a.sskch_id, a.kch_id) order by a.xnm ||
                                                                                                       lpad(a.xqm, 2,
                                                                                                            '0') desc, a.czsj desc) rn
                    from jw_cj_xscjb a
                    where a.xh_id = vXh_id
                      and not exists(select 'X'
                                     from jw_cj_xsgrjhdtb jhdtb
                                     where jhdtb.zszt = '3'
                                       and a.xh_id = jhdtb.xh_id
                                       and a.kch_id = jhdtb.kch_id
                                         union all
                                         select 'X'
                                         from jw_cj_xsgrcjdtb cjdtb
                                         where cjdtb.zszt = '3'
                                           and a.xh_id = cjdtb.xh_id
                                           and a.kch_id = cjdtb.kch_id
                                           and cjdtb.kcthzbm = 'xnkc'
                        ))
              where rn = 1

              union all ----校内被替代课程
              select rdmxb.xnm,
                     rdmxb.xqm,
                     b.xh_id,
                     null                                                               as sskch_id,
                     rdmxb.kch_id,
                     null                                                               as jxb_id,
                     rdmxb.kcxzdm,
                     rdmxb.kclbdm,
                     '01',
                     '0',
                     rdmxb.cj,
                     rdmxb.bfzcj,
                     case when rdmxb.kcxzdm in ('01', '02') then rdmxb.jd else null end as jd,
                     null                                                               as cjbz,
                     case when rdmxb.kcxzdm in ('01', '02') then  to_char(rdmxb.xf) else null end as xf
              from Jw_Cj_Xsgrjhdtb rdmxb,
                   jw_jh_kcdmb kc,
                   jw_xjgl_xsjbxxb b
              where rdmxb.zszt = '3'
                and rdmxb.xh_id = b.xh_id
                and rdmxb.kch_id = kc.kch_id
                and b.xh_id = vXh_id
              union all ---被认定校内课程
              select rdmxb.xnm,
                     rdmxb.xqm,
                     b.xh_id,
                     null                                                               as sskch_id,
                     rdmxb.kch_id,
                     null                                                               as jxb_id,
                     rdmxb.kcxzdm,
                     rdmxb.kclbdm,
                     '01',
                     '0',
                     rdmxb.cj,
                     rdmxb.bfzcj,
                     case when rdmxb.kcxzdm in ('01', '02') then rdmxb.jd else null end as jd,
                     null                                                               as cjbz,
                     case when rdmxb.kcxzdm in ('01', '02') then  to_char(rdmxb.xf) else null end as xf
              from jw_cj_xfrdb rdb,
                   jw_cj_xfrdmxb rdmxb,
                   jw_xjgl_xsjbxxb b
              where rdb.xrdz_id = rdmxb.rdz_id
                and rdb.xh_id = b.xh_id
                and b.xh_id = vXh_id
                and rdb.rdlybj = '0'
                and rdb.shjg = '3')
        group by xh_id;
        return sJgxx;
      end if;


      if vBj = 'zhcjbjgmc'
      then ---最后成绩不及格门次
        select count(1) into sJgxx
        from (select xnm, xqm, xh_id, sskch_id, kch_id, jxb_id, kcxzdm, kclbdm, cjxzm, kcbj, cj, bfzcj, jd, cjbz, xf
              from (select a.xnm,
                           a.xqm,
                           a.XH_ID,
                           a.sskch_id,
                           a.KCH_ID,
                           a.jxb_id,
                           a.kcxzdm,
                           a.kclbdm,
                           a.cjxzm,
                           a.kcbj,
                           a.CJ,
                           a.BFZCJ,
                           case when a.kcxzdm in ('01', '02') then a.JD else null end as jd,
                           a.cjbz,
                           case when a.kcxzdm in ('01', '02') then a.xf else null end as xf,
                           row_number() over (partition by a.xh_id, nvl(a.sskch_id, a.kch_id) order by a.xnm ||
                                                                                                       lpad(a.xqm, 2,
                                                                                                            '0') desc, a.czsj desc) rn
                    from jw_cj_xscjb a
                    where a.xh_id = vXh_id
                      and not exists(select 'X'
                                     from jw_cj_xsgrjhdtb jhdtb
                                     where jhdtb.zszt = '3'
                                       and a.xh_id = jhdtb.xh_id
                                       and a.kch_id = jhdtb.kch_id
                                         union all
                                         select 'X'
                                         from jw_cj_xsgrcjdtb cjdtb
                                         where cjdtb.zszt = '3'
                                           and a.xh_id = cjdtb.xh_id
                                           and a.kch_id = cjdtb.kch_id
                                           and cjdtb.kcthzbm = 'xnkc'
                        ))
              where rn = 1

              union all ----校内被替代课程
              select rdmxb.xnm,
                     rdmxb.xqm,
                     b.xh_id,
                     null                                                               as sskch_id,
                     rdmxb.kch_id,
                     null                                                               as jxb_id,
                     rdmxb.kcxzdm,
                     rdmxb.kclbdm,
                     '01',
                     '0',
                     rdmxb.cj,
                     rdmxb.bfzcj,
                     case when rdmxb.kcxzdm in ('01', '02') then rdmxb.jd else null end as jd,
                     null                                                               as cjbz,
                     case when rdmxb.kcxzdm in ('01', '02') then to_char(rdmxb.xf) else null end as xf
              from Jw_Cj_Xsgrjhdtb rdmxb,
                   jw_jh_kcdmb kc,
                   jw_xjgl_xsjbxxb b
              where rdmxb.zszt = '3'
                and rdmxb.xh_id = b.xh_id
                and rdmxb.kch_id = kc.kch_id
                and b.xh_id = vXh_id
              union all ---被认定校内课程
              select rdmxb.xnm,
                     rdmxb.xqm,
                     b.xh_id,
                     null                                                               as sskch_id,
                     rdmxb.kch_id,
                     null                                                               as jxb_id,
                     rdmxb.kcxzdm,
                     rdmxb.kclbdm,
                     '01',
                     '0',
                     rdmxb.cj,
                     rdmxb.bfzcj,
                     case when rdmxb.kcxzdm in ('01', '02') then rdmxb.jd else null end as jd,
                     null                                                               as cjbz,
                     case when rdmxb.kcxzdm in ('01', '02') then to_char(rdmxb.xf) else null end as xf
              from jw_cj_xfrdb rdb,
                   jw_cj_xfrdmxb rdmxb,
                   jw_xjgl_xsjbxxb b
              where rdb.xrdz_id = rdmxb.rdz_id
                and rdb.xh_id = b.xh_id
                and b.xh_id = vXh_id
                and rdb.rdlybj = '0'
                and rdb.shjg = '3')
                where bfzcj<60
        group by xh_id;
        return sJgxx;
      end if;

      exception
      When others
      then
        return null;
    end;
    null;
end get_xscjtjxx;

/

