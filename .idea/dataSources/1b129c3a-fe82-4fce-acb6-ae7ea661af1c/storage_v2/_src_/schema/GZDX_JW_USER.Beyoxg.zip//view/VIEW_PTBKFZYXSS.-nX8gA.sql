create view VIEW_PTBKFZYXSS as
  select (select a.xkmc
            from zftal_xtgl_xxzydmb a,
                 jw_jh_dlzydzb      b,
                 zftal_xtgl_njdmb   c
           where a.zydm = b.xxzydm
             and a.pcdm = c.njdm
             and b.njdm_id = c.njdm_id
             and c.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and b.zyh_id = zy.zyh_id) as xk,
         (select a.zymc
            from zftal_xtgl_zydmb a,
                 jw_jh_dlzydzb    b,
                 zftal_xtgl_njdmb c
           where a.sfty = '0'
             and a.dlbs = 'dl'
             and a.zyh = b.dldm
             and b.njdm_id = c.njdm_id
             and c.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and b.zyh_id = zy.zyh_id) as zyfl,
         (select a.zymc
            from zftal_xtgl_xxzydmb a,
                 jw_jh_dlzydzb      b,
                 zftal_xtgl_njdmb   c
           where a.zydm = b.xxzydm
             and a.pcdm = c.njdm
             and b.njdm_id = c.njdm_id
             and c.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and b.zyh_id = zy.zyh_id) as zymc,
         (select zymc from zftal_xtgl_zydmb where zyh_id = zy.zyh_id) as zzzymc,
         (select a.zydm
            from zftal_xtgl_xxzydmb a,
                 jw_jh_dlzydzb      b,
                 zftal_xtgl_njdmb   c
           where a.zydm = b.xxzydm
             and a.pcdm = c.njdm
             and b.njdm_id = c.njdm_id
             and c.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and b.zyh_id = zy.zyh_id) as zydm,
         (select sfsf from zftal_xtgl_zydmb where zyh_id=zy.zyh_id) as sfsfzy,--是否师范专业
         (select xz from zftal_xtgl_zydmb where zyh_id = zy.zyh_id) as nz,
         zy.zyh_id,
         nvl(bys.rs, 0) as bys,
         nvl(bys.grs, 0) as gbys,
         nvl(bys.gzqd, 0) as gzqdbys,
         nvl(syxws.rs, 0) as syxws,
         nvl(syxws.grs, 0) as gsyxws,
         nvl(syxws.gzqd, 0) as gzqdsyxws,
         nvl(t1.rs, 0) as zszrs,
         nvl(t1.grs, 0) as gzszrs,
         nvl(t1.gzqd, 0) as gzqdzszrs,
         nvl(t3.rs, 0) as yjbys,
         nvl(t3.grs, 0) as gyjbys,
         nvl(t3.gzqd, 0) as gzqdyjbys,
         nvl(t2.rs, 0) as cjzs,
         nvl(t2.grs, 0) as gcjzs,
         nvl(t2.gzqd, 0) as gzqdcjzs,
         nvl(t4.rs, 0) as yks,
         nvl(t4.grs, 0) as gyks,
         nvl(t4.gzqd, 0) as gzqdyks,
         nvl(a.rs, 0) + nvl(b.rs, 0) + nvl(c.rs, 0) + nvl(d.rs, 0) as zxzrs,
         nvl(a.grs, 0) + nvl(b.grs, 0) + nvl(c.grs, 0) +
         nvl(d.grs, 0) as gzxzrs,
         nvl(a.gzqd, 0) + nvl(b.gzqd, 0) + nvl(c.gzqd, 0) +
         nvl(d.gzqd, 0) as gzqdzxzrs,
         nvl(a.rs, 0) as nj1rs,
         nvl(a.grs, 0) as nj1grs,
         nvl(a.gzqd, 0) as nj1gzqdrs,
         nvl(b.rs, 0) as nj2rs,
         nvl(b.grs, 0) as nj2grs,
         nvl(b.gzqd, 0) as nj2gzqdrs,
         nvl(c.rs, 0) as nj3rs,
         nvl(c.grs, 0) as nj3grs,
         nvl(c.gzqd, 0) as nj3gzqdrs,
         nvl(d.rs, 0) as nj4rs,
         nvl(d.grs, 0) as nj4grs,
         nvl(d.gzqd, 0) as nj4gzqdrs,
         nvl(f.rs, 0) as nj5rs,
         nvl(f.grs, 0) as nj5grs,
         nvl(f.gzqd, 0) as nj5gzqdrs,
         nvl(e.rs, 0) as yjbyss,
         nvl(e.grs, 0) as gyjbyss,
         nvl(e.gzqd, 0) as gzqdyjbyss
          from (
          --毕业生数
          select count(a.xh_id) as rs,
                  zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.xh_id in
                          (select xh_id from jw_bygl_bysfzxxb)
                      and t1.pyccdm = '3'
                      and t1.njdm_id = t2.njdm_id
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND') - 1
                      and t1.xbm = '2'
                      and t1.zyh_id = a.zyh_id) as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.xh_id in
                          (select xh_id from jw_bygl_bysfzxxb)
                      and t1.pyccdm = '3'
                      and t1.njdm_id = t2.njdm_id
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND') - 1
                      and t1.kslbm = '1'
                      and t1.zyh_id = a.zyh_id) as gzqd
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.xh_id in (select xh_id from jw_bygl_bysfzxxb)
             and a.pyccdm = '3'
             and a.njdm_id = b.njdm_id
             and b.njdm + a.xz =
                 (select zdz
                    from zftal_xtgl_xtszb
                   where xtsz_id = 'DQND') - 1
           group by a.zyh_id) bys,
         (
  --授予学位数
          select count(a.xh_id) as rs,
                  zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.xh_id in
                          (select xh_id from jw_bygl_bysfzxxb)
                      and t1.pyccdm = '3'
                      and t1.njdm_id = t2.njdm_id
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND') - 1
                      and t1.xbm = '2'
                      and t1.zyh_id = a.zyh_id) as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.xh_id in (select xh_id
                                         from jw_bygl_bysfzxxb
                                        where ywxw = '有')
                      and t1.pyccdm = '3'
                      and t1.njdm_id = t2.njdm_id
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND') - 1
                      and t1.kslbm = '1'
                      and t1.zyh_id = a.zyh_id) as gzqd
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.xh_id in
                 (select xh_id from jw_bygl_bysfzxxb where ywxw = '有')
             and a.pyccdm = '3'
             and a.njdm_id = b.njdm_id
             and b.njdm + a.xz =
                 (select zdz
                    from zftal_xtgl_xtszb
                   where xtsz_id = 'DQND') - 1
           group by a.zyh_id) syxws,
         (
          --招生总人数
          select count(a.xh_id) rs,
                  a.zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where xbm = '2'
                      and zyh_id = a.zyh_id
                      and pyccdm = '3'
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春')))) as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where kslbm = '1'
                      and zyh_id = a.zyh_id
                      and pyccdm = '3'
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春')))) as gzqd
            from jw_xjgl_xsxjxxb a
           where a.xnm = (select zdz
                            from zftal_xtgl_xtszb
                           where xtsz_id = 'DQND')
             and ((a.xqm = '3' and a.zsjd = '秋') or
                 (a.xqm = '12' and a.zsjd = '春'))
             and a.pyccdm = '3'
             and a.zyh_id is not null
           group by a.zyh_id) t1,
         (
          --春季招生人数
          select count(a.xh_id) rs,
                  a.zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where xbm = '2'
                      and zyh_id = a.zyh_id
                      and pyccdm = '3'
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and xqm = '3'
                              and zsjd = '秋')) as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where kslbm = '1'
                      and zyh_id = a.zyh_id
                      and pyccdm = '3'
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and xqm = '3'
                              and zsjd = '秋')) as gzqd
            from jw_xjgl_xsxjxxb a
           where a.xnm = (select zdz
                            from zftal_xtgl_xtszb
                           where xtsz_id = 'DQND')
             and a.xqm = '3'
             and a.zsjd = '秋'
             and a.pyccdm = '3'
             and a.zyh_id is not null
           group by a.zyh_id) t2,
         (
          --应届毕业生
          select count(a.xh_id) rs,
                  a.zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春')))
                      and lym in ('101', '102')
                      and pyccdm = '3'
                      and zyh_id = a.zyh_id
                      and xbm = '2') as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春')))
                      and lym in ('101', '102')
                      and pyccdm = '3'
                      and zyh_id = a.zyh_id
                      and kslbm = '1') as gzqd
            from jw_xjgl_xsxjxxb a, jw_xjgl_xsjbxxb b
           where a.xh_id = b.xh_id
             and ((a.xqm = '3' and a.zsjd = '秋') or
                 (a.xqm = '12' and a.zsjd = '春'))
             and a.xnm = (select zdz
                            from zftal_xtgl_xtszb
                           where xtsz_id = 'DQND')
             and b.lym in ('101', '102')
             and b.pyccdm = '3'
           group by a.zyh_id
          /*
          select count(a.xh_id) rs,a.zyh_id,(select count(distinct t1.xh_id) from jw_xjgl_xsjbxxb t1,jw_xjgl_xsxjxxb t2 where t1.xh_id=t2.xh_id and t1.zyh_id=a.zyh_id and t1.xh_id in (select xh_id from jw_xjgl_xsxjxxb where xnm=(select zdz from zftal_xtgl_xtszb where xtsz_id='DQND')
          and ((xqm='3' and zsjd='秋') or (xqm='12' and zsjd='春'))) and t1.xbm='2' and t1.lym in ('101','102')) as grs from jw_xjgl_xsxjxxb a,jw_xjgl_xsjbxxb b where a.xh_id=b.xh_id and ((a.xqm='3' and a.zsjd='秋') or (a.xqm='12' and a.zsjd='春')) and
          a.xnm=(select zdz from zftal_xtgl_xtszb where xtsz_id='DQND') and b.lym in ('101','102') group by a.zyh_id */
          ) t3,
         (
          --预科生转入
          select count(a.xh_id) rs,
                  a.zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where xbm = '2'
                      and zyh_id = a.zyh_id
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春'))
                              and xslbdm = '452')
                      and xbm = '2'
                      and pyccdm = '3') as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb
                    where kslbm = '1'
                      and zyh_id = a.zyh_id
                      and xh_id in
                          (select xh_id
                             from jw_xjgl_xsxjxxb
                            where xnm = (select zdz
                                           from zftal_xtgl_xtszb
                                          where xtsz_id = 'DQND')
                              and ((xqm = '3' and zsjd = '秋') or
                                  (xqm = '12' and zsjd = '春'))
                              and xslbdm = '452')
                      and xbm = '2'
                      and pyccdm = '3') as gzqd
            from jw_xjgl_xsxjxxb a
           where a.xnm = (select zdz
                            from zftal_xtgl_xtszb
                           where xtsz_id = 'DQND')
             and ((a.xqm = '3' and a.zsjd = '秋') or
                 (a.xqm = '12' and a.zsjd = '春'))
             and a.xslbdm = '452'
             and a.pyccdm = '3'
             and a.njdm_id = (select zdz
                                from zftal_xtgl_xtszb
                               where xtsz_id = 'DQND')
           group by a.zyh_id) t4,
         (
          --一年级
          select count(a.xh_id) rs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and xbm = '2'
                      and sfzx = '1'
                      and pyccdm = '3') as grs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and kslbm = '1'
                      and sfzx = '1'
                      and pyccdm = '3') as gzqd,
                  a.zyh_id
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.njdm_id = b.njdm_id
             and a.pyccdm = '3'
             and zyh_id is not null
             and b.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and sfzx = '1'
           group by a.zyh_id, a.njdm_id) a,
         (
          --二年级
          select count(a.xh_id) rs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and xbm = '2'
                      and sfzx = '1'
                      and pyccdm = '3') as grs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and kslbm = '1'
                      and sfzx = '1'
                      and pyccdm = '3') as gzqd,
                  a.zyh_id
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.njdm_id = b.njdm_id
             and a.pyccdm = '3'
             and zyh_id is not null
             and b.njdm + 1 = (select zdz
                                 from zftal_xtgl_xtszb
                                where xtsz_id = 'DQND')
             and sfzx = '1'
           group by a.zyh_id, a.njdm_id) b,
         (
          --三年级
          select count(a.xh_id) rs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and xbm = '2'
                      and sfzx = '1'
                      and pyccdm = '3') as grs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and kslbm = '1'
                      and sfzx = '1'
                      and pyccdm = '3') as gzqd,
                  a.zyh_id
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.njdm_id = b.njdm_id
             and a.pyccdm = '3'
             and zyh_id is not null
             and b.njdm + 2 = (select zdz
                                 from zftal_xtgl_xtszb
                                where xtsz_id = 'DQND')
             and sfzx = '1'
           group by a.zyh_id, a.njdm_id) c,
         (
          --四年级
          select count(a.xh_id) rs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and xbm = '2'
                      and sfzx = '1'
                      and pyccdm = '3') as grs,
                  (select count(xh_id)
                     from jw_xjgl_xsjbxxb
                    where zyh_id = a.zyh_id
                      and njdm_id = a.njdm_id
                      and kslbm = '1'
                      and sfzx = '1'
                      and pyccdm = '3') as gzqd,
                  a.zyh_id
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.njdm_id = b.njdm_id
             and a.pyccdm = '3'
             and zyh_id is not null
             and b.njdm + 3 = (select zdz
                                 from zftal_xtgl_xtszb
                                where xtsz_id = 'DQND')
             and sfzx = '1'
           group by a.zyh_id, a.njdm_id) d,
         (
          --五年级及以后
          select sum(rs) as rs,
                  sum(grs) as grs,
                  sum(gzqd) as gzqd,
                  zyh_id
            from (select count(a.xh_id) rs,
                          (select count(xh_id)
                             from jw_xjgl_xsjbxxb
                            where zyh_id = a.zyh_id
                              and njdm_id = a.njdm_id
                              and xbm = '2'
                              and sfzx = '1'
                              and pyccdm = '3') as grs,
                          (select count(xh_id)
                             from jw_xjgl_xsjbxxb
                            where zyh_id = a.zyh_id
                              and njdm_id = a.njdm_id
                              and kslbm = '1'
                              and sfzx = '1'
                              and pyccdm = '3') as gzqd,
                          a.zyh_id
                     from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
                    where a.njdm_id = b.njdm_id
                      and a.pyccdm = '3'
                      and zyh_id is not null
                      and b.njdm + 4 <=
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
                      and sfzx = '1'
                    group by a.zyh_id, a.njdm_id)
           group by zyh_id) f,
         (
          --预计毕业生数
          select count(a.xh_id) as rs,
                  zyh_id,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.njdm_id = t2.njdm_id
                      and t1.pyccdm = '3'
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
                      and t1.xbm = '2'
                      and t1.zyh_id = a.zyh_id) as grs,
                  (select count(*)
                     from jw_xjgl_xsjbxxb t1, zftal_xtgl_njdmb t2
                    where t1.njdm_id = t2.njdm_id
                      and t1.pyccdm = '3'
                      and t2.njdm + t1.xz =
                          (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
                      and t1.kslbm = '1'
                      and t1.zyh_id = a.zyh_id) as gzqd
            from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b
           where a.njdm_id = b.njdm_id
             and a.pyccdm = '3'
             and b.njdm + a.xz =
                 (select zdz
                    from zftal_xtgl_xtszb
                   where xtsz_id = 'DQND')
           group by a.zyh_id) e,
         zftal_xtgl_zydmb zy
         where zy.zyh_id = bys.zyh_id(+)
           and zy.zyh_id = syxws.zyh_id(+)
           and zy.zyh_id = t1.zyh_id(+)
           and zy.zyh_id = t2.zyh_id(+)
           and zy.zyh_id = t3.zyh_id(+)
           and zy.zyh_id = t4.zyh_id(+)
           and zy.zyh_id = a.zyh_id(+)
           and zy.zyh_id = b.zyh_id(+)
           and zy.zyh_id = c.zyh_id(+)
           and zy.zyh_id = d.zyh_id(+)
           and zy.zyh_id = e.zyh_id(+)
           and zy.zyh_id = f.zyh_id(+)

/

