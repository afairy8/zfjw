create function Get_JxbJsxx(vJxb_id varchar2, vBj varchar2)
  return varchar2 ---教学班教师信息----
as
  sJsxx varchar2(2000); ---教师信息
  begin
    sJsxx := '无';
    begin
      if vBj = '0'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.jgh || '/' || b.xm || '/' || nvl(b.zcmc, '无') jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;
      if vBj = '1'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.xm as jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;
      if vBj = '2'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.jgh || '/' || b.xm as jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;

      if vBj = '3'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.jgh || '/' || b.xm || '/' || nvl(b.zcmc, '无') || '[' ||
                     nvl((select jg.jgmc from zftal_xtgl_jgdmb jg where jg.jg_id = b.jg_id), '无') || ']' jsxx,
                     a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;
      if vBj = '4'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.xm || '/' || nvl(b.zcmc, '无') jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;

      if vBj = '5'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.xm || '/' || nvl(b.zcmc, '无') jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
                and nvl(a.sfjxrllrjs, a.sfcjlrjs) = '1'
              order by a.sfcjlrjs desc);
      end if;
      if vBj = '6'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.jgh || '/' || b.xm || '[第' || get_jcbinarydesc(a.qsjsz, '') || '周]' as jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;

      if vBj = 'jgh'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select wm_concat(jsxx) into sJsxx
        from (select b.jgh jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;

      if vBj = 'jsxm'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select wm_concat(jsxx) into sJsxx
        from (select b.xm jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;
      if vBj = 'jszc'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select wm_concat(jsxx) into sJsxx
        from (select nvl(b.zcmc, '无') jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);
      end if;
      if vBj = 'jsbm'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select wm_concat(jsxx) into sJsxx
        from (select nvl((select jg.jgmc from zftal_xtgl_jgdmb jg where jg.jg_id = b.jg_id), '无') jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and a.jxb_id = vJxb_id
              order by a.sfcjlrjs desc);


      end if;
      if substr(vBJ, 1, instr(vBj, ':', 1, 1) - 1) = 'sfzj'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.xm jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b,
                   jw_jxrw_jxbxxb c
              where a.jgh_id = b.jgh_id
                and a.JXB_ID = c.JXB_ID
                and a.jxb_id = vJxb_id
                and a.sfzj = substr(vBJ, instr(vBj, ':', 1, 1) + 1, 100)
              order by b.xm  );

      end if;

      if vBj = '7'
      then
        --dbms_output.put_line('vJxb_id:'||vJxb_id);
        select replace(wm_concat(jsxx), ',', ';') into sJsxx
        from (select b.xm jsxx, a.sfcjlrjs
              from jw_jxrw_jxbjsrkb a,
                   jw_jg_jzgxxb b,
                   jw_jxrw_jxbxxb c
              where a.jgh_id = b.jgh_id
                and a.JXB_ID = c.JXB_ID
                and a.jxb_id = vJxb_id
              order by b.xm  );

      end if;

      if sJsxx is null
      then
        sJsxx := '无';
      end if;
      exception
      When others
      then
        sJsxx := '无';
    end;
    return sJsxx;
end Get_JxbJsxx;

/

