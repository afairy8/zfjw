create function fn_getJxbQszZzz(vJxb_id varchar2,vBj varchar2) return varchar2/**---返回教学班课表周次信息**/
 as
  sZcxx        varchar2(32); /**---返回的周次信息**/
begin
  sZcxx := '';
  begin
    if vBj='0' then   /**---返回最小周次**/
       select round(log(2,min(a.num)*2)) into sZcxx from (select power(2,rownum-1) num from zftal_xtgl_jcsjb where rownum<=60) a,jw_pk_kbsjb b
       where b.jxb_id=vJxb_id and bitand(a.num,b.zcd)>0;
    elsif vBj='1' then  /**---返回最大周次**/
       select round(log(2,max(a.num)*2)) into sZcxx from (select power(2,rownum-1) num from zftal_xtgl_jcsjb where rownum<=60) a,jw_pk_kbsjb b
       where b.jxb_id=vJxb_id and bitand(a.num,b.zcd)>0;
    end if;
  exception
    When others then
      sZcxx := '';
  end;
  return sZcxx;
end fn_getJxbQszZzz;

/

