create function get_byxx(vXh_id varchar2,vTab varchar2,vZdz varchar2,vBj varchar2) return varchar2  ---班级组合----
as
   sSql varchar2(2000);
   sZdz varchar2(200);
begin
  if vBj = '0' then
  -- sSql := 'select * from '||vTab||' where xh_id = '''||vXh_id||''' order by bynd desc';
  -- sSql := 'select '||vZdz||' from ('||sSql||') where rownum =1';
   --dbms_output.put_line('sSql:'||sSql);
  -- Execute Immediate sSql into sZdz;
  if lower(vTab) = 'jw_bygl_byshb' then
    select xxsh into sZdz from (select t.*,row_number() over(partition by 1 order by bynd desc) rn from jw_bygl_byshb t where xh_id = vXh_id ) where rn =1 ;
  end if;
   if lower(vTab) = 'jw_bygl_xwshb' then
    select xxsh into sZdz from (select t.*,row_number() over(partition by 1 order by bynd desc) rn from jw_bygl_xwshb t where xh_id = vXh_id ) where rn =1 ;
  end if;
   if lower(vTab) = 'jw_bygl_fxshb' then
    select xxsh into sZdz from (select t.*,row_number() over(partition by 1 order by bynd desc) rn from jw_bygl_fxshb t where xh_id = vXh_id ) where rn =1 ;
  end if;
   if lower(vTab) = 'jw_bygl_fxxwshb' then
    select xxsh into sZdz from (select t.*,row_number() over(partition by 1 order by bynd desc) rn from jw_bygl_fxxwshb t where xh_id = vXh_id ) where rn =1 ;
  end if;
   return sZdz;
  end if;
   null;
end;

/

