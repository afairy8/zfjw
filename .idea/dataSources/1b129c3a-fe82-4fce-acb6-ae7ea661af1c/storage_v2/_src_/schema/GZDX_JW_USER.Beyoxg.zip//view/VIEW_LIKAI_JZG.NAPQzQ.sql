create view VIEW_LIKAI_JZG as
  select
t.jgh_id,t.jgh,t.xm,t.xb,t.csrq,
case when t.DQZT in ('101','1') then '1' else '0' end dqzt,
(select zcm from JW_JG_ZYJSZCB zc where zc.zcmc=t.ZCMC )zcm,(select zcmc from JW_JG_ZYJSZCB zc where zc.zcmc=t.ZCMC ) zcmc,jg.JG_ID
from likai_sjtb_jzgxxb t,zftal_xtgl_jgdmb jg
where jg.jgdm=t.jgdm
/

