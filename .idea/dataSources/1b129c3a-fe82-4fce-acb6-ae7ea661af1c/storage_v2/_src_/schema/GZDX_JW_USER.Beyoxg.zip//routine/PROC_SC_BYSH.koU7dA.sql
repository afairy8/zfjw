create PROCEDURE PROC_SC_BYSH(
       V_BYND in VARCHAR2,
       V_NJDM_ID in VARCHAR2,
       V_ZYH_ID in VARCHAR2,
    --   V_TJ_ID  in VARCHAR2,
       V_TJSY in VARCHAR2,
       V_XH_ID in VARCHAR2
)
IS
   --定义审核结果数组
  type  arr_tj_type is varray(20) of varchar2(2);
  tj_table arr_tj_type;
   --定义原因数组
  type  arr_result_type is varray(20) of varchar2(4000);
  result_table arr_result_type;

   --定义条件id
  type  arr_tjid_type is varray(20) of varchar2(50);
  tjid_table arr_tjid_type;

  --定义关系
  type v_table is table of number;
  my_table v_table;
  --定义二维数组
   type tRecordTest is record (tjjg varchar2(2),tjgx varchar2(2));
   type tTableTest is table of tRecordTest index by varchar2(2);
   TableTest tTableTest;
   --游标类型
  --TYPE xsjbxx_cursor_type IS REF CURSOR;
  TYPE byshtj_cursor_type IS REF CURSOR;
  --游标变量
  --xsjbxx_cursor xsjbxx_cursor_type;
  byshtj_cursor byshtj_cursor_type;
    --审核条件
  TYPE byshtj_record_type IS RECORD(
    tjzd      int,
    tjmc      jw_bygl_shtjb.tjmc%TYPE,
    tj_id     jw_bygl_shtjb.tj_id%TYPE,
    tjsy      jw_bygl_shtjsjsyb.tjsy%TYPE,
    tjxz      jw_bygl_shtjsjsyb.tjxz%TYPE,
    tjsjz     jw_bygl_shtjsjb.tjsjz%TYPE,
    tjsjcs    jw_bygl_shtjsjb.tjsjcs%TYPE,
    tjsj_id   jw_bygl_shtjsjsyb.tjsjsy_id%TYPE,
    tjsjly    jw_bygl_shtjsjb.tjsjly%TYPE,
    tjsjgx    jw_bygl_shtjsjb.tjsjgx%TYPE,
    tjsjmc    jw_bygl_shtjsjb.tjsjmc%TYPE,
    tjsjlymc  jw_bygl_shtjsjb.tjsjlymc%TYPE,
    jxzxjhxx_id jw_bygl_shtjsjsyzyb.jxzxjhxx_id%TYPE,
    tjpx      jw_bygl_shtjsjb.tjpx%TYPE,
    tjgx      jw_bygl_shtjsjsyzyb.tjgx%TYPE,
    tjsjz1    jw_bygl_shtjsjb.tjsjz1%TYPE,
    tjsjgx1   jw_bygl_shtjsjb.tjsjgx1%TYPE,
    tjkcxz   jw_bygl_shtjsjsyzyb.tjkcxz%TYPE,
    btjkc   jw_bygl_shtjsjsyzyb.btjkc%TYPE,
    xdlx   jw_bygl_shtjsjsyzyb.xdlx%TYPE
    );
  --RECORD变量
  byshtj_record byshtj_record_type;
  --动态SQL语句
  v_sql VARCHAR2(2000);
  --xs_sql VARCHAR2(2000);
  v_result  varchar2(3000);
  V_FLAG VARCHAR2(1);
  V_NUMBER NUMBER;
  v_result_one varchar2(3000);
  v_result_two varchar2(3000);

BEGIN

     tj_table:=arr_tj_type('0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
     result_table:=arr_result_type('','','','','','','','','','','','','','','','','','','','');
     tjid_table:=arr_tjid_type('','','','','','','','','','','','','','','','','','','','');
     my_table:=v_table(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
     --tjgx_table:=arr_tjgx_type('','','','','','','','','','','','','','','','','','','','');
     /*查询出审核条件*/
     v_sql:='select a.tjzd, a.tjmc,b.* from (select rownum tjzd,t.* from (select  b.tj_id,b.tjmc from jw_bygl_shtjb b where b.tjlx=''2'' and exists (select 1 from jw_bygl_shtjsjb a, jw_bygl_shtjsjsyb c  where b.tj_id = a.tj_id  and a.tjsj_id = c.tjsj_id  and c.tjsy =  '''||V_TJSY||''') order by to_number(b.tjpx),b.tj_id )t) a, ';
     v_sql:=v_sql||' (select t.tj_id,t1.tjsy,t1.tjxz,t1.tjsjz,t2.tjsjcs,t2.tjsj_id, t2.tjsjly,t2.tjsjgx,t2.tjsjmc,t2.tjsjlymc,t1.jxzxjhxx_id,t2.tjpx,t1.tjgx,t1.tjsjz1,t2.tjsjgx1,t1.tjkcxz,t1.btjkc,t1.xdlx ';
     v_sql:=v_sql||' from jw_bygl_shtjb  t,jw_bygl_shtjsjsyzyb t1, jw_bygl_shtjsjb t2,  jw_bygl_shtjsjsyb t3';
     v_sql:=v_sql||' where t1.tjsjsy_id = t3.tjsjsy_id  and t3.tjsj_id = t2.tjsj_id  and t2.tj_id = t.tj_id and t.tjlx=''2'' ';
     v_sql:=v_sql||' and t1.tjsy = '''||V_TJSY||'''';
     v_sql:=v_sql||' and exists (select 1 from jw_jh_jxzxjhxxb jh where jh.jxzxjhxx_id = t1.jxzxjhxx_id';
     v_sql:=v_sql||' and jh.njdm_id = '''||V_NJDM_ID||''' and jh.zyh_id = '''||V_ZYH_ID||''')';
     --v_sql:=v_sql||' and instr('''||V_TJ_ID||''', t.tj_id  )> 0
     v_sql:=v_sql||' )b';
     v_sql:=v_sql||' where a.tj_id = b.tj_id(+) order by tjzd';

     V_FLAG :='';

     /*审核条件*/
     OPEN byshtj_cursor FOR v_sql;
     LOOP
            FETCH byshtj_cursor INTO byshtj_record;
            EXIT WHEN byshtj_cursor%NOTFOUND;
            TableTest(byshtj_record.tjzd).tjgx:= nvl(byshtj_record.tjgx,'0');

            TableTest(byshtj_record.tjzd).tjjg:= '';
            if byshtj_record.jxzxjhxx_id is not null then
               tjid_table(byshtj_record.tjzd):=byshtj_record.tj_id;
               /* 0,课程性质类别归属学分*/
               if byshtj_record.tj_id like '%kcxz%' or byshtj_record.tj_id like '%kclb%' or byshtj_record.tj_id like '%kcgs%'
                  or byshtj_record.tj_id like '%kjxm%' or byshtj_record.tj_id like '%pycc%' then
                v_result := fun_byysh_kcxzxfsh(V_XH_ID,byshtj_record.tj_id,byshtj_record.tjmc,byshtj_record.tjsjz,
                byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,byshtj_record.btjkc,byshtj_record.tjsjcs,byshtj_record.tjkcxz);
                result_table(byshtj_record.tjzd):= v_result;
                if instr(v_result, '不合格') > 0 then
                   tj_table(byshtj_record.tjzd):= '2';
                else
                   tj_table(byshtj_record.tjzd):= '1';
                end if;
               /*1,获得有效学分>=培养方案学分要求 */
               elsif byshtj_record.tj_id='11111111' then
                  v_result := fun_by_pyfaxdxf(V_XH_ID,byshtj_record.xdlx);
                  result_table(byshtj_record.tjzd):= v_result;
                  if instr(v_result, '不合格') > 0 then
                     tj_table(byshtj_record.tjzd):= '2';
                  else
                     tj_table(byshtj_record.tjzd):= '1';
                  end if;
                /* 2,符合培养方案学分节点要求（门数）*/
               elsif byshtj_record.tj_id='22222222' then
                    v_result := fun_by_pyfajdms(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*3,学分要求主节点1-N*/
               elsif byshtj_record.tj_id='33333333' then
                     v_result := fun_by_xfyqzjd(V_XH_ID);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                         tj_table(byshtj_record.tjzd):= '1';
                     end if;
              /*4,个人培养方案修读完整*/
               elsif byshtj_record.tj_id='44444444' then
                    v_result := fun_by_pyfaxdwz(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*5,已经缴费*/
               elsif byshtj_record.tj_id='55555555' then
                    v_result := fun_by_jf(V_XH_ID, V_BYND);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*6,cet*/
               elsif byshtj_record.tj_id='66666666' then
                    v_result := fun_by_cet(V_XH_ID,byshtj_record.tjsjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,byshtj_record.tjsjly,
                    byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*7,处分*/
               elsif byshtj_record.tj_id='77777777' then
                    v_result := fun_by_cf(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*8,平均分大于*/
               elsif byshtj_record.tj_id='88888888' then
                    v_result := fun_by_pjf(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
                    byshtj_record.tjkcxz,byshtj_record.btjkc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*9,平均学分绩1(两种计算公式满足一种就符合)*/
               elsif byshtj_record.tj_id='99999979' then
                    v_result := fun_by_pjxfj(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
                    byshtj_record.tjkcxz,byshtj_record.btjkc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;

               /*10,平均绩点*/
               elsif byshtj_record.tj_id='99999989' then
                    v_result := fun_by_pjjd(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
                    byshtj_record.tjkcxz,byshtj_record.btjkc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;

                /*11,平均学分绩点大于*/
               elsif byshtj_record.tj_id='99999999' then
                   v_result := fun_by_pjxfjd(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
                    byshtj_record.tjkcxz,byshtj_record.btjkc,byshtj_record.xdlx);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;

               /*12,分项学分分布（华师）*/
               elsif byshtj_record.tj_id='00000010' then
                    v_result := fun_by_kcxzsh(V_XH_ID,V_ZYH_ID,V_NJDM_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*13,其他课程是否合格（华师）*/
               elsif byshtj_record.tj_id='00000011' or byshtj_record.tj_id='00000012'
                     or byshtj_record.tj_id='00000014' or byshtj_record.tj_id='00000020'
                     or byshtj_record.tj_id='00000022' or byshtj_record.tj_id='00000023'
                     or byshtj_record.tj_id='00000025' or byshtj_record.tj_id='00000026'
                     or byshtj_record.tj_id='00000046' or byshtj_record.tj_id='00000047'
                     or byshtj_record.tj_id='00000048' or byshtj_record.tj_id='00000049' then
                    v_result := fun_by_qtkcsh(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,byshtj_record.tjsjly,
                    byshtj_record.tjsjlymc,byshtj_record.tjsjgx);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
               /*14,毕业论文成绩*/
               elsif byshtj_record.tj_id='00000013' then
                    v_result := fun_by_bylwcjsh(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,byshtj_record.tjsjly,
                    byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjsjmc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;

                /*15,达到毕业要求 */
               elsif byshtj_record.tj_id='00000015' then
                    v_result := fun_by_ddbyyq(V_XH_ID,V_BYND);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*16,达到本专业授予学位要求 */
               elsif byshtj_record.tj_id='00000016' then
                    v_result := fun_by_ddbzyxw(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
               /*17,辅修学分大于等于*/
               elsif byshtj_record.tj_id='00000017' then
                    v_result := fun_by_fxzyxfsh(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjsjmc,byshtj_record.tjsjz1,byshtj_record.tjsjgx1);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
               /*18,辅修报名信息里面有注册*/
               elsif byshtj_record.tj_id='00000018' then
                    v_result := fun_by_fxzcbmsh(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
              /*19,完成辅修专业毕业论文*/
               elsif byshtj_record.tj_id='00000019' then
                    v_result := fun_by_fxlwcjsh(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjsjmc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
               /*21,执行计划课程性质分项学分达到要求*/
               elsif byshtj_record.tj_id='00000021' then
                    v_result := fun_by_zxjhkcxzsh(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                      tj_table(byshtj_record.tjzd):= '2';
                    else
                      tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*24,正补考成绩不通过门次*/
               elsif byshtj_record.tj_id='00000024' then
                    v_result := fun_by_zbkcjbtgsh(V_XH_ID,byshtj_record.tjsjz);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                /*27,学生学业情况审查,吉林建筑*/
               elsif byshtj_record.tj_id='00000027' then
                    v_result := fun_by_xsxysh(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*28,作弊严重作弊*/
               elsif byshtj_record.tj_id='00000028' then
                    v_result := fun_by_zbsh(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*29,最低毕业总学分要求*/
               elsif byshtj_record.tj_id='00000029' then
                    v_result := fun_by_zdbyzxfsh(V_XH_ID);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*30 31 32,课程性质的学分审核*/
                elsif byshtj_record.tj_id='00000030' or byshtj_record.tj_id='00000031' or byshtj_record.tj_id='00000032' then
                    v_result := fun_by_kcxzxfsh(V_XH_ID,byshtj_record.tjsjz,byshtj_record.tjkcxz);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*33,成绩库成绩全部合格*/
                elsif byshtj_record.tj_id='00000033' then
                    v_result := fun_by_kcxzcjsh(V_XH_ID,byshtj_record.tjsjz,byshtj_record.tjkcxz,byshtj_record.btjkc);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                 /*34，必修课正考累计不及格*/
                 elsif byshtj_record.tj_id='00000034' then
                    v_result := fun_by_bxkzksh(V_XH_ID,byshtj_record.tjsjz);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                  /*35，专业核心课正考累计不及格*/
                 elsif byshtj_record.tj_id='00000035' then
                    v_result := fun_by_zyhxkzksh(V_XH_ID,byshtj_record.tjsjz);
                    result_table(byshtj_record.tjzd):= v_result;
                    if instr(v_result, '不合格') > 0 then
                       tj_table(byshtj_record.tjzd):= '2';
                    else
                       tj_table(byshtj_record.tjzd):= '1';
                    end if;
                   /*36，重修总学分/总学分*/
                  elsif byshtj_record.tj_id='00000036' then
                       v_result := fun_by_cxxfzxfsh(V_XH_ID,byshtj_record.tjsjz);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                   /*37,其他所有课程GPA》=2.0 */
                  elsif byshtj_record.tj_id='00000037' then
                       v_result := fun_by_getqtpjxfjd(V_XH_ID,byshtj_record.tjsjz);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                  /*38,毕业环节：毕业设计(论文) 所获成绩绩点》=2.0*/
                  elsif byshtj_record.tj_id='00000038' then
                       v_result := fun_by_getbypjxfjd(V_XH_ID,byshtj_record.tjsjz);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                  /*39,学位课程门数(成绩>=65)/学位课程总数*/
                  elsif byshtj_record.tj_id='00000039' then
                       v_result := fun_by_xwkcmssh(V_XH_ID,byshtj_record.tjsjz);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                   /*40,通过国家外语四级考试*/
                  elsif byshtj_record.tj_id='00000040' then
                       v_result := fun_by_gjwysjsh(V_XH_ID);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                   /*41,大学英语4成绩>=60且口语通过*/
                  elsif byshtj_record.tj_id='00000041' then
                       v_result := fun_by_dxyykysh(V_XH_ID);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                   /*42,通过学生资格审核（北开放）*/
                  elsif byshtj_record.tj_id='00000042' then
                       v_result := fun_by_xwzgsh(V_XH_ID);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                   /*43,必修课程不通过门次<= _门*/
                  elsif byshtj_record.tj_id='00000043' then
                       v_result := fun_by_bxkbtgsh(V_XH_ID,byshtj_record.tjsjz);
                       result_table(byshtj_record.tjzd):= v_result;
                       if instr(v_result, '不合格') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                           tj_table(byshtj_record.tjzd):= '1';
                       end if;
                  /*44,学位课每门课最低分*/
                  elsif byshtj_record.tj_id='00000044' then
                     v_result := fun_by_xwktgsh(V_XH_ID,byshtj_record.tjsjz);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                         tj_table(byshtj_record.tjzd):= '1';
                     end if;
                  /*45,辅修、二专业成绩是否合格*/
                  elsif byshtj_record.tj_id='00000045' then
                     v_result := fun_by_ezykcjgpd(V_XH_ID);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;

                   /*50,华师2015级的学分分布审核*/
                  elsif byshtj_record.tj_id='00000050' then
                     v_result := fun_by2015_kcxzsh(V_XH_ID,V_ZYH_ID,V_NJDM_ID);

                     if instr(v_result, '未设置规则') > 0 then
                        result_table(byshtj_record.tjzd):= v_result;
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        v_result_one := substr(v_result, 1, instr(v_result,'$')-2);
                        v_result_two := substr(v_result,instr(v_result,'$')+1,1);

                       result_table(byshtj_record.tjzd):= v_result_one;
                       if instr(v_result_two, '0') > 0 then
                          tj_table(byshtj_record.tjzd):= '2';
                       else
                          tj_table(byshtj_record.tjzd):= '1';
                       end if;
                    end if;
                  /*51,辅修二专最长毕业延迟年限【】年*/
                  elsif byshtj_record.tj_id='00000051' then
                     v_result := fun_by_fxezyByycnx(V_XH_ID,byshtj_record.tjsjz);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;
                  /*52,重修门数<=【】门*/
                  elsif byshtj_record.tj_id='00000052' then
                     v_result := fun_by_cxms(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
                    byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
                    byshtj_record.tjkcxz,byshtj_record.btjkc,byshtj_record.xdlx);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;

                  /*53,已获学分全部课程平均学分绩-华师*/
                  elsif byshtj_record.tj_id='00000053' then
                     v_result := fun_by_yhxfpjj(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,byshtj_record.tjsjz1,
                     byshtj_record.tjsjmc,byshtj_record.tjsjgx,byshtj_record.tjkcxz,byshtj_record.btjkc,byshtj_record.tjpx,byshtj_record.xdlx);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;

                   /*54,计划课程必修课全部合格--重庆电力首发*/
                  elsif byshtj_record.tj_id='00000054' then
                     v_result := fun_by_jhkcjgpd(V_XH_ID,byshtj_record.tjsjz, byshtj_record.tjpx,byshtj_record.tjkcxz,
                     byshtj_record.btjkc,byshtj_record.xdlx,byshtj_record.tjsjmc);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;

                   /*55,正考成绩不合格学分>=35不授学位--四川传媒*/
                  elsif byshtj_record.tj_id='00000055' then
                     v_result := fun_by_zkcjxfsh(V_XH_ID,byshtj_record.tjsjz, byshtj_record.tjkcxz,byshtj_record.btjkc,byshtj_record.xdlx);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;

                  /*56,必修课程正考（课程替代也依据必修课程正考成绩）不及格学分占最低毕业学分的比例不超过30%--西华大学*/
                  elsif byshtj_record.tj_id='00000056' then
                     v_result := fun_by_zkcjxdblsh(V_XH_ID,byshtj_record.tjsjz, byshtj_record.tjpx,byshtj_record.tjkcxz,
                     byshtj_record.btjkc,byshtj_record.xdlx,byshtj_record.tjsjmc);
                     result_table(byshtj_record.tjzd):= v_result;
                     if instr(v_result, '不合格') > 0 then
                        tj_table(byshtj_record.tjzd):= '2';
                     else
                        tj_table(byshtj_record.tjzd):= '1';
                     end if;
                   end if;
                TableTest(byshtj_record.tjzd).tjjg:= tj_table(byshtj_record.tjzd);
           end if;
       END LOOP;
  CLOSE byshtj_cursor;

   /*判断 当全部条件符合时候，机审结果将为通过*/
/*   if ( tj_table(1)!='2' and tj_table(2)!='2' and tj_table(3)!='2' and tj_table(4)!='2' and tj_table(5)!='2' and tj_table(6)!='2' and tj_table(7)!='2' and tj_table(8)!='2' and tj_table(9)!='2' and tj_table(10)!='2') then
               V_FLAG:='1';
   end if;*/

   for j in 1 .. 3 loop
      V_NUMBER:='0';
      for i in 1 .. TableTest.count loop
          --dbms_output.put_line('审核结果='||TableTest(i).tjjg||'审核关系='||TableTest(i).tjgx);
          if TableTest(i).tjgx=j then --或j
             my_table(i):=i;---序号
          end if;
      end loop;
      for i in 1 .. my_table.count loop      ---有真则真
          if my_table(i)>0 then  ------大于0的才是存的值
              if(TableTest(my_table(i)).tjjg='1') then
                  V_NUMBER:='1';
                  exit;
              end if;
           end if;
      end loop;

      if V_NUMBER='1' then                      -----这一组是真
         for i in 1 .. my_table.count loop
           if my_table(i)>0 then  ------大于0的才是存的值
              TableTest(my_table(i)).tjjg:='1';
           end if;
         end loop;
      end if;
      my_table:=v_table(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
   end loop;
   -----根据条件关系，或者的关系有通过 则把相关组设置为都通过
     for m in 1 .. TableTest.count loop
       if TableTest(m).tjjg ='1' then
          dbms_output.put_line('TableTest(m).tjjg='||TableTest(m).tjjg);
          V_FLAG := '1';
       end if;
       if TableTest(m).tjjg='2' then
           V_FLAG:='2';
           exit;
       end if;
     end loop;

  if  V_TJSY='1' then
       select count(1) into V_NUMBER  from JW_BYGL_BYSHB where xh_id = V_XH_ID;
       if V_NUMBER = 0 then
         insert into JW_BYGL_BYSHB(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
         result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
         result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
         TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,
         JSBYF,XYZS,XYZS_GHID,XYZSSJ,XXYSH,XXYSH_GHID,XXYSHSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
         values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
         tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
         result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
         result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
         result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
         tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
         tjid_table(19),tjid_table(20),
         V_FLAG,'','','','','','','','','','','');
       else
          update JW_BYGL_BYSHB set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
          TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
          TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
          result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
          result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
          result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
          result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
          TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
          TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
          TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
          TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
          JSBYF = V_FLAG
          where xh_id = V_XH_ID;
       end if;
   elsif V_TJSY='2' then
       select count(1) into V_NUMBER  from jw_bygl_xwshb where xh_id = V_XH_ID;
       if V_NUMBER = 0 then
         insert into jw_bygl_xwshb(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
         result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
         result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
         TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,JSsyF,XYZS,XYZS_GHID,XYZSSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
         values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
         tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
         result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
         result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
         result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
         tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
         tjid_table(19),tjid_table(20),V_FLAG,'','','','','','','','');
       else
         update jw_bygl_xwshb set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
          TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
          TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
          result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
          result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
          result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
          result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
          TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
          TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
          TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
          TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
          JSsyF = V_FLAG
          where xh_id = V_XH_ID;
       end if;
   elsif V_TJSY='5' then
       select count(1) into V_NUMBER  from jw_bygl_fxshb where xh_id = V_XH_ID;
       if V_NUMBER = 0 then
         insert into jw_bygl_fxshb(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
         result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
         result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
         TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,JSsyF,XYZS,XYZS_GHID,XYZSSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
         values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
         tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
         result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
         result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
         result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
         tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
         tjid_table(19),tjid_table(20),V_FLAG,'','','','','','','','');
       else
         update jw_bygl_fxshb set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
          TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
          TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
          result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
          result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
          result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
          result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
          TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
          TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
          TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
          TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
          JSsyF = V_FLAG
          where xh_id = V_XH_ID;
       end if;
    elsif V_TJSY='6' then
       select count(1) into V_NUMBER  from jw_bygl_fxxwshb where xh_id = V_XH_ID;
       if V_NUMBER = 0 then
         insert into jw_bygl_fxxwshb(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
         result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
         result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
         TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,JSsyF,XYZS,XYZS_GHID,XYZSSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
         values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
         tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
         result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
         result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
         result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
         tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
         tjid_table(19),tjid_table(20),V_FLAG,'','','','','','','','');
       else
         update jw_bygl_fxxwshb set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
          TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
          TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
          result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
          result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
          result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
          result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
          TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
          TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
          TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
          TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
          JSsyF = V_FLAG
          where xh_id = V_XH_ID;
       end if;
    elsif V_TJSY='7' then
       select count(1) into V_NUMBER  from JW_BYGL_EZYSHB where xh_id = V_XH_ID;
       if V_NUMBER = 0 then
         insert into JW_BYGL_EZYSHB(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
         result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
         result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
         TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,JSsyF,XYZS,XYZS_GHID,XYZSSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
         values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
         tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
         result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
         result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
         result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
         tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
         tjid_table(19),tjid_table(20),V_FLAG,'','','','','','','','');
       else
         update JW_BYGL_EZYSHB set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
          TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
          TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
          result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
          result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
          result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
          result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
          TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
          TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
          TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
          TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
          JSsyF = V_FLAG
          where xh_id = V_XH_ID;
       end if;
   end if;
END;

/

