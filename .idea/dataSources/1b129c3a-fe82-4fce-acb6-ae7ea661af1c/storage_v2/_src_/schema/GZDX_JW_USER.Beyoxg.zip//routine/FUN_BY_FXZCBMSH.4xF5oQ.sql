create function fun_by_fxzcbmsh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_flag varchar2(2);
begin
    sJg := '合格';
    begin

select (case
         when num > 0 then
          '合格'
         else
          '未报名辅修专业,不合格！'
       end) into sJg
  from (select count(1) num
          from JW_FX_FXEZYBMB a, JW_FX_FXEZYBMKZB b
         where a.fxezybmkz_id = b.fxezybmkz_id
           and exists (select 1
                  from jw_xjgl_xsxjxxb c
                 where c.xh_id = a.xh_id
                   and c.xnm = a.xnm
                   and c.xqm = a.xqm)
           and a.xh_id = v_xh_id);
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_fxzcbmsh;

/

