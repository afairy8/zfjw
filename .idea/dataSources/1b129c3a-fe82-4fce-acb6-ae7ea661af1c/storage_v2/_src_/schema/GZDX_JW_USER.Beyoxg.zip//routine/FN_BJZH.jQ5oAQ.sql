create function fn_bjzh(vXnm varchar2,vXqm varchar2,vKch_id varchar2,vBj varchar2) return varchar2  ---班级组合----
as
   sBjzh varchar2(2000);   ---班级组合
begin
    sBjzh := '无';
    begin
       if vBj = '0' then
         select replace(wm_concat(a.bj),',',';') into sBjzh from
         (select distinct a.bj
         from zftal_xtgl_bjdmb a, jw_jh_kcyxrstjb b
         where b.xnm = vXnm
               and b.xqm = vXqm
               and b.kch_id = vKch_id
               and b.bh_id = a.bh_id
          order by a.bj) a;
       end if ;
     exception
        When others then
          sBjzh := '无';
    end;
    return sBjzh ;
end fn_bjzh;

/

