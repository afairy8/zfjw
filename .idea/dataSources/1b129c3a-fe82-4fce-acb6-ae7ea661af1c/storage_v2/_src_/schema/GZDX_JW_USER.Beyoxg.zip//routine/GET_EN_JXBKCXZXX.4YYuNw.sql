create function Get_En_JxbKcxzxx(vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班课程性质信息----
as
   sKcxzxx varchar2(500);   ---课程性质信息
begin
    sKcxzxx := 'nothing';
    begin
       if vBj='0' then
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select nvl(wm_concat(kcxzywmc),'nothing') into sKcxzxx from (
         select distinct b.kcxzywmc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm=b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
       end if ;
     if vBj='1' then
       select nvl(wm_concat(kcxzywjc),'nothing') into sKcxzxx from (
         select distinct b.kcxzywjc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm=b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
    end if ;

    if vBj='2' then
       select nvl(wm_concat(kcxzdm),'nothing') into sKcxzxx from (
         select distinct b.kcxzjc,b.kcxzdm from
              jw_jxrw_jxbhbxxb a,jw_jh_kcxzdmb b
                where a.kcxzdm=b.kcxzdm
                  and a.jxb_id= vJxb_id
                  order by b.kcxzdm
          );
    end if ;

     exception
        When others then
          sKcxzxx := 'nothing';
    end;
    return sKcxzxx ;
end Get_En_JxbKcxzxx;

/

