create function likai_get_xnPJCJJD(v_xh in varchar2,
                                              v_xn in varchar2)
  return varchar2 is
  v_pjcjjd varchar2(255); --记载平均成绩#平均学分绩点
begin
  if v_xh is null then
    select round(sum(to_number(bfzcj)) / count(kcid), 0) || '#' ||
           round(sum(to_number(xf) * to_number(jd)) / sum(to_number(xf)), 2)
      into v_pjcjjd
      from likai_gzdx_cjview zfcj
     where zfcj.xn = '2017-2018'
       and zfcj.xh = v_xh;
  end if;
  select round(sum(to_number(bfzcj)) / count(kcid), 0) || '#' ||
         round(sum(to_number(xf) * to_number(jd)) / sum(to_number(xf)), 2)
    into v_pjcjjd
    from likai_gzdx_cjview zfcj
   where zfcj.xn = v_xn
     and zfcj.xh = v_xh;
  return v_pjcjjd;
end;
/

