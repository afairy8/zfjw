create function fun_by_getpjjd(v_xh_id varchar2,v_lx varchar2,v_tjkcxz varchar2,v_btjkc varchar2)
Return varchar2
as
pjjd varchar2(100);
sqlstr varchar2(4000);-------------------平均绩点
begin
    sqlstr:= ' select to_char(nvl(avg(e.jd),0), ''fm99990.09'') pjjd from '||
     '(select a.kcxzdm,a.xh_id,a.jd,a.jxb_id,a.kch_id,row_number() over(partition by a.xh_id, a.kch_id order by a.bfzcj desc) rn '||
     ' from jw_cj_xscjb a where 1 = 1 and a.xh_id = '''||v_xh_id||'''  ';

     if v_lx='2' then
        sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = a.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
     end if;

     sqlstr:= sqlstr||') e where rn = 1 ';

     if v_tjkcxz is not null and v_tjkcxz!='qb' then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
     end if;

     if v_btjkc is not null then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
     end if;
   execute immediate sqlstr into pjjd;
  return pjjd;
end;

/

