create function fn_bysj_pyjsxx(vpyjsjgh_id varchar2,vflag varchar2) ---评阅教师信息----
return varchar2
as
vstr varchar2(2000) :='';
v_index    NUMBER;
v_strtemp varchar2(2000);
v_strsub  varchar2(2000);
v_start   varchar2(2000);
BEGIN
  v_strtemp :=vpyjsjgh_id;
  if vflag='1' then
    if INSTR(v_strtemp,',')=0 then
      select jgh into vstr from jw_jg_jzgxxb where jgh_id=v_strtemp;
      return vstr;
    else
     loop
        v_index := instr(v_strtemp, ',');
        if v_index=0 then
            select jgh into v_start from jw_jg_jzgxxb where jgh_id=v_strtemp;
            vstr:=vstr || ',' || v_start;
        end if;
        exit when v_index = 0;

         v_strsub := substr(v_strtemp, 0, v_index - 1);
         select jgh into v_start from jw_jg_jzgxxb where jgh_id=v_strsub;
         if vstr is null then
              vstr:=v_start;
         else
              vstr:=vstr || ',' ||v_start;
         end if;
         v_strtemp   := substr(v_strtemp, v_index + 1);
     end loop;
           return vstr;
    end if;
  end if;

  if vflag='2' then
    if INSTR(v_strtemp,',')=0 then
      select xm into vstr from jw_jg_jzgxxb where jgh_id=v_strtemp;
      return vstr;
    else
     loop
        v_index := instr(v_strtemp, ',');
        if v_index=0 then
            select xm into v_start from jw_jg_jzgxxb where jgh_id=v_strtemp;
            vstr:=vstr || ',' || v_start;
        end if;
        exit when v_index = 0;

         v_strsub := substr(v_strtemp, 0, v_index - 1);
         select xm into v_start from jw_jg_jzgxxb where jgh_id=v_strsub;
         if vstr is null then
              vstr:=v_start;
         else
              vstr:=vstr || ',' ||v_start;
         end if;
         v_strtemp   := substr(v_strtemp, v_index + 1);
     end loop;
           return vstr;
    end if;
  end if;
end fn_bysj_pyjsxx;

/

