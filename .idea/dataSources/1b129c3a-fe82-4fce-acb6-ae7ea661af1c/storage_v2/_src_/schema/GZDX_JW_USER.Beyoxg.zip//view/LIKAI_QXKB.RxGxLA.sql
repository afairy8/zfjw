create view LIKAI_QXKB as
  select
   rownum                                                             zjxh,
   t4.xnm,
   (select xnmc
    from jw_jcdm_xnb t
    where t4.xnm = t.xnm)                                             xn,
   t4.xqm,
   (select mc
    from zftal_xtgl_jcsjb t
    where t.lx = '0001' and t.dm = t4.xqm)                            xq,
   t4.jxb_id,
   t4.jgh,
   t4.jgh_id,
   t4.xm,
   t4.xbmc,
   t4.jslxdh,
   t4.zgxl,
   t4.zcmc,
   t4.zcd,
   get_weeksdesc(t4.zcd)                                              qsjsz,
   t4.jc,
   get_binarydesc(t4.jc, '节')                                         skjc,
   t4.xqj,
   t4.kch_id,
   t4.xqh_id,
   (select xqmc
    from zftal_xtgl_xqdmb t
    where t.xqh_id = t4.xqh_id)                                       xqmc,
   fn_jxbzh(t4.jxb_id, 0)                                             jxbzc,
   t4.jxbmc,
   t4.kch,
   t4.kcmc,
   t4.xf,
   t4.rwzxs,
   t4.kkbm_id,
   t4.jgmc as                                                         jsxy,
   (select jgmc
    from zftal_xtgl_jgdmb t
    where t.jg_id = t4.kkbm_id)                                       kkxy,
   (select count(xh_id)
    from jw_xk_xsxkb t
    where t.xnm = t4.xnm and t.xqm = t4.xqm and t.jxb_id = t4.jxb_id) xkrs,
   t4.jxbrs,
   get_kczhxszh(t4.kch_id, '')                                        zhxs,
   t4.sksj,
   t4.jxdd,
   (select wm_concat(distinct t2.kcxzmc)
    from jw_jxrw_jxbhbxxb t1, jw_jh_kcxzdmb t2
    where t1.kcxzdm = t2.kcxzdm and t1.jxb_id = t4.jxb_id)            kcxzmc,
   t4.cdbh,
   t4.cdmc,
   (select g.cdlbmc
    from jw_jcdm_cdlbdmb g
    where t4.cdlb_id = g.cdlb_id)                                     cdlbmc,
   '第' || get_weeksdesc(t4.zcd)                                       cdqsjsz,
   t4.jc   as                                                         cdjc,
   '第' || get_binarydesc(t4.jc, '节')                                  cdskjc,
   t4.zws,
   (select jxlmc
    from jw_jcdm_jxldmb t
    where t4.lh = t.jxldm)                                            jxlmc,
   lch,
   (select wm_concat(distinct ( select zymc from zftal_xtgl_zydmb where zyh_id = a.zyh_id))
    from jw_jxrw_jxbhbxxb a
    where jxb_id = t4.jxb_id)                                         zyzc
 from (select
         min(pkbj) pkbj,
         xnm,
         xqm,
         xqh_id,
         kch_id,
         jxb_id,
         jxbmc,
         xsdm,
         jgh_id,
         cd_id,
         xqj,
         jgh,
         xm,
         xbmc,
         jslxdh,
         zgxl,
         zcmc,
         jxbrs,
         jxdd,
         sksj,
         rwzxs,
         kch,
         kcmc,
         xf,
         kkbm_id,
         cdbh,
         cdmc,
         zws,
         cdlb_id,
         lh,
         lch,
         jgmc,
         sum(zcd)  zcd,
         jc
       from (select
               min(pkbj) pkbj,
               xnm,
               xqm,
               xqh_id,
               kch_id,
               jxb_id,
               jxbmc,
               xsdm,
               jgh_id,
               cd_id,
               xqj,
               zcd,
               jgh,
               xm,
               xbmc,
               jslxdh,
               zgxl,
               zcmc,
               jxbrs,
               jxdd,
               sksj,
               rwzxs,
               kch,
               kcmc,
               xf,
               kkbm_id,
               cdbh,
               cdmc,
               zws,
               cdlb_id,
               lh,
               lch,
               jgmc,
               sum(jc)   jc
             from (select
                     t3.xnm,
                     t3.xqm,
                     t3.xqh_id,
                     t3.kch_id,
                     t3.jxb_id,
                     t3.jxbmc,
                     t3.xsdm,
                     t3.jgh_id,
                     t3.cd_id,
                     t3.xqj,
                     t3.pkbj,
                     case when t3.pkbj = 0
                       then t3.zcd
                     else t3.cdzcd end                  zcd,
                     case when t3.pkbj = 0
                       then t3.jc
                     else t3.cdjc end                   jc,
                     c.jgh,
                     c.xm,
                     (select mc
                      from zftal_xtgl_jcsjb
                      where lx = '0006' and dm = c.xbm) xbmc,
                     c.zgxl,
                     (select zcmc
                      from jw_jg_zyjszcb
                      where zcm = c.zcm)                zcmc,
                     (select jgmc
                      from zftal_xtgl_jgdmb
                      where jg_id = c.jg_id)            jgmc,
                     c.sjhm as                          jslxdh,
                     b.jxbrs,
                     b.jxdd,
                     b.sksj,
                     b.rwzxs,
                     d.kch,
                     d.kcmc,
                     d.xf,
                     d.kkbm_id,
                     f.cdbh,
                     f.cdmc,
                     f.zws,
                     f.cdlb_id,
                     f.lh,
                     f.lch
                   from (select
                           t1.kb_id,
                           t1.xnm,
                           t1.xqm,
                           t1.xqh_id,
                           t1.kch_id,
                           t1.jxb_id,
                           t1.jxbmc,
                           t1.xsdm,
                           t1.jgh_id,
                           t1.zcd,
                           t1.xqj,
                           t1.jc,
                           t1.pkly,
                           t2.cd_id,
                           t2.zcd     cdzcd,
                           t2.jc      cdjc,
                           case when t2.cd_id is null
                             then 0
                           else 1 end pkbj
                         from (select
                                 s.kb_id,
                                 s.xnm,
                                 s.xqm,
                                 s.jxb_id,
                                 s.jgh_id,
                                 s.zcd,
                                 s.xqj,
                                 s.jc,
                                 s.pkly,
                                 a.xqh_id,
                                 a.kch_id,
                                 a.jxbmc,
                                 a.xsdm
                               from jw_pk_kbsjb s, jw_jxrw_jxbxxb a
                               where s.jxb_id = a.jxb_id and s.xnm = a.xnm and s.xqm = a.xqm and
                                     (a.shzt is null or a.shzt = '3') and a.xnm=(select zdz from zftal_xtgl_xtszb where zs='当前学年') and
                                     a.xqm=(select zdz from zftal_xtgl_xtszb where zs='当前学期')) t1 left join (select
                                                                  kb_id,
                                                                  xnm,
                                                                  xqm,
                                                                  xqj,
                                                                  jxb_id,
                                                                  jgh_id,
                                                                  cd_id,
                                                                  zcd,
                                                                  jc,
                                                                  get_bitorsunion(wm_concat(zcd)
                                                                                  over (
                                                                                    partition by kb_id )) kb_zcd,
                                                                  get_bitorsunion(wm_concat(jc)
                                                                                  over (
                                                                                    partition by kb_id )) kb_jc
                                                                from (select
                                                                        kb_id,
                                                                        xnm,
                                                                        xqm,
                                                                        xqj,
                                                                        jxb_id,
                                                                        jgh_id,
                                                                        cd_id,
                                                                        sum(zcd) zcd,
                                                                        jc
                                                                      from (select
                                                                              kb_id,
                                                                              xnm,
                                                                              xqm,
                                                                              xqj,
                                                                              jxb_id,
                                                                              jgh_id,
                                                                              cd_id,
                                                                              zcd,
                                                                              sum(jc) jc
                                                                            from (select
                                                                                    t1.kb_id,
                                                                                    t1.xnm,
                                                                                    t1.xqm,
                                                                                    t1.xqj,
                                                                                    t1.jxb_id,
                                                                                    t1.jgh_id,
                                                                                    t2.cd_id,
                                                                                    t2.zcd,
                                                                                    t2.jc
                                                                                  from jw_pk_kbsjb t1,
                                                                                    jw_pk_kbcdb t2
                                                                                  where
                                                                                    t1.kb_id = t2.kb_id
                                                                                    and t1.xnm=(select zdz from zftal_xtgl_xtszb where zs='当前学年')
                                                                                    and t1.xqm=(select zdz from zftal_xtgl_xtszb where zs='当前学期') and
                                                                                    exists(select 'X'
                                                                                           from
                                                                                             jw_jxrw_jxbxxb a
                                                                                           where
                                                                                             t1.jxb_id =
                                                                                             a.jxb_id
                                                                                             and
                                                                                             t1.xnm =
                                                                                             a.xnm and
                                                                                             t1.xqm =
                                                                                             a.xqm and
                                                                                             a.xnm =
                                                                                             (select zdz from zftal_xtgl_xtszb where zs='当前学年') and
                                                                                             a.xqm =
                                                                                             (select zdz from zftal_xtgl_xtszb where zs='当前学期')))
                                                                            group by kb_id, xnm, xqm,
                                                                              xqj, jxb_id, jgh_id,
                                                                              cd_id, zcd)
                                                                      group by kb_id, xnm, xqm, xqj,
                                                                        jxb_id, jgh_id, cd_id, jc)) t2
                             on (t1.kb_id = t2.kb_id)
                         where 1 = 1 and t1.xnm=(select zdz from zftal_xtgl_xtszb where zs='当前学年') and t1.xqm=(select zdz from zftal_xtgl_xtszb where zs='当前学期')) t3 left join
                     jw_jcdm_cdxqxxb f on t3.cd_id = f.cd_id and t3.xnm = f.xnm and t3.xqm = f.xqm
                     inner join jw_jxrw_jxbxxb b
                       on t3.xnm = b.xnm and t3.xqm = b.xqm and t3.jxb_id = b.jxb_id
                     inner join jw_jg_jzgxxb c on t3.jgh_id = c.jgh_id
                     inner join jw_jh_kcdmb d on t3.kch_id = d.kch_id
                   where 1 = 1)
             group by xnm, xqm, xqh_id, kch_id, jxb_id, jxbmc, xsdm, jgh_id, cd_id, xqj, zcd, jgh, xm,
               xbmc, jslxdh, zgxl, zcmc, jxbmc, jxbrs, jxdd, sksj, rwzxs, kch, kcmc, xf, kkbm_id, cdbh,
               cdmc, zws, lh, lch, cdlb_id, jgmc)
       group by xnm, xqm, xqh_id, kch_id, jxb_id, jxbmc, xsdm, jgh_id, cd_id, xqj, jc, jgh, xm, xbmc,
         jslxdh, zgxl, zcmc, jxbmc, jxbrs, jxdd, sksj, rwzxs, kch, kcmc, xf, kkbm_id, cdbh, cdmc, zws,
         lh, lch, cdlb_id, jgmc
       order by xqj, jc, zcd) t4
/

