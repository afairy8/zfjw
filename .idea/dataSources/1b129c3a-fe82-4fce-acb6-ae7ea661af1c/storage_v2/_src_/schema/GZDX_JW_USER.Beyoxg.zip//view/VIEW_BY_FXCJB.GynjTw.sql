create view VIEW_BY_FXCJB as
  select nvl(sum(nvl(a.xf,kc.xf)),0) fxhdxf, a.xh_id
    from jw_cj_xscjb a, jw_jh_kcdmb kc
   where kc.kch_id = a.kch_id
     and a.kcbj = '1'
     and a.bfzcj >= 60
     group by a.xh_id

/

