create Function isNum
(
  vStr            In      VarChar2         --日期型字符串
)
Return Number
Is
  ExecResult         integer;
Begin
  ExecResult := To_number(vStr);
  Return 1;        --返回值
Exception When Others Then
  Return 0;
End isNum;

/

