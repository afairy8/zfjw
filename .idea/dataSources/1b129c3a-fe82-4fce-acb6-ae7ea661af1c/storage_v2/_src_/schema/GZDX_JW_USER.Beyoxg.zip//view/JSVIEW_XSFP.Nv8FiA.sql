create view JSVIEW_XSFP as
  select xnb.xnmc xn,
       xqb.mc xq,
       jzg.jgh jszgh,
       t1.xqj,replace(substr(fn_bittozc(t1.jc*2),1,2),',','') sjd,
       fn_bittostr(t1.zcd) qsjsz,fn_jszs(t1.jc) skcd,t1.jxb_id from
jw_pk_kbsjb t1,jw_jcdm_xnb xnb,zftal_xtgl_jcsjb xqb,jw_jg_jzgxxb jzg
where t1.xnm = xnb.xnm
  and t1.xqm = xqb.dm
  and xqb.lx = '0001'
  and t1.jgh_id = jzg.jgh_id
/

