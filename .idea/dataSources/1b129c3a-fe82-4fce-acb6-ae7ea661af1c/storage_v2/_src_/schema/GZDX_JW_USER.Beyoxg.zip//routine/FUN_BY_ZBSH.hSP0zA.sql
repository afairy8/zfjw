create function fun_by_zbsh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
begin
    sJg := '合格';
    begin
       select decode(wm_concat(kc.kcmc),
              '',
              '合格',
              '存在考试课程[' || wm_concat((kc.kcmc)) || ']作弊，不合格！') into sJg
          from jw_cj_xscjb cj ,jw_jh_kcdmb kc
          where kc.kch_id = cj.kch_id
          and cj.xh_id = v_xh_id
          and cj.cjbz like '%作弊%'
         ;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;


    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_zbsh;

/

