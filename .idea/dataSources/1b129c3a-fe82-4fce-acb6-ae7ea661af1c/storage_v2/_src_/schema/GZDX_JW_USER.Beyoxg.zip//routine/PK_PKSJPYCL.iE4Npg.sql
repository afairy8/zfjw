create procedure PK_PKSJPYCL      -----排课时间平移处理
(
 vXnm in varchar2,
 vXqm in varchar2,
 vKch_id in varchar2,
 vJxb_id in varchar2,
 vYrq in varchar2,
 vXrq in varchar2,
 vJgh_id in varchar2,
 vBj out varchar2)
 as
 sJxb_id varchar2(50);
 sYzc    varchar2(20);
 sYxqj   varchar2(20);
 sYrq    varchar2(20);
 sXzc    varchar2(20);
 sXxqj   varchar2(20);
 sXrq    varchar2(20);
 sID     varchar2(32);
 sCjsj   varchar2(20);

 sSksjjxdd varchar2(4000);
 sSksj   varchar2(2000);
 sSkdd   varchar2(2000);
 sSksjyw varchar2(2000);
 sSkddyw varchar2(2000);
 sSksjms varchar2(2000);
 sKcjssj varchar2(2000);

 icount  number;
 i       number;
 k       number;

 cursor Get_Pysj is     ----平移方案时间循环信息----游标---
    select t.yrq,t.tdrq from jw_pk_jjrfaszb t
                   where t.xnm = vXnm
                     and t.xqm = vXqm
                     and t.ztdm = '1'
                     and t.yrq = nvl(vYrq,t.yrq)
                     and t.tdrq = nvl(vXrq,t.tdrq) order by yrq;
 Cur_Pysj Get_Pysj%rowtype;

  cursor Get_Pyjxbxx is     ----教学班循环信息----游标---
    select distinct jxb.jxb_id from jw_jxrw_jxbxxb jxb,jw_pk_kbsjb kbsj
                          where jxb.xnm = vXnm
                            and jxb.xqm = vXqm
                            and kbsj.xnm = vXnm
                            and kbsj.xqm = vXqm
                            and jxb.jxb_id = kbsj.jxb_id
                            and kbsj.xqj = sYxqj
                            and bitand(kbsj.zcd,sYzc) >0
                            and jxb.jxb_id = nvl(vJxb_id,jxb.jxb_id)
                            and jxb.kch_id = nvl(vKch_id,jxb.kch_id);
 Cur_Pyjxbxx Get_Pyjxbxx%rowtype;
begin
   vBj := '0';
   i := 0;
   k := 0;
   open Get_Pysj;
    loop
    fetch Get_Pysj into Cur_Pysj;  ---平移方案时间循环
    exit when Get_Pysj%notfound;
        sYrq := Cur_Pysj.yrq;
        sXrq := Cur_Pysj.tdrq;

       select max(decode(t2.rq,sYrq,power(2,t2.dxqzc-1))),max(decode(t2.rq,sYrq,t2.xqj)),
              max(decode(t2.rq,sXrq,power(2,t2.dxqzc-1))),max(decode(t2.rq,sXrq,t2.xqj))
              into sYzc,sYxqj,sXzc,sXxqj from jw_pk_xlb t1,jw_pk_rcmxb t2
        where t1.xl_id = t2.xl_id
          and t1.xnm = vXnm
          and t1.xqm = vXqm
          and (t2.rq = sYrq or t2.rq = sXrq );

       open Get_Pyjxbxx;
        loop
        fetch Get_Pyjxbxx into Cur_Pyjxbxx;  ---平移方案时间循环
        exit when Get_Pyjxbxx%notfound;
            sJxb_id := Cur_Pyjxbxx.jxb_id;

       begin
       i := i+1;
        sID := sys_guid();
        sCjsj := to_char(sysdate,'yyyy-mm-dd hh24:mi:ss');

        if sXzc is null or sXxqj is null then
          insert into jw_pk_pysjclztb(pysjclzt_id,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,zt,ztms,cjjgh_id,cjsj)
               values(sID,vXnm,vXqm,sJxb_id,sYrq,sYzc,sYxqj,sXrq,sXzc,sXxqj,'0','校历信息无替代的日期信息',vJgh_id,sCjsj);
          -- Goto Exend;
          continue;
        end if;

        delete from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id;
        ----拆分排课数据----具体单周、星期、单节-----
        insert into jw_pk_pysjlsb(xnm,xqm,jxb_id,jgh_id,zc,xqj,jc,cd_id,rq)
        select distinct a.xnm,a.xqm,a.jxb_id,a.jgh_id,xl.zc,a.xqj,jc.jc,
        case when bitand(b.zcd,xl.zc) >0 and bitand(b.jc,jc.jc) >0 then b.cd_id else null end cd_id,
          xl.rq from jw_pk_kbsjb a,jw_pk_kbcdb b,
        (select t1.xnm,t2.dxqm as xqm,t2.rq,t2.xqj,power(2,t2.dxqzc-1) as zc from
               jw_pk_xlb t1,jw_pk_rcmxb t2
        where t1.xl_id = t2.xl_id) xl,
        (select power(2,rownum -1) jc from zftal_xtgl_jcsjb where rownum <=20) jc
        where a.kb_id = b.kb_id(+)
          and a.zcd != 0
          and a.jxb_id = sJxb_id
          and a.xnm = xl.xnm
          and a.xqm = xl.xqm
          and bitand(a.zcd,xl.zc)> 0
          and a.xqj = xl.xqj
          and bitand(a.jc,jc.jc)>0;
        ----将现周次、现星期几做为替换信息更新jw_pk_pysjlsb-thzc、thxqj
         update jw_pk_pysjlsb set thrq = sXrq,thzc = sXzc,thxqj = sXxqj where xnm = vXnm
                                                              and xqm = vXqm
                                                              and jxb_id = sJxb_id
                                                              and zc = sYzc
                                                              and xqj = sYxqj;

         -----判断内部替换周次、替换星期几与本教学班内部时间有无冲突
         insert into jw_pk_pysjctqkb(pysjctqk_id,ctlx,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,jc,ctjxb_id,ctxx,cjjgh_id,cjsj)
         select sID,'本教学班内冲突',xnm,xqm,jxb_id,sYrq,sYzc,sYxqj,sXrq,zc,xqj,jc,jxb_id as ctjxb_id,jgh_id||'-'||cd_id,vJgh_id,sCjsj from
         (select xnm,xqm,jxb_id,jgh_id,cd_id,nvl(thzc,zc) as zc,nvl(thxqj,xqj) as xqj,jc
            from  jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id
           group by xnm,xqm,jxb_id,jgh_id,cd_id,nvl(thzc,zc) ,nvl(thxqj,xqj) ,jc
          having count(*) > 1
          );
         select count(*) into icount from jw_pk_pysjctqkb where xnm = vXnm and xqm = vXqm and pysjctqk_id = sID;
         if icount > 0 then
           insert into jw_pk_pysjclztb(pysjclzt_id,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,zt,ztms,cjjgh_id,cjsj)
               values(sID,vXnm,vXqm,sJxb_id,sYrq,sYzc,sYxqj,sXrq,sXzc,sXxqj,'0','本教学班内部时间与代替时间冲突',vJgh_id,sCjsj);
           continue;
         end if;
        ----课表冲突---count(*) into icount
     	insert into jw_pk_pysjctqkb(pysjctqk_id,ctlx,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,jc,ctjxb_id,ctxx,cjjgh_id,cjsj)
        select distinct sID,lx,xnm,xqm,jxb_id,sYrq,sYzc,sYxqj,sXrq,zcd,xqj,jc,ctjxb_id,ctxx,vjgh_id,sCjsj from
        (
        select '课表冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,b.ctxx from
        (select xnm,xqm,jxb_id,jgh_id,thzc as zcd,thxqj as xqj,jc from
         jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc
         ) a,
        (select t2.xnm,t2.xqm,t2.jxb_id,t2.jgh_id,t2.zcd,t2.xqj,t2.jc,
                t1.njdm_id||'-'||t1.zyh_id||'-'||t1.bh_id||'-'||t1.tjkbzdm||'-'||t1.tjkbzxsdm as ctxx from jw_pk_tjkbjgb t1,jw_pk_kbsjb t2
                where t1.xnm = t2.xnm
                  and t1.xqm = t2.xqm
                  and t1.jxb_id = t2.jxb_id
                  and t2.jxb_id != sJxb_id
                  and t2.xnm = vXnm
                  and t2.xqm = vXqm
                  and t2.xqj = sXxqj
                  and bitand(t2.zcd,sXzc) > 0
        and exists(select 'X' from jw_pk_tjkbjgb t3
                             where t1.xnm = t3.xnm
                               and t1.xqm = t3.xqm
                               and t1.njdm_id = t3.njdm_id
                               and t1.zyh_id = t3.zyh_id
                               and t1.bh_id = t3.bh_id
                               and t1.tjkbzdm = t3.tjkbzdm
                               and t1.tjkbzxsdm = t3.tjkbzxsdm
                               and t3.jxb_id = sJxb_id)
        ) b where a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----教师冲突
        union all
        select '教师冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,a.jgh_id as ctxx from
        (select xnm,xqm,jxb_id,jgh_id,thzc as zcd,thxqj as xqj,jc from
         jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc) a,
        (select t2.jxb_id,t2.jgh_id,t2.zcd,t2.xqj,t2.jc from jw_pk_kbsjb t2
                where t2.jxb_id != sJxb_id
                  and t2.xnm = vXnm
                  and t2.xqm = vXqm
                  and t2.xqj = sXxqj
                  and bitand(t2.zcd,sXzc) > 0
        and exists(select 'X' from jw_pk_kbsjb t3
                             where t2.xnm = t3.xnm
                               and t2.xqm = t3.xqm
                               and t2.jgh_id = t3.jgh_id
                               and t3.xnm = vXnm
                               and t3.xqm = vXqm
                               and t3.jxb_id = sJxb_id
                               and t3.xqj = sYxqj
                               and bitand(t3.zcd,sYzc) >0
                               )
         ) b where a.jgh_id = b.jgh_id and a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----学生选课冲突---count(*) into icount
        union all
        select  '学生选课冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,b.xh_id as ctxx  from
        (select xnm,xqm,jxb_id,jgh_id,thzc as zcd,thxqj as xqj,jc
           from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc) a,
        (select t1.jxb_id,t1.jgh_id,t1.zcd,t1.xqj,t1.jc,t2.xh_id from jw_pk_kbsjb t1,jw_xk_xsxkb t2
                where t2.jxb_id != sJxb_id
                  and t1.jxb_id = t2.jxb_id
                  and t1.xnm = t2.xnm
                  and t1.xqm = t2.xqm
                  and t2.xnm = vXnm
                  and t2.xqm = vXqm
                  and t1.xqj = sXxqj
                  and bitand(t1.zcd,sXzc) > 0
                  and exists(select 'X' from jw_xk_xsxkb t3
                                       where t2.xnm = t3.xnm
                                         and t2.xqm = t3.xqm
                                         and t2.xh_id = t3.xh_id
                                         and t3.xnm = vXnm
                                         and t3.xqm = vXqm
                                         and t3.jxb_id = sJxb_id)
        ) b where a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----学生考试冲突---count(*) into icount
        union all
        select '学生考试冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,b.xh_id||'-'||b.kssj as ctxx from
        (select xnm,xqm,jxb_id,jgh_id,thzc as zcd,thxqj as xqj,jc
           from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc
         ) a,
        (select t1.jxb_id,sXzc as zcd,sXxqj as xqj,t1.jc,t2.xh_id,t1.kssj from
        (select jxbdz.xnm,jxbdz.xqm,jxbdz.jxb_id,
        (select sum(distinct power(2,b.jcm-1)) from jw_pk_rsdszb a, jw_pk_rjcszb b where a.rsdsz_id = b.rsdsz_id
        and a.xqh_id = (select xqh_id from jw_kw_ksmcxqb where ksmcdmb_id = jxbdz.ksmcdmb_id and rownum = 1)
        and jssj >= ksccb.kskssj||':00' and qssj <= ksccb.ksjssj||':00' ) as jc ,
        ksccb.ksrq||' '||ksccb.kskssj||'-'||ksccb.ksjssj as kssj
        from jw_kw_ksmcjxbdzb jxbdz,jw_kw_kssjb sjb,jw_kw_ksccb ksccb
        where jxbdz.ksmcdmb_id = sjb.ksmcdmb_id
          and jxbdz.sjbh_id = sjb.sjbh_id
          and sjb.ksccb_id = ksccb.ksccb_id
          and ksccb.ksrq = sXrq
          and jxbdz.xnm = vXnm
          and jxbdz.xqm = vXqm) t1,jw_xk_xsxkb t2
                where t1.jxb_id = t2.jxb_id
                  and t1.xnm = t2.xnm
                  and t1.xqm = t2.xqm
                  and t2.xnm = vXnm
                  and t2.xqm = vXqm
                  and exists(select 'X' from jw_xk_xsxkb t3
                                       where t2.xnm = t3.xnm
                                         and t2.xqm = t3.xqm
                                         and t2.xh_id = t3.xh_id
                                         and t3.xnm = vXnm
                                         and t3.xqm = vXqm
                                         and t3.jxb_id = sJxb_id)
        ) b where a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----监考教师冲突--count(*) into icount
        union all
        select '监考教师冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,b.jgh_id||'-'||b.kssj as ctxx from
        (select xnm,xqm,jxb_id,jgh_id,thzc as zcd,thxqj as xqj,jc
           from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc
        ) a,
        (select jxb_id,jgh_id,sXzc as zcd,sXxqj as xqj,jc,kssj from
        (select jxbdz.jxb_id,c.jgh_id,
        (select sum(distinct power(2,b.jcm-1)) from jw_pk_rsdszb a, jw_pk_rjcszb b where a.rsdsz_id = b.rsdsz_id
        and a.xqh_id = (select xqh_id from jw_kw_ksmcxqb where ksmcdmb_id = jxbdz.ksmcdmb_id and rownum = 1)
        and jssj >= ksccb.kskssj||':00' and qssj <= ksccb.ksjssj||':00' ) as jc,
        ksccb.ksrq||' '||ksccb.kskssj||'-'||ksccb.ksjssj as kssj
        from jw_kw_ksmcjxbdzb jxbdz,jw_kw_kssjb sjb,jw_kw_ksccb ksccb,
        jw_kw_ksddbjdzb a,jw_kw_ksddb b ,jw_kw_ksddjkb c
        where jxbdz.ksmcdmb_id = sjb.ksmcdmb_id
          and jxbdz.sjbh_id = sjb.sjbh_id
          and sjb.ksccb_id = ksccb.ksccb_id
          and sjb.sjbh_id = a.sjbh_id
          and a.kshkbj_id = b.kshkbj_id
          and b.ksdd_id = c.ksdd_id
          and ksccb.ksrq = sXrq
          and jxbdz.xnm = vXnm
          and jxbdz.xqm = vXqm)
         ) b where a.jgh_id = b.jgh_id and a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----场地冲突 --count(*) into icount
        union all
         select '排课场地冲突' as lx,t.xnm,t.xqm,t.jxb_id,t.thzc,t.thxqj,t.jc,t1.jxb_id as ctjxb_id,t.cd_id as ctxx
           from jw_pk_pysjlsb t, jw_pk_kbsjb t1,jw_pk_kbcdb t2
          where t.xnm = vXnm
            and t.xqm = vXqm
            and t1.xnm = vXnm
            and t1.xqm = vXqm
            and t.jxb_id = sJxb_id
            and t.zc = sYzc
            and t.xqj = sYxqj
            and t.cd_id = t2.cd_id
            and t.thxqj = t1.xqj
            and bitand(t.thzc,t2.zcd) > 0
            and bitand(t.jc,t2.jc) > 0
            and t1.jxb_id != sJxb_id
            and t1.xqj = sXxqj
            and t1.kb_id = t2.kb_id
            and bitand(t2.zcd,sXzc) > 0
        ----排考场地冲突--count(*) into icount
        union all
        select '排考场地冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,b.jxb_id as ctjxb_id,b.cd_id||'-'||b.kssj as ctxx from
        (select xnm,xqm,jxb_id,jgh_id,cd_id,thzc as zcd,thxqj as xqj,jc
           from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc
        ) a,
        (select jxb_id,cd_id,sXzc as zcd,sXxqj as xqj,jc,kssj from
        (select jxbdz.jxb_id,b.cd_id,
        (select sum(distinct power(2,b.jcm-1)) from jw_pk_rsdszb a, jw_pk_rjcszb b where a.rsdsz_id = b.rsdsz_id
        and a.xqh_id = (select xqh_id from jw_kw_ksmcxqb where ksmcdmb_id = jxbdz.ksmcdmb_id and rownum = 1)
        and jssj >= ksccb.kskssj||':00' and qssj <= ksccb.ksjssj||':00' ) as jc,
        ksccb.ksrq||' '||ksccb.kskssj||'-'||ksccb.ksjssj as kssj
        from jw_kw_ksmcjxbdzb jxbdz,jw_kw_kssjb sjb,jw_kw_ksccb ksccb,
        jw_kw_ksddbjdzb a,jw_kw_ksddb b
        where jxbdz.ksmcdmb_id = sjb.ksmcdmb_id
          and jxbdz.sjbh_id = sjb.sjbh_id
          and sjb.ksccb_id = ksccb.ksccb_id
          and sjb.sjbh_id = a.sjbh_id
          and a.kshkbj_id = b.kshkbj_id
          and ksccb.ksrq = sXrq
          and jxbdz.xnm = vXnm
          and jxbdz.xqm = vXqm)
        ) b where a.cd_id = b.cd_id and a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
        ----借用场地冲突--count(*) into icount
        union all
        select '借用场地冲突' as lx,a.xnm,a.xqm,a.jxb_id,a.zcd,a.xqj,a.jc,null as ctjxb_id,b.cd_id as ctxx from
        (select xnm,xqm,jxb_id,jgh_id,cd_id,thzc as zcd,thxqj as xqj,jc
           from jw_pk_pysjlsb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and xqj = sYxqj and zc = sYzc) a,
        (select a.xnm,a.xqm,b.cd_id,c.zcd,c.xqj,c.jc from jw_pk_jxcdyuyb a,jw_pk_jxcdyuymxb b,jw_pk_jxcdyuysjb c
          where a.yyxx_id = b.yyxx_id and a.yyxx_id = c.yyxx_id
            and a.xnm = vXnm
            and a.xqm = vXqm
            and b.xnm = vXnm
            and b.xqm = vXqm
            and a.sqzt = '1'
            and nvl(a.shzt,'-1') =  case when (select count(*) from zftal_xtgl_xtszb where zdm = 'YUYJSCTBJ' and zdz = '1') > 0
                                         then nvl(a.shzt,'-1') else '3' end
            and a.cxbj = '0') b
         where a.cd_id = b.cd_id and a.xqj = b.xqj and bitand(a.zcd,b.zcd) > 0 and bitand(a.jc,b.jc) > 0
         );
        select count(*) into icount from jw_pk_pysjctqkb where xnm = vXnm and xqm = vXqm and pysjctqk_id = sID;
        if icount > 0 then
          insert into jw_pk_pysjclztb(pysjclzt_id,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,zt,ztms,cjjgh_id,cjsj)
               values(sID,vXnm,vXqm,sJxb_id,sYrq,sYzc,sYxqj,sXrq,sXzc,sXxqj,'0','替代日期与相关信息时间冲突',vJgh_id,sCjsj);
          continue;
        end if;

         begin
          delete from jw_pk_pysjlszhb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id;
          ----组合排课数据----先按节相同的把周组合，然后按组合后的周相同的把节组合-----
          insert into jw_pk_pysjlszhb(kb_id,xnm,xqm,jxb_id,jgh_id,cd_id,zc,xqj,jc)
          select sys_guid() kbid,xnm,xqm,jxb_id,jgh_id,cd_id,zc,xqj,sum(jc) as jc from (
          select xnm,xqm,jxb_id,jgh_id,cd_id,sum(nvl(thzc,zc)) as zc,nvl(thxqj,xqj) as xqj,jc
           from jw_pk_pysjlsb
          where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id
          group by xnm,xqm,jxb_id,jgh_id,cd_id,nvl(thxqj,xqj),jc
          ) group by xnm,xqm,jxb_id,jgh_id,cd_id,xqj,zc;

          ------同一事务处理，先删除课表场地数据再删除课表时间数据--然后重新生成课表时间、场地数据
         insert into jw_xk_kbsjclb (kb_id, xnm, xqm, jxb_id, jgh_id, zcd, xqj, jc, clsj, pkly,lx)
         select a.kb_id, a.xnm, a.xqm, a.jxb_id, a.jgh_id, a.zcd, a.xqj, a.jc, sCjsj, a.pkly ,'2'
           from jw_pk_kbsjb a
          where a.xnm = vXnm and a.xqm = vXqm and a.jxb_id = sJxb_id;

          insert into jw_xk_kbcdclb (cdkb_id, kb_id, cd_id, clsj, zcd, jc)
          select b.cdkb_id, b.kb_id, b.cd_id, sCjsj, b.zcd, b.jc
            from jw_pk_kbcdb b, jw_pk_kbsjb a
           where b.kb_id = a.kb_id and a.xnm = vXnm and a.xqm = vXqm and a.jxb_id = sJxb_id;

          delete from jw_pk_kbcdb a where
          exists(select 'X' from jw_pk_kbsjb b where a.kb_id = b.kb_id and b.xnm = vXnm and b.xqm = vXqm and b.jxb_id = sJxb_id );

          delete from jw_pk_kbsjb a where a.xnm = vXnm and a.xqm = vXqm and a.jxb_id = sJxb_id;

          insert into jw_pk_kbsjb(kb_id,xnm,xqm,jxb_id,jgh_id,zcd,xqj,jc,pkly)
          select kb_id,xnm,xqm,jxb_id,jgh_id,zc,xqj,jc,'4' from jw_pk_pysjlszhb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id;

          insert into jw_pk_kbcdb(kb_id,cd_id,zcd,jc)
          select kb_id,cd_id,zc,jc from jw_pk_pysjlszhb where xnm = vXnm and xqm = vXqm and jxb_id = sJxb_id and cd_id is not null;

          sSksjjxdd :=fn_jxbsjcdxx(sJxb_id, '0');
          sSksj   :=fn_jqzd(sSksjjxdd,'|',1);
          sSkdd   :=fn_jqzd(sSksjjxdd,'|',2);
          sSksjyw :=fn_jqzd(sSksjjxdd,'|',3);
          sSkddyw :=fn_jqzd(sSksjjxdd,'|',4);
          sSksjms :=fn_jxbsjcdxx(sJxb_id, '1');
          sKcjssj := fn_kcjssj(sJxb_id);
        update jw_jxrw_jxbxxb set sksj = sSksj,jxdd = sSkdd,sksjyw = sSksjyw,jxddyw = sSkddyw,sksjms =sSksjms,kcjssj = sKcjssj where jxb_id = sJxb_id;

          insert into jw_pk_pysjclztb(pysjclzt_id,xnm,xqm,jxb_id,rq,zcd,xqj,thrq,thzcd,thxqj,zt,ztms,cjjgh_id,cjsj)
                 values(sID,vXnm,vXqm,sJxb_id,sYrq,sYzc,sYxqj,sXrq,sXzc,sXxqj,'1','处理成功',vJgh_id,sCjsj);
         end;
        k := k +1 ;
        COMMIT;
        exception
          When others then
          rollback;
          continue;
        end;
        end loop;
      close Get_Pyjxbxx;
    end loop;
  close Get_Pysj;
       if i = k and i != 0 then
         vBj := '1';  --------执行完成
       elsif i > k and k != 0then
         vBj := '2';  --------部分执行完成
       else
         vBj := '0';  --------未执行成功
       end if;
 null;
end;

/

