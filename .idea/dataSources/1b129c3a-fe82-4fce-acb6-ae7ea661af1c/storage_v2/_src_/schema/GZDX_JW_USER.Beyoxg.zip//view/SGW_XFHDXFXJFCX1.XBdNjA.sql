create view SGW_XFHDXFXJFCX1 as
  select zyxy,jg_id, zyh_id,bh_id,njdm_id, xy, zymc,bjmc,xh,xh_id,xm,xb,mz,zzmm,xjzt,cc,njdm_id dqszj,xz,zjhm,hx,bx,yinghdxyxf,yhdxf,yinghdxyxjf,yhdxjf ,yinghdzxf,pyfayqzxf,pyfayqzxjf,yhdzxjf
from (select zyxy,jg_id, zyh_id,bh_id,njdm_id, xy, zymc,bjmc,xh,a.xh_id,xm,xb,mz,zzmm,xjzt,cc,njdm_id dqszj,xz,zjhm,hx.hx,bx.bx,yinghdxyxf,yhdxf.yhdxf,yinghdxyxjf,yhdxjf.yhdxjf,yinghdzxf,pyfayqzxf,pyfayqzxjf,yhdzxjf
		 from (select * from  SGW_XSJBXXB a where nvl(a.njdm_id,0)+nvl(xz,0)+5>=to_char(sysdate,'yyyy')) a
		 left join
		 (select  xh_id,wm_concat(kcmc||'/'||xf||'卷二成绩：'||(select dzmc from jw_cj_dzb  where jzdm=7 and  bfzcj>= qsf and bfzcj<jsf )||'卷一成绩：'||CASE WHEN  JYBFZCJ>=60 THEN 'P'   WHEN  JYBFZCJ=1 then  'F'     WHEN  JYBFZCJ=2 then  'H'
		   WHEN  JYBFZCJ=3 then  'Q' WHEN  JYBFZCJ=4 then  'U' WHEN  JYBFZCJ=5 then  'W'  ELSE 'U' end   ) hx   from   sgw_bhxy_byshzhcj  where
       kch_id not  in  (select  kch_id from  jw_bysh_pbshkc)  AND  kcxzdm='06' and  (bfzcj<60  or jybfzcj<60 )
     group   by xh_id
     ) hx on a.xh_id=hx.xh_id
     left join
     (select  xh_id,wm_concat(kcmc||'/'||xf||'卷二成绩：'||(select dzmc from jw_cj_dzb  where jzdm=7 and  bfzcj>= qsf and bfzcj<jsf )||'卷一成绩：'||CASE WHEN  JYBFZCJ>=60 THEN 'P'   WHEN  JYBFZCJ=1 then  'F'     WHEN  JYBFZCJ=2 then  'H'
       WHEN  JYBFZCJ=3 then  'Q' WHEN  JYBFZCJ=4 then  'U' WHEN  JYBFZCJ=5 then  'W'  ELSE 'U' end   ) bx from   sgw_bhxy_byshzhcj  where
      kch_id not  in  (select  kch_id from  jw_bysh_pbshkc) AND  kcxzdm='25'  and  (  jybfzcj<60 )  group   by xh_id
     ) bx on a.xh_id=bx.xh_id
     left join
     (select  xh_id, sum(nvl(xf,0)) yhdxf  from  (select xh_id,xf from  sgw_bhxy_byshzhcj   where  jybfzcj>=60 and bfzcj>=40 and   kcxzdm<>'06'
     union all  select xh_id,xf from  sgw_bhxy_byshzhcj   where  jybfzcj>=60 and bfzcj>=60 and   kcxzdm='06' )  group   by xh_id
    ) yhdxf on a.xh_id=yhdxf.xh_id
    left join
    (select  xh_id, sum(nvl(xf,0)*nvl(jd,0) ) yhdxjf from   sgw_bhxy_byshzhcj  where jybfzcj>=60 and bfzcj>=60  group   by xh_id
     ) yhdxjf on a.xh_id=yhdxjf.xh_id
 ) where 1=1
/

