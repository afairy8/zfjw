create function FN_BITTOZCMX_KZ(int_ZC in int,iWs in int,vBj in varchar2) return varchar2 is
  i       int;
  LoopCount int;
  returnstr varchar2(1000);
begin
   /**通过周次二进制计算出，周次明细**/
  if int_ZC = 0 then
    return '';
  end if;
  i := 0;
  returnstr:='';
  LoopCount:=iWs;
  if vBj = '1' then  ----从左到右
  while i <= LoopCount Loop
    if bitand (power(2,i),int_ZC)<>0 then
      if (returnstr = '') or (returnstr is null) then
       returnstr := '1';
       else
       returnstr := returnstr||'1';
       end if;
     ELSE
       if (returnstr = '') or (returnstr is null) then
       returnstr := '0';
       else
       returnstr := returnstr||'0';
       end if;
    End if;
    i := i + 1;
  End Loop;
  else  ----从右到左
   while i <= LoopCount Loop
    if bitand (power(2,i),int_ZC)<>0 then
      if (returnstr = '') or (returnstr is null) then
       returnstr := '1';
       else
       returnstr := '1'||returnstr;
       end if;
     ELSE
       if (returnstr = '') or (returnstr is null) then
       returnstr := '0';
       else
       returnstr := '0'||returnstr;
       end if;
    End if;
    i := i + 1;
  End Loop;
  end if;
  return(returnstr);
end FN_BITTOZCMX_KZ;

/

