create procedure p_xk_choose_zykc_2
(
  in_rwlx in varchar2,
  in_ids in varchar2,
  in_xsbxfs in varchar2,
  in_rlkz in varchar2,
  in_rlzlkz in varchar2,
  in_xh_id in varchar2,
  in_xkxnm in varchar2,
  in_xkxqm in varchar2,
  in_xklc in varchar2,
  in_xxkbj in varchar2,
  in_kch_id in varchar2,
  in_xkkz_id in varchar2,
  in_qz in varchar2,
  in_sxbj in varchar2,
  out_flag out varchar2,  --2:先行课未修；3:超过最大志愿数;4:;5:;6:;7:;8:;
  out_msg out varchar2
)
as
    v_count number;
    ispass varchar2(1);
    inzdzys varchar2(1);
    inxksj varchar2(1);
    isexist varchar2(1);
    havetyk varchar2(1);
    --v_kch_id varchar2(32);
    v_xzjxbCount number;
    v_xsmc varchar2(20);
    v_jxbmc varchar2(40);
    v_kcmc varchar2(40);
    v_xsdm varchar2(40);
    isfjxb varchar2(40);
    v_sfkzyxk varchar2(1);
    v_jxbrs number;
    v_krrl number;
    v_yxzrs number;
    v_bxrs number;
    v_yl number;
    v_index number;
    jxb_id_array mytype;
    xsbxf_array mytype;
    cursor cursor_xsxk(v_xh_id varchar2,v_xnm varchar2,v_xqm varchar2,v_kch_id varchar2) is
    select jxb_id,xh_id,rownum rwn from JW_XK_XSXKB where xh_id=v_xh_id and zy>0 and jxb_id in (select jxb_id from jw_jxrw_jxbxxb where kch_id=v_kch_id and xnm=v_xnm and xqm=v_xqm and fjxb_id is null) order by zy;
    cursor cursor_crash_jxb(v_xh_id varchar2,v_xnm varchar2,v_xqm varchar2,v_jxb_id varchar2,v_kch_id varchar2) is
           select distinct (select kcmc from jw_jh_kcdmb where kch_id = t1.kch_id) kcmc, t1.jxbmc into v_kcmc,v_jxbmc from (select c.kch_id, c.jxbmc, b.* from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jxrw_jxbxxb c where a.jxb_id = b.jxb_id and a.jxb_id = c.jxb_id and c.kch_id != v_kch_id and a.xh_id = v_xh_id and b.xnm = v_xnm and b.xqm = v_xqm) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id = v_jxb_id) t2 where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0;
    --select t1.jxbmc,t1.kcmc into v_jxbmc,v_kcmc from (select b.xqj,b.zcd,b.jc,a.jxb_id,c.jxbmc,(select kcmc from jw_jh_kcdmb where kch_id=c.kch_id) kcmc from jw_xk_xsxkb a,jw_pk_kbsjb b,jw_jxrw_jxbxxb c where a.jxb_id = b.jxb_id and a.jxb_id=c.jxb_id and a.xh_id=v_xh_id and b.xnm=v_xnm and b.xqm=v_xqm) t1,(select * from jw_pk_kbsjb where jxb_id=v_jxb_id) t2 where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0;
begin
    out_flag := '1';
    v_xsdm := '01';
    v_xsmc := '讲课';
    jxb_id_array := my_split(in_ids,',');
    xsbxf_array := my_split(in_xsbxfs,',');

    --判断当前是否在选课时间内
    select count(*) into inxksj from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if inxksj = '0' then
       out_flag := '2';--不在选课时间内
       out_msg := '选课时间已过，不可再选！';
       goto nextOne; --跳出循环
    end if;

    --最大志愿数判断
    select case when m.xzzys>=n.zdzys then '0' else '1' end into inzdzys from
    (
        select count(*) xzzys from jw_jxrw_jxbxxb a,jw_xk_xsxkb b
        where a.jxb_id=b.jxb_id and a.fjxb_id is null and a.xnm=in_xkxnm
        and a.xqm=in_xkxqm and a.kch_id=in_kch_id and b.xh_id=in_xh_id
    ) m,
    (
        select case when b.sfzyxk='1' then nvl(b.zdzys,'1') else 1 end zdzys
        from JW_XK_XKKZB a,JW_XK_XKKZXMB b where a.xkkz_id=b.xkkz_id and a.xkkz_id=in_xkkz_id
    ) n;
    if inzdzys = '0' then
       out_flag := '3';--超出最大志愿数
       out_msg := '超过最大志愿数限制，不可再选！';
       goto nextOne; --跳出循环
    end if;



    if in_xxkbj='1' then
        select nvl((select sfkzyxk from jw_xk_qtxkgzb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id='tongyi'),'0') into v_sfkzyxk from dual;
        if v_sfkzyxk='1' then --判断先行课（预修课）控制是否设置为控制
            select case when count(1)>0 then '1' else '0' end into ispass  from
            (
                select a.kch_id,a.yxkch_id from jw_jh_kcyxyqb a,jw_xk_xsxkb b,jw_jxrw_jxbxxb c
                where a.kch_id=c.kch_id and b.jxb_id=c.jxb_id and c.xnm||c.xqm!=in_xkxnm||in_xkxqm
                and b.xh_id = in_xh_id and a.kch_id = in_kch_id
            );
            if ispass = '0' then
               out_flag := '4';--先行课未修
               out_msg :='该课程的先行课未修，不可选！';
               goto nextOne; --跳出检验
            end if;
        end if;
    end if;

    --判断学生是否已选体育课
    select case when count(*)>0 then '1' else '0' end into havetyk from jw_jxrw_jxbxxb a,jw_xk_xsxkb b,view_xk_tykdzb c,view_xk_tykdzb d where a.jxb_id=b.jxb_id  and a.kch_id=c.kch_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and b.xh_id=in_xh_id and d.kch_id=in_kch_id;
    if havetyk = '1' then
       out_flag := '5';--已选体育课
       out_msg :='您已选过体育课，不可再选！';
       goto nextOne; --跳出循环
    end if;

    --判断该课程学生是否已选过
    select count(*) into isexist from jw_xk_xsxkb a where xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    if isexist = '1' then
       out_flag := '6';--该教学班该学生已选过
       goto nextOne; --跳出循环
    end if;

    --判断学生所选教学班的上课时间有无和其他已选课程冲突
    FOR i IN 1..jxb_id_array.count LOOP
        v_count := 0;
        --select count(*) into v_count from (select b.* from jw_xk_xsxkb a,jw_pk_kbsjb b where a.jxb_id = b.jxb_id and a.xh_id=in_xh_id and b.xnm=in_xkxnm and b.xqm=in_xkxqm) t1,(select * from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2 where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0;
        select count(*) into v_count from (select c.kch_id, c.jxbmc, b.* from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jxrw_jxbxxb c where a.jxb_id = b.jxb_id and a.jxb_id = c.jxb_id and c.kch_id != in_kch_id and a.xh_id = in_xh_id and b.xnm = in_xkxnm and b.xqm = in_xkxqm) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id = jxb_id_array(i)) t2 where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0;
        if v_count>0 then
           out_flag := '7';
           --select t1.jxbmc,t1.kcmc into v_jxbmc,v_kcmc from (select b.xqj,b.zcd,b.jc,a.jxb_id,c.jxbmc,(select kcmc from jw_jh_kcdmb where kch_id=c.kch_id) kcmc from jw_xk_xsxkb a,jw_pk_kbsjb b,jw_jxrw_jxbxxb c where a.jxb_id = b.jxb_id and a.jxb_id=c.jxb_id and a.xh_id=in_xh_id and b.xnm=in_xkxnm and b.xqm=in_xkxqm) t1,(select * from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2 where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0;
           select b.xsdm,b.xsmc into v_xsdm,v_xsmc from jw_jxrw_jxbxxb a,jw_jh_kcxsxxdmb b where a.xsdm=b.xsdm and a.jxb_id=jxb_id_array(i);
           if v_xsdm = '01' then
              out_msg := '该教学班的上课时间与';
           else
               out_msg := '子教学班的上课时间与';
           end if;
           v_index := 0;
           for p_crash_jxb in cursor_crash_jxb(in_xh_id,in_xkxnm,in_xkxqm,jxb_id_array(i),in_kch_id) loop
               if v_index = 0 then
                  out_msg := out_msg||'“'||p_crash_jxb.kcmc||'”的“'||p_crash_jxb.jxbmc||'”教学班';
                  v_index := 1;
               else
                  out_msg := out_msg||'、“'||p_crash_jxb.kcmc||'”的“'||p_crash_jxb.jxbmc||'”教学班';
               end if;
           end loop;
           out_msg := out_msg||'有冲突！';
           goto nextOne; --跳出循环
        end if;
    end LOOP;

    --检测全部合格时将教学班加入学生的选课表中
    FOR i IN 1..jxb_id_array.count LOOP
    	if i=1 and in_qz='0' then
    		--select kch_id into v_kch_id from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(1);
        --一门课程可能有多个可选教学班志愿，新加一个志愿时，要排在已选志愿的最后面
    		select count(*)+1 into v_xzjxbCount from JW_XK_XSXKB where xh_id=in_xh_id and zy>0 and jxb_id in (select jxb_id from jw_jxrw_jxbxxb where kch_id=in_kch_id and xnm=in_xkxnm and xqm=in_xkxqm and fjxb_id is null);
    		if v_xzjxbCount > 1 then
               for p_xsxk in cursor_xsxk(in_xh_id,in_xkxnm,in_xkxqm,in_kch_id) loop
                   update JW_XK_XSXKB set zy=p_xsxk.rwn where jxb_id=p_xsxk.jxb_id and xh_id=p_xsxk.xh_id;
               end loop;
    		end if;
      elsif i=1 then
        v_xzjxbCount := 0;
      end if;

      if in_rlkz!='1' and in_rlzlkz!='1' then --不控制容量时，不统计教学班选中人数信息
    	   select nvl(fjxb_id,'0') into isfjxb from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(i);
      elsif in_rwlx='1' and in_rlkz='1' then
         select nvl(fjxb_id,'0'),nvl(a.jxbrs,0) jxbrs,nvl(a.krrl,0) krrl,
  			      (select count(xh_id) from jw_xk_xsxkb where jxb_id=a.jxb_id) yxzrs,
             	(select count(xh_id) from jw_xk_xsxkb m where jxb_id=a.jxb_id and exists(select '1' from JW_XJGL_XSXJXXB n,jw_jxrw_jxbhbxxb o where o.jxb_id=a.jxb_id and n.xh_id=m.xh_id and n.zyh_id=o.zyh_id and n.njdm_id=o.njdm_id)) bxrs
              into isfjxb,v_jxbrs,v_krrl,v_yxzrs,v_bxrs
       from jw_jxrw_jxbxxb a where a.jxb_id=jxb_id_array(i);
      else  --in_rwlx='1' and in_rlzlkz='1' 和 in_rwlx!='1' 时都只是控制总容量
         select nvl(fjxb_id,'0'),nvl(a.jxbrs,0) jxbrs,nvl(a.krrl,0) krrl,
  			      (select count(xh_id) from jw_xk_xsxkb where jxb_id=a.jxb_id) yxzrs,0 bxrs
              into isfjxb,v_jxbrs,v_krrl,v_yxzrs,v_bxrs
       from jw_jxrw_jxbxxb a where a.jxb_id=jxb_id_array(i);
      end if;
      --父教学班有排志愿的需要，而子教学班统一将志愿字段设为０
    	if isfjxb != '0' then
    		 v_xzjxbCount := 0;
    	end if;

      if in_rlkz!='1' and in_rlzlkz!='1' then
         v_yl := 1;
      elsif in_rwlx='1' and in_rlkz='1' and xsbxf_array(i)='1' then
         v_yl := v_jxbrs - v_bxrs;
      elsif in_rwlx='1' and in_rlkz='1' and xsbxf_array(i)='0' then
         v_yl := v_krrl - (v_yxzrs - v_bxrs);
      else
         v_yl := v_jxbrs + v_krrl - v_yxzrs;
      end if;

      if v_yl > 0 then
        --将所选教学班依次插入到学生选课表中（包括父教学班）
      	--insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy) values (jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount);
        --xkbj=10(学生自选)，20(配课生成)，30(管理员调课生成)
	    	insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj) values (jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10');
      else
          out_flag := '-1';
          goto nextOne; --跳出循环
      end if;
    end LOOP;

    <<nextOne>>

    if out_flag = '-1' then
		   rollback;
    end if;
end;

/

