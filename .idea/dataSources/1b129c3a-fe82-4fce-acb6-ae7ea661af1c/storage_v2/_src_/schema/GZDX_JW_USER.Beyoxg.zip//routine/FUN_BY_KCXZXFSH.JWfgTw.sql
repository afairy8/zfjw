create function fun_by_kcxzxfsh(v_xh_id varchar2,v_tjsjz varchar2,v_tjkcxz varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_xf number;
   v_kcxzmc varchar2(50);
begin
    sJg := '合格';
    begin
       --根据课程类型获得总学分
           select kcxzmc into v_kcxzmc from jw_jh_kcxzdmb where kcxzdm=v_tjkcxz;
           select nvl(max(sum(xf)),0)xf, v_kcxzmc into v_xf,v_kcxzmc
             from (select cj.*,
                          row_number() over(partition by cj.xh_id, nvl(cj.sskch_id,cj.kch_id) order by cj.BFZCJ desc) rn
                     from jw_cj_xscjb cj
                    where cj.xh_id = v_xh_id
                      and cj.kcxzdm = v_tjkcxz
                      and bfzcj >= 60) a
            where rn = 1
            group by a.kcxzdm;

            if v_xf<v_tjsjz then
               sJg:= v_kcxzmc||'获得总学分'||v_xf||'低于'||v_tjsjz||'学分，不合格！';
            else
               sJg:= '合格！';
            end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_kcxzxfsh;

/

