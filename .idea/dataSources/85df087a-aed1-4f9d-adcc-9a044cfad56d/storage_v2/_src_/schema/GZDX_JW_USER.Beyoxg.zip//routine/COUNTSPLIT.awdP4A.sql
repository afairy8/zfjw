create function countSplit(v_a varchar2, v_b varchar2)
------统计两字符串中按逗号分割后的重复记录条数----------
  return number as
  counta number;

Begin
  counta := 0;
  select count(1)
    into counta
    from (SELECT REGEXP_SUBSTR(v_a,'[^,]+', 1, rownum) substrv_a
            FROM DUAL
          CONNECT BY ROWNUM <=
                     LENGTH(v_a) - LENGTH(REPLACE(v_a, ',', '')) + 1) aa,
         (SELECT REGEXP_SUBSTR(v_b,'[^,]+', 1, rownum) substrv_b
            FROM DUAL
          CONNECT BY ROWNUM <=
                     LENGTH(v_b) - LENGTH(REPLACE(v_b, ',', '')) + 1) bb
   where aa.substrv_a = bb.substrv_b;

  return counta;
end countSplit;

/

