create function get_thkchid(in_kch_id in varchar2) return varchar2 is
  out_kch_id varchar2(30);
begin
       select t.kch_id into out_kch_id from
       jw_jh_kcthzb t,jw_jh_kcdmb k where 1=1 and t.kch_id=k.kch_id and k.tkbj='0' and t.kcthz_id in
       (select t1.kcthz_id from jw_jh_kcthzccb t1 where t1.kcthzz_id in
       (select t.kcthz_id  from jw_jh_kcthzb t,jw_jh_kcdmb kc where t.kch_id = in_kch_id and kc.kch_id=t.kch_id)
       );
  return(out_kch_id);
end get_thkchid;

/

