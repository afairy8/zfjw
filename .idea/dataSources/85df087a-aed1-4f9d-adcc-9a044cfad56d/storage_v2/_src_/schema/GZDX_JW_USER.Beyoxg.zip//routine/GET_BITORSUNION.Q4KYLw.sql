create function Get_BitorsUnion(vWeeksUnion IN varchar2)
---1,3,5,7合集组合为 7 即周次1-1，1-2，1-1.3-3，1-3 合集组合为1-3
---周合集转为二进制或运算
--11001  1+8+16    = 25
--01101  1+4+8     = 13

--11101  1+4+8+16  = 29
--例如WeeksUnionToBitor(13,25) = 29
return number
as
  type Type_weekArray is table of int;
  i integer;
  k integer;
  aWeek integer;  ---周变量
  WeeksCount integer;--周组数
  WeeksUnion integer;--第一周
  WeekArray Type_weekArray := Type_weekArray(); ---周数组
begin
   WeeksCount := fn_jsfgfs(vWeeksUnion,',');
   if WeeksCount > 0 then
   i := 1;
   k := 1;
   for aWeek in 0..WeeksCount  loop  ---log(2,vBinary)取整


      weekArray.Extend;
      weekArray(i) :=  fn_jqzd(vWeeksUnion,   ---原数据
                                ',',      ---分格符
                                aWeek+1);
      i := i + 1;
  end loop;

  WeeksUnion := weekArray(1);
  for k in 1..WeeksCount loop
   WeeksUnion := bitor(WeeksUnion,weekArray(k+1));
  end loop;
  else
   WeeksUnion := vWeeksUnion;
  end if;
  return WeeksUnion;
end;


/

