create function Fn_getSyxw
(vPyfaxx_id varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vZyw varchar2,---授予学位显示中英文（0:中文;1:英文）
 vBj  varchar2) return varchar2
as
 sSyxw varchar2(200); ---授予学位
 sZyh_id varchar2(32);
 sNjdm_id varchar2(32);
begin
     sSyxw:='';

     if vZyh_id is null then
        select max(zyh_id) into sZyh_id from jw_jh_pyfaxxb where pyfaxx_id=vPyfaxx_id;
     else
        sZyh_id:=vZyh_id;
     end if;

     if vNjdm_id is null then
        select max(njdm_id) into sNjdm_id from jw_jh_PYFASYNJB where pyfaxx_id=vPyfaxx_id;
     else
        sNjdm_id:=vNjdm_id;
     end if;

     if vBj = '0' then---培养方案

        select (select case when vZyw='0' then max(a.mc) when vZyw='1' then max(a.ywmc) else max(a.mc) end
                  from zftal_xtgl_jcsjb a, zftal_xtgl_xxzydmb b
                 where a.lx='0027' and a.dm=b.xwm and b.pcdm=dlzydzb.njdm_id and b.zydm=dlzydzb.xxzydm) into sSyxw
          from jw_jh_dlzydzb dlzydzb
         where zyh_id = sZyh_id
           and njdm_id = sNjdm_id;

     end if;

     if sSyxw is null then
        sSyxw:='';
     end if;

    return sSyxw;

  Exception When Others Then
  return null;
end Fn_getSyxw;

/

