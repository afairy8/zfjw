create function fn_getOrderStr    --获取顺序名称String
  (
       table_str in varchar2,                --表名
       mc_str in varchar2,                   --名称列名
       dm_str in varchar2,                   --代码列名
       dms_str in varchar2,                  --多个代码组合的字串
       yfg_str in varchar2,                  --分割符(参数)
       xfg_str in varchar2                   --分割符(返回值)
  )
  return varchar2 is
  dm_array     mytype;
  sqlstr       varchar2(4000);
  tempsqlstr   varchar2(4000);
  tempsqlstr2  varchar2(4000);
  result_str   varchar2(4000);
  temp_str     varchar2(400);
  tempCount    number;
begin
    sqlstr := 'select '||mc_str||' from '||table_str||' where '||dm_str||' = ';
    dm_array := my_split(dms_str,yfg_str);
  	FOR i IN 1..dm_array.count LOOP
   	   tempsqlstr := sqlstr||''''||dm_array(i)||'''';
       tempsqlstr2:='select count(*) from ('||tempsqlstr||')';
       execute immediate tempsqlstr2 into tempCount;
       if to_number(tempCount)>0 then
          execute immediate tempsqlstr into temp_str;
          if temp_str is not null then
             if result_str is null then
                result_str := temp_str;
             else
                result_str := result_str||xfg_str||temp_str;
             end if;
          end if;
       end if;
    end LOOP;
    return result_str;
end fn_getOrderStr;

/

