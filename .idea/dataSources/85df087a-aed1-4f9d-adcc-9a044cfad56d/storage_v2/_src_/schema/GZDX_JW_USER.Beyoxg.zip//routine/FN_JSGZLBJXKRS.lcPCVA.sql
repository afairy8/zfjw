create function fn_jsgzlBjxkrs
(vXnm    varchar2,
 vXqm    varchar2,
 vJxb_id varchar2,
 vZc     varchar2,
 vBj     varchar2) return number /**---计算教师工作量班级人数----**/
 as
  iBjxkrs number; /**---班级选课人数**/
begin
  iBjxkrs := 0;
  begin
  if vBj = '0' then
   select count(distinct xj.xh_id) into iBjxkrs from jw_xk_xsxkb xk,jw_xjgl_xsxjxxb xj,JW_JH_BJJDB bjjd
    where xk.xh_id = xj.xh_id
      and bjjd.bh_id = xj.bh_id
      and bjjd.xnm = vXnm
      and bjjd.xqm = vXqm
      and xj.xnm = vXnm
      and xj.xqm = vXqm
      and xk.xnm = vXnm
      and xk.xqm = vXqm
      and xk.jxb_id = vJxb_id
      and bjjd.zc = vZc;
   if iBjxkrs = 0 then
   select count(distinct xj.xh_id) into iBjxkrs from
    jw_xk_xsxkb xk,jw_xjgl_xsxjxxb xj,jw_jxrw_jxbxxb jxb,jw_jxrw_jxbhbxxb hb
    where xk.xh_id = xj.xh_id
      and xk.jxb_id = vJxb_id
      and xk.xnm = vXnm
      and xk.xqm = vXqm
      and xj.xnm = vXnm
      and xj.xqm = vXqm
      and xj.bh_id = hb.bh_id
      and jxb.jxb_id = hb.jxb_id
      and jxb.xnm = vXnm
      and jxb.xqm = vXqm
      and jxb.kkzt = '1'
      --and jxb.sksj is null
      and jxb.bpkbj = '1'
      and exists(select 'x' from jw_jh_kcxsxxdmb xsdm where jxb.xsdm =  xsdm.xsdm and xsdm.xsmc like '%课程设计%')
      and to_number(jxb.qsz) <= to_number(vZc)
      and to_number(jxb.zzz) >= to_number(vZc);
    end if;
  end if;
  exception
    When others then
      iBjxkrs :=  0;
  end;
  return iBjxkrs;
end fn_jsgzlBjxkrs;

/

