create function WeekssToBitary(vQsz IN NUMBER,vJsz IN NUMBER)---起始周与结束周单（single）转换为二进制数,如：1-2 转为1
return number is
i integer;
aweek integer;
aWeeks integer;  ---周变量
weeks varchar2(100);
begin
  aWeeks := 0;
  aweek := 0;
  if vJsz = 0 then
    weeks := fn_bittozc(vQsz*2)||',';
    for i in 1..fn_jsfgfs(weeks,',') loop
      aweek := fn_jqzd(weeks,',',i);
    if mod(aweek,2) > 0 then
       aWeeks := aWeeks + power(2,aweek-1);
      end if;
    end loop;
    else
  for i in vQsz..vJsz loop
     if mod(i,2) > 0 then
        aWeeks := aWeeks + power(2,i-1);
   end if;
  end loop;
  end if;
  return aWeeks;
end;


/

