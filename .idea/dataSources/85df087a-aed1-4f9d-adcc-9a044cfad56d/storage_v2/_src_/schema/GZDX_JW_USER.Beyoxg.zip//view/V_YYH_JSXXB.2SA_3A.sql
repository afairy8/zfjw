create view V_YYH_JSXXB as
  select zgh,(select zcm from jw_jg_zyjszcb where zcmc=zc) zc,zc zcmc from jsxxb v
/

