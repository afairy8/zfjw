create Procedure Pk_Jxbhbpktb(vJxb_id in varchar2)---教学班合班排课情况同步
as
v_kb_id varchar2(32); ----课表id
cursor Get_Jxbhbxx is     ----查询教学班合班信息游标---
select n.jxb_id,n.jgh_id,jxb.xqh_id,jxb.xnm,jxb.xqm,m.bbbj
from jw_pk_bbfzb m,jw_jxrw_jxbjsrkb n,jw_jxrw_jxbxxb jxb
where m.jxb_id=n.jxb_id and m.jxb_id=jxb.jxb_id and m.jxb_id != vJxb_id and m.bbbj = '1'
  and exists(select 'x' from jw_pk_bbfzb where bbfz_id=m.bbfz_id and jxb_id=vJxb_id);
Cur_Jxbhbxx Get_Jxbhbxx%rowtype;

cursor Get_kbid is     ----查询课表id游标---
select kb_id from jw_pk_kbsjb where jxb_id = vJxb_id;
Cur_kbid Get_kbid%rowtype;
-----------------------------------------------------------------------------------------------------------------------
begin
----合班教学班循环
for Cur_Jxbhbxx in Get_Jxbhbxx loop
  ---先删课表场地数据
  delete from jw_pk_kbcdb where kb_id in (select kb_id from jw_pk_kbsjb where jxb_id = Cur_Jxbhbxx.jxb_id);
  ---再删课表时间数据
  delete from jw_pk_kbsjb where jxb_id = Cur_Jxbhbxx.jxb_id;

  for Cur_kbid in Get_kbid loop
    v_kb_id:=sys_guid();
    ---插入课表时间数据
    insert into jw_pk_kbsjb(kb_id, xnm, xqm, jxb_id, jgh_id, zcd, xqj, jc, pkly, czsj)
    select v_kb_id, xnm, xqm, Cur_Jxbhbxx.jxb_id, jgh_id, zcd, xqj, jc, pkly, TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') from jw_pk_kbsjb where kb_id = Cur_kbid.kb_id;
    ---插入课表场地数据
    insert into jw_pk_kbcdb(cdkb_id, kb_id, cd_id, zcd, jc, czsj)
    select sys_guid(), v_kb_id, cd_id, zcd, jc, TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') from jw_pk_kbcdb where kb_id = Cur_kbid.kb_id;


  end loop;

  ----起始结束周、任课教师、主辅讲
  --先删除
  delete from jw_jxrw_jxbjsrkb where jxb_id = Cur_Jxbhbxx.jxb_id;
  --再插入
  insert into jw_jxrw_jxbjsrkb(jxb_id,jgh_id,xqm,sknr,sfzj,qrbz,qsjsz,sfcjlrjs,jcfs,jsgzl,rlgzl,rlgzljgh_id,rlgzlsj,yjsgzl,sfjxrllrjs)
  select Cur_Jxbhbxx.jxb_id,jgh_id,xqm,sknr,sfzj,qrbz,qsjsz,sfcjlrjs,jcfs,jsgzl,rlgzl,rlgzljgh_id,rlgzlsj,yjsgzl,sfjxrllrjs from jw_jxrw_jxbjsrkb where jxb_id = vJxb_id;

  ----教学班信息
  update jw_jxrw_jxbxxb set
      sksj = (select sksj from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      sfkxk = (select sfkxk from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      jxdd = (select jxdd from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      sksjms = (select sksjms from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      psjzt = (select psjzt from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      pcdzt = (select pcdzt from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      jsxx = (select jsxx from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
  xqh_id = (select xqh_id from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      cdxqh_id = (select cdxqh_id from jw_jxrw_jxbxxb where jxb_id = vJxb_id),
      kcjssj = (select kcjssj from jw_jxrw_jxbxxb where jxb_id = vJxb_id)
    where jxb_id = Cur_Jxbhbxx.jxb_id;

end loop;
end;

/

