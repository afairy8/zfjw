create function FN_GetXsjhkcXdzt(v_xh_id varchar2,v_kch_id varchar2,v_kcxzdm varchar2,v_bfzcj varchar2) return varchar2
/****查询学生计划课程 的修读状态 kwy ****/
as
   xdzt varchar2(20);
begin
        select
             (case when (select count(1)
                       from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                      where b.xrdz_id = t.rdz_id
                        and b.shjg = '3'
                        and b.xh_id = v_xh_id
                        and t.kch_id = v_kch_id) > 0 then
                '6'
               when (select count(1)
                       from jw_cj_xsgrjhdtb t, jw_cj_xsgrdtzb b
                      where t.kcthzh_id = b.kcthzh_id
                        and b.zszt = '3'
                        and t.xh_id = v_xh_id
                        and t.kch_id = v_kch_id) > 0 then
                '5'
               when (select count(1)
                       from jw_cj_xsgrcjdtb t, jw_cj_xsgrdtzb b, jw_jxrw_jxbxxb jxb
                      where t.kcthzh_id = b.kcthzh_id
                        and t.jxb_id = jxb.jxb_id
                        and b.zszt = '3'
                        and t.xh_id = v_xh_id
                        and jxb.kch_id = v_kch_id) > 0 then
                '7'
               when (select count(1)
                       from jw_xk_xsxkb t
                      where t.xh_id = v_xh_id
                        and t.kch_id = v_kch_id) = 0 and
                    (select count(1)
                       from jw_cj_xscjb cj
                      where cj.kcxzdm = v_kcxzdm
                        and cj.xh_id = v_xh_id
                        and nvl(cj.sskch_id, cj.kch_id) = v_kch_id) = 0 then
                '3'
               when (select count(1)
                       from jw_xk_xsxkb t
                      where t.xh_id = v_xh_id
                        and t.kch_id = v_kch_id
                        and v_bfzcj is null
                        and not exists
                      (select 1 from jw_cj_xscjb cj
                              where cj.kcxzdm = v_kcxzdm
                                and cj.xh_id = v_xh_id
                                and nvl(cj.sskch_id, cj.kch_id) = t.kch_id)) > 0 then
                '1'
               when v_bfzcj < 60 then
                '2'
               when v_bfzcj >= 60 then
                '4'

             end)  into xdzt

           from dual;

    if xdzt is null then
       xdzt := 0;
    end if;
    return xdzt;
end FN_GetXsjhkcXdzt;

/

