create function Get_Jxbpkrs1(
vXnm varchar2,
vXqm varchar2,
vKch_id varchar2,
vJxb_id varchar2,
vNjdm_id varchar2,
vZyh_id varchar2,
vBh_id varchar2,
vBj varchar2) return number  ---教学班配课人数----  标记目前不为1、2时 可传专业方向信息--
as
   rs number;
   xkrs number;
   pkrs number;
   qtpkrs number;
   xsrs number;
   sFjxb_id varchar2(50);
   sXsdm varchar2(10);
begin
    begin
       if vBj = '1' then  ---所属班级对应教学任务配课人数
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select count(a.xh_id) into rs from jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xh_id = b.xh_id
                                                  and a.jxb_id = vJxb_id
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  --and a.xkbj ='20'
                                                  and b.sfzx = '1';
       end if ;
       if vBj = '2' then ---所属班级对应教学任务配课人数
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select fjxb_id,xsdm into sFjxb_id,sXsdm from jw_jxrw_jxbxxb where xnm = vXnm and xqm = vXqm and jxb_id = vJxb_id;
         if sFjxb_id is null then
           select count(a.xh_id) into rs from jw_jxrw_jxbxxb t,jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where t.xnm = vXnm
                                                  and t.xqm = vXqm
                                                  and t.jxb_id = a.jxb_id
                                                  and t.sfzjxb = '1'
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xh_id = b.xh_id
                                                  and a.kch_id = vKch_id
                                                  and t.kch_id = vKch_id
                                                  and b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and b.sfzx = '1';
           else
         select count(a.xh_id) into rs from jw_jxrw_jxbxxb t,jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where t.xnm = vXnm
                                                  and t.xqm = vXqm
                                                  and t.jxb_id = a.jxb_id
                                                  and t.sfzjxb = '1'
                                                  and t.xsdm = sXsdm
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xh_id = b.xh_id
                                                  and a.kch_id = vKch_id
                                                  and t.kch_id = vKch_id
                                                  and b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and b.sfzx = '1';
        end if;
       end if ;

       if vBj = '3' then  ---所属班级对应教学任务配课人数
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select count(a.xh_id) into rs from jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xh_id = b.xh_id
                                                  and a.jxb_id = vJxb_id
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  ;
       end if ;

       if vBj != '1' and vBj != '2' and vBj != '3' then
         select fjxb_id,xsdm into sFjxb_id,sXsdm from jw_jxrw_jxbxxb where xnm = vXnm and xqm = vXqm and jxb_id = vJxb_id;
         ----所属班级对应教学任务配课人数---
         select count(a.xh_id) into pkrs from jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and a.xh_id = b.xh_id
                                                  and a.jxb_id = vJxb_id
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and decode(vBj,'wfx',1,b.zyfx_id,2,0) > 0
                                                  and b.sfzx = '1';
          if sFjxb_id is null then ---理论教学任务
            select count(a.xh_id) into qtpkrs from jw_jxrw_jxbxxb t ,jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where t.xnm = vXnm
                                                  and t.xqm = vXqm
                                                  and t.jxb_id = a.jxb_id
                                                  and t.jxb_id != vJxb_id
                                                  and t.kch_id = vKch_id
                                                  and t.sfzjxb = '1'
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xnm = b.xnm
                                                  and a.xqm = b.xqm
                                                  and a.xh_id = b.xh_id
                                                  and a.jxb_id != vjxb_id
                                                  and a.kch_id = vKch_id
                                                  and b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and decode(vBj,'wfx',1,b.zyfx_id,2,0) > 0
                                                  and b.sfzx = '1';
            else       ---子学时教学任务 如理论带实验的实验教学任务部分
             select count(a.xh_id) into qtpkrs from jw_jxrw_jxbxxb t ,jw_xk_xsxkb a, jw_xjgl_xsxjxxb b
                                                where t.xnm = vXnm
                                                  and t.xqm = vXqm
                                                  and t.jxb_id = a.jxb_id
                                                  and t.jxb_id != vJxb_id
                                                  and t.kch_id = vKch_id
                                                  and t.fjxb_id is not null
                                                  and t.xsdm = sXsdm
                                                  and a.xnm = vXnm
                                                  and a.xqm = vXqm
                                                  and a.xnm = b.xnm
                                                  and a.xqm = b.xqm
                                                  and a.xh_id = b.xh_id
                                                  and a.jxb_id != vjxb_id
                                                  and a.kch_id = vKch_id
                                                  and b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and decode(vBj,'wfx',1,b.zyfx_id,2,0) > 0
                                                  and b.sfzx = '1';
          end if;
         ----学生人数
         select count(b.xh_id) into xsrs from jw_xjgl_xsxjxxb b
                                                where b.xnm = vXnm
                                                  and b.xqm = vXqm
                                                  and b.njdm_id = vNjdm_id
                                                  and b.zyh_id = vZyh_id
                                                  and (case when vBh_id = 'wbj' then  b.bh_id else vBh_id end) = b.bh_id
                                                  and decode(vBj,'wfx',1,b.zyfx_id,2,0) > 0
                                                  and b.sfzx = '1';
        xkrs := pkrs + qtpkrs;
        if xkrs >= xsrs and xkrs != 0 then
          rs := 1;
          else
          rs := 0;
        end if;
       end if ;

    exception
        When others then
          rs := null;
    end;
    return rs ;
end Get_Jxbpkrs1;

/

