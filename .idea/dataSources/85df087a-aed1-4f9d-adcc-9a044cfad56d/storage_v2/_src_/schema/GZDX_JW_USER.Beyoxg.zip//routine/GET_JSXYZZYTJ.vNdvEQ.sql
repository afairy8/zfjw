create function get_jsxyzzytj(v_xnm varchar2,
                                         v_xqm varchar2,
                                         v_njdm_id varchar2,
                                         v_zryh_id varchar2,
                                         v_zyh_id varchar2,
                                         v_bh_id varchar2,
                                         v_xh_id varchar2,
                                         v_tjz varchar2,
                                         v_tjz1 varchar2,
                                         v_tjxh number)
Return varchar2
as
     sFhjg varchar2(2000);
     sPjgf    number;--平均录取高分
     sPjdf    number;--平均录取低分
     sPjxfjd  number;--平均学分绩点
     sJqxfjd  number;--加权学分绩点
     sTc      varchar2(200);--特长
     sBjgmc   number;--不及格门次
     sJqpmbfb varchar2(32);--加权排名百分比
     sYdsqs   number;--转专业异动申请数
     sZyjhz   number;--专业间互转限制
     sJqpms   number;--加权排名数据条数
     sZdkcxzBjgmc   varchar2(2000);--指定课程性质不及格门次
     sZdkclbBjgmc   number;--指定课程类别不及格门次
     sKcxzmc  varchar2(200);--课程性质名称
     sKclbmc  varchar2(200);--课程类别名称
     sXnxqmc  varchar2(200);--课程性质名称
     sKjxms   number;--考级项目数
     sBmxms   number;--报名的项目数
     sXmmc    varchar2(200);--项目名称
     sJgxms   number;--及格项目数
     sSxnxq   varchar2(32);--上学期
     sXqpmbfb varchar2(32);--学期排名百分比
     sXszzys  varchar2(32);--学生转专业数
     sCfjls   varchar2(32);--学生转专业数
     sKcxzs   number;--课程性质数
     sJqqzfw  varchar2(2);--加权平均分排名、占比取值范围0：单学期   1：历年
     sJqtjms  varchar2(10);--加权范围描述
     sCount1  number;
     sCount2  number;
     sZdkc    varchar2(400);--指定课程
     s_tjzs mytype;  --指定课程成绩要求tjz
     s_kcfs mytype; --指定课程成绩要求kchid
     s_kcmc varchar2(100);
     s_tjmc varchar2(100);--条件名称
     sJqcj varchar2(8);
     sMldm varchar2(4);
     sZrmldm varchar2(4);
     sZdz varchar2(4000);--字段值
begin
     select substr(zdz,0,1) into sJqqzfw from zftal_xtgl_xtszb where zdm = 'JQQZFS';
     if sJqqzfw = '0' then
        sJqtjms := '单学期';
     else
        sJqtjms := '历年';
     end if;
     if v_tjxh = 6 then--因有专业特长需转专业
        select a.tc into sTc from jw_xjgl_xsjbxxb a where a.xh_id = v_xh_id;
     end if;

     if v_tjxh = 14 then--学生在参加转专业考试前必须通过等级考试项目
        sKjxms := fn_jsfgfs(v_tjz,',')+1;
     end if;

     if v_tjxh = 1 or v_tjxh = 2 or v_tjxh = 3 or v_tjxh = 4 then
       select nvl(round(avg(rxzf), 2),0) into sPjgf from jw_xjgl_xsjbxxb where zyh_id=v_zyh_id and njdm_id=v_njdm_id and sfzx='1';
       select nvl(round(avg(rxzf), 2),0) into sPjdf from jw_xjgl_xsjbxxb where zyh_id=v_zryh_id and njdm_id=v_njdm_id and sfzx='1';
     end if;

     case v_tjxh
          when 1 then
               if sPjgf < sPjdf then
                  sFhjg := '转出专业平均录取分：'||sPjgf||'小于转入专业平均录取分：'||sPjdf||'，不符合转专业条件。';
               end if;
          when 2 then
               if sPjgf > sPjdf then
                  sFhjg := '转出专业平均录取分：'||sPjgf||'大于转入专业平均录取分：'||sPjdf||'，不符合转专业条件。';
               end if;
          when 3 then
               if sPjgf < sPjdf then
                  sFhjg := '转出专业平均录取分：'||sPjgf||'小于转入专业平均录取分：'||sPjdf||'，不符合转专业条件。';
               end if;
          when 4 then
               if sPjgf > sPjdf then
                  sFhjg := '转出专业平均录取分：'||sPjgf||'大于转入专业平均录取分：'||sPjdf||'，不符合转专业条件。';
               end if;
          when 5 then--所学课程平均学分绩点需达到
               select case when nvl(sum(case when t.jd is null then '0' else t.xf end ),'0') = '0' then null else nvl(round(sum(t.jd*t.xf)/sum(case when t.jd is null then '0' else t.xf end ),2),0) end into sPjxfjd from
               (select row_number() over(partition by nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) pm, a.kch_id, a.bfzcj, a.xf,
                       fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,a.cjxzm,a.kcbj,null,a.cjbz,a.jd,a.bfzcj,'cjb','tj','0') as jd
               from jw_cj_xscjb a where  a.xh_id = v_xh_id and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)) t where pm='1';
               if v_tjz != '-1' and sPjxfjd<v_tjz then
                  sFhjg := sFhjg||'平均学分绩点：'||sPjxfjd||'小于条件值'||v_tjz||'，不符合转专业条件。';
               end if;
          when 6 then--因有专业特长需转专业
               if sTc is null then
                  sFhjg := '无特长，不符合转专业条件。';
               end if;
          when 7 then
               dbms_output.put_line('无');
          when 8 then
               select zdz into sZdz from jw_jcdml_xtnzb where xtnz_id='CJZFKG';--成绩作废开关1课程2教学班
               if sZdz='2' then
                  select count(*) into sBjgmc from (select max(a.bfzcj) bfzcj from jw_cj_xscjb a where a.xh_id = v_xh_id and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)
                                                                                                and not exists(select 'X' from jw_cj_cjjglxsqb b where b.sqxnm=a.xnm and b.sqxqm=a.xqm and b.xh_id=a.xh_id
                                                                                                                                                   and b.jxb_id=a.jxb_id) group by a.kch_id) where bfzcj < 60;
               else
                  select count(*) into sBjgmc from (select max(a.bfzcj) bfzcj from jw_cj_xscjb a where a.xh_id = v_xh_id and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)
                                                                                                and not exists(select 'X' from jw_cj_cjjglxsqb b where b.sqxnm=a.xnm and b.sqxqm=a.xqm and b.xh_id=a.xh_id
                                                                                                                                                   and b.kch_id=a.kch_id) group by a.kch_id) where bfzcj < 60;
               end if;

               if sBjgmc > 0 then
                  sFhjg := '存在不及格课程，不符合转专业条件。';
               end if;
          when 9 then--所学课程平均学分绩点需名列专业前
               if sJqqzfw = '0' then
                   select count(*) into sJqpms
                     from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                     and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
               else
                   select count(*) into sJqpms
                     from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                     and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
               end if;

               if sJqpms > 0 then
                  if sJqqzfw = '0' then
                       select case when a.njzyrs is null then '0' else round(a.pjjdpm/a.njzyrs,4)*100||'' end into sJqpmbfb
                          from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                          and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                  else
                       select case when a.njzyrs is null then '0' else round(a.pjjdpm/a.njzyrs,4)*100||'' end into sJqpmbfb
                          from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                          and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                  end if;

                  if sJqpmbfb is null then
                     sFhjg := '平均学分绩点排名百分比为空，数据异常！';
                  else
                     if v_tjz != '-1' and sJqpmbfb*1>v_tjz*1 then
                        sFhjg := '平均学分绩点排名超出专业总人数的'||v_tjz||'%，不符合转专业条件。';
                     end if;
                  end if;
               else
                  sFhjg := sJqtjms||'学生排名未统计，无数据异常！';
               end if;
          when 10 then
               dbms_output.put_line('无');
          when 11 then
               select count(*) into sYdsqs from jw_xjgl_xjydb a where a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)
               and a.ydlbm = '23' and a.shzt not in ('4','5') and a.xh_id=v_xh_id;
               if sYdsqs > 0 then
                  sFhjg := '已经申请过学籍异动转专业。';
               end if;
          when 12 then
               if v_tjz is not null then
                 select Get_Tjjls(12,v_xnm,v_xqm,v_xh_id,v_tjz,'0') into sZdkclbBjgmc from dual;
                 if sZdkclbBjgmc > 0 then
                    select wm_concat(kcxzmc) into sKcxzmc from jw_jh_kcxzdmb where ','||v_tjz||',' like '%,'||kcxzdm||',%';
                    sFhjg := '课程性质为（'||sKcxzmc||'）的课程存在不及格课程，不符合转专业条件。';
                 end if;
               end if;
               if v_tjz1 is not null then
                 select Get_Tjjls(12,v_xnm,v_xqm,v_xh_id,v_tjz1,'1') into sZdkclbBjgmc from dual;
                 if sZdkclbBjgmc > 0 then
                    select wm_concat(kclbmc) into sKclbmc from jw_jh_kclbdmb where ','||v_tjz1||',' like '%,'||kclbdm||',%';
                    sFhjg := '课程类别为（'||sKclbmc||'）的课程存在不及格课程，不符合转专业条件。';
                 end if;
               end if;
          when 13 then
               if v_tjz is not null then
                 select count(*) into sZdkclbBjgmc from
                 (select max(a.bfzcj) bfzcj, a.jxb_id, a.kch_id, a.kcxzdm from jw_cj_xscjb a
                 where a.xh_id = v_xh_id and v_tjz <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0) group by a.jxb_id, a.kch_id, a.kcxzdm)
                 where bfzcj < 60;
                 if sZdkclbBjgmc > 0 then
                    select a.xnmc||'-'||b.mc into sXnxqmc from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                    and a.xnm||lpad(b.dm,2,'0')=v_tjz;
                    sFhjg := '学年学期'||sXnxqmc||'到当前学年学期存在不及格课程，不符合转专业条件。';
                 end if;
               end if;
          when 14 then--学生在参加转专业考试前必须通过等级考试项目
               if v_tjz is not null then
                  select count(distinct b.xmdm) into sBmxms
                  from jw_xmgl_xmxsbmqkb a, jw_xmgl_xmbmszb b
                  where a.xmbmsz_id = b.xmbmsz_id
                        and a.xh_id = v_xh_id
                        and b.xnm||lpad(b.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)
                        and ','||v_tjz||',' like '%,'||b.xmdm||',%';

                 select wm_concat(a.xmmc) into sXmmc from jw_jcdm_xmdmb a where ','||v_tjz||',' like '%,'||a.xmdm||',%';
                 if sKjxms = sBmxms then
                    select count(*) into sJgxms from (
                    select a.xh_id, b.xmdm, c.jgf, max(nvl(a.xmcj, '0')) xmcj
                    from jw_xmgl_xmxsbmqkb a, jw_xmgl_xmbmszb b, jw_xmgl_xmjzdmb c
                    where a.xmbmsz_id = b.xmbmsz_id
                          and b.jfzdm = c.xmjzdm
                          and a.xh_id = v_xh_id
                          and b.xnm||lpad(b.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)
                          and ','||v_tjz||',' like '%,'||b.xmdm||',%'
                          group by a.xh_id, b.xmdm, c.jgf)
                    where to_number(xmcj) >= to_number(jgf);
                    if sJgxms < sKjxms then
                       sFhjg := sXmmc||'中存在未通过项，不符合转专业条件。';
                    end if;
                  else
                    sFhjg := sXmmc||'中存在未通过项，不符合转专业条件。';
                  end if;
               end if;
          when 15 then--上学期成绩位列全班成绩的前50%
                select a.xnm||lpad(b.dm,2,0) into sSxnxq from jw_jcdm_xnb a, zftal_xtgl_jcsjb b where a.sfyx='1' and b.lx='0001'
                and a.xnm||lpad(b.dm,2,0) < v_xnm||lpad(v_xqm, 2, 0) and rownum = 1;

                select count(*) into sJqpms
                from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm,2,0) = sSxnxq
                and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id and a.bh_id=v_bh_id;

               if sJqpms > 0 then
                  select case when a.bjrs is null then '0' else round(a.bjpm/a.bjrs,4)*100||'' end into sJqpmbfb
                  from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm,2,0) = sSxnxq
                  and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id and a.bh_id=v_bh_id;

                  if sJqpmbfb is null then
                     sFhjg := '班级排名百分比为空，数据异常！';
                  else
                     if v_tjz != '-1' and sJqpmbfb*1>v_tjz*1 then
                        sFhjg := '上学期成绩排名位列全班总人数的'||v_tjz||'%之后，不符合转专业条件。';
                     end if;
                  end if;
               else
                  sFhjg := '年级专业排名未统计，无数据异常！';
               end if;
          when 16 then
               select((select count(*) from jw_xjgl_xjydb a where a.xh_id = v_xh_id and a.shzt < 4 and a.shzt > 0 and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0) ) + (select count(*) from jw_xjgl_xszzysqb b where b.xh_id = v_xh_id and b.shzt < 4 and b.shzt > 0 and b.xnm||lpad(b.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0))) into sXszzys from dual;
               if sXszzys > 0 then
                 sFhjg := '存在转专业记录，不符合转专业条件。';
               end if;
          when 17 then
               select count(*) into sCfjls from jw_xjgl_xscfb a where a.xh_id = v_xh_id and ','||v_tjz||',' like '%,'||a.cfdm||',%';
               if sCfjls > 0 then
                 sFhjg := '存在处分记录，不符合转专业条件。';
               end if;
          when 18 then--课程性质为______大于______分成绩（按计划）
               select (a1-a2) into sKcxzs from (
                select
                (select count(1) from (
                  select
                       (select count(1)
                          from jw_jxrw_jxbxxb          jxb,
                               jw_jh_jxzxjhkcyxxdxnxqb yxxd,
                               jw_jxrw_jxbhbxxb        hb
                         where jxb.kch_id = kc.kch_id
                           and jxb.xnm = yxxd.yxkkxnm
                           and yxxd.yxkkxqm = jxb.xqm
                           and yxxd.jxzxjhkcxx_id = t.jxzxjhkcxx_id
                           and jxb.jxb_id = hb.jxb_id
                           and hb.zyh_id = jh.zyh_id
                           and hb.njdm_id = jh.njdm_id
                           and nvl(hb.zyfx_id, 'wfx') = nvl(xf.zyfx_id, 'wfx')
                           and jxb.kkzt = '1') sfkk,
                           cj.bfzcj,
                           t.kcxzdm
                    from jw_jh_jxzxjhkcxxb   t,
                         jw_jh_kcdmb         kc,
                         jw_jh_jxzxjhxfyqxxb xf,
                         jw_jh_jxzxjhxxb     jh,
                         zftal_xtgl_zydmb    zy,
                         JW_CJ_XSCJB         cj
                   where 1 = 1
                     and t.kch_id = kc.kch_id
                     and t.xfyqjd_id = xf.xfyqjd_id
                     and xf.jxzxjhxx_id = jh.jxzxjhxx_id
                     and jh.zyh_id = zy.zyh_id
                     and t.kch_id = cj.kch_id
                     and cj.xh_id = v_xh_id
                     and t.njdm_id = v_njdm_id
                     and zy.zyh_id = v_zyh_id
                     and t.jyxdxnm || lpad(t.jyxdxqm, 2, '0') < v_xnm || lpad(v_xqm, 2, '0')
                     and t.kcxzdm = v_tjz
                )t where t.sfkk != '0')a1,
                (select count(1) from (
                  select
                       (select count(1)
                          from jw_jxrw_jxbxxb          jxb,
                               jw_jh_jxzxjhkcyxxdxnxqb yxxd,
                               jw_jxrw_jxbhbxxb        hb
                         where jxb.kch_id = kc.kch_id
                           and jxb.xnm = yxxd.yxkkxnm
                           and yxxd.yxkkxqm = jxb.xqm
                           and yxxd.jxzxjhkcxx_id = t.jxzxjhkcxx_id
                           and jxb.jxb_id = hb.jxb_id
                           and hb.zyh_id = jh.zyh_id
                           and hb.njdm_id = jh.njdm_id
                           and nvl(hb.zyfx_id, 'wfx') = nvl(xf.zyfx_id, 'wfx')
                           and jxb.kkzt = '1') sfkk,
                           cj.bfzcj,
                           t.kcxzdm
                    from jw_jh_jxzxjhkcxxb   t,
                         jw_jh_kcdmb         kc,
                         jw_jh_jxzxjhxfyqxxb xf,
                         jw_jh_jxzxjhxxb     jh,
                         zftal_xtgl_zydmb    zy,
                         JW_CJ_XSCJB         cj
                   where 1 = 1
                     and t.kch_id = kc.kch_id
                     and t.xfyqjd_id = xf.xfyqjd_id
                     and xf.jxzxjhxx_id = jh.jxzxjhxx_id
                     and jh.zyh_id = zy.zyh_id
                     and t.kch_id = cj.kch_id
                     and cj.xh_id = v_xh_id
                     and t.njdm_id = v_njdm_id
                     and zy.zyh_id = v_zyh_id
                     and t.jyxdxnm || lpad(t.jyxdxqm, 2, '0') < v_xnm || lpad(v_xqm, 2, '0')
                     and t.kcxzdm = v_tjz
                     and cj.bfzcj > v_tjz1
                )t where t.sfkk != '0' )a2 from dual);
                if sKcxzs > 0 then
                 sFhjg := '专业计划内对应课程性质成绩不符合要求，不符合转专业条件！';
               end if;

          when 19 then --所学课程加权学分绩点需达到
               select case when nvl(sum(case when t.jd is null then '0' else t.xf end ),'0') = '0' then null else nvl(round(sum(t.jd*t.xf)/sum(case when t.jd is null then '0' else t.xf end ),2),0) end into sJqxfjd from
               (select row_number() over(partition by nvl(a.sskch_id,a.kch_id) order by a.bfzcj desc) pm, a.kch_id, a.bfzcj, a.xf,
                       fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,a.cjxzm,a.kcbj,null,a.cjbz,a.jd,a.bfzcj,'cjb','tj','0') as jd
               from jw_cj_xscjb a where  a.xh_id = v_xh_id and a.xnm||lpad(a.xqm, 2, 0) <= v_xnm||lpad(v_xqm, 2, 0)) t where pm='1';
               if v_tjz != '-1' and sJqxfjd*1<v_tjz*1 then
                  sFhjg := sFhjg||'加权学分绩点：'||sJqxfjd||'小于条件值'||v_tjz||'，不符合转专业条件。';
               end if;
          when 20 then --所学课程加权学分成绩需名列专业前
               if sJqqzfw = '0' then
                   select count(*) into sJqpms
                     from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                     and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
               else
                   select count(*) into sJqpms
                     from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                     and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
               end if;

               if sJqpms > 0 then
                  if sJqqzfw = '0' then
                       select case when a.njzyrs is null then '0' else round(a.pm/a.njzyrs,4)*100||'' end into sJqpmbfb
                          from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                          and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                  else
                       select case when a.njzyrs is null then '0' else round(a.pm/a.njzyrs,4)*100||'' end into sJqpmbfb
                          from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                          and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                  end if;

                  if sJqpmbfb is null then
                     sFhjg := '加权排名百分比为空，数据异常！';
                  else
                     if v_tjz != '-1' and sJqpmbfb*1>v_tjz*1 then
                        sFhjg := '加权成绩排名超出专业总人数的'||v_tjz||'%，不符合转专业条件。';
                     end if;
                  end if;
               else
                  sFhjg := sJqtjms||'学生排名未统计，无数据异常！';
               end if;
          when 21 then --年级专业课程要求(先修课),每个年级专业指定课程_____通过率占比不低于_____
               if v_tjz != '-1' then
                 select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
                 select count(*) into sCount1 from jw_cj_xscjb where ','||v_tjz||',' like '%,'||kch_id||',%' and nvl(bfzcj,'0')>=60 and xh_id = v_xh_id;
                 select count(*) into sCount2 from jw_cj_xscjb where ','||v_tjz||',' like '%,'||kch_id||',%' and xh_id = v_xh_id;
                 if sCount2 > 0 then
                    if v_tjz != '-1' and round(sCount1/sCount2,2)*100<v_tjz1*1 then
                       sFhjg := '年级专业课程要求(先修课),指定课程('||sZdkc||'),通过率占比低于'||v_tjz1||'%，不符合转专业条件。';
                    end if;
                 else
                    sFhjg := '年级专业课程要求(先修课),指定课程('||sZdkc||')无成绩。';
                 end if;
               end if;
          when 22 then --外语类课程成绩不低于______分
               if v_tjz != '-1' then
                  select count(*)
                    into sCount1
                    from jw_cj_xscjb c
                   where exists (select 'x'
                            from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                           where c.kch_id = a.kch_id
                             and a.kz_id = b.kz_id
                             and b.kzmc = '外语类课程')
                     and xh_id = v_xh_id;
                  if sCount1 > 0 then
                    select count(*)
                      into sCount2
                      from jw_cj_xscjb c
                     where exists (select 'x'
                              from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                             where c.kch_id = a.kch_id
                               and a.kz_id = b.kz_id
                               and b.kzmc = '外语类课程')
                       and nvl(bfzcj, '0') < v_tjz*1
                       and xh_id = v_xh_id;
                    if sCount2 > 0 then
                       sFhjg := '外语类课程存在低于'||v_tjz||'分的课程，不符合转专业条件。';
                    end if;
                  else
                    sFhjg := '外语类课程无成绩。';
                  end if;
               end if;
          when 23 then --数学类课程不低于______分
                if v_tjz != '-1' then
                  select count(*)
                    into sCount1
                    from jw_cj_xscjb c
                   where exists (select 'x'
                            from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                           where c.kch_id = a.kch_id
                             and a.kz_id = b.kz_id
                             and b.kzmc = '数学类课程')
                     and xh_id = v_xh_id;
                  if sCount1 > 0 then
                    select count(*)
                      into sCount2
                      from jw_cj_xscjb c
                     where exists (select 'x'
                              from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                             where c.kch_id = a.kch_id
                               and a.kz_id = b.kz_id
                               and b.kzmc = '数学类课程')
                       and nvl(bfzcj, '0') < v_tjz*1
                       and xh_id = v_xh_id;
                    if sCount2 > 0 then
                       sFhjg := '数学类课程存在低于'||v_tjz||'分的课程，不符合转专业条件。';
                    end if;
                  else
                    sFhjg := '数学类课程无成绩。';
                  end if;
               end if;
          when 24 then --经济学类课程______分（含）以上
                if v_tjz != '-1' then
                  select count(*)
                    into sCount1
                    from jw_cj_xscjb c
                   where exists (select 'x'
                            from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                           where c.kch_id = a.kch_id
                             and a.kz_id = b.kz_id
                             and b.kzmc = '经济学类课程')
                     and xh_id = v_xh_id;
                  if sCount1 > 0 then
                    select count(*)
                      into sCount2
                      from jw_cj_xscjb c
                     where exists (select 'x'
                              from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b
                             where c.kch_id = a.kch_id
                               and a.kz_id = b.kz_id
                               and b.kzmc = '经济学类课程')
                       and nvl(bfzcj, '0') < v_tjz*1
                       and xh_id = v_xh_id;
                    if sCount2 > 0 then
                       sFhjg := '经济学类课程存在低于'||v_tjz||'分的课程，不符合转专业条件。';
                    end if;
                  else
                    sFhjg := '经济学类课程无成绩。';
                  end if;
               end if;
           when 25 then--对应课程成绩要求
                if v_tjz != '-1' then
                    s_tjzs := my_split(v_tjz,',');
                    for i in 1..s_tjzs.count loop
                         s_kcfs := my_split(s_tjzs(i),'@');
                        select count(1)
                          into sCount1
                          from jw_cj_xscjb c,jw_jh_kcdmb kc
                         where c.kch_id = s_kcfs(1)
                           and c.kch_id = kc.kch_id
                           and xh_id = v_xh_id;
                         select kc.kcmc
                          into s_kcmc
                          from jw_jh_kcdmb kc
                         where kc.kch_id = s_kcfs(1);
                         if sCount1 >0 then
                           select count(*)
                              into sCount2
                              from jw_cj_xscjb c
                             where c.kch_id = s_kcfs(1)
                               and nvl(bfzcj, '0') < s_kcfs(2)*1
                               and xh_id = v_xh_id;
                           if sCount2 > 0 then
                              if sFhjg is not null then
                               sFhjg := sFhjg ||'|'||s_kcmc||'低于'||s_kcfs(2)||'分，不符合转专业条件。';
                              else
                               sFhjg := s_kcmc||'低于'||s_kcfs(2)||'分，不符合转专业条件。';
                              end if;
                           end if;
                         else
                           if sFhjg is not null then
                             sFhjg := s_kcmc||','||sFhjg;
                           else
                             sFhjg := s_kcmc||'无成绩！';
                           end if;
                         end if;
                    end loop;
                end if;
         when 26 then
              if v_tjz != '-1' then
                    select count(*)
                      into sCount1
                      from jw_xjgl_xsjbxxb
                     where xh_id = v_xh_id
                       and nvl(ylzd1, '0') > v_tjz*1;
                    if sCount1 = 0 then
                       sFhjg := '高考语文成绩需大于'||v_tjz||'分，不符合转专业条件。';
                    end if;
               end if;
         when 27 then
              if v_tjz != '-1' then
                    select count(*)
                      into sCount1
                      from jw_xjgl_xsjbxxb
                     where xh_id = v_xh_id
                       and nvl(ylzd2, '0') > v_tjz*1;
                    if sCount1 = 0 then
                       sFhjg := '高考数学成绩需大于'||v_tjz||'分，不符合转专业条件。';
                    end if;
               end if;
         when 28 then
              if v_tjz != '-1' then
                    select count(*)
                      into sCount1
                      from jw_xjgl_xsjbxxb
                     where xh_id = v_xh_id
                       and nvl(ylzd3, '0') > v_tjz*1;
                    if sCount1 = 0 then
                       sFhjg := '高考英文成绩需大于'||v_tjz||'分，不符合转专业条件。';
                    end if;
               end if;
         when 29 then
              if v_tjz != '-1' then
                    select count(*)
                      into sCount1
                      from jw_xjgl_xsjbxxb
                     where xh_id = v_xh_id
                       and nvl(rxzf, '0') > v_tjz*1;
                    if sCount1 = 0 then
                       sFhjg := '高考总成绩需大于'||v_tjz||'分，不符合转专业条件。';
                    end if;
               end if;
         when 30 then --招生科类___
              if v_tjz != '-1' then
                 select count(1) into sCount1 from jw_xjgl_xsjbxxb where xh_id= v_xh_id and nvl(zskldm,'-1') = v_tjz;
                 if sCount1 = 0 then
                    select mc into s_tjmc from zftal_xtgl_jcsjb where lx ='1050' and dm = v_tjz;
                    sFhjg := '只允许招生科类:'||s_tjmc||'转专业，不符合转专业条件。';
                 end if;
              end if;
         when 31 then --学分加权平均分需达到__分
              if v_tjz != '-1' then
                 if sJqqzfw = '0' then
                     select count(*) into sJqpms
                       from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                       and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                 else
                     select count(*) into sJqpms
                       from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                       and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                 end if;
                 if sJqpms > 0 then
                    if sJqqzfw = '0' then
                         select nvl(a.jqcj,'0') into sJqcj
                            from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                            and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                    else
                         select nvl(a.jqcj,'0') into sJqcj
                            from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                            and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                    end if;

                    if sJqcj is null then
                       sFhjg := '加权成绩为空，数据异常！';
                    else
                       if v_tjz != '-1' and sJqcj*1<v_tjz*1 then
                          sFhjg := '加权成绩未达到'||v_tjz||'%，不符合转专业条件。';
                       end if;
                    end if;
                 else
                    sFhjg := '学生加权成绩未统计，无数据异常！';
                 end if;
              end if;
         when 32 then --外语、数学类课程成绩均达到__分，其中一门课程成绩达到__分
              if v_tjz != '-1' then
                   select count(*) into sCount1 from jw_cj_xscjb c
                   where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                         and a.kz_id = b.kz_id and b.kzmc = '数学类课程') and xh_id = v_xh_id;

                   select count(*) into sCount2 from jw_cj_xscjb c
                   where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                         and a.kz_id = b.kz_id and b.kzmc = '外语类课程') and xh_id = v_xh_id;

                  if sCount1 > 0 and sCount2 > 0 then
                     select count(*) into sCount1 from jw_cj_xscjb c
                     where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                               and a.kz_id = b.kz_id and b.kzmc = '数学类课程') and nvl(bfzcj, '0') < v_tjz*1
                               and xh_id = v_xh_id;

                     select count(*) into sCount2 from jw_cj_xscjb c
                     where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                           and a.kz_id = b.kz_id and b.kzmc = '外语类课程') and nvl(bfzcj, '0') < v_tjz*1
                           and xh_id = v_xh_id;
                    if sCount1 = 0 and sCount2 = 0 then
                       sFhjg := '数学类、外语类课程存在未达到'||v_tjz||'分的课程，不符合转专业条件。';
                    elsif sCount2 = 0 then
                       sFhjg := '数学类课程存在未达到'||v_tjz||'分的课程，不符合转专业条件。';
                    else
                       sFhjg := '外语类课程存在未达到'||v_tjz||'分的课程，不符合转专业条件。';
                    end if;
                  else
                    if sCount1 = 0 and sCount2 = 0 then
                       sFhjg := '数学类、外语类课程无成绩。';
                    elsif sCount2 = 0 then
                       sFhjg := '数学类课程无成绩。';
                    else
                       sFhjg := '外语类课程无成绩。';
                    end if;
                  end if;

                  if sFhjg is not null and v_tjz1 != '-1' then
                     select count(*) into sCount1 from jw_cj_xscjb c
                     where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                               and a.kz_id = b.kz_id and b.kzmc = '数学类课程') and nvl(bfzcj, '0') < v_tjz1*1
                               and xh_id = v_xh_id;

                     select count(*) into sCount2 from jw_cj_xscjb c
                     where exists (select 'x' from jw_jh_kzkcdmb a, jw_jh_kzjbxxb b where c.kch_id = a.kch_id
                           and a.kz_id = b.kz_id and b.kzmc = '外语类课程') and nvl(bfzcj, '0') < v_tjz1*1
                           and xh_id = v_xh_id;

                      if sCount1 = 0 and sCount2 = 0 then
                         sFhjg := '数学类、外语类课程其中一门需达到'||v_tjz||'分。';
                      end if;
                  end if;
               end if;
         when 33 then --学年学期__期末考试成绩加权平均分需达到__分
              if v_tjz != '-1' then
                 if sJqqzfw = '0' then
                     select count(*) into sJqpms
                       from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm, 2, 0) = v_tjz
                       and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                 else
                     select count(*) into sJqpms
                       from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm, 2, 0) = v_tjz
                       and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                 end if;

                 if sJqpms > 0 then
                    if sJqqzfw = '0' then
                         select a.jqcj into sJqcj
                            from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm, 2, 0) = v_tjz
                            and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                    else
                         select a.jqcj into sJqcj
                            from jw_cj_xscjpmlnjgb a where a.tjlx = '1' and a.xnm||lpad(a.xqm, 2, 0) = v_tjz
                            and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                    end if;

                    if sJqcj is null then
                       sFhjg := '加权成绩为空，数据异常！';
                    else
                       if sJqcj*1<v_tjz1*1 then
                          sFhjg := '加权成绩需达到'||v_tjz1||'%，不符合转专业条件。';
                       end if;
                    end if;
                 else
                    sFhjg := '学生排名未统计，无数据异常！';
                 end if;
              end if;
         when 34 then --已修过__课程（计划内）且考试成绩需达到__分
              if v_tjz != '-1' then
                 select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
                 select count(*) into sCount1 from jw_cj_xscjb where ','||v_tjz||',' like '%,'||kch_id||',%' and nvl(bfzcj,'0')>=v_tjz1*1 and xh_id = v_xh_id;
                 select count(*) into sCount2 from jw_cj_xscjb where ','||v_tjz||',' like '%,'||kch_id||',%' and xh_id = v_xh_id;
                 if sCount2 > 0 then
                    if sCount2>sCount1 then
                       sFhjg := '已修过课程('||sZdkc||'),考试成绩需达到'||v_tjz1||'%，不符合转专业条件。';
                    end if;
                 else
                    sFhjg := '已修过课程('||sZdkc||')无成绩。';
                 end if;
              end if;
         when 35 then --学分绩点排名列班级前__名(取年级专业排名)
              if v_tjz != '-1' then
                 select count(*) into sJqpms
                       from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                       and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                 if sJqpms > 0 then
                         select nvl(a.bjpm,'0') into sJqpms
                            from jw_cj_xscjpmjgb a where a.tjlx = '1' and a.xnm = v_xnm and a.xqm = v_xqm
                            and a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id and a.xh_id=v_xh_id;
                    if sJqpms is null then
                       sFhjg := '无班级排名，数据异常！';
                    else
                       if sJqpms*1<v_tjz*1 then
                          sFhjg := '学分绩点排名需列班级前'||v_tjz||'%，不符合转专业条件。';
                       end if;
                    end if;
                 else
                    sFhjg := '学生年级专业排名未统计，无数据异常！';
                 end if;
              end if;
         when 36 then --自主招生学生只能在同一级学科门类范围内申请转专业
              select t2.mldm into sMldm from jw_jh_dlzydzb t1,zftal_xtgl_xxzydmb t2 where t1.njdm_id = v_njdm_id and t1.zyh_id = v_zyh_id and t1.xxzydm = t2.zydm and t2.pcdm = v_njdm_id;
              select t2.mldm into sZrmldm from jw_jh_dlzydzb t1,zftal_xtgl_xxzydmb t2 where t1.njdm_id = v_njdm_id and t1.zyh_id = v_zryh_id and t1.xxzydm = t2.zydm and t2.pcdm = v_njdm_id;
              if sMldm != sZrmldm then
                 sFhjg := '自主招生学生只能在同一级学科门类范围内申请转专业。';
              end if;
         when 37 then  ---课程性质为______必须及格，且平均学分绩点不低于______

             select Get_Tjjls(37,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
             if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
                sFhjg := '总课程门数为'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'通过课程门数为'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'，不符合转专业条件。';
             end if;
             if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
                sFhjg := '平均学分绩点为'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'低于要求平均学分绩点'||v_tjz1||'，不符合转专业条件。';
             end if;
             if fn_jqzd(sZdkcxzBjgmc,'|',1) = '3' then
                sFhjg := '平均学分绩点为'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'低于要求平均学分绩点'||v_tjz1||'；并且总课程门数为'||fn_jqzd(sZdkcxzBjgmc,'|',3)||'通过课程门数为'||fn_jqzd(sZdkcxzBjgmc,'|',4)||'，不符合转专业条件。';
             end if;

        when 38 then    --平均学分绩点不低于______
             select Get_Tjjls(38,v_xnm,v_xqm,v_xh_id,v_tjz,'0') into sZdkcxzBjgmc from dual;
             if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
                sFhjg := '平均学分绩点为'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'低于要求平均学分绩点'||v_tjz||'，不符合转专业条件。';
             end if;
        when 39 then    --课组为______的课程成绩不低于______分
           select Get_Tjjls(39,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
           if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a,jw_jh_kzkcdmb b where a.kch_id = b.kch_id and ','||v_tjz||',' like '%,'||b.kz_id||',%';
             sFhjg := '课程为：'||sZdkc||'，未修读；不符合转专业条件。';
           end if;
           if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := '课程为：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'，低于要求成绩'||v_tjz1||'；不符合转专业条件。';
           end if;
        when 40 then  --课组为______的课程平均成绩不低于______分
          select Get_Tjjls(40,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a,jw_jh_kzkcdmb b where a.kch_id = b.kch_id and ','||v_tjz||',' like '%,'||b.kz_id||',%';
             sFhjg := '课程为：'||sZdkc||'，未修读；不符合转专业条件。';
           end if;
           if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := '课程平均成绩为：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'，低于要求成绩'||v_tjz1||'课程成绩为：'||fn_jqzd(sZdkcxzBjgmc,'|',3)||'；不符合转专业条件。';
           end if;
         when 41 then  --修读______，并取得相应学分
          select Get_Tjjls(41,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
            select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
             sFhjg := sZdkc||'课程都未取得相应学分；不符合转专业条件。';
          end if;

          when 42 then  --修读______，并取得相应学分
          select Get_Tjjls(42,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
            select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
             sFhjg := sZdkc||'课程都未取得相应学分；不符合转专业条件。';
          end if;

          when 43 then  --修读______，并取得相应学分
          select Get_Tjjls(43,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
            select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
             sFhjg := sZdkc||'课程都未取得相应学分；不符合转专业条件。';
          end if;

          when 44 then  --修读______，并取得相应学分
          select Get_Tjjls(44,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
            select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
             sFhjg := sZdkc||'课程都未取得相应学分；不符合转专业条件。';
          end if;

          when 45 then  --修读______，并取得相应学分
          select Get_Tjjls(45,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
            select wm_concat(a.kcmc) into sZdkc from jw_jh_kcdmb a where ','||v_tjz||',' like '%,'||a.kch_id||',%';
             sFhjg := sZdkc||'课程都未取得相应学分；不符合转专业条件。';
          end if;

          when 46 then  --修读______，且成绩不低于______分
            select Get_Tjjls(46,v_xnm,v_xqm,v_xh_id,v_tjz||'|'||v_tjz1,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||'部分课程成绩低于：'||v_tjz1||'；不符合转专业条件。';
          end if;

          when 47 then  --修读原专业(类)的所有课程，并取得相应学分
            select Get_Tjjls(47,v_xnm,v_xqm,v_xh_id,null,'0') into sZdkcxzBjgmc from dual;
            if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := '存在部分课程未取得相应学分：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'；不符合转专业条件。';
            end if;

          when 48 then  --修读______，且成绩不低于______分
            select Get_Tjjls(48,v_xnm,v_xqm,v_xh_id,v_tjz,'0') into sZdkcxzBjgmc from dual;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '1' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||'部分课程未取得相应学分；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '2' then
             sFhjg := fn_jqzd(sZdkcxzBjgmc,'|',2)||'部分课程未取得相应学分，并且平均学分绩点为：'||fn_jqzd(sZdkcxzBjgmc,'|',3)||'低于要求平均学分绩点'||v_tjz||'；不符合转专业条件。';
          end if;
          if fn_jqzd(sZdkcxzBjgmc,'|',1) = '3' then
             sFhjg := '平均学分绩点为：'||fn_jqzd(sZdkcxzBjgmc,'|',2)||'低于要求平均学分绩点'||v_tjz||'；不符合转专业条件。';
          end if;

     end case;
     return sFhjg;
end get_jsxyzzytj;
/

