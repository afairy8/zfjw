create function fun_by_kcxzcjsh(v_xh_id varchar2,v_tjsjz varchar2,v_tjkcxz varchar2,v_btjkc varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   sqlstr VARCHAR2(4000);
   v_count number;
   v_kcxzmc varchar2(500);
begin
    sJg := '合格';
    begin
       --根据课程类型获得总学分
         if v_tjkcxz is not null and v_tjkcxz='qb' then
            v_kcxzmc:='全部课程性质';
            select count(cj.kch_id) into v_count from jw_cj_xscjb cj  where cj.xh_id = v_xh_id;
         elsif v_tjkcxz is not null and v_tjkcxz!='qb' then
               sqlstr:= ' select  wm_concat(kcxzmc)kcxzmc from jw_jh_kcxzdmb where   instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
                execute immediate sqlstr into v_kcxzmc;
/*           select kcxzmc into v_kcxzmc from jw_jh_kcxzdmb where   instr(','||''||v_tjkcxz||''||',' , ','||kcxzdm||',' )>0;*/
             sqlstr:= 'select count(cj.kch_id) count from jw_cj_xscjb cj  where cj.xh_id ='''||v_xh_id||'''  and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||cj.kcxzdm||'','' )>0 ';
             execute immediate sqlstr into v_count;
/*          select count(cj.kch_id) into v_count from jw_cj_xscjb cj  where cj.xh_id = v_xh_id and instr(','||''||v_tjkcxz||''||',' , ','||cj.kcxzdm||',' )>0;
*/         end if;
           if v_count>0 then
      sqlstr := 'select nvl(count(a.kch_id),0) count from (select cj.kch_id,cj.bfzcj,row_number() ' ||
                'over(partition by cj.xh_id, cj.kch_id order by cj.BFZCJ desc) rn from jw_cj_xscjb cj where cj.xh_id = ''' ||
                v_xh_id || ''''||'and cj.cj not in (select cj from JW_CJ_CJJGLXSQB where CJJGLX=''01'' and shzt=''3'' and cj.JXB_ID=jxb_id and xh_id=cj.xh_id)';
           if v_tjkcxz is not null and v_tjkcxz!='qb' then
              sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||cj.kcxzdm||'','' )>0 ';
           end if;

           if v_btjkc is not null then
              sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
            end if;
           sqlstr:= sqlstr||' ) a   where rn = 1 and a.bfzcj<'||v_tjsjz;
           execute immediate sqlstr into v_count;
              if v_count>0 then
                 sJg:= v_kcxzmc||'共有'||v_count||'门课程低于'||v_tjsjz||'分，不合格！';
              else
                 sJg:= '合格！';
              end if;
            else
                sJg:= '无'||v_kcxzmc||'课程成绩，不合格！';
            end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_kcxzcjsh;

/

