create function fn_jqjdjs
 (vXnm       in varchar2,  ---学年码
 vXqm        in varchar2,  ---学期码
 vSskch_id   in varchar2,  ---所属课程号ID
 vKch_id     in varchar2,  ---课程号ID
 vKcmc       in varchar2,  ---课程名称
 vJxb_id     in varchar2,  ---教学班
 vNjdm_id    in varchar2,  ---年级代码
 vZyh_id     in varchar2,  ---专业号
 VZyfx_id    in varchar2,  ---专业方向
 vXh_id      in varchar2,  ---学号ID
 vKcxzdm     in varchar2,  ---课程性质代码
 vKclbdm     in varchar2,  ---课程类别代码
 vCjxzm      in varchar2,  ---成绩性质码
 vKcbj       in varchar2,  ---课程标记
 vJzdm       in varchar2,  ---级制代码
 vCjbz       in varchar2,  ---成绩备注
 iJd         in number,    ---成绩绩点
 iXf         in number,    ---学分
 iBfzcj      in number,    ---成绩百分制
 vCjly       in varchar2,  ---成绩来源
 vFs         in varchar2,  ---方式（xs显示、tj统计）
 vBj         in varchar2  ---标记默认为0，如有特殊再做扩展
 )
return number is
iZxf   number;
iCount number;
begin
  if vBj = '1' then
    select count(*) into iCount from jw_jh_jxzxjhxfyqxxb t1, jw_jh_jxzxjhkcxxb t2
    where t1.xfyqjd_id = t2.xfyqjd_id
          and t2.kch_id = case when length(vSskch_id) = 1 or vSskch_id is null then vKch_id else vSskch_id end
          and t2.njdm_id = vNjdm_id
          and t2.zyh_id = vZyh_id
          and decode(nvl(t1.zyfx_id,'wfx'),'wfx',1,nvl(vZyfx_id,'wfx'),2,0) > 0
          and t2.ZYZGKCBJ = '1'
          and rownum = 1;
    if iCount > 0 then
     return  iJd*iXf;
    else
     return null;
    end if;
  end if;

  if vBj = '2' then
    select sum(t2.xf) into iZxf from jw_jh_jxzxjhxfyqxxb t1, jw_jh_jxzxjhkcxxb t2
    where t1.xfyqjd_id = t2.xfyqjd_id
          and t2.njdm_id = vNjdm_id
          and t2.zyh_id = vZyh_id
          and decode(nvl(t1.zyfx_id,'wfx'),'wfx',1,nvl(vZyfx_id,'wfx'),2,0) > 0
          and t2.ZYZGKCBJ = '1'
          ;
   return iZxf;
  end if;
end fn_jqjdjs;

/

