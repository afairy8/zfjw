create function Get_Fxcjtj -- 获取辅修成绩条件
(vTjxh varchar2,--条件序号
 vXnm varchar2,
 vXqm varchar2,
 vXh_id varchar2,
 fxlx varchar2,
 v_tjz varchar2,
 v_tjz1 varchar2,
 vTjbj  varchar2 --条件标记，0为条件1， 1为条件2
 ) return varchar2
as
 sFhjg varchar2(10);--返回结果
begin

       case vTjxh
            when 1 then
                if vTjbj = '0' then

                    select sum(xf) into sFhjg

                    from
                      (select 'cjb' as ly,t.xnm,t.xqm,t.jg_id,t.njdm_id,t.zyh_id,t.zyfx_id,t.bh_id,t.xh_id,
                         t.kcxzdm,t.kclbdm,t.kcgsdm,t.sskch_id,t.kch_id,t.kch,t.kcmc,t.kcywmc,t.xf,t.jxb_id,t.kcbj,
                         t.cj,t.bfzcj,t.cjbz,t.jd,t.cjxzm,t.mbkcj,t.mbkbfzcj,t.mbkcjbz,t.mbycj,t.mbybfzcj,t.mbyjd,t.mbycjbz,t.mcxcj,t.mcxbfzcj,t.mcxjd,t.mcxcjbz,
                         decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),cj,
                                          nvl(mbkbfzcj,0),mbkcj
                                          ) as mzbcj,
                          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)) as mzbbfzcj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),jd,
                                          nvl(mbkbfzcj,0),mbkjd
                                          ) as mzbjd,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),cjbz,
                                          nvl(mbkbfzcj,0),mbkcjbz
                                          ) as mzbcjbz,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx' when cjxzm in ('21','22') then 'bybk' else 'zk' end),
                                          nvl(mbkbfzcj,0),'bk'
                                          ) as mzbcjbj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),cj,
                                          nvl(mbkbfzcj,0),mbkcj,
                                          nvl(mcxbfzcj,0),mcxcj,
                                          nvl(mbybfzcj,0),mbycj
                                          ) as maxcj,
                          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)) as maxbfzcj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),jd,
                                          nvl(mbkbfzcj,0),mbkjd,
                                          nvl(mcxbfzcj,0),mcxjd,
                                          nvl(mbybfzcj,0),mbyjd
                                          ) as maxjd,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),cjbz,
                                          nvl(mbkbfzcj,0),mbkcjbz,
                                          nvl(mcxbfzcj,0),mcxcjbz,
                                          nvl(mbybfzcj,0),mbycjbz
                                          ) as maxcjbz,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx' when cjxzm in ('21','22') then 'bybk' else 'zk' end),
                                          nvl(mbkbfzcj,0),'bk',
                                          nvl(mcxbfzcj,0),'cx',
                                          nvl(mbybfzcj,0),'bybk'
                                          ) as maxcjbj,
                          -------替代课程标记begin----------------
                         (select count(1) from jw_cj_xsgrcjdtb cjdtb
                                         where cjdtb.zszt = '3'
                                           and t.xh_id = cjdtb.xh_id
                                           and t.kch_id = cjdtb.kch_id
                                           and rownum = 1) as tdkcbj,
                          -------替代课程标记end------------------
                         (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc from
                        (select t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.zyfx_id,t1.bh_id,t1.xh_id,
                          t1.kcxzdm,t1.kclbdm,t1.kcgsdm,t1.sskch_id,t1.kch_id,t1.kch,t1.kcmc,t1.kcywmc,t1.xf, t1.jxb_id,t1.kcbj,
                          case when t1.hkcj is null then nvl(t1.cj,t1.cjbz) else t1.hkcj end as cj,
                          case when t1.hkcj is null then t1.bfzcj else t1.hkbfzcj end as bfzcj,
                          case when t1.hkcj is null then t1.cjbz  else t1.hkbz end as cjbz,
                          case when t1.hkcj is null then t1.jd else t1.hkjd end as jd,
                          t1.cjxzm,
                          t1.bkcj as mbkcj,
                          t1.bkbfzcj as mbkbfzcj,
                          t1.bkbz as mbkcjbz,
                          t1.bkjd as mbkjd,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycj end as mbycj,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbybfzcj end as mbybfzcj,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbyjd end as mbyjd,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycjbz end as mbycjbz,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcj end as mcxcj,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxbfzcj end as mcxbfzcj,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxjd end as mcxjd,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcjbz end as mcxcjbz
                          from
                          (select XNM,XQM,njdm_id,jg_id,zyh_id,zyfx_id,bh_id,XH_ID,sskch_id,KCH_ID,KCH,KCMC,KCYWMC,XF,KCXZDM,KCLBDM,KCGSDM,JXB_ID,
                                 CJ,BFZCJ,CJBZ,JD,CJXZM,KCBJ,BZXX,bkcj,bkbfzcj,bkbz,bkjd,hkcj,hkbfzcj,hkbz,hkjd from
                           (select a.XNM,a.XQM,b.jg_id,b.njdm_id,b.zyh_id,nvl(b.zyfx_id,'wfx') zyfx_id,b.bh_id,a.XH_ID,
                                a.sskch_id,a.KCH_ID,
                                nvl(kc.kch,a.KCH) as kch,
                                nvl(kc.kcmc,a.KCMC) as kcmc,
                                nvl(kc.kcywmc,a.KCYWMC) as kcywmc,
                                a.XF,a.KCXZDM,a.KCLBDM,a.KCGSDM,a.JXB_ID,
                                a.CJ,a.BFZCJ,a.CJBZ,a.JD,a.CJXZM,a.KCBJ,a.BZXX,
                                a.bkcj,a.bkbfzcj,a.bkbz,a.bkjd,
                                a.hkcj,a.hkbfzcj,a.hkbz,a.hkjd,
                                row_number() over (partition by a.xh_id,nvl(a.sskch_id,a.kch_id) order by to_number(a.cjxzm),a.bfzcj desc,a.xnm,to_number(a.xqm)) rn
                           from JW_CJ_XSCJB a,jw_xjgl_xsjbxxb b,jw_jh_kcdmb kc
                          where a.xh_id = b.xh_id
                            and a.cjxzm in ('01','16','21','22')
                            and a.xh_id = vXh_id
                            and a.kcbj = '1'
                            and a.xnm = vXnm
                            and a.xqm = vXqm
                            and (case when length(a.sskch_id)=1 or a.sskch_id is null then a.kch_id else a.sskch_id end)  = kc.kch_id(+)
                            ------不显示被替代课程（参数需要控制）begin----------------
                            and not exists(select 'X' from jw_cj_xsgrjhdtb jhdtb
                                                     where jhdtb.zszt = '3'
                                                       and a.xh_id = jhdtb.xh_id
                                                       and a.kch_id = jhdtb.kch_id)
                            ------不显示被替代课程（参数需要控制）end------------------
                            ) where rn = '1') t1
                            left join
                            (select XH_ID,sskch_id,KCH_ID,CJ as MBYCJ,BFZCJ as MBYBFZCJ,JD as MBYJD,CJBZ as MBYCJBZ from
                               ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,t1.JD,t1.CJBZ,row_number() over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id) order by t1.bfzcj desc) rn from
                               JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
                               where t1.xh_id = t2.xh_id
                                 and t1.cjxzm in ('21','22')
                                 and t1.xh_id = vXh_id
                                ) where rn = '1'
                             ) t2
                             on t1.xh_id = t2.xh_id
                             and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
                                = case when length(t2.sskch_id) =1 then t2.sskch_id||'-'||t2.kch_id else nvl(t2.sskch_id,t2.kch_id) end
                            left join
                            (select XH_ID,sskch_id,KCH_ID,CJ as MCXCJ,BFZCJ as MCXBFZCJ,JD as MCXJD,CJBZ as MCXCJBZ from
                               ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,t1.JD,t1.CJBZ,row_number() over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id) order by t1.bfzcj desc) rn from
                               JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
                               where t1.xh_id = t2.xh_id
                                 and t1.cjxzm in ('16','17')
                                 and t1.xh_id = vXh_id
                               ) where rn = '1'
                            ) t3
                            on t1.xh_id = t3.xh_id
                            and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
                                = case when length(t3.sskch_id) =1 then t3.sskch_id||'-'||t3.kch_id else nvl(t3.sskch_id,t3.kch_id) end
                        ) t )  a

                       where a.xh_id = vXh_id and a.xnm||lpad(a.xqm, 2, 0) <= vXnm||lpad(vXqm, 2, 0)
                       and maxbfzcj >= 60
                       group by xh_id,xnm,xqm;

                end if;

          when 2 then

                if vTjbj = '0' then

                    select (case when count(*)>0 then (case when count(*)=sum(jgs) then 0 else 1 end) else 1 end) into sFhjg

                    from
                      (select 'cjb' as ly,t.xnm,t.xqm,t.jg_id,t.njdm_id,t.zyh_id,t.zyfx_id,t.bh_id,t.xh_id,
                         (case when t.bfzcj<60 then '0' else '1' end) jgs,
                         t.kcxzdm,t.kclbdm,t.kcgsdm,t.sskch_id,t.kch_id,t.kch,t.kcmc,t.kcywmc,t.xf,t.jxb_id,t.kcbj,
                         t.cj,t.bfzcj,t.cjbz,t.jd,t.cjxzm,t.mbkcj,t.mbkbfzcj,t.mbkcjbz,t.mbycj,t.mbybfzcj,t.mbyjd,t.mbycjbz,t.mcxcj,t.mcxbfzcj,t.mcxjd,t.mcxcjbz,
                         decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),cj,
                                          nvl(mbkbfzcj,0),mbkcj
                                          ) as mzbcj,
                          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)) as mzbbfzcj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),jd,
                                          nvl(mbkbfzcj,0),mbkjd
                                          ) as mzbjd,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),cjbz,
                                          nvl(mbkbfzcj,0),mbkcjbz
                                          ) as mzbcjbz,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx' when cjxzm in ('21','22') then 'bybk' else 'zk' end),
                                          nvl(mbkbfzcj,0),'bk'
                                          ) as mzbcjbj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),cj,
                                          nvl(mbkbfzcj,0),mbkcj,
                                          nvl(mcxbfzcj,0),mcxcj,
                                          nvl(mbybfzcj,0),mbycj
                                          ) as maxcj,
                          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)) as maxbfzcj,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),jd,
                                          nvl(mbkbfzcj,0),mbkjd,
                                          nvl(mcxbfzcj,0),mcxjd,
                                          nvl(mbybfzcj,0),mbyjd
                                          ) as maxjd,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),cjbz,
                                          nvl(mbkbfzcj,0),mbkcjbz,
                                          nvl(mcxbfzcj,0),mcxcjbz,
                                          nvl(mbybfzcj,0),mbycjbz
                                          ) as maxcjbz,
                          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx' when cjxzm in ('21','22') then 'bybk' else 'zk' end),
                                          nvl(mbkbfzcj,0),'bk',
                                          nvl(mcxbfzcj,0),'cx',
                                          nvl(mbybfzcj,0),'bybk'
                                          ) as maxcjbj,
                          -------替代课程标记begin----------------
                         (select count(1) from jw_cj_xsgrcjdtb cjdtb
                                         where cjdtb.zszt = '3'
                                           and t.xh_id = cjdtb.xh_id
                                           and t.kch_id = cjdtb.kch_id
                                           and rownum = 1) as tdkcbj,
                          -------替代课程标记end------------------
                         (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc from
                        (select t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.zyfx_id,t1.bh_id,t1.xh_id,
                          t1.kcxzdm,t1.kclbdm,t1.kcgsdm,t1.sskch_id,t1.kch_id,t1.kch,t1.kcmc,t1.kcywmc,t1.xf, t1.jxb_id,t1.kcbj,
                          case when t1.hkcj is null then nvl(t1.cj,t1.cjbz) else t1.hkcj end as cj,
                          case when t1.hkcj is null then t1.bfzcj else t1.hkbfzcj end as bfzcj,
                          case when t1.hkcj is null then t1.cjbz  else t1.hkbz end as cjbz,
                          case when t1.hkcj is null then t1.jd else t1.hkjd end as jd,
                          t1.cjxzm,
                          t1.bkcj as mbkcj,
                          t1.bkbfzcj as mbkbfzcj,
                          t1.bkbz as mbkcjbz,
                          t1.bkjd as mbkjd,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycj end as mbycj,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbybfzcj end as mbybfzcj,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbyjd end as mbyjd,
                          case when t1.cjxzm in ('21','22') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycjbz end as mbycjbz,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcj end as mcxcj,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxbfzcj end as mcxbfzcj,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxjd end as mcxjd,
                          case when t1.cjxzm in ('16') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcjbz end as mcxcjbz
                          from
                          (select XNM,XQM,njdm_id,jg_id,zyh_id,zyfx_id,bh_id,XH_ID,sskch_id,KCH_ID,KCH,KCMC,KCYWMC,XF,KCXZDM,KCLBDM,KCGSDM,JXB_ID,
                                 CJ,BFZCJ,CJBZ,JD,CJXZM,KCBJ,BZXX,bkcj,bkbfzcj,bkbz,bkjd,hkcj,hkbfzcj,hkbz,hkjd from
                           (select a.XNM,a.XQM,b.jg_id,b.njdm_id,b.zyh_id,nvl(b.zyfx_id,'wfx') zyfx_id,b.bh_id,a.XH_ID,
                                a.sskch_id,a.KCH_ID,
                                nvl(kc.kch,a.KCH) as kch,
                                nvl(kc.kcmc,a.KCMC) as kcmc,
                                nvl(kc.kcywmc,a.KCYWMC) as kcywmc,
                                a.XF,a.KCXZDM,a.KCLBDM,a.KCGSDM,a.JXB_ID,
                                a.CJ,a.BFZCJ,a.CJBZ,a.JD,a.CJXZM,a.KCBJ,a.BZXX,
                                a.bkcj,a.bkbfzcj,a.bkbz,a.bkjd,
                                a.hkcj,a.hkbfzcj,a.hkbz,a.hkjd,
                                row_number() over (partition by a.xh_id,nvl(a.sskch_id,a.kch_id) order by to_number(a.cjxzm),a.bfzcj desc,a.xnm,to_number(a.xqm)) rn
                           from JW_CJ_XSCJB a,jw_xjgl_xsjbxxb b,jw_jh_kcdmb kc
                          where a.xh_id = b.xh_id
                            and a.cjxzm in ('01','16','21','22')
                            and a.xh_id = vXh_id
                            and (case when length(a.sskch_id)=1 or a.sskch_id is null then a.kch_id else a.sskch_id end)  = kc.kch_id(+)
                            ------不显示被替代课程（参数需要控制）begin----------------
                            and not exists(select 'X' from jw_cj_xsgrjhdtb jhdtb
                                                     where jhdtb.zszt = '3'
                                                       and a.xh_id = jhdtb.xh_id
                                                       and a.kch_id = jhdtb.kch_id)
                            ------不显示被替代课程（参数需要控制）end------------------
                            ) where rn = '1') t1
                            left join
                            (select XH_ID,sskch_id,KCH_ID,CJ as MBYCJ,BFZCJ as MBYBFZCJ,JD as MBYJD,CJBZ as MBYCJBZ from
                               ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,t1.JD,t1.CJBZ,row_number() over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id) order by t1.bfzcj desc) rn from
                               JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
                               where t1.xh_id = t2.xh_id
                                 and t1.cjxzm in ('21','22')
                                 and t1.xh_id = vXh_id
                                ) where rn = '1'
                             ) t2
                             on t1.xh_id = t2.xh_id
                             and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
                                = case when length(t2.sskch_id) =1 then t2.sskch_id||'-'||t2.kch_id else nvl(t2.sskch_id,t2.kch_id) end
                            left join
                            (select XH_ID,sskch_id,KCH_ID,CJ as MCXCJ,BFZCJ as MCXBFZCJ,JD as MCXJD,CJBZ as MCXCJBZ from
                               ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,t1.JD,t1.CJBZ,row_number() over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id) order by t1.bfzcj desc) rn from
                               JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
                               where t1.xh_id = t2.xh_id
                                 and t1.cjxzm in ('16','17')
                                 and t1.xh_id = vXh_id
                               ) where rn = '1'
                            ) t3
                            on t1.xh_id = t3.xh_id
                            and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
                                = case when length(t3.sskch_id) =1 then t3.sskch_id||'-'||t3.kch_id else nvl(t3.sskch_id,t3.kch_id) end
                        ) t )  a

                       where a.xh_id = vXh_id and (case when v_tjz=-1 then '000000' else v_tjz end) <= a.xnm||lpad(a.xqm, 2, 0) and a.xnm||lpad(a.xqm, 2, 0) <= (case when v_tjz1=-1 then '999999' else v_tjz1 end);

                end if;

         end case;

  return sFhjg;
end Get_Fxcjtj;

/

