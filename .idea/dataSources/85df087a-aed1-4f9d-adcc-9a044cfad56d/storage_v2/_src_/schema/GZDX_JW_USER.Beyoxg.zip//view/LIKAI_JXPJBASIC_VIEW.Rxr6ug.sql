create view LIKAI_JXPJBASIC_VIEW as
  select
    t.xspjtjb_id,
    t.xnm,
    t.xqm,
    LIKAI_JW_PUBLICINTERFACE.RETURN_XNORXQMC(t.xnm) xn,
    LIKAI_JW_PUBLICINTERFACE.RETURN_XNORXQMC(t.xqm) xq,
    t.cprs,
    t.jfrs,
    t.xsmc,
    t.jg_id,
    t.jgh,
    jg.jgmc,
    t.jsmc,
    t.zcmc,
    t.kch,
    t.kcmc,
    t1.jqpf,
    t1.jsjqpfpm                                     jqpfjgpm,
    t1.jsjqpfpmq || '%'                             jqpfjgpmq,
    t1.jszpf,
    t1.jszpfpm,
    t1.jszpfpmq || '%'                              jszpfpmq,
    t.bfzpf,
    t.bfzpfpm,
    t.bfzpfpmq || '%'                               bfzpfpmq
  from (select
          t.xspjtjb_id,
          t.xnm,
          t.xqm,
          t.cprs,
          t.jfrs,
          t.xsmc,
          t.JGH_ID,
          t.jg_id,
          t.jgh,
          t.jsmc,
          t.zcmc,
          t.kch,
          t.kcmc,
          t.bfzpf,
          t.bfzpfpm,
          t.bfzpfpmq
        from (
               select
                 t1.xspjtjb_id,
                 t1.xnm,
                 t1.xqm,
                 t1.bfzpf,
                 t1.cprs,
                 t1.jfrs,
                 t1.pjdxdm,
                 decode(t1.pjdxdm, '01', '教师', '02', '课程', '03', '教材') pjdxmc,
                 (select a.xsmc
                  from jw_jh_kcxsxxdmb a
                  where a.xsdm = t1.xsdm)                              xsmc,
                 t3.jg_id,
                 (select jysmc
                  from zftal_xtgl_jysdmb
                  where jys_id = t3.jys_id)                            xkgsbm,
                 (select jgh from JW_JG_JZGXXB where jgh_id=t3.jgh_id)                                                jgh,
                 t1.JGH_ID,
                 (select xm from JW_JG_JZGXXB where jgh_id=t3.jgh_id)                                                 jsmc,
                 (select zcmc
                  from jw_jg_zyjszcb
                  where zcm = t3.zcm)                                  zcmc,
                 t2.kch,
                 t2.kcmc,
                 t2.kkbm_id,
                 get_jglsxx(t2.kkbm_id)                                kkbm,
                 t1.skxs,
                 t1.zgf                                                maxpf,
                 t1.zdf                                                minpf,
                 rank()
                 over (
                   partition by t1.xnm, t1.xqm, t3.jg_id
                   order by t1.bfzpf desc )                            bfzpfpm,
                 round(RANK()
                       over (
                         partition by t1.xnm, t1.xqm, t3.jg_id
                         order by to_number(t1.bfzpf) desc ) / (RANK()
                                                                over (
                                                                  partition by t1.xnm, t1.xqm, t3.jg_id
                                                                  order by to_number(t1.bfzpf) desc ) + RANK()
                                                                over (
                                                                  partition by t1.xnm, t1.xqm, t3.jg_id
                                                                  order by to_number(t1.bfzpf) asc ) - 1) * 100,
                       0)                                              bfzpfpmq
               from jw_pj_xspjtjb t1, jw_jh_kcdmb t2, JW_JG_JZGSHXXB t3
               where t1.kch_id = t2.kch_id and t3.XNM=t1.XNM and t3.XQM=t1.XQM
                     and t1.jgh_id = t3.jgh_id) t) t, (select *
                                                       from (
                                                              select
                                                                t1.xnm,
                                                                t1.xqm,
                                                                t1.jgh_id,
                                                                t1.jszpf,
                                                                rank()
                                                                over (
                                                                  partition by t1.XNm, t1.xqm, t1.jg_id
                                                                  order by t1.jszpf desc ) jszpfpm,
                                                                round(RANK()
                                                                      over (
                                                                        partition by t1.xnm, t1.xqm, t1.jg_id
                                                                        order by to_number(t1.jszpf) desc ) / (RANK()
                                                                                                               over (
                                                                                                                 partition by t1.xnm, t1.xqm, t1.jg_id
                                                                                                                 order by
                                                                                                                   to_number(
                                                                                                                       t1.jszpf) desc )
                                                                                                               + RANK()
                                                                                                               over (
                                                                                                                 partition by t1.xnm, t1.xqm, t1.jg_id
                                                                                                                 order by
                                                                                                                   to_number(
                                                                                                                       t1.jszpf) asc )
                                                                                                               - 1) *
                                                                      100,
                                                                      0)                   jszpfpmq,
                                                                t1.jqpf,
                                                                rank()
                                                                over (
                                                                  partition by t1.xnm, t1.XQM, t1.JG_ID
                                                                  order by t1.jqpf desc )  jsjqpfpm,
                                                                round(RANK()
                                                                      over (
                                                                        partition by t1.xnm, t1.xqm, t1.jg_id
                                                                        order by to_number(t1.jqpf) desc ) / (RANK()
                                                                                                              over (
                                                                                                                partition by t1.xnm, t1.xqm, t1.jg_id
                                                                                                                order by
                                                                                                                  to_number(
                                                                                                                      t1.jqpf) desc )
                                                                                                              + RANK()
                                                                                                              over (
                                                                                                                partition by t1.xnm, t1.xqm, t1.jg_id
                                                                                                                order by
                                                                                                                  to_number(
                                                                                                                      t1.jqpf) asc )
                                                                                                              - 1) *
                                                                      100,
                                                                      0)                   jsjqpfpmq
                                                              from
                                                                (select
                                                                   jstjb.XNM,
                                                                   jstjb.XQM,
                                                                   jsshb.JG_ID,
                                                                   jsshb.JGH_ID,
                                                                   jstjb.BFZPF jszpf,
                                                                   jstjb.JQPJF jqpf
                                                                 from JW_PJ_JSPJZHTJB jstjb, JW_JG_JZGSHXXB jsshb
                                                                 where jstjb.JGH_ID = jsshb.JGH_ID
                                                                       and jstjb.XNM = jsshb.XNM
                                                                       and jstjb.XQM = jsshb.XQM
                                                                and jstjb.CPDXDM='01') t1) t1) t1,
    zftal_xtgl_jgdmb jg
  where t.XNM = t1.XNM and t.xqm = t1.XQM and t.JGH_ID = t1.JGH_ID and t.jg_id = jg.jg_id
/

