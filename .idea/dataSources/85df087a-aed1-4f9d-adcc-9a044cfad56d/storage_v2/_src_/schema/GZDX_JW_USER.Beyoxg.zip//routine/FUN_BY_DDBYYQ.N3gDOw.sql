create function fun_by_ddbyyq(v_xh_id varchar2,v_bynd varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_flag varchar2(2);
   sqlstr VARCHAR2(2000);
begin
    sJg := '合格';
    begin
        select decode(xxsh,'1','合格','没有达到毕业要求，不合格') into sJg from JW_BYGL_BYSHB where xh_id = v_xh_id and bynd = v_bynd;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_ddbyyq;

/

