create function fn_jd(vXnm in varchar2 ,
                                     vXqm in varchar2 ,
                                     vXh_id in varchar2,
                                     vJzdm in varchar2 ,
                                     cjbfz in number,
                                     vBj in varchar2)
    /**-----成绩绩点转换---bj-当为空时按默认计算 为1时正考 为2时补考 为3时重修对应的分数段对应绩点值 如果没有的话还按默认的计算---**/
     return number is
      kcjd number;
      k number;
      iCount number;
      sZsnddm varchar2(4);
      sJdjsfs number;
begin
  select to_number(nvl(max(zdz),0)) into sJdjsfs from jw_jcdml_xtnzb where zdm = 'JDJSFS';--绩点计算方式: 0：按绩点类型计算绩点，1：按绩点类型级制招生年度计算绩点，2：按绩点类型级制年级计算绩点
  if sJdjsfs > 0 then --1：按绩点类型级制招生年度计算绩点，2：按绩点类型级制年级计算绩点
     select count(*) into iCount from jw_xjgl_xsxjxxb where xnm = vXnm and bitand(xqm , vXqm) > 0 and xh_id = vXh_id;
     if iCount > 0 then
       if sJdjsfs=1 then
         select zsnddm into sZsnddm from jw_xjgl_xsxjxxb where xnm = vXnm and bitand(xqm , vXqm) > 0 and xh_id = vXh_id;
       elsif sJdjsfs=2 then
         select njdm_id into sZsnddm from jw_xjgl_xsxjxxb where xnm = vXnm and bitand(xqm , vXqm) > 0 and xh_id = vXh_id;
       else
         kcjd := null;
         return(kcjd);
       end if;
       select count(*) into k from jw_cj_jddzb_zjdx
                                 where  cjlxbj = vBj
                                   and (qsf <= cjbfz  and (cjbfz < jsf or (cjbfz = 100 and jsf = 100) ) )
                                   and jzdm = vJzdm
                                   and JDDZMC_ID in (select JDDZMC_ID from JW_CJ_JDDZSYB_ZJDX where zsnddm = sZsnddm) ;
       if k = 0 then
         begin
           if cjbfz < 60 or cjbfz > 100 then
             kcjd := 0;
           else
             kcjd:=trunc((cjbfz-50)/10)+ trunc(mod(cjbfz,10))/10;
             if kcjd > 5 then
                kcjd := 5;
             end if;
           end if;
         exception
           WHEN OTHERS THEN
             kcjd := '''';
         end;
       else
         select jd into kcjd from jw_cj_jddzb_zjdx
                             where  cjlxbj = vBj
                                     and (qsf <= cjbfz  and (cjbfz < jsf or (cjbfz = 100 and jsf = 100) ) )
                                     and jzdm = vJzdm
                                     and JDDZMC_ID in (select JDDZMC_ID from JW_CJ_JDDZSYB_ZJDX where zsnddm = sZsnddm) ;
       end if;
       return(kcjd);
     else
       kcjd := null;
       return(kcjd);
     end if;

  else  --0：按绩点类型计算绩点
     select count(*) into k from jw_cj_jddzb where cjlxbj = vBj and (qsf <= cjbfz  and (cjbfz < jsf or (cjbfz = 100 and jsf = 100) ) );
     if k = 0 then
     begin
       if cjbfz < 60 or cjbfz > 100 then
         kcjd := 0;
       else
         kcjd:=trunc((cjbfz-50)/10)+ trunc(mod(cjbfz,10))/10;
         if kcjd > 5 then
            kcjd := 5;
         end if;
       end if;
     exception
       WHEN OTHERS THEN
         kcjd := null;
     end;
     else
       select jd into kcjd from jw_cj_jddzb where cjlxbj = vBj and (qsf <= cjbfz  and (cjbfz < jsf or (cjbfz = 100 and jsf = 100) ) );
     end if;
     return(kcjd);
  end if;
end fn_jd;

/

