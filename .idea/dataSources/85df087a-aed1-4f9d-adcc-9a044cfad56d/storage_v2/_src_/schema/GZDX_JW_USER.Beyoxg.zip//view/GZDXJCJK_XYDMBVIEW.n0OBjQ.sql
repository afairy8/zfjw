create view GZDXJCJK_XYDMBVIEW as
  select xydm,xymc from(
select jg_id xydm,
          jgdm,
       --jgdm,
       jgmc xymc
  from zftal_xtgl_jgdmb
  where jgmc<>'音乐舞蹈学院（团委课）')
/

