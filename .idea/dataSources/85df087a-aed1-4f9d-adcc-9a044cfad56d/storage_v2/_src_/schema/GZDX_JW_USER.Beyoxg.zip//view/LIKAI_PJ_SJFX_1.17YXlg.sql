create view LIKAI_PJ_SJFX_1 as
  select xnm,xqm,CPDXDM,jgh_id,理论优,理论良,理论中,理论差,实验优,实验良,实验中,实验差,其它优,其它良,其它中,其它差 from
(select t.xnm,t.xqm,t.cpdxdm,t.jgh_id,t.fsd,count(t.JXBPFB_ID) fsdcs
  from
(select
     pfb.XNM,
     pfb.xqm,
     pfb.CPDXDM,
     pfb.JGH_ID,
     LIKAI_JW_PUBLICINTERFACE.getTklxByMbmc(pfb.JXBPFB_ID)||'-'||(case when pfb.BFZPF>=90 then '优' when pfb.BFZPF>=80 then '良' when pfb.BFZPF>=70 then '中' else '差' end) fsd,
    pfb.JXBPFB_ID
   from jw_pj_jxbpfb pfb
   where to_number(pfb.BFZPF) > 0) t
group by t.xnm,t.xqm,t.cpdxdm,t.jgh_id,t.fsd) t
pivot (max(fsdcs) for fsd in ('理论-优' as 理论优,'实验-优' as 实验优,
'理论-良' as 理论良,'实验-良' as 实验良,
'理论-中' as 理论中,'实验-中' as 实验中,
'理论-差' as 理论差,'实验-差' as 实验差,
'其它-优' as 其它优,
'其它-良' as 其它良,
'其它-中' as 其它中,
'其它-差' as 其它差))
/

