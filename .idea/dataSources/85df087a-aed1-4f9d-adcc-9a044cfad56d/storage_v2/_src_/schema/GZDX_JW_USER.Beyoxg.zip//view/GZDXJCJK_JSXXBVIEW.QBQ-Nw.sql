create view GZDXJCJK_JSXXBVIEW as
  select zgh, xm, xb, bm, csrq, zc
  from (select t0.jgh zgh,
               t0.xm,
               case
                 when xbm = '1' then
                  '男'
                 else
                  '女'
               end xb,
               t2.jgmc bm,
               '' csrq,
               zcmc zc
          from jw_jg_jzgxxb t0, JW_JG_JZGSHXXB t1, zftal_xtgl_jgdmb t2
         where t1.jg_id = t2.jg_id
           and t0.jgh_id = t1.jgh_id
           and t1.xnm =
               (select zdz from zftal_xtgl_xtszb where zs = '任务落实学年')
           and t1.xqm =
               (select zdz from zftal_xtgl_xtszb where zs = '任务落实学期')
           and t0.dqzt = '1')
/

