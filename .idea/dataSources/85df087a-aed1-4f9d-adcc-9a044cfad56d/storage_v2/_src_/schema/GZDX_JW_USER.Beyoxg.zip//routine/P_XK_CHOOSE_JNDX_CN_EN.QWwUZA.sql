create procedure p_xk_choose_jndx_cn_en
(
  in_kklxdm in varchar2,
  in_ids in varchar2,
  in_rlkz in varchar2,
  in_rlzlkz in varchar2,
  in_xh_id in varchar2,
  in_njdm_id in varchar2,
  in_xkxnm in varchar2,
  in_xkxqm in varchar2,
  in_xklc in varchar2,
  in_cxbj in varchar2,
  in_xxkbj in varchar2,
  in_kch_id in varchar2,
  in_xkkz_id in varchar2,
  in_qz in varchar2,
  in_sxbj in varchar2,
  in_zh_en in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
    v_wyljxbxx varchar2(200);
    sqlStr varchar2(2000);
    v_count number;
    v_total_kc number;
    v_total_xf float;
    v_zdzys number;
    v_zy_count number;
    v_lnzgxkmc number;
    v_lnzgxkxf number;
    v_bxqzgxkmc number;
    v_bxqzgxkxf number;
    v_sfzyxk varchar2(1);
    v_kklxmc varchar2(20);
	v_kklxywmc varchar2(200);
    v_fxbj varchar2(1);
    v_njdm_id varchar2(5);
    v_bklx_id varchar2(32);
    v_xzjxbCount number;
    isfjxb varchar2(40);
    v_sfkzyxk varchar2(1);
    v_xnm varchar2(5);
    v_xqm varchar2(2);
    v_sfkxk varchar2(1);
    v_pjkz varchar2(1);
    v_jfkz varchar2(1);
    v_gz_sfzx varchar2(1);
    v_xs_sfzx varchar2(1);
    v_bdzcbj varchar2(2);
    v_zckz varchar2(1);
    v_ztbj varchar2(1);
    v_kklxdm varchar2(5);
    v_xf float;
    v_jxbrs number;
    v_krrl number;
    v_yxzrs number;
    v_yl number;
    v_rwyxzrs number;
    jxb_id_array mytype;
    wyljxb_id_array mytype;
    cursor cursor_xsxk(v_xh_id varchar2,v_xnm varchar2,v_xqm varchar2,v_kch_id varchar2) is
           select jxb_id,rownum rwn from (
                 select a.jxb_id from JW_XK_XSXKB a,jw_jxrw_jxbxxb b
                 where a.jxb_id=b.jxb_id and a.xnm=v_xnm and a.xqm=v_xqm and a.xh_id=v_xh_id
                       and a.zy>0 and b.kch_id=v_kch_id and b.xnm=v_xnm and b.xqm=v_xqm and b.fjxb_id is null
                 order by a.zy);
begin
    out_flag := '1';
    v_bklx_id := '0';
    v_fxbj := '0';
    v_zy_count := 0;
    jxb_id_array := my_split(in_ids,',');
    v_wyljxbxx := '';

    if in_kklxdm='04' then
        v_fxbj := '1';
    elsif in_kklxdm='02' then
        v_fxbj := '2';
    elsif in_kklxdm='03' then
        v_fxbj := '3';
    end if;

    --判断该课程学生是否已选过
    select count(*) into v_count from jw_xk_xsxkb a where xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    if v_count='1' then
        out_flag := '1';--该教学班该学生已选过
        goto nextOne; --跳出循环
    end if;

    --判断当前是否在选课时间内
    select count(*) into v_count from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if v_count='0' then
        out_flag := '0';--不在选课时间内
        if in_zh_en='en_US' then
            out_msg := 'Class selection time is over!';
        else
            out_msg := '选课时间已过！';
        end if;
        goto nextOne; --跳出循环
    end if;

    --查找可能要用到的选课规则设置项
    --select kklxmc into v_kklxmc from jw_jcdm_kklxdmb where kklxdm=in_kklxdm;
    select kklxmc,kklxywmc into v_kklxmc,v_kklxywmc from jw_jcdm_kklxdmb where kklxdm=in_kklxdm;
    select
        nvl(b.sfkxk,'0'),b.sfzyxk,nvl(b.zdzys,1),nvl(b.lnzgxkmc,0),nvl(b.lnzgxkxf,0),
        nvl(b.bxqzgxkmc,0),nvl(b.bxqzgxkxf,0),nvl(pjkz,'0'),nvl(jfkz,'0'),nvl(sfzx,'0'),nvl(zckz,'0')
    into
        v_sfkxk,v_sfzyxk,v_zdzys,v_lnzgxkmc,v_lnzgxkxf,v_bxqzgxkmc,v_bxqzgxkxf,v_pjkz,v_jfkz,v_gz_sfzx,v_zckz
    from JW_XK_XKKZXMB b where b.xkkz_id=in_xkkz_id;

    if v_sfkxk='0' then
        out_flag:='0';
        if in_zh_en='en_US' then
            out_msg := 'Sorry, class selection is not open at the present time!';
        else
            out_msg := '对不起，当前未开放选课！';
        end if;
        goto nextOne;
    end if;

    if v_pjkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDPJXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDPJXQM';
        select max(nvl(ztbj,'0')) into v_ztbj from jw_pj_xspjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id;
        if nvl(v_ztbj,'w')='w' then --不存在状态记录
            if fn_xspjztbj(v_xnm,v_xqm,in_xh_id)='0' then
                out_flag:='0';
                if in_zh_en='en_US' then
                    out_msg := 'Unfinished evaluation, not optional course!';
                else
                    out_msg := '未完成评价，不可选课！';
                end if;
                goto nextOne; --跳出循环
            end if;
        else
            if v_ztbj!='1' then
                out_flag:='0';
                if in_zh_en='en_US' then
                    out_msg := 'Unfinished evaluation, not optional course!';
                else
                    out_msg := '未完成评价，不可选课！';
                end if;
                goto nextOne; --跳出循环
            end if;
        end if;
    end if;

    if v_jfkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDJFXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDJFXQM';
        select count(*) into v_count from jw_xjgl_xsxqjfztb where xh_id=in_xh_id and xnm=v_xnm and decode(xqm,'0',v_xqm,xqm)=v_xqm and jfzt='1';
        if v_count=0 then
            out_flag:='0';
            if in_zh_en='en_US' then
                out_msg := 'Not paid, not optional course!';
            else
                out_msg := '未缴费，不可选课！';
            end if;
            goto nextOne; --跳出循环
        end if;
    end if;

    if v_gz_sfzx='1' or v_zckz='1' then
      select nvl(sfzx,'0'),nvl(bdzcbj,'0') into v_xs_sfzx,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;
      if v_gz_sfzx='1' and v_xs_sfzx='0' then
            out_flag:='0';
            if in_zh_en='en_US' then
                out_msg:='Sorry, your current status is not in school, you can not choose such courses!';
            else
                out_msg:='对不起，您当前学籍状态为不在校，不可选此类课程！';
            end if;
            goto nextOne;
        end if;
        if v_zckz='1' and v_bdzcbj not in ('2','3') then
            out_flag:='0';
            if in_zh_en='en_US' then
                out_msg:='Sorry, your student status is unregistered, you can not choose this kind of course!';
            else
                out_msg:='对不起，您的学籍处于未注册状态，不可选此类课程！';
            end if;
            goto nextOne;
        end if;
    end if;

    --最大志愿数判断
    if v_sfzyxk='1' then
        select count(*) into v_count from jw_jxrw_jxbxxb a,jw_xk_xsxkb b where a.jxb_id=b.jxb_id and a.fjxb_id is null and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.kch_id=in_kch_id and b.xh_id=in_xh_id;
        v_zy_count := v_count;
        if v_count >= v_zdzys then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'Over the maximum number of volunteers limit, no re-election!';
            else
                out_msg := '超过最大志愿数限制，不可再选！';
            end if;
            goto nextOne; --跳出循环
        end if;
    end if;

    select nvl(t.xf,0) into v_xf from jw_jxrw_jxbxxb t where jxb_id=jxb_id_array(1);
    --历年最高选课学分
    if v_lnzgxkmc > 0 or v_lnzgxkxf > 0 then
        select sum(nvl(t1.xf,0)),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb a,jw_xk_xsxkb b where t1.kch_id=a.kch_id and a.jxb_id=b.jxb_id and a.kklxdm=in_kklxdm and a.xnm=b.xnm and a.xqm=b.xqm and a.xnm||lpad(a.xqm,3,'0') <= in_xkxnm||lpad(in_xkxqm,3,'0') and b.xh_id=in_xh_id);
        if v_lnzgxkmc > 0 and v_total_kc >= v_lnzgxkmc and v_zy_count=0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'It is not optional to exceed the maximum number of elective courses for '||v_kklxywmc||' in previous years.';
            else
                out_msg := '超过'||v_kklxmc||'历年最高选课门次限制，不可选！';
            end if;
           goto nextOne; --跳出循环
        end if;
        if v_lnzgxkxf > 0 and (v_total_xf+v_xf) > v_lnzgxkxf and v_zy_count=0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'It is not optional to exceed the maximum credit limit for elective courses in '||v_kklxywmc||' in previous years.';
            else
                out_msg := '超过'||v_kklxmc||'历年最高选课学分限制，不可选！';
            end if;
           goto nextOne; --跳出循环
        end if;
    end if;

    --本学期最高选课学分
    /*if v_bxqzgxkmc > 0 or v_bxqzgxkxf > 0 then
       select sum(t1.xf),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb t2,jw_xk_xsxkb t3 where t1.kch_id=t2.kch_id and t2.jxb_id=t3.jxb_id and t2.kklxdm=in_kklxdm and t2.xnm=in_xkxnm and t2.xqm=in_xkxqm and t3.xnm=in_xkxnm and t3.xqm=in_xkxqm and t3.xh_id=in_xh_id);
       if v_bxqzgxkmc > 0 and v_total_kc >= v_bxqzgxkmc and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课门次限制，不可选！';
          goto nextOne; --跳出循环
       end if;
       if v_bxqzgxkxf > 0 and (v_total_xf+v_xf) > v_bxqzgxkxf and v_zy_count=0 then
          out_flag := '0';
          out_msg := '超过'||v_kklxmc||'本学期最高选课学分限制，不可选！';
          goto nextOne; --跳出循环
       end if;
    end if;*/

    if in_xxkbj='1' then
        select nvl((select sfkzyxk from jw_xk_qtxkgzb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id='tongyi'),'0') into v_sfkzyxk from dual;
        if v_sfkzyxk='1' then --判断先行课（预修课）控制是否设置为控制
            select count(b.jxb_id) into v_count from jw_jh_kcyxyqb a,jw_xk_xsxkb b where a.yxkch_id=b.kch_id and b.xnm||b.xqm!=in_xkxnm||in_xkxqm and b.xh_id=in_xh_id and a.kch_id=in_kch_id;
            if v_count=0 then
                out_flag := '0';
                if in_zh_en='en_US' then
                    out_msg := 'The advanced course of this course has not been taken, so it is not optional! ';
                else
                    out_msg :='该课程的先行课未修，不可选！';
                end if;
                goto nextOne; --跳出检验
            end if;
        end if;
    end if;

    --判断学生是否已选体育课
    if in_kklxdm='10' then
        select count(jxb_id) into v_count from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(1) and kklxdm='05';
        if v_count > 0 then
            select count(a.jxb_id) into v_count from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != in_kch_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.xh_id=in_xh_id;
            if v_count > 0 then
                out_flag := '0';
                if in_zh_en='en_US' then
                    out_msg := 'You have chosen PE class, no more!';
                else
                    out_msg :='您已选过体育课，不可再选！';
                end if;
                goto nextOne; --跳出循环
            end if;
        end if;
    end if;

    --板块课同一个课组只能选一门课程
    if in_kklxdm='06' then
        --该课程是否为某课组内课程
        --select nvl((select bklx_id from view_xk_bkkkzb a where xnm=in_xkxnm and xqm=in_xkxqm and kch_id=in_kch_id and njdm_id=in_njdm_id and exists (select 1 from jw_xjgl_xsbklxcjb b where a.bklx_id=b.bklx_id and b.xh_id=in_xh_id)),'0') into v_bklx_id from dual;
        select nvl(bklx_id,'0') into v_bklx_id from JW_XK_XKKZB where xkkz_id=in_xkkz_id;
        if v_bklx_id != '0' then select count(*) into v_count from jw_xk_xsxkb a,view_xk_bkkkzb b where a.kch_id=b.kch_id and a.kch_id != in_kch_id and a.xnm=b.xnm and a.xqm=b.xqm and b.njdm_id=in_njdm_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.xh_id=in_xh_id and b.bklx_id=v_bklx_id;
            if v_count > 0 then
                out_flag := '0';
                if in_zh_en='en_US' then
                    out_msg := 'You have chosen other courses in the course group of this course, and can’t choose any more!';
                else
                    out_msg :='您已选过该课程所在课组的其他课程，不可再选！';
                end if;
                goto nextOne; --跳出循环
            end if;
        end if;
    end if;

    select njdm_id into v_njdm_id from jw_xjgl_xsxjxxb where xh_id=in_xh_id and xnm=in_xkxnm and xqm=in_xkxqm;

    if v_njdm_id >= '2014' then
        sqlStr := 'select count(*) from (select a.jxb_id,b.xqj,b.zcd,b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b where a.jxb_id=b.jxb_id and a.kch_id != '''||in_kch_id||''' and a.xh_id='''||in_xh_id||''' and b.xnm='''||in_xkxnm||''' and b.xqm='''||in_xkxqm||''' and a.xnm='''||in_xkxnm||''' and a.xqm='''||in_xkxqm||''') t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
        Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
        if v_count > 0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'The class time of the selected class is in conflict with other classes! ';
            else
                out_msg := '所选教学班的上课时间与其他教学班有冲突！';
            end if;
            goto nextOne; --跳出循环
        end if;
    elsif in_cxbj != '1' then
         sqlStr := 'select count(*) from (select a.jxb_id,b.xqj,b.zcd,b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b where a.jxb_id=b.jxb_id and a.kch_id != '''||in_kch_id||''' and a.cxbj!=''1'' and a.xh_id='''||in_xh_id||''' and b.xnm='''||in_xkxnm||''' and b.xqm='''||in_xkxqm||''' and a.xnm='''||in_xkxnm||''' and a.xqm='''||in_xkxqm||''') t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
         Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
         if v_count > 0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'The class time of the selected class is in conflict with other classes! ';
            else
                out_msg := '所选教学班的上课时间与其他教学班有冲突！';
            end if;
            goto nextOne; --跳出循环
         end if;
    end if;

    select count(*) into v_count from zftal_xtgl_xtszb where zdm='PKFS' and zdz='1';
    if v_count > 0 then--先排考后选课，需判断考试冲突
        sqlStr := 'select count(*) from (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_xk_xsxkb xk, jw_pk_kbsjb kb where kb.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxsk,
            (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
            from jw_pk_xlb t4,jw_pk_rcmxb t5,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
            where t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq and t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
            where yxsk.xqj=dxks.xqj and bitand(yxsk.zcd, dxks.zcd) > 0 and bitand(yxsk.jc, dxks.jc) > 0';
        Execute Immediate sqlStr into v_count;--考试与上课冲突个数
        if v_count > 0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'The exam time of the selected class conflicts with that of other classes.';
            else
                out_msg := '所选教学班的考试时间与其他教学班上课时间有冲突！';
            end if;
            goto nextOne; --跳出循环
        end if;

        sqlStr := 'select count(*) from(select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
            where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxks,
            (select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
            where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
            where yxks.ksrq=dxks.ksrq and yxks.ksjssj >= dxks.kskssj and yxks.kskssj <= dxks.ksjssj';
        Execute Immediate sqlStr into v_count;--考试与考试冲突个数
        if v_count > 0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'The exam time of the selected class conflicts with that of other classes.';
            else
                out_msg := '所选教学班的考试时间与其他教学班考试时间有冲突！';
            end if;
            goto nextOne; --跳出循环
        end if;

        sqlStr := 'select count(*) from (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
            from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3,jw_pk_xlb t4,jw_pk_rcmxb t5 where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq and t1.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||in_xkxnm||''' and xk.xqm='''||in_xkxqm||''') yxks,
            (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_pk_kbsjb kb where kb.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxsk where yxks.xqj=dxsk.xqj and bitand(yxks.zcd, dxsk.zcd) > 0 and bitand(yxks.jc, dxsk.jc) > 0';
        Execute Immediate sqlStr into v_count;--上课与考试冲突个数
        if v_count > 0 then
            out_flag := '0';
            if in_zh_en='en_US' then
                out_msg := 'The class time of the selected class is in conflict with the examination time of other classes.';
            else
                out_msg := '所选教学班的上课时间与其他教学班考试时间有冲突！';
            end if;
            goto nextOne; --跳出循环
        end if;
    end if;

    --检测全部合格时将教学班加入学生的选课表中
    FOR i IN 1..jxb_id_array.count LOOP
      if i=1 and in_qz='0' then
        --一门课程可能有多个可选教学班志愿，新加一个志愿时，要排在已选志愿的最后面
        select count(a.jxb_id)+1 into v_xzjxbCount from JW_XK_XSXKB a,jw_jxrw_jxbxxb b where a.jxb_id=b.jxb_id and a.xh_id=in_xh_id and a.xnm=in_xkxnm and a.xqm=in_xkxqm and a.zy>0 and b.kch_id=in_kch_id and b.xnm=in_xkxnm and b.xqm=in_xkxqm and b.fjxb_id is null;
        if v_xzjxbCount > 1 then
               for p_xsxk in cursor_xsxk(in_xh_id,in_xkxnm,in_xkxqm,in_kch_id) loop
                   update JW_XK_XSXKB set zy=p_xsxk.rwn where jxb_id=p_xsxk.jxb_id and xh_id=in_xh_id;
               end loop;
        end if;
      elsif i=1 then
        v_xzjxbCount := 0;
      end if;

      select nvl(fjxb_id,'0'),nvl(a.jxbrs,0) jxbrs,nvl(a.krrl,0) krrl,kklxdm
         into isfjxb,v_jxbrs,v_krrl,v_kklxdm
      from jw_jxrw_jxbxxb a where a.jxb_id=jxb_id_array(i);

      --统计该教学班已选人数
      select count(xh_id) into v_yxzrs from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i);

      --父教学班有排志愿的需要，而子教学班统一将志愿字段设为０
      if isfjxb != '0' then
         v_xzjxbCount := 0;
      end if;

      if nvl(in_rlkz,'0')!='1' and nvl(in_rlzlkz,'0')!='1' then
         v_yl := 1;
      else
         v_yl := v_jxbrs + v_krrl - v_yxzrs;
      end if;

      if v_yl > 0 then
        --xkbj=10(学生自选)，20(配课生成)，30(管理员调课生成)
        if in_rlzlkz='1' then
           insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,kklxdm)   select jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,in_cxbj,in_xkxnm,in_xkxqm,in_kch_id,v_bklx_id,in_kklxdm from jw_jxrw_jxbxxb t1 where t1.jxb_id=jxb_id_array(i) and (t1.jxbrs+nvl(t1.krrl,0))>(select count(xh_id) from jw_xk_xsxkb t2 where t2.jxb_id=jxb_id_array(i) and xnm=in_xkxnm and xqm=in_xkxqm);
        else
            insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id,kklxdm) values (jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,in_cxbj,in_xkxnm,in_xkxqm,in_kch_id,v_bklx_id,in_kklxdm);
        end if;

        update jw_jxrw_jxbxxb set yxzrs=v_yxzrs+1 where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i);

        if in_rlzlkz='1' then
           select count(xh_id) into v_count from JW_XK_XSXKB where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i) and xh_id=in_xh_id;
           if v_count=0 then
              select (jxbrs+nvl(krrl,0)) into v_yxzrs from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=jxb_id_array(i);
              out_flag := '-1';
              if i=0 then
                 out_msg := '0'||','||jxb_id_array(i)||','||v_yxzrs;
              else
                 out_msg := '1'||','||jxb_id_array(i)||','||v_yxzrs;
              end if;
              goto nextOne; --跳出循环
           end if;
        end if;

      else
          out_flag := '-1';
          if i=0 then
             out_msg := '0'||','||jxb_id_array(i)||','||v_yxzrs;
          else
             out_msg := '1'||','||jxb_id_array(i)||','||v_yxzrs;
          end if;
          v_wyljxbxx := v_wyljxbxx ||','|| jxb_id_array(i);--记录无余量教学班id
          goto nextOne; --跳出循环
      end if;
    end LOOP;

    <<nextOne>>

    if out_flag='-1' then
       rollback;
       wyljxb_id_array := my_split(v_wyljxbxx,',');
       for k in 2..wyljxb_id_array.count loop
         select yxzrs into v_rwyxzrs from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
         select count(xh_id) into v_yxzrs from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
         if v_rwyxzrs != v_yxzrs then
             update jw_jxrw_jxbxxb set yxzrs=v_yxzrs where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=wyljxb_id_array(k);
         end if;
       end loop;
       commit;
    else
       commit;
    end if;
end;

/

