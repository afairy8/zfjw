create view ZFTAL_SJCJ_S_GJ331 as
  (select
  al,
  rownum bh,
  sxnzxss,
  zjzs,
  zjfx,
  zjzr,
  zjqt,
  jsby,
  jsjy,
  jsxx,
  jstx,
  jssw,
  jszc,
  (sxnzxss + zjzs + zjfx + zjzr + zjqt - jsby - jsjy - jsxx - jstx - jssw - jszc - bxnzxss) jsqt,
  bxnzxss
from
(select t.mc al,
         sum(case when b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) and b.xqm='3' and b.sfzx='1' then 1 else 0 end) sxnzxss,
         sum(case when b.xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') and b.xqm='3' and b.sfzx='1' and b.xnm = b.zsnddm then 1 else 0 end) zjzs,
         sum(case when b.ydlbm = '12' and b.xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') then 1 else 0 end) zjfx,
         sum(case when b.ydlbm = '22' and b.xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') then 1 else 0 end) zjzr,
         0 zjqt,
         sum(case when b.xjztdm= '07' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jsby,
         sum(case when b.ydlbm = '62' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jsjy,
         sum(case when b.ydlbm = '11' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jsxx,
         sum(case when b.ydlbm = '31' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jstx,
         sum(case when b.ydlbm = '42' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jskc,
         sum(case when b.ydlbm = '51' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jssw,
         sum(case when b.ydlbm = '21' and b.xnm = ((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) then 1 else 0 end) jszc,
         1 jsqt,
         sum(case when b.xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') and b.xqm='3' and b.sfzx='1' then 1 else 0 end) bxnzxss

    from zftal_xtgl_jcsjb t,
         (select t.ydlbm,xj.xslbdm,xj.xnm,xj.xqm,xj.zsnddm,xj.xjztdm,xj.sfzx
          from JW_XJGL_XJYDB t, jw_xjgl_xsxjxxb xj,jw_xjgl_xjydlbdmb yddm
          where t.xh_id(+) = xj.xh_id and t.ydlbm = yddm.ydlbm(+)
          and (xj.bdzcbj = '1' or xj.bdzcbj = '2')
         ) b
   where t.lx = '0016'
     and t.dm = b.xslbdm
   group by t.mc
))
/

