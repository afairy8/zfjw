create view VIEW_XK_BKKKZB as
  select a.xnm,a.xqm,a.bklx_id,a.bklxdjb_id,b.kch_id,a.njdm_id from
 jw_jxrw_bklxdjkzdzb a,jw_jh_kzkcdmb b where a.kz_id = b.kz_id
union all
select a.xnm,a.xqm,a.bklx_id,a.bklxdjb_id,b.kch_id,a.njdm_id from
 jw_jxrw_bklxdjkzdzb a,jw_jh_kcdmb b where a.kz_id = b.kch_id
/

