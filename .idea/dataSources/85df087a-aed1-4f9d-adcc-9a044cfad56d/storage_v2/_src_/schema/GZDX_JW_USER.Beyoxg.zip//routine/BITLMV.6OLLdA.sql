create function bitlmv(x IN NUMBER,y IN NUMBER)---以X值左移Y位
return number is
begin
return x* power(2,y);
end;


/

