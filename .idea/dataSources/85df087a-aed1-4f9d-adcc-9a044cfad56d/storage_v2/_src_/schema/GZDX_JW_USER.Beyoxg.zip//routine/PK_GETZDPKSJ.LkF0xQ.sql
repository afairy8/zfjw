create Procedure Pk_GetZdpksj(  ---自动排课任务要求取时间---
 vXnm in varchar2,
 vXqm in varchar2,
 vXqh_id in varchar2,
 vkch_ids in varchar2,
 vJxb_id in varchar2,
 vJgh_ids in varchar2,
 nZhxs in number,
 nZcd in number,
 nXqj out number,
 nJcd out number,
 vBj out varchar2)
 as
 sJxbxqj varchar2(30);
 sKcxqj varchar2(30);
 sJsxqj varchar2(30);
 begin
   sJxbxqj := '';
   sKcxqj  := '';
   sJsxqj  := '';
 -------取同一教学班有无排课到某一星期----
 select wm_concat(xqj) xqj  into sJxbxqj from
                (select distinct xqj from jw_pk_kbsjb where jxb_id = vJxb_id ) ;
 -------取同一课程不同教学班有无排课到某一星期----
 select wm_concat(xqj) xqj into sKcxqj from (select distinct xqj from jw_pk_kbsjb a where a.xnm = vXnm and a.xqm = vXqm and
        exists(select 'X' from jw_jxrw_jxbxxb b where a.jxb_id = b.jxb_id and
        instr(','||vKch_ids||',' , ','||b.kch_id||',') > 0 ) and
        jxb_id <> vJxb_id);
 -------取同一教师有无排课到某一星期----
 select wm_concat(xqj) xqj into sJsxqj from (select distinct xqj from jw_pk_kbsjb a where a.xnm = vXnm and a.xqm = vXqm and
       exists(select 'X' from jw_jxrw_jxbjsrkb b where a.jxb_id = b.jxb_id and
       instr(','||vJgh_ids||',' , ','||b.jgh_id||',') > 0 ));

  vBj := '';
  select xqj,Get_JcToBinary((minjc+1)||'-'||(minjc+nZhxs)) jcd into nXqj,nJcd   from (  --,px,jxbpx,kcpx,jspx
   select xnm,xqm,xqh_id,rsdm,rsdmc,xqj,zc,jcd,jcxx,jcs,minjc,px,jxbpx,kcpx,jspx from (
   select xnm,xqm,xqh_id,rsdm,rsdmc,xqj,
       zc,jcd,jcxx,fn_jszs(jcxx) jcs,minjc,
       to_number(case when xqj <= 5 and bitand(rsdm,14) > 0 then 1   /*14表示日时段白天的时间，本排序（PX）用于排课白天优于晚上，星期五及之前优于周末的情况*/
                      when xqj > 5 and bitand(rsdm,14) > 0 then 2
                      when xqj > 5 and bitand(rsdm,14) = 0 then 3
                                                           else 4 end) px,
       instr(get_xqjxx(sJxbxqj,1),xqj) jxbpx,
       instr(get_xqjxx(sKcxqj,0),xqj) kcpx,
       instr(get_xqjxx(sJsxqj,0),xqj) jspx
       from
      (select a.xnm,a.xqm,a.xqh_id,a.rsdm,a.rsdmc,a.xqj,a.zc,a.jcd,
              get_jctobinary(fn_jqzd(Get_JcBinaryDesc(jcd,''), ',', b.rn)) jcxx,
              fn_jqzd(fn_jqzd(Get_JcBinaryDesc(jcd,''), ',', b.rn),'-',1)-1 minjc from
       (select xnm,xqm,xqh_id,rsdm,rsdmc,xqj,zc,jcd,fn_jsfgfs(Get_JcBinaryDesc(jcd,''),',')+1 rn from
         (select xnm,xqm,xqh_id,rsdm,rsdmc,get_bitorsunion(wm_concat(zc)) zc,xqj,jcd from
          (select xnm,xqm,xqh_id,zc,xqj,rsdm,rsdmc,get_bitorsunion(wm_concat(jcm)) jcd  from
           (
            select xnm,xqm,xqh_id,zc,xqj,rsdm,rsdmc,jcm from ---日时段节次信息---------------------
             (select distinct a.xnm,a.xqm,a.xqh_id,e.zc,d.xqj,c.rsdm,c.rsdmc,b.jcmc,b.jcm from
                     jw_pk_rsdszb a,jw_pk_rjcszb b,jw_pk_rsddmb c,
                     (select xnm,xqm,rn xqj from jw_pk_pkkzb a,(select rownum rn from jw_pk_rjcszb ) b where rn<=kblx) d,
                     (select distinct a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc from jw_pk_xlb a, jw_pk_rcmxb b where
                             a.xl_id = b.xl_id  and b.dxqzc <> 0 ) e where
                                                                    a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and
                                                                    c.qyzt = '1' and
                                                                    a.xnm = d.xnm and a.xqm = d.xqm and
                                                                    a.xnm = e.xnm and a.xqm = e.xqm and
                                                                    a.xnm = vXnm and a.xqm = vXqm and a.xqh_id = vXqh_id
              )---日时段节次信息----------------
           minus
            select a.xnm,a.xqm,a.xqh_id,a.zc,a.xqj,a.rsdm,a.rsdmc,a.jcm  from
             (select distinct a.xnm,a.xqm,a.xqh_id,e.zc,d.xqj,c.rsdm,c.rsdmc,b.jcmc,b.jcm from ---日时段节次信息------------
                     jw_pk_rsdszb a, jw_pk_rjcszb b,jw_pk_rsddmb c,
                     (select xnm,xqm,rn xqj from jw_pk_pkkzb a,(select rownum rn from jw_pk_rjcszb ) b where rn<=kblx) d,
                     (select distinct a.xnm,b.dxqm xqm,power(2,b.dxqzc-1) zc from jw_pk_xlb a, jw_pk_rcmxb b where
                             a.xl_id = b.xl_id  and b.dxqzc <> 0 ) e where
                                                                          a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and
                                                                          c.qyzt = '1' and
                                                                          a.xnm = d.xnm and a.xqm = d.xqm and
                                                                          a.xnm = e.xnm and a.xqm = e.xqm and
                                                                          a.xnm = vXnm and a.xqm = vXqm and a.xqh_id = vXqh_id
             ) a  ---日时段节次信息---------------------------------------------------------------------------------------------
              inner join
              (------------取出教学班内课表已使用时间**begin----------------------------------
               select b.zcd, b.xqj,b.jc from
                         jw_pk_tjkbjgb a ,jw_pk_kbsjb b where
                                              a.jxb_id = b.jxb_id and
                                              exists (select 'x' from jw_pk_tjkbjgb c where
                                                      exists (select 'X' from
                                                                  (select jxb_id from jw_pk_bbfzb where  --取出存在并班的教学班信息
                                                                     bbfz_id = (select bbfz_id from jw_pk_bbfzb where
                                                                      jxb_id = vJxb_id )
                                                                   union all
                                                                   select vJxb_id from dual  --本教学班信息
                                                                      ) e where e.jxb_id =c.jxb_id) and
                                                      a.xnm = c.xnm and bitand(a.xqm,c.xqm) > 0  and
                                                      a.njdm_id = c.njdm_id and a.zyh_id = c.zyh_id and
                                                      a.bh_id = c.bh_id and
                                                      a.tjkbzdm = c.tjkbzdm and
                                                      a.tjkbzxsdm = c.tjkbzxsdm
                                                      )------------课表已使用时间****end------------
               union all
               select t3.zcd,t3.xqj,t3.jc from  --t2.xnm,t2.xqm,t2.xqh_id,t2.njdm_id,t1.zyh_id,t1.bh_id,
                      jw_jxrw_bkzybjdzb t1,jw_jxrw_bkxxb t2,jw_jxrw_bkpksjb t3,jw_jxrw_jxbhbxxb t4 where
                       t1.bkxxb_id = t2.bkxxb_id
                   and t1.bkxxb_id = t3.bkxxb_id
                   and t2.njdm_id = t4.njdm_id
                   and t1.zyh_id  = t4.zyh_id
                   and t1.bh_id = t4.bh_id
                   and t4.jxb_id = vJxb_id  -----板块课使用时间
               union all
               select zcd, xqj,jc from ------------取出教学班内教师已使用时间**begin-----
                                          jw_pk_kbsjb where
                                                xnm = vXnm and bitand(xqm ,vXqm) > 0  and
                                                instr(','||vJgh_ids||',' , ','||jgh_id||',') > 0  ---取出教学班内教师已使用时间****end--
               union all
               select b.zcd,b.xqj,b.jc from  ----教学任务属性限制排课时间信息--begin---
                                       jw_pk_pksjxzb a,jw_pk_pksjxzzb b,jw_jxrw_jxbxxb c,
                                       jw_jxrw_jxbhbxxb d,jw_jxrw_jxbjsrkb e where
                                                a.xnm = vXnm and a.xqm = vXqm and a.xqh_id = vXqh_id and
                                                c.jxb_id = vJxb_id and
                                                a.pksjxz_id = b.pksjxz_id  and
                                                a.xnm = c.xnm and a.xqm = c.xqm and
                                                a.xqh_id = c.xqh_id and
                                                c.jxb_id = d.jxb_id and
                                                c.jxb_id = e.jxb_id and
                                                a.dm = (case
                                                           when a.lb = '1' then(select jg_id from
                                                                                        zftal_xtgl_zydmb m where
                                                                                        m.zyh_id = d.zyh_id
                                                                                )
                                                             when a.lb = '2' then d.zyh_id
                                                             when a.lb = '3' then c.kch_id
                                                             when a.lb = '4' then e.jgh_id
                                                             when a.lb = '6' then d.njdm_id
                                                             when a.lb = '7' then d.bh_id
                                                             when a.lb = '8' then d.njdm_id||d.zyh_id
                                                             when a.lb = '9' then c.xqh_id end
                                                         )----教学任务属性限制排课时间信息----end--------
                 ) b
                 on (a.xqj = b.xqj and bitand(a.zc,nvl(b.zcd,0))>0 and bitand(a.jcm,nvl(b.jc,0))> 0 )
                 )  where
                /*教学周次条件*/ bitand(zc,nZcd)>0
                     group by xnm,xqm,xqh_id,zc,xqj,rsdm,rsdmc
             ) group by xnm,xqm,xqh_id,xqj,jcd,rsdm,rsdmc
            )
           )  a,
          (select rownum rn from jw_pk_rjcszb ) b  where a.rn >= b.rn
        )
       ) where
        /*课时条件*/ jcs >= nZhxs  and
       /*周次是否完整*/(nZcd-bitand(zc,nZcd) = 0) and

       xqj not in
               ( --------------------------------------------
               select xqj from
                 (select jgh_id,xqj,(select b.mtzdxs from jw_jg_jzgrwszb b where a.jgh_id = b.jgh_id ) - max(ks) ks from
                   (select jgh_id,zc,xqj,fn_jszs(get_bitorsunion(wm_concat(jc))) ks from
                     (select b.jgh_id,c.zc, b.xqj,b.jc from ------------取出教学班内教师已使用时间**begin-----
                                jw_pk_kbsjb b,
                                (select power(2,rownum-1) zc from zftal_xtgl_jcsjb where rownum <= 30 ) c where
                                                b.xnm = vXnm and bitand(b.xqm ,vXqm) > 0  and
                                                 instr(','||vJgh_ids||',' , ','||b.jgh_id||',') >0 and
                                                 --b.jgh_id in ('0003283','0003281','0003282') and
                                                bitand(b.zcd,c.zc) >0
                       ) group by jgh_id,zc,xqj
                     ) a group by jgh_id,xqj
                  ) where ks is not null and (ks - nZhxs) < -nZhxs   ---取出教学班内教师已使用时间****end--
               )
                 order by px,jxbpx,kcpx,jspx
               )
                      where rownum <= 1;
------取可用的排课时间--------end--------------------------------------------------------

  null;
 end;


/

