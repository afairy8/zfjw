create function get_cjcxwpj(vXnm varchar2,vXqm varchar2) return varchar2 ---根据学年学期周次判断未评价学生成绩是否可查询
 as
  sFlag     varchar2(2); /*---是否可查询标记（0：不可查询；1：可查询）*/
  sZc       number; /*---周次*/
  sRq       varchar2(32); /*---日期*/
  sCount    number;
begin
  sFlag := '0';
  begin
        ----获取最后一个教学周
        select max(a.zc) into sZc from JW_PK_RCMXB a, jw_pk_xlb b where a.xl_id = b.xl_id and b.xnm = vXnm and a.dxqm = vXqm;

        ----未评价的学生第16周周五24点之后，可以自动让学生看到成绩，夏季学期是课程的结束周周五就可以看到成绩
        if sZc is not null then
            if sZc>15 then
               select to_char(to_date(a.rq, 'yyyy-mm-dd'), 'yyyy-mm-dd') into sRq
                 from JW_PK_RCMXB a, jw_pk_xlb b
                where a.xl_id = b.xl_id and b.xnm = vXnm and a.dxqm = vXqm and a.zc=16 and a.xqj=5;
               ---16周没有星期五
               if sRq is null then
                  select to_char(to_date(max(a.rq), 'yyyy-mm-dd'), 'yyyy-mm-dd') into sRq
                    from JW_PK_RCMXB a, jw_pk_xlb b
                   where a.xl_id = b.xl_id and b.xnm = vXnm and a.dxqm = vXqm and a.zc=16;
               end if;
            else
                select to_char(to_date(a.rq, 'yyyy-mm-dd'), 'yyyy-mm-dd') into sRq
                  from JW_PK_RCMXB a, jw_pk_xlb b
                 where a.xl_id = b.xl_id and b.xnm = vXnm and a.dxqm = vXqm and a.zc=sZc and a.xqj=5;
                ---最后一周没有星期五
                if sRq is null then
                   select to_char(to_date(max(a.rq), 'yyyy-mm-dd'), 'yyyy-mm-dd') into sRq
                     from JW_PK_RCMXB a, jw_pk_xlb b
                    where a.xl_id = b.xl_id and b.xnm = vXnm and a.dxqm = vXqm and a.zc=sZc;
                end if;
            end if;
        end if;

        if sRq is not null then
           select case when to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')>to_date(substr(sRq,1,10),'yyyy-mm-dd') then '1' else '0' end into sFlag from dual;
        end if;
        ---上海交通大学
        select count(*) into sCount from zftal_xtgl_xxxxszb where xxdm in('10248');
        if sCount=0 then---如果不是上海交大就不给查询
           sFlag := '0';
        end if;

  exception
    When others then
      sFlag := '0';
  end;
  return sFlag;
end get_cjcxwpj;

/

