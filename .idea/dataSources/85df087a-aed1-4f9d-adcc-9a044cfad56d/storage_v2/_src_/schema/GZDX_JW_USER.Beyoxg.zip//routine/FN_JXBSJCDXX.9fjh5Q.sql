create function fn_jxbsjcdxx(vJxb_id varchar2,vBj varchar2) return varchar2  /**---教学班时间场地信息实时显示----**/
as
   sSjxx varchar2(2000);   /**---时间信息**/
   sCdxx varchar2(2000);   /**---场地信息**/
   sSjywxx varchar2(2000);   /**---时间英文信息**/
   sCdywxx varchar2(2000);   /**---场地英文信息**/
   sSjCdxx varchar2(2000); /**---时间场地信息**/
begin
    sSjcdxx := '';
    begin
     if vBj = '0' then
         /**--dbms_output.put_line('vJxb_id:'||vJxb_id);**/
         select replace(replace(wm_concat(sjxx),',',';'),'|',',')  sjxx,replace(replace(wm_concat(cdxx),',',';'),'|',',') cdxx,
                replace(replace(wm_concat(sjywxx),',',';'),'|',',')  sjywxx,replace(replace(wm_concat(cdywxx),',',';'),'|',',') cdywxx into sSjxx,sCdxx,sSjywxx,sCdywxx from
         (select replace('星期'||
                 case when xqj =1 then '一'
                      when xqj =2 then '二'
                      when xqj = 3 then '三'
                      when xqj = 4 then '四'
                      when xqj = 5 then '五'
                      when xqj = 6 then '六'
                      when xqj = 7 then '日'
                      else  '' end||'第'||Get_JcBinaryDesc(jc,'')||'节{'||get_weeksdesc_xnxq(xnm,xqm,zcd),',','|')||'}' sjxx,
                (select cdmc from jw_jcdm_cdxqxxb b where b.xnm = a.xnm and b.xqm = a.xqm and b.cd_id = a.cd_id) cdxx,
                replace(
                 case when xqj =1 then 'Monday '
                      when xqj =2 then 'Tuesday '
                      when xqj = 3 then 'Wednesday '
                      when xqj = 4 then 'Thursday '
                      when xqj = 5 then 'Friday '
                      when xqj = 6 then 'Saturday '
                      when xqj = 7 then 'Sunday '
                      else  '' end||'Section '||Get_JcBinaryDesc(jc,'')||'{'||get_weeksdesc_xnxqywb(xnm,xqm,zcd),',','|')||'}' sjywxx,
                (select nvl(cdywmc,cdmc) from jw_jcdm_cdxqxxb b where b.xnm = a.xnm and b.xqm = a.xqm and b.cd_id = a.cd_id) cdywxx
          from
          (select min(pkbj) pkbj,xnm,xqm,xqj,jxb_id,jgh_id,cd_id,sum(zcd) zcd, jc from
           (select min(pkbj) pkbj,xnm,xqm,xqj,jxb_id,jgh_id,cd_id,zcd,sum(jc) jc from
            (select xnm,xqm,xqj,jxb_id,jgh_id,cd_id,
                    case when pkbj = 2 then cdzcd
                         when pkbj = 1 then cdzcd
                         when pkbj = 0 then zcd end zcd,
                    case when pkbj = 2 then cdjc
                         when pkbj = 1 then cdjc
                         when pkbj = 0 then jc end jc,pkbj from
              (select kb_id,xnm,xqm,jxb_id,jgh_id,zcd,xqj,jc,pkly,cd_id,cdzcd,cdjc,kb_zcd,kb_jc,
                           case when cd_id is null then 0
                                when zcd != kb_zcd or jc != kb_jc then 1
                                else 2 end pkbj from
                (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd,cdjc,
                        get_bitorsunion(wm_concat(cdzcd) over (partition by kb_id)) kb_zcd,
                        get_bitorsunion(wm_concat(cdjc) over (partition by kb_id)) kb_jc from
                  (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,sum(cdzcd) cdzcd, cdjc from
                    (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd,sum(cdjc) cdjc from
                      (select t1.kb_id,t1.xnm,t1.xqm,t1.xqj,t1.zcd,t1.jc,t1.pkly,t1.jxb_id,t1.jgh_id,t2.cd_id,t2.zcd cdzcd,t2.jc cdjc from
                              jw_pk_kbsjb t1, jw_pk_kbcdb t2,jw_jxrw_jxbxxb t
                                               where t1.jxb_id = t.jxb_id
                                                 and t1.xnm = t.xnm
                                                 and t1.xqm = t.xqm
                                                 and t1.kb_id = t2.kb_id(+)
                                                 and t.jxb_id = vJxb_id
                        ) group by kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd
                     ) group by kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdjc
                    )
                 )
               )
             ) group by xnm,xqm,xqj,jxb_id,jgh_id,cd_id,zcd
           ) group by xnm,xqm,xqj,jxb_id,jgh_id,cd_id,jc order by xqj,jc,zcd
          ) a
        ) ;
         sSjcdxx := trim(sSjxx)||'|'||trim(sCdxx)||'|'||trim(sSjywxx)||'|'||trim(sCdywxx);
   end if ;

   if vBj = '1' then
      select replace(wm_concat(xqjc),'|',',')||','  into sSjcdxx from
      (select replace(case when t1.xqj =1 then '一'
             when t1.xqj =2 then '二'
             when t1.xqj = 3 then '三'
             when t1.xqj = 4 then '四'
             when t1.xqj = 5 then '五'
             when t1.xqj = 6 then '六'
             when t1.xqj = 7 then '日' end||','||fn_bittozc(get_bitorsunion(wm_concat(t1.jc))*2),',','|') xqjc from
             jw_pk_kbsjb t1 where t1.jxb_id = vJxb_id
        group by  t1.xnm,t1.xqm,t1.xqj order by t1.xqj);

   end if ;

     if vBj <> '0' and vBj <> '1' then --传入教师职工号
         /**--dbms_output.put_line('vJxb_id:'||vJxb_id);**/
         select replace(replace(wm_concat(sjxx),',',';'),'|',',')  sjxx,replace(replace(wm_concat(cdxx),',',';'),'|',',') cdxx into sSjxx,sCdxx from
         (select replace('星期'||
                 case when xqj =1 then '一'
                      when xqj =2 then '二'
                      when xqj = 3 then '三'
                      when xqj = 4 then '四'
                      when xqj = 5 then '五'
                      when xqj = 6 then '六'
                      when xqj = 7 then '日'
                      else  '' end||'第'||Get_JcBinaryDesc(jc,'')||'节{'||get_weeksdesc_xnxq(xnm,xqm,zcd),',','|')||'}' sjxx,
                (select cdmc from jw_jcdm_cdxqxxb b where b.xnm = a.xnm and b.xqm = a.xqm and b.cd_id = a.cd_id) cdxx from
          (select min(pkbj) pkbj,xnm,xqm,xqj,jxb_id,jgh_id,cd_id,sum(zcd) zcd, jc from
           (select min(pkbj) pkbj,xnm,xqm,xqj,jxb_id,jgh_id,cd_id,zcd,sum(jc) jc from
            (select xnm,xqm,xqj,jxb_id,jgh_id,cd_id,
                    case when pkbj = 2 then cdzcd
                         when pkbj = 1 then cdzcd
                         when pkbj = 0 then zcd end zcd,
                    case when pkbj = 2 then cdjc
                         when pkbj = 1 then cdjc
                         when pkbj = 0 then jc end jc,pkbj from
              (select kb_id,xnm,xqm,jxb_id,jgh_id,zcd,xqj,jc,pkly,cd_id,cdzcd,cdjc,kb_zcd,kb_jc,
                           case when cd_id is null then 0
                                when zcd != kb_zcd or jc != kb_jc then 1
                                else 2 end pkbj from
                (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd,cdjc,
                        get_bitorsunion(wm_concat(cdzcd) over (partition by kb_id)) kb_zcd,
                        get_bitorsunion(wm_concat(cdjc) over (partition by kb_id)) kb_jc from
                  (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,sum(cdzcd) cdzcd, cdjc from
                    (select kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd,sum(cdjc) cdjc from
                      (select t1.kb_id,t1.xnm,t1.xqm,t1.xqj,t1.zcd,t1.jc,t1.pkly,t1.jxb_id,t1.jgh_id,t2.cd_id,t2.zcd cdzcd,t2.jc cdjc from
                              jw_pk_kbsjb t1, jw_pk_kbcdb t2,jw_jxrw_jxbxxb t
                                               where t1.jxb_id = t.jxb_id
                                                 and t1.xnm = t.xnm
                                                 and t1.xqm = t.xqm
                                                 and t1.kb_id = t2.kb_id(+)
                                                 and t.jxb_id = vJxb_id
                                                 and t1.jgh_id = vBj
                        ) group by kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdzcd
                     ) group by kb_id,xnm,xqm,xqj,zcd,jc,pkly,jxb_id,jgh_id,cd_id,cdjc
                    )
                 )
               )
             ) group by xnm,xqm,xqj,jxb_id,jgh_id,cd_id,zcd
           ) group by xnm,xqm,xqj,jxb_id,jgh_id,cd_id,jc order by xqj,jc,zcd
          ) a
        ) ;
         sSjcdxx := trim(sSjxx)||'|'||trim(sCdxx);
   end if ;

   exception
    When others then
      sSjcdxx := '';
   end;
  return sSjcdxx ;
end fn_jxbsjcdxx;

/

