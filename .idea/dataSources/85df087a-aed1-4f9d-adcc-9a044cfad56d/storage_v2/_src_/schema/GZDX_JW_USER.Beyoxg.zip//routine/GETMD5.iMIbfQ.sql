create function getMD5 ( vin_string IN VARCHAR2 )
RETURN VARCHAR2 IS
   temp varchar2(40);
   varzjhm varchar2(100);
 BEGIN

 if vin_string is null then
   varzjhm:='000000';
   else
   varzjhm:=vin_string;
 end if ;
 temp := dbms_obfuscation_toolkit.MD5(input => utl_raw.cast_to_raw(varzjhm));

 RETURN '{MD5}'||utl_raw.cast_to_varchar2(utl_encode.base64_encode(temp));
END getMD5;

/

