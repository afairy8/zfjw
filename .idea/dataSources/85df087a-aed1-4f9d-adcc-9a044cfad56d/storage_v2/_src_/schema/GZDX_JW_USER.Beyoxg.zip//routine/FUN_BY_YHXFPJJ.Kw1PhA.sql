create function fun_by_yhxfpjj(v_xh_id varchar2,v_tjmc varchar2,v_tjsjcs varchar2,v_tjsjz varchar2,v_tjsjz1 varchar2,
v_tjsjmc varchar2,v_tjsjgx varchar2,v_tjkcxz varchar2,v_btjkc varchar2,v_lx varchar2,v_xdlx varchar2) return varchar2
as
   sJg varchar2(2000);   ---已获学分全部课程平均学分绩-华师
   sqlstr VARCHAR2(30000);
   v_pjf varchar2(10);
   pjxfj_lc varchar2(100);
   v_n   number;
   v_sql varchar(32767);---总的sql
begin
    sJg := '合格';
    begin
       --根据类型获得平均学分绩点
     sqlstr:='select to_char((
    case when t6.cjj_zxf = 0 then 0
    else nvl(round(t6.zxfj / t6.cjj_zxf, 2), 0) end), ''fm9999999990.09'') pjxfj from(select nvl(sum(to_number(nvl(xf, ''0'')) * to_number(nvl(bfzcj, 0))), 0) zxfj, nvl(sum(to_number(nvl((
    case when bfzcj is null then 0
    else to_number(nvl(xf, ''0'')) end), 0))), 0) cjj_zxf from(select row_number() over(partition by xh_id, kch_id order by nvl(bfzcj, 0) desc) rn, xh_id, kch_id, nvl(xf, ''0'') xf, nvl(bfzcj, 0) bfzcj from(select * from(select t1.lx, t1.xnm, t1.xqm, t1.xnm || lpad(t1.xqm, 2, 0) xnxqm, t1.xh_id,
    '''' as cxcs, (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) xnmc, (select mc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) xqmc, (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || ''学年 第'' || (select mc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) || ''学期''
        xnxqmc, (select mc from zftal_xtgl_jcsjb where lx = ''0037''
            and dm = (select khfsdm from jw_jxrw_jxbxxb where jxb_id = t1.jxb_id)) khfs, (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || '' '' || (select ywmc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) || ''Term''
        xnxqywmc, (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || '' '' || ''semester'' || (select ywmc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) xnxqywmc1, (
            case when t1.xqm = ''3''
            then ''The First Semester of the Academic Year of''
            when t1.xqm = ''12''
            then ''The Second Semester of the Academic Year of ''
            else ''''
            end) || (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) xnxqywmc2, ''Academic Year ('' || (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || '')'' || (select ywmc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) || '' Term'' || ''('' || (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || ''学年第'' || (
            case when t1.xqm = ''3''
            then ''一''
            when t1.xqm = ''12''
            then ''二''
            when t1.xqm = ''16''
            then ''三''
            else ''''
            end) || ''学期)''
        as xnxqywmc3, ''Academic Year ('' || (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) || '')'' || (select ywmc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) || '' Term''
        as xnxqywmc4, substr(t1.xnm, -2) || ''-'' || (substr(t1.xnm, -2) + 1) || ''-'' || (select mc from zftal_xtgl_jcsjb where lx = ''0001''
            and dm = t1.xqm) xnxqjc, mzbcj, mbkjd, mzbcjbj, nvl(t1.kcmc, (select kcmc from jw_jh_kcdmb where kch_id = t1.kch_id)) kcmc, t1.kcxzdm, (
            case when t1.cjxzm in (''11'', ''12'') then ''bk''
            when t1.cjxzm = ''16''
            then ''cx''
            else ''zk''
            end) maxcjbj, (select kcxzmc from jw_jh_kcxzdmb where kcxzdm = t1.kcxzdm) kcxzmc, (select kcxzjc from jw_jh_kcxzdmb where kcxzdm = t1.kcxzdm) kcxzjc, (select kcxzywmc from jw_jh_kcxzdmb where kcxzdm = t1.kcxzdm) kcxzywmc, (select kcxzywjc from jw_jh_kcxzdmb where kcxzdm = t1.kcxzdm) kcxzywjc, mzbjd, t1.kclbdm, (select kclbmc from jw_jh_kclbdmb where kclbdm = t1.kclbdm) kclbmc, (select sftjjd from jw_jh_kcxzdmb where kcxzdm = t1.kcxzdm) sftjjd, t1.sskch_id, t1.kch_id, t1.kch, t1.kcywmc, t1.xf, t1.jxb_id, t1.kcbj, t1.cjxzm, t1.jd, t1.bfzcj, ''''
        MCXCJ, ''''
        mcxbfzcj, ''''
        mbkcj, ''''
        mbkbfzcj, ''''
        mcxjd, jd as maxjd, t1.bfzcj as MAXBFZCJ, t1.cj as maxcj, t1.cj, t1.cjbz

        from

        (

            select a.lx, a.XNM, a.XQM, b.njdm_id, b.zyh_id, nvl(b.zyfx_id, ''wfx'') zyfx_id, b.bh_id, a.XH_ID, a.KCH_ID, a.sskch_id, a.KCH, a.KCMC, mzbcj, mbkjd, mzbcjbj, a.KCYWMC, a.XF, a.KCXZDM, a.kclbdm, a.JXB_ID, a.CJ, a.BFZCJ, a.CJBZ, a.JD, a.CJXZM, a.KCBJ, mzbjd, a.BZXX from(select ly as lx, t.XNM, t.XQM, t.njdm_id, t.jg_id, t.zyh_id, t.zyfx_id, t.bh_id, t.XH_ID, t.xh, t.xm, t.xbm, t.sskch_id, t.KCH_ID, t.KCH, t.KCMC, t.KCYWMC, t.XF, t.KCXZDM, t.KCLBDM, t.KCGSDM, t.JXB_ID, ''''
                as mzbcj, ''''
                as mbkjd, ''''
                as mzbcjbj, ''''
                as mzbjd, t.CJ, t.BFZCJ, t.CJBZ, t.JD, t.CJXZM, t.KCBJ, t.BZXX, maxcjbj, maxbfzcj, tdkcbj from

                (

                    select ''cjb''
                    as ly, t.XNM, t.XQM, t.njdm_id, t.jg_id, t.zyh_id, t.zyfx_id, t.bh_id, t.XH_ID, t.xh, t.xm, t.xbm, t.sskch_id, t.KCH_ID, t.KCH,
                    t.KCMC, t.KCYWMC, t.XF, t.KCXZDM, t.KCLBDM, t.KCGSDM, t.JXB_ID, t.CJ, t.BFZCJ, t.CJBZ, t.hkcj, fn_jdjs(t.xnm, t.xqm, t.sskch_id,
                        t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm, t.cjxzm, t.kcbj, null, t.cjbz, t.jd, t.bfzcj,
                        case when t.tdkcbj = ''1''
                        then ''cjb-dtkc''
                        when t.btdkcbj = ''1''
                        then ''cjb-bdtkc''
                        else ''cjb''
                        end, ''tj'', ''0'') as JD, t.CJXZM, t.KCBJ, t.BZXX, row_number() over(partition by t.xh_id, (
                        case when length(t.sskch_id) = 1 or t.sskch_id is null then t.kch_id
                        else t.sskch_id end) order by to_number(t.bfzcj) desc) maxcjbj, max(t.bfzcj) over(partition by t.xh_id, (
                        case when length(t.sskch_id) = 1 or t.sskch_id is null then t.kch_id
                        else t.sskch_id end)) maxbfzcj, fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm,
                        t.cjxzm, t.kcbj, null, t.cjbz, t.jd, t.bfzcj,
                        case when t.tdkcbj = ''1''
                        then ''cjb-dtkc''
                        when t.btdkcbj = ''1''
                        then ''cjb-bdtkc''
                        else ''cjb''
                        end, ''tj'', ''0'') as mzbjd, fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm, t.cjxzm, t.kcbj,
                        null, t.cjbz, t.jd, t.bfzcj,
                        case when t.tdkcbj = ''1''
                        then ''cjb-dtkc''
                        when t.btdkcbj = ''1''
                        then ''cjb-bdtkc''
                        else ''cjb''
                        end, ''tj'', ''0'') as maxjd, null as mbkcj, null as mbkcjbz, null as mbycj, 0 as mbyjd, null as mbycjbz, null as mcxcj, 0 as mcxjd,
                    null as mcxcjbz, t.CJBZ as mzbcjbz, 0 as mzbcjbj, t.CJ as maxcj, t.CJBZ as maxcjbz, t.CJ as mzbcj, t.BFZCJ as mzbbfzcj,
                    t.bkbfzcj as mbkbfzcj, t.BFZCJ as mcxbfzcj, t.BFZCJ as mbybfzcj, (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc, t.tdkcbj, t.btdkcbj from

                    (

                        select a.XNM, a.XQM, b.jg_id, b.njdm_id,
                        b.zyh_id, nvl(b.zyfx_id, ''wfx'') zyfx_id, b.bh_id, a.XH_ID, b.xh, b.xm, b.xbm, a.sskch_id, a.KCH_ID, nvl(kc.kch, a.KCH) as kch,
                        nvl(kc.kcmc, a.KCMC) as kcmc, nvl(kc.kcywmc, a.KCYWMC) as kcywmc, a.XF, a.KCXZDM, a.KCLBDM, a.KCGSDM, a.JXB_ID, a.CJXZM, a.KCBJ, a.BZXX, (select count(1) from jw_cj_xsgrcjdtb cjdtb where cjdtb.zszt = ''3''
                            and a.xh_id = cjdtb.xh_id and(
                                case when length(a.sskch_id) = 1 or a.sskch_id is null then a.kch_id
                                else a.sskch_id end) = cjdtb.kch_id and cjdtb.kcthzbm = ''xnkc''
                            and rownum = 1) as tdkcbj, (select count(1) from jw_cj_xsgrdtzb m, jw_cj_xsgrjhdtb n where m.kcthzh_id = n.kcthzh_id and m.kcthzbm = ''xnkc''
                            and m.zszt = ''3''
                            and n.kch_id = (
                                case when length(a.sskch_id) = 1 or a.sskch_id is null then a.kch_id
                                else a.sskch_id end) and n.xh_id = a.xh_id and rownum = 1) as btdkcbj,
                        case when a.hkcj is null then nvl(a.cj, a.cjbz)
                        else a.hkcj end as cj,
                            case when a.hkcj is null then a.bfzcj
                        else a.hkbfzcj end as bfzcj,
                            case when a.hkcj is null then a.cjbz
                        else a.hkbz end as cjbz,
                            case when a.hkcj is null then a.jd
                        else a.hkjd end as jd, a.bkcj, a.bkbfzcj, a.bkbz, a.bkjd, a.hkcj, a.hkbfzcj, a.hkbz, a.hkjd,
                            case when a.cjxzm in (''16'', ''17'') then row_number() over(partition by a.xh_id, (
                                case when length(a.sskch_id) = 1 or a.sskch_id is null then a.kch_id
                                else a.sskch_id end) order by(
                                case when a.cjxzm in (''16'', ''17'') then to_number(nvl(a.hkbfzcj, a.bfzcj))
                                else 0 end) desc)
                        else 1 end as rn from JW_CJ_XSCJB a, jw_xjgl_xsjbxxb b, jw_jh_kcdmb kc where a.xh_id = b.xh_id and a.cjxzm
                        not in (''02'', ''20'') and nvl(a.cjzt, ''3'') = ''3''
                        and not exists(select ''X''
                            from jw_cj_cjjglxsqb zfb where zfb.cjjglx = ''01''
                            and zfb.shzt = ''3''
                            and zfb.xh_id = a.xh_id and zfb.jxb_id = a.jxb_id) and a.kch_id = kc.kch_id(+) and not exists(select 1 from jw_cj_bzdmb c where(
                            case when a.hkcj is null then a.cjbz
                            else a.hkbz end) = c.cjbzmc and c.cjtjfx = ''0'') and a.kcbj = ''0''
                        and a.xh_id = '''||v_xh_id||'''
                        and a.bfzcj>='''||v_tjsjz1||''' ';
               if v_lx='2' then
                    sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = a.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
              end if;
              if v_tjkcxz is not null and v_tjkcxz!='qb' then
                    sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||a.kcxzdm||'','' )>0 ';
              end if;

        if v_xdlx is not null and v_xdlx!='qb' then
              sqlstr :='AND EXISTS (select 1 from (SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxb xfyq,JW_JH_xsJXZXJHKCXXB kcxx'||
                    ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id union all '||
                    ' SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxfxezyb xfyq,Jw_Jh_Xsjxzxjhkcxxfxezyb kcxx '||
                    ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id) tt '||
                    ' WHERE tt.XH_ID=a.XH_ID  AND tt.KCH_ID=nvl(a.sskch_id,a.KCH_ID) AND ('||

                    ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| tt.xdlx ||'','' ) >0 or'||
                    ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| tt.xdlx ||'','' ) >0 or'||
                    ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| tt.xdlx ||'','' ) >0 or'||
                    ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| tt.xdlx ||'','' ) >0 ))';
              sqlstr:= sqlstr||''||sqlstr;
         end if;

          if v_btjkc is not null then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||a.kch_id||'','' )<1 ';
          end if;

             sqlstr:=sqlstr||'       ) t) t) a, jw_xjgl_xsjbxxb b where a.xh_id = b.xh_id and a.kcbj = ''0''
            and a.xh_id = '''||v_xh_id||'''
            and not exists(select ''X''
                from jw_cj_cjjglxsqb zfb where zfb.cjjglx = ''01''
                and zfb.shzt = ''3''
                and zfb.xh_id = a.xh_id and zfb.jxb_id = a.jxb_id)) t1) t99 where 1 = 1) t4 where xh_id is not null and lx = ''cjb''
    and nvl(t4.bfzcj, 0) >= 60) t5) t6';
    v_n := 1;
    loop
        v_sql := substr(sqlstr, v_n, 1000);
        dbms_output.put_line(v_sql);

        v_n := v_n + 1000;
        exit when v_n > length(sqlstr);
    end loop;


   execute immediate sqlstr into pjxfj_lc;

    sqlstr:='select (case when '||pjxfj_lc||v_tjsjgx||v_tjsjz||' then ''平均学分绩'||pjxfj_lc||',合格！'' else '''||v_tjsjmc||v_tjmc||pjxfj_lc||',低于'||v_tjsjz||',不合格！'' end) from dual';
    execute immediate sqlstr into sJg;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_yhxfpjj;

/

