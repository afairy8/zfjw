create procedure p_xk_check_tkzg(
	in_xkxnm in varchar2,
	in_xkxqm in varchar2,
	in_jxb_id in varchar2,
    in_xh_id in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
) as
	v_count number;
	v_njdm_id varchar2(32);
	v_kklxdm varchar2(5);
	v_bklx_id varchar2(32) default '0';
	v_xkkz_id varchar2(32);
	v_sfktk varchar2(1);
	v_zckz varchar2(1);
	v_tktjrs number;
	v_gz_xklc number;
	v_xs_xklc number;
	v_xkbj number;
	v_bdzcbj varchar2(2);
	v_gpksfkt varchar2(1);
	v_zntxbl varchar2(1);
begin
	out_flag:='1';

	select count(*) into v_count from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id and jxb_id=in_jxb_id;
	if v_count=0 then --该课程可能已通过其他页面退掉了
        out_flag:='2';
        goto EndPoint;
	end if;

	select nvl(bklx_id,'0'),xklc,xkbj,nvl(kklxdm,'w') into v_bklx_id,v_xs_xklc,v_xkbj,v_kklxdm from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id and jxb_id=in_jxb_id;

	if v_kklxdm='w' then
		select kklxdm into v_kklxdm from jw_jxrw_jxbxxb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=in_jxb_id;
	end if;

	select count(*) into v_count from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;

	if v_count=0 then
        out_flag:='0';
        out_msg:='对不起，未找到您的学籍信息，不可退课！';
        goto EndPoint;
    end if;

	select njdm_id,nvl(bdzcbj,'0') into v_njdm_id,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;

	if v_kklxdm in ('02','03','04') then
		select c.njdm_id into v_njdm_id from jw_fx_fxezybmb a,jw_fx_fxezybmkzb b,jw_jh_jxzxjhxxb c
		where a.fxezybmkz_id=b.fxezybmkz_id and b.jxzxjhxx_id=c.jxzxjhxx_id and b.bmlbdm=decode(v_kklxdm,'02','02','03','03','04','01','00')
		    and a.xh_id=in_xh_id and a.zzshjg='3' and rownum=1;
	end if;

	select max(xkkz_id) into v_xkkz_id from jw_xk_xkkzb where xnm=in_xkxnm and xqm=in_xkxqm and kklxdm=v_kklxdm and nvl(bklx_id,'0')=v_bklx_id
        and njdm=(select njdm from zftal_xtgl_njdmb where njdm_id=v_njdm_id) and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between xkkssj and xkjssj;
    if nvl(v_xkkz_id,'0')='0' then
        out_flag:='0';
        out_msg:='对不起，当前时间不可退课！';
        goto EndPoint;
    end if;

	select nvl(sfktk,'0'),nvl(tktjrs,0),nvl(zntxbl,'0'),nvl(zckz,'0') into v_sfktk,v_tktjrs,v_zntxbl,v_zckz from jw_xk_xkkzxmb where xkkz_id=v_xkkz_id;
	if v_sfktk='0' then
        out_flag:='0';
        out_msg:='对不起，该类课程不允许退课！';
        goto EndPoint;
	end if;

	if v_zckz='1' and v_bdzcbj not in ('2','3') then
        out_flag:='0';
        out_msg:='对不起，您的学籍处于未注册状态，不可退课！';
        goto EndPoint;
	end if;

	if v_sfktk='1' and v_tktjrs>0 then
		select count(*) into v_count from jw_xk_xsxkb where xnm=in_xkxnm and xqm=in_xkxqm and jxb_id=in_jxb_id;
		if v_count<=v_tktjrs then
			out_flag:='0';
			out_msg:='对不起，未达到最低选课人数，不可退课！';
			goto EndPoint;
		end if;
	end if;

	if v_zntxbl='1' then
		select xklc into v_gz_xklc from jw_xk_xkkzb where xkkz_id=v_xkkz_id;
		if v_gz_xklc!=v_xs_xklc then
			out_flag:='0';
			out_msg:='对不起，不是本轮选的课程，不可退课！';
			goto EndPoint;
		end if;
	end if;

	if v_xkbj != 10 then
		select nvl(gpksfkt,'0') into v_gpksfkt from (
			select gpksfkt from JW_XK_QTXKGZB
			where xnm=in_xkxnm and xqm=in_xkxqm and xh_id in (in_xh_id,'tongyi')
			order by case when xh_id='tongyi' then 1 else 0 end
		) where rownum=1;
		if v_gpksfkt='0' then
			out_flag:='0';
			out_msg:='对不起，该教学班是管理员配课生成的，不可退！';
			goto EndPoint;
		end if;
	end if;

	<<EndPoint>>
	null;
end;

/

