create function f_fx_bjgmc(
  i_xnm   varchar2,
  i_xqm   varchar2,
  i_xh_id varchar2,
  i_bj    varchar2
)
  return number
as
  v_mc number;
  begin
    v_mc := 0;
    if i_bj = 'dxq'
    then --单学期
      select count(*) into v_mc
      from (select a.xnm,
                   a.xqm,
                   a.XH_ID,
                   a.sskch_id,
                   a.KCH_ID,
                   a.CJ,
                   a.BFZCJ,
                   row_number() over (partition by a.xh_id, nvl(a.sskch_id, a.kch_id) order by a.xnm || lpad(a.xqm, 2,
                                                                                                             '0') desc, a.czsj desc) rn
            from jw_cj_xscjb a
            where a.xh_id = i_xh_id)
      where rn = 1
        and xnm = i_xnm
        and xqm = i_xqm
        and nvl(bfzcj, 0) < 60;
    end if;

    if i_bj = 'allxq'
    then --所有学期
      select count(*) into v_mc
      from (select a.xnm,
                   a.xqm,
                   a.XH_ID,
                   a.sskch_id,
                   a.KCH_ID,
                   a.CJ,
                   a.BFZCJ,
                   row_number() over (partition by a.xh_id, nvl(a.sskch_id, a.kch_id) order by a.xnm || lpad(a.xqm, 2,
                                                                                                             '0') desc, a.czsj desc) rn
            from jw_cj_xscjb a
            where a.xh_id = i_xh_id)
      where rn = 1
        and xnm = i_xnm
        and xqm = i_xqm
        and nvl(bfzcj, 0) < 60;
    end if;
    return v_mc;
end;

/

