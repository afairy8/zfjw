create function fun_by_zbkcjbtgsh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---正补考成绩不通过门次
   v_flag int;
begin
    sJg := '合格';
    begin
        select count(1)sl into v_flag from (
            select cj.*, row_number() over(partition by cj.xh_id, nvl(cj.sskch_id,cj.kch_id) order by nvl(cj.BFZCJ,0) desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id=v_xh_id and cj.cjxzm in('01','11','12')
            )where rn=1
            and bfzcj<60 ;

         if v_flag>v_tjsjz then
            sJg:= '正补考成绩不通过门次'||v_flag||'>'||v_tjsjz||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_zbkcjbtgsh;

/

