create procedure p_cj_bhkcjcl(vJxb_id in varchar2,vYjxb_id in varchar2,vXh_id in varchar2,vSfhk in varchar2)
    -----补缓考成绩处理(教学班ID，原教学班ID，学号ID，是否缓考)
    as
    v_count  number;
    v_ybfzcj varchar2(10);
    v_xbfzcj varchar2(10);
    v_cjxzm  varchar2(10);
    v_kch_id varchar2(32);
begin
     select count(1),min(cjxzm),min(kch_id) into v_count,v_cjxzm,v_kch_id from jw_cj_xscjb where jxb_id=vYjxb_id and xh_id=vXh_id;
     if v_count>0 then--存在原正考成绩
        if vSfhk='1' then --缓考
             update jw_cj_xscjb t1 set
             (t1.hkcj,t1.hkbfzcj,t1.hkbz,t1.hkjd) = (select t2.cj,t2.bfzcj,t2.cjbz,t2.jd from jw_cj_xscjb t2 where t2.jxb_id=vJxb_id and t2.xh_id=vXh_id and t2.cjzt='3')
             where t1.jxb_id=vYjxb_id and t1.xh_id=vXh_id;
        else --补考
             --当前补考成绩跟最大补考成绩比较
             select count(1) into v_count from jw_cj_xscjb where jxb_id=vJxb_id and xh_id=vXh_id and cjzt='3';
             if v_count=0 then --当前补考成绩被删掉或撤销审核了，找最大补考成绩更新
                 update jw_cj_xscjb t1 set
                 (t1.bkcj,t1.bkbfzcj,t1.bkbz,t1.bkjd) =
                 (select cj,bfzcj,cjbz,jd from(select t2.cj,t2.bfzcj,t2.cjbz,t2.jd from jw_cj_xscjb t2 where t2.kch_id=v_kch_id and t2.xh_id=vXh_id and t2.cjzt='3'
                     and decode(t2.cjxzm,'12','11',t2.cjxzm)=(case when v_cjxzm='01' then '11' when v_cjxzm='16' then '17' else null end) order by to_number(nvl(t2.bfzcj,0)) desc
                 ) where rownum<=1
                 ) where t1.jxb_id=vYjxb_id and t1.xh_id=vXh_id;
             else--当前补考成绩是新增或修改的，与正考成绩的最大补考成绩作比较后再处理
                 select nvl(bkbfzcj,'0') into v_ybfzcj from jw_cj_xscjb where jxb_id=vYjxb_id and xh_id=vXh_id;
                 select nvl(bfzcj,'0') into v_xbfzcj from jw_cj_xscjb where jxb_id=vJxb_id and xh_id=vXh_id and cjzt='3';
                 if to_number(v_xbfzcj)>to_number(v_ybfzcj) then
                     update jw_cj_xscjb t1 set
                     (t1.bkcj,t1.bkbfzcj,t1.bkbz,t1.bkjd) = (select t2.cj,t2.bfzcj,t2.cjbz,t2.jd from jw_cj_xscjb t2 where t2.jxb_id=vJxb_id and t2.xh_id=vXh_id and t2.cjzt='3')
                     where t1.jxb_id=vYjxb_id and t1.xh_id=vXh_id;
                 else
                     update jw_cj_xscjb t1 set
                     (t1.bkcj,t1.bkbfzcj,t1.bkbz,t1.bkjd) =
                     (select cj,bfzcj,cjbz,jd from(select t2.cj,t2.bfzcj,t2.cjbz,t2.jd from jw_cj_xscjb t2 where t2.kch_id=v_kch_id and t2.xh_id=vXh_id and t2.cjzt='3'
                         and decode(t2.cjxzm,'12','11',t2.cjxzm)=(case when v_cjxzm='01' then '11' when v_cjxzm='16' then '17' else null end) order by to_number(nvl(t2.bfzcj,0)) desc
                     ) where rownum<=1
                     ) where t1.jxb_id=vYjxb_id and t1.xh_id=vXh_id;
                 end if;
             end if;
             --更新补考次数
             if v_cjxzm='01' then
                update jw_cj_xscjb a set
                 bkcs = (select count(distinct b.jxb_id) from jw_cj_xscjb b where a.xh_id = b.xh_id and a.kch_id = b.kch_id and b.cjxzm in ('11','12') and b.cjzt='3')
                where a.jxb_id = vYjxb_id and a.xh_id=vXh_id;
             elsif v_cjxzm='16' then
                update jw_cj_xscjb a set
                 bkcs = (select count(distinct b.jxb_id) from jw_cj_xscjb b where a.xh_id = b.xh_id and a.kch_id = b.kch_id and b.cjxzm='17' and b.cjzt='3')
                where a.jxb_id = vYjxb_id and a.xh_id=vXh_id;
             end if;
        end if;
     end if;
end p_cj_bhkcjcl;

/

