create view GETJXWJMC as
  select
    t2.xnmc||'-'||t2.xqmc||'('||t2.jxbmc||')-'||t2.jsxm wjjmc,
    t2.xnmc||'第'||t2.xqmc||'学期'||'/'||t2.jsxm ||'/'||t2.kcmc||'('||t2.kch|| ')/'||t2.jxbmc as wjmc,
    t1.id,t1.jxb_id,t2.kch_id,t2.jsxm,t2.jxbmc,t2.kcmc,t2.kch,t2.jgh_id,nvl(fn_jxbzh(t1.jxb_id, 0), '无') jxbzc
from
    jw_jxwj_jxwjxxb t1,
    (
        select
           (select xn.xnmc from jw_jcdm_xnb xn where xn.xnm=a.xnm) xnmc,
           (select mc from zftal_xtgl_jcsjb where lx='0001'and dm=a.xqm) xqmc,
           (select t.xm from jw_jg_jzgxxb t where t.jgh_id=b.jgh_id) jsxm,
           a.xqm,a.xnm,a.jxb_id,a.kch_id,a.jxbmc,b.jgh_id,c.kcmc,c.kch,c.kkbm_id,get_jglsxx(c.kkbm_id) kkxy
        from jw_jxrw_jxbxxb   a,
           jw_jxrw_jxbjsrkb b,
           jw_jh_kcdmb      c
        where a.jxb_id = b.jxb_id
           and a.kch_id = c.kch_id
           and nvl(b.sfjxrllrjs, b.sfcjlrjs) = '1'
           and a.kkzt = '1'
           and nvl(a.shzt, '3') = '3'
   ) t2
where t1.jxb_id=t2.jxb_id(+) and t1.xnm=t2.xnm(+) and t1.xqm=t2.xqm(+) and nvl(t1.shzt,'3')='3'
/

