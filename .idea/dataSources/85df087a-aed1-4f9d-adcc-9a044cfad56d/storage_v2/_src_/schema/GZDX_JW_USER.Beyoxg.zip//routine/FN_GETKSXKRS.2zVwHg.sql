create function fn_getKsxkrs(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_apfs in varchar2,v_cd_id in varchar2)-----获取考试选课人数
return number is
    v_bksfayjxbpk number; --补考是否按原教学班排考(0：正考或补考不按原教学班;1:补考且按原教学班;)
    v_axzbpksfqfjxb number; --按行政班排考是否区分教学班(0：否;1:是;)
    v_axzbpkfssz number; --按行政班排考方式设置(1：合班班级;2:学生班级;)
    v_ksxkrs number:=0; --考试选课人数
begin
     if v_apfs='0' then --按试卷
        select count(distinct a.xh_id) into v_ksxkrs from
            (
            select xk.xh_id,xk.jxb_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_cj_bzdmb bz
             where xk.xnm=v_xnm and xk.xqm=v_xqm
                   and dzb.jxb_id=xk.jxb_id
                   and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                   and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                   and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
            union all
            select bk.xh_id,bk.jxb_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb
             where bk.xnm=v_xnm and bk.xqm=v_xqm
                   and dzb.jxb_id=bk.jxb_id
                   and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                   and dzb.xnm=v_xnm and dzb.xqm=v_xqm
             ) a;
     end if;
     if v_apfs='1' then --按行政班
        select count(1) into v_axzbpksfqfjxb from zftal_xtgl_xtszb where zdm='AXZBPKSFQFJXB' and zdz='1';
        select decode(count(1),1,'1','2') into v_axzbpkfssz from zftal_xtgl_xtszb szb where szb.zdm='AXZBPKFSSZ' and szb.zdz='1';
        if v_axzbpkfssz='1' then --按合班班级区分教学班
          select sum(a.fgbrs+b.gbrs) into v_ksxkrs from
              (
              select t3.jxb_id,t3.bh_id,count(xk.xh_id) fgbrs
                from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
               where xk.xnm=v_xnm and xk.xqm=v_xqm
                     and dzb.jxb_id=xk.jxb_id
                     and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                     and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and xk.xh_id=xs.xh_id
                     and t3.bh_id=xs.bh_id
                     and t3.jxb_id=dzb.jxb_id
                     and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
               group by t3.jxb_id,t3.bh_id
              ) a,
              (
              select jxb_id,bh_id,
                     case when row_number() over (partition by jxb_id order by rs,bh_id) <= mod(gbrs,bjgs) then trunc(gbrs/bjgs)+1
                          else trunc(gbrs/bjgs)
                     end as gbrs
              from (
              select jxb_id,bh_id,rs,bjgs,
                     (select count(xk.xh_id) from jw_xk_xsxkb xk,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz where xk.jxb_id = t.jxb_id and xk.xh_id=xs.xh_id
                     and xs.bh_id not in (select hb.bh_id from jw_jxrw_jxbhbxxb hb where hb.jxb_id=t.jxb_id ) and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                     ) gbrs
              from(
              select jxb_id,bh_id,sum(rs) rs,count(distinct bh_id) over (partition by jxb_id) bjgs
              from (
              select hb.jxb_id,hb.bh_id,hb.zyh_id,hb.zyfx_id,hb.rs
                from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb
               where t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t4.xnm=v_xnm and t4.xqm=v_xqm
                     and t3.jxb_id=hb.jxb_id and nvl(hb.bh_id,'wbj') != 'wbj'
               group by hb.jxb_id,hb.bh_id,hb.zyh_id,hb.zyfx_id,hb.rs
              ) t group by jxb_id,bh_id
              ) t
              )) b where a.jxb_id=b.jxb_id and a.bh_id=b.bh_id;
        elsif v_axzbpksfqfjxb > 0 then --学生班级区分教学班
          select count(distinct a.xh_id) into v_ksxkrs from
              (
              select xk.xh_id,xk.jxb_id,xs.bh_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
               where xk.xnm=v_xnm and xk.xqm=v_xqm
                     and dzb.jxb_id=xk.jxb_id
                     and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                     and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and xk.xh_id=xs.xh_id
                     and t3.bh_id=xs.bh_id
                     and t3.jxb_id=dzb.jxb_id
                     and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
              union all
              select bk.xh_id,bk.jxb_id,xs.bh_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
               where bk.xnm=v_xnm and bk.xqm=v_xqm and bk.bkqrbj = '1'
                     and dzb.jxb_id=bk.jxb_id
                     and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                     and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and bk.xh_id=xs.xh_id
                     and t3.bh_id=xs.bh_id
                     and t3.jxb_id=dzb.jxb_id
               ) a;
        else --学生班级不区分教学班
          select count(distinct a.xh_id) into v_ksxkrs from
              (
              select xk.xh_id,xk.jxb_id,xs.bh_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
               where xk.xnm=v_xnm and xk.xqm=v_xqm
                     and dzb.jxb_id=xk.jxb_id
                     and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                     and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and xk.xh_id=xs.xh_id
                     and t3.bh_id=xs.bh_id
                     and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
              union all
              select bk.xh_id,bk.jxb_id,xs.bh_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
               where bk.xnm=v_xnm and bk.xqm=v_xqm and bk.bkqrbj = '1'
                     and dzb.jxb_id=bk.jxb_id
                     and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                     and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and bk.xh_id=xs.xh_id
                     and t3.bh_id=xs.bh_id
               ) a;
         end if;
     end if;
     if v_apfs='2' then --按教学班
        select count(1) into v_bksfayjxbpk from jw_kw_ksmcdmb ksmc,zftal_xtgl_xtszb szb where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12') and szb.zdm='BKSFAYJXBPK' and szb.zdz='1';
        if v_bksfayjxbpk > 0 then --补考按原教学班
          select count(distinct a.xh_id) into v_ksxkrs from
              (
              select bk.xh_id,bk.jxb_id from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
               where bk.xnm=v_xnm and bk.xqm=v_xqm and bk.bkqrbj = '1'
                     and t3.yjxb_id=bk.yjxb_id
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               ) a;
        else --正考和补考按补考教学班
          select count(distinct a.xh_id) into v_ksxkrs from
              (
              select xk.xh_id,xk.jxb_id from jw_xk_xsxkb xk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_cj_bzdmb bz
               where xk.xnm=v_xnm and xk.xqm=v_xqm
                     and t3.jxb_id=xk.jxb_id
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                     and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
              union all
              select bk.xh_id,bk.jxb_id from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
               where bk.xnm=v_xnm and bk.xqm=v_xqm and bk.bkqrbj = '1'
                     and t3.jxb_id=bk.jxb_id
                     and t3.kshkbj_id=t4.kshkbj_id
                     and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                     and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               ) a;
         end if;
     end if;
     if v_apfs='3' then --按学院
        select count(distinct a.xh_id) into v_ksxkrs from
            (
            select xk.xh_id,xk.jxb_id,xs.jg_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
             where xk.xnm=v_xnm and xk.xqm=v_xqm
                   and dzb.jxb_id=xk.jxb_id
                   and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                   and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                   and t3.kshkbj_id=t4.kshkbj_id
                   and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                   and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                   and xk.xh_id=xs.xh_id
                   and t3.jg_id=xs.jg_id
                   and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
            union all
            select bk.xh_id,bk.jxb_id,xs.jg_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
             where bk.xnm=v_xnm and bk.xqm=v_xqm and bk.bkqrbj = '1'
                   and dzb.jxb_id=bk.jxb_id
                   and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                   and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                   and t3.kshkbj_id=t4.kshkbj_id
                   and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                   and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                   and bk.xh_id=xs.xh_id
                   and t3.jg_id=xs.jg_id
             ) a;
     end if;
     return v_ksxkrs;
end fn_getKsxkrs;

/

