create view V_GD_JW_JH_PYFASYNJB as
  select distinct  njdm_id||(select v.zyh from zftal_xtgl_zydmb v where v.zyh_id=s.zyh_id )jxjhh ,
njdm_id from zftal_xtgl_bjdmb s where njdm_id='2018'
/

