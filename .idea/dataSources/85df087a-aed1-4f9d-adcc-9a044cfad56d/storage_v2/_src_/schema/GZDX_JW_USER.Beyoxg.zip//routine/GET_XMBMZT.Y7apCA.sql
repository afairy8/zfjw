create function get_xmbmzt(vxh_id varchar2,vXmbmsz_id varchar2)---项目报名状态
Return varchar2
as
 sSql varchar2(200);
 sXqh_id varchar2(32);
 sJg_id varchar2(32);
 sNjdm_id varchar2(32);
 sZyh_id varchar2(32);
 sZyfx_id varchar2(32);
 sBh_id varchar2(32);
 sXbm varchar2(32);
 sXslbm varchar2(32);
 sCcdm varchar2(32);
 sXsbj varchar2(32);

 sxnm varchar2(10);
 sxqm varchar2(10);
 sbmtj varchar2(200);
 icount number;
 imx number;
 ixz number;
 icount_mx number;
 icount_xz number;

 stj1 varchar2(4);
 stj2 varchar2(4);
 stj3 varchar2(4);
 stj4 varchar2(4);
begin

 stj1 := '0';
 stj2 := '0';
 stj3 := '0';
 stj4 := '0';
 select count(*) into icount from JW_XMGL_XMBMSZB where xmbmsz_id = vXmbmsz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between kssj and jssj;
 if icount <= 0 then
  Return '0';
  goto Next_Null ;
 end if;

 select xnm,xqm,bmtj into sXnm,sXqm,sbmtj from JW_XMGL_XMBMSZB where xmbmsz_id = vXmbmsz_id;

     select nvl((select xqh_id from zftal_xtgl_bjdmb where bh_id = t2.bh_id),-1),
            nvl(t2.jg_id,-1),nvl(t2.njdm_id,-1),nvl(t2.zyh_id,-1),nvl(t2.zyfx_id,-1),
            nvl(t2.bh_id,-1),nvl(t1.xbm,-1),nvl(t2.xslbdm,-1),nvl(t2.pyccdm,-1),nvl(t1.xsbj,4294967296)
            into sXqh_id,sJg_id,sNjdm_id,sZyh_id,sZyfx_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj from
            jw_xjgl_xsjbxxb t1,jw_xjgl_xsxjxxb t2
                         where t1.xh_id = t2.xh_id
                           and t2.xh_id = vXh_id
                           and t2.xnm = sXnm
                           and t2.xqm = sXqm;

 select count(*),nvl(max(decode(xzlb,'mx',1)),0) ,nvl(max(decode(xzlb,'xz',1)),0) into icount,imx,ixz from JW_XM_XMMXDXXXB where
    xmbmsz_id = vXmbmsz_id;

 if icount > 0 then
   select count(*) into icount_mx from JW_XM_XMMXDXXXB
    where xmbmsz_id = vXmbmsz_id
      and xzlb = 'mx'
      and nvl(xqh_id,sxqh_id) = sxqh_id
      and nvl(jg_id,sJg_id) = sJg_id
      and nvl(njdm_id,snjdm_id) = snjdm_id
      and nvl(zyh_id,szyh_id) = szyh_id
      and nvl(zyfx_id,sZyfx_id) = szyfx_id
      and nvl(bh_id,sbh_id) = sbh_id
      and nvl(xbm,sxbm) = sXbm
      and nvl(xslbm,sxslbm) = sxslbm
      and nvl(ccdm,sccdm) = sccdm
      and bitand(nvl(xsbj,sxsbj),sxsbj) >0
      and nvl(xh_id,vxh_id) = vxh_id;

    select count(*) into icount_xz from JW_XM_XMMXDXXXB
    where xmbmsz_id = vXmbmsz_id
      and xzlb = 'xz'
      and nvl(xqh_id,sxqh_id) = sxqh_id
      and nvl(jg_id,sJg_id) = sJg_id
      and nvl(njdm_id,snjdm_id) = snjdm_id
      and nvl(zyh_id,szyh_id) = szyh_id
      and nvl(zyfx_id,sZyfx_id) = szyfx_id
      and nvl(bh_id,sbh_id) = sbh_id
      and nvl(xbm,sxbm) = sXbm
      and nvl(xslbm,sxslbm) = sxslbm
      and nvl(ccdm,sccdm) = sccdm
      and bitand(nvl(xsbj,sxsbj),sxsbj) >0
      and nvl(xh_id,vxh_id) = vxh_id;

 if (imx > 0 and icount_mx <= 0) or (ixz > 0 and icount_xz > 0 ) then
  Return '0';
  goto Next_Null ;
 end if;
end if;
 if sbmtj is not null then
 if instr(sbmtj,'TJ1') > 0 then
  stj1 := get_xmbmtj('TJ1',vXmbmsz_id,sXqh_id ,sJg_id,sZyh_id,sZyfx_id,sNjdm_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj,vXh_id);
 end if;
 if instr(sbmtj,'TJ2') > 0 then
  stj2 := get_xmbmtj('TJ2',vXmbmsz_id,sXqh_id ,sJg_id,sZyh_id,sZyfx_id,sNjdm_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj,vXh_id);
 end if;
 if instr(sbmtj,'TJ3') > 0 then
  stj3 := get_xmbmkctj('TJ3',vXmbmsz_id,sXqh_id ,sJg_id,sZyh_id,sZyfx_id,sNjdm_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj,vXh_id);
 end if;
 if instr(sbmtj,'TJ4') > 0 then
  stj4 := get_xmbmkctj('TJ4',vXmbmsz_id,sXqh_id ,sJg_id,sZyh_id,sZyfx_id,sNjdm_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj,vXh_id);
 end if;

 sSql := 'select count(*) from (select '||stj1||' TJ1,'||stj2||' TJ2,'||stj3||' TJ3,'||stj4||' TJ4 from  dual ) where '||sbmtj;
 Execute Immediate sSql into icount;

 if icount > 0 then
   Return '1';
   goto Next_Null ;
   else
   Return '0';
   goto Next_Null ;
 end if;
 else
   Return '1';
   goto Next_Null ;
 end if;

 <<Next_Null>>
 NULL;
end;

/

