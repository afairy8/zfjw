create view ZFTAL_SJCJ_S_GJ322 as
  (select
       al,
       rownum bh,
       zszks,
       zsbks,
       zxptzks,
       zxptbks,
       zxcrzks,
       zxcrbks,
       zxwlzks,
       zxwlbks,
       zxssyjs,
       zxbsyjs
from (
select b.jg al,
       sum(case when t.dm = '411' and (b.bdzcbj='1' or b.bdzcbj='2') then 1 else 0 end) zszks,
       sum(case when t.dm = '421' and (b.bdzcbj='1' or b.bdzcbj='2') then 1 else 0 end) zsbks,
       sum(case when t.dm = '411' and b.sfzx='1' then 1 else 0 end) zxptzks,
       sum(case when t.dm = '421' and b.sfzx='1' then 1 else 0 end) zxptbks,
       sum(case when t.dm = '412' and b.sfzx='1' then 1 else 0 end) zxcrzks,
       sum(case when t.dm = '422' and b.sfzx='1' then 1 else 0 end) zxcrbks,
       sum(case when t.dm = '413' and b.sfzx='1' then 1 else 0 end) zxwlzks,
       sum(case when t.dm = '423' and b.sfzx='1' then 1 else 0 end) zxwlbks,
       sum(case when t.dm = '431' and b.sfzx='1' then 1 else 0 end) zxssyjs,
       sum(case when t.dm = '432' and b.sfzx='1' then 1 else 0 end) zxbsyjs

 from zftal_xtgl_jcsjb t,
   (select t.jg,xj.sfzx,xj.xslbdm,xj.bdzcbj
   from jw_xjgl_xsjbxxb t, jw_xjgl_xsxjxxb xj
   where t.jg is not null
   and t.xh_id = xj.xh_id
   and xj.xnm = (select t.zdz
                from zftal_xtgl_xtszb t
                where t.zdm='XKXNM')) b
where t.dm = b.xslbdm
group by b.jg
) )
/

