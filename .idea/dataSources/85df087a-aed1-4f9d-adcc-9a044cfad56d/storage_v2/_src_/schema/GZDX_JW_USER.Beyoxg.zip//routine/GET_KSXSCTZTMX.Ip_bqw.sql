create function get_ksxsctztmx(
    vXh_id varchar2,--学号ID
    vXnm varchar2,--学年
    vXqm varchar2,--学期
    vSjbh_id varchar2,--试卷编号ID
    vKsrq varchar2,--考试日期
    vKskssj varchar2,--考试开始时间
    vKsjssj varchar2,--考试结束时间
    vZcd varchar2,--周次段
    vXqj varchar2,--星期几
    vJcd varchar2,--节次段
    vSfpdxsskct varchar2--是否判断学生上课冲突
)
    return varchar2
as
    ctmx varchar2(300) := '';
begin
    --学生考试与考试冲突(正考学生)
    select replace(WM_CONCAT(kc.kcmc||'('||t2.KSKSSJ||'-'||t2.KSJSSJ||')'),',','\n') into ctmx from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4,JW_JH_KCDMB kc
    where t1.xnm = t2.xnm and kc.KCH_ID=t4.KCH_ID
      and t1.xqm = t2.xqm
      and t1.xnm = t3.xnm
      and t1.xqm = t3.xqm
      and t1.sjbh_id = t3.sjbh_id
      and t1.ksccb_id = t2.ksccb_id
      and t2.ksmcdmb_id = t3.ksmcdmb_id
      and t3.jxb_id = t4.jxb_id
      and t1.xnm = vXnm
      and t1.xqm = vXqm
      and t3.xnm = vXnm
      and t3.xqm = vXqm
      and t4.xnm = vXnm
      and t4.xqm = vXqm
      and t2.ksrq = vKsrq
      and t2.ksjssj >= vKskssj
      and t2.kskssj <= vKsjssj
      and t1.sjbh_id != nvl(vSjbh_id,'no')
      and t4.xh_id = vXh_id;
    if length(ctmx) > 0 then
        return ctmx;
    end if;

    --学生考试与考试冲突(补考学生)
    select replace(WM_CONCAT(kc.kcmc||'('||t2.KSKSSJ||'-'||t2.KSJSSJ||')'),',','\n') into ctmx from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4,JW_JH_KCDMB kc
    where t1.xnm = t2.xnm and kc.KCH_ID=t4.KCH_ID
      and t1.xqm = t2.xqm
      and t1.xnm = t3.xnm
      and t1.xqm = t3.xqm
      and t1.sjbh_id = t3.sjbh_id
      and t1.ksccb_id = t2.ksccb_id
      and t2.ksmcdmb_id = t3.ksmcdmb_id
      and t3.jxb_id = t4.jxb_id
      and t4.bkqrbj = '1'
      and t1.xnm = vXnm
      and t1.xqm = vXqm
      and t3.xnm = vXnm
      and t3.xqm = vXqm
      and t4.xnm = vXnm
      and t4.xqm = vXqm
      and t2.ksrq = vKsrq
      and t2.ksjssj >= vKskssj
      and t2.kskssj <= vKsjssj
      and t1.sjbh_id != nvl(vSjbh_id,'no')
      and t4.xh_id = vXh_id;
    if length(ctmx) > 0 then
        return ctmx;
    end if;

    if vSfpdxsskct = '1' and vZcd is not null then --判断学生上课冲突
        select replace(WM_CONCAT(kcmc||'('||GET_JCBINARYDESC(t2.JC,'节')||')'),',','\n') into ctmx from jw_xk_xsxkb t1,jw_pk_kbsjb t2,JW_JH_KCDMB kc
        where t1.xnm = t2.xnm and t1.KCH_ID=kc.KCH_ID
          and t1.xqm = t2.xqm
          and t1.jxb_id = t2.jxb_id
          and t1.xnm = vXnm
          and t1.xqm = vXqm
          and bitand(t2.zcd,vZcd) > 0
          and t2.xqj = vXqj
          and bitand(t2.jc,vJcd) > 0
          and nvl(t1.zxbj,'0')='0'
          and t1.xh_id = vXh_id;
        if length(ctmx) > 0 then
            return ctmx;
        end if;
    end if;
    return ctmx;
end get_ksxsctztmx;

/

