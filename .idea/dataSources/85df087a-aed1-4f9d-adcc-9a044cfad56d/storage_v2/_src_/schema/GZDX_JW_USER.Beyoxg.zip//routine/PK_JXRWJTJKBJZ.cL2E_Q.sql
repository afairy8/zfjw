create procedure PK_JXRWJTJKBJZ-----教学任务进推荐课表矩阵---
(  vXnm in varchar2,
   vXqm in varchar2,
   vJg_id in varchar2,
   vNjdm_id in varchar2,
   vZyh_id in varchar2,
   vBh_id in varchar2,
   vBj out varchar2)
 as
   sNjdm_id   varchar2(32);
   sZyh_id   varchar2(32);
   sBh_id    varchar2(32);
   iGs      number;  ---有分学时及加入方向信息数
   iPkgs    number;  ---已排课个数
   iZyfxgs  number;
   iTjkbgs  number;
   iYcgs    number;
   sKbgsbj varchar2(8);    ----课表个数标记
 cursor Get_Tjkb is     ----已经生成推荐课表信息。----游标---
      select distinct a.njdm_id,a.zyh_id,a.bh_id from jw_pk_cshztb a
                      where a.xnm = vXnm
                        and a.dxqm = vXqm
                        and bj = '2'
                        and nvl(vNjdm_id,a.njdm_id) = a.njdm_id
                        and exists (select 'X' from zftal_xtgl_zydmb b where a.zyh_id = b.zyh_id and b.jg_id = vJg_id)
                        and nvl(vZyh_id,a.zyh_id) = a.zyh_id
                        and nvl(vBh_id,a.bh_id) = a.bh_id
                        and exists(select 'X' from jw_pk_tjkbjgb t
                                           where a.xnm = t.xnm
                                             and a.xqm = t.xqm
                                             and a.njdm_id = t.njdm_id
                                             and a.zyh_id = t.zyh_id
                                             and a.bh_id = t.bh_id
                                             and t.xnm = vXnm
                                             and t.dxqm = vXqm);
 Cur_Tjkb Get_Tjkb%rowtype;

begin
  select nvl((select zdz from jw_jcdml_xtnzb  where zdm = 'KBGSBJ'),0) into sKbgsbj from dual;
  vBj := '';
  open Get_Tjkb;
    loop
      fetch Get_Tjkb into Cur_Tjkb;
      exit when Get_Tjkb%notfound;
         sZyh_id   := Cur_Tjkb.zyh_id;
         sNjdm_id  := Cur_Tjkb.njdm_id;
         sBh_id    := Cur_Tjkb.bh_id;
     if sKbgsbj = '1' then
      insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id,tjkbzdm,tjkbzxsdm,rs)
          select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id,'1' tjkbzdm,'0' tjkbzxsdm,rs from
                    jw_pk_jxrwlsb a where a.xnm = vXnm
                                      and a.dxqm = vXqm
                                      and a.njdm_id = sNjdm_id
                                      and a.zyh_id = sZyh_id
                                      and a.bh_id = sBh_id
                                      and not exists
                                          (select 'X' from jw_pk_tjkbjgb b
                                                 where a.jxb_id = b.jxb_id
                                                   and b.xnm = vXnm
                                                   and b.dxqm= vXqm
                                                   and a.xnm = b.xnm
                                                   and a.xqm = b.xqm
                                                   and b.njdm_id = sNjdm_id
                                                   and b.zyh_id = sZyh_id
                                                   and b.bh_id = sBh_id);
      commit;
      else
      select count(*) into iYcgs from jw_pk_jxrwyclsb where xnm =vXnm
                                                        and dxqm = vXqm
                                                        and njdm_id = sNjdm_id
                                                        and zyh_id = sZyh_id
                                                        and bh_id = sBh_id;
      if iYcgs = 0 then
      begin
      select count(*) into iGs from (
      select nvl(fjxb_id,jxb_id) jxb_id,zyfx_id from jw_pk_jxrwlsb where xnm =vXnm
                                                         and dxqm = vXqm
                                                         and njdm_id = sNjdm_id
                                                         and zyh_id = sZyh_id
                                                         and bh_id = sBh_id
      minus
      select nvl(fjxb_id,jxb_id) jxb_id,zyfx_id from jw_pk_tjkbjgb where xnm =vXnm
                                                         and dxqm= vXqm
                                                         and njdm_id = sNjdm_id
                                                         and zyh_id = sZyh_id
                                                         and bh_id = sBh_id
      ) where zyfx_id <> 'wfx';


      select count(distinct tjkbzdm||tjkbzxsdm) into iTjkbgs from jw_pk_tjkbjgb where xnm =vXnm
                                                                                  and dxqm= vXqm
                                                                                  and njdm_id = sNjdm_id
                                                                                  and zyh_id = sZyh_id
                                                                                  and bh_id = sBh_id;

      if iTjkbgs > 1 then  ---判断当多张课表专业方向已存在课表结果表内的也可以把新增教学任务刷新到课表内
       select count(*) into iZyfxgs from (
      select zyfx_id from jw_pk_jxrwlsb where xnm =vXnm
                                                         and dxqm = vXqm
                                                         and njdm_id = sNjdm_id
                                                         and zyh_id = sZyh_id
                                                         and bh_id = sBh_id
      minus
      select zyfx_id from jw_pk_tjkbjgb where xnm =vXnm
                                                         and dxqm= vXqm
                                                         and njdm_id = sNjdm_id
                                                         and zyh_id = sZyh_id
                                                         and bh_id = sBh_id
      ) where zyfx_id <> 'wfx';

      end if;

      if iGs = 0 or iTjkbgs = 1 or (iTjkbgs > 1 and iZyfxgs = 0) then
      begin
        if iTjkbgs = 1 then
        begin
          insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id,tjkbzdm,tjkbzxsdm,rs)
          select distinct t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.xsdm,t1.zyfx_id,t1.kch_id,t1.jxb_id,t1.fjxb_id,t2.tjkbzdm,t2.tjkbzxsdm,t2.rs from
            ( select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id from
                    jw_pk_jxrwlsb a where a.xnm = vXnm
                                      and a.dxqm = vXqm
                                      and a.njdm_id = sNjdm_id
                                      and a.zyh_id = sZyh_id
                                      and a.bh_id = sBh_id
                                      --and a.fjxb_id is null
                                      and not exists
                                          (select 'X' from jw_pk_tjkbjgb b
                                                 where a.jxb_id = b.jxb_id
                                                   and b.xnm = vXnm
                                                   and b.dxqm= vXqm
                                                   and a.xnm = b.xnm
                                                   and a.xqm = b.xqm
                                                   and b.njdm_id = sNjdm_id
                                                   and b.zyh_id = sZyh_id
                                                   and b.bh_id = sBh_id)
             ) t1,
             (select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,zyfx_id,rs from
                                   jw_pk_tjkbjgb where xnm = vXnm
                                                   and dxqm= vXqm
                                                   and njdm_id = sNjdm_id
                                                   and zyh_id = sZyh_id
                                                   and bh_id = sBh_id
             ) t2;
        end;
        else
        begin
          insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id,tjkbzdm,tjkbzxsdm,rs)
          select distinct t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.xsdm,t1.zyfx_id,t1.kch_id,t1.jxb_id,t1.fjxb_id,t2.tjkbzdm,t2.tjkbzxsdm,t2.rs from
            ( select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,xsdm,zyfx_id,kch_id,jxb_id,fjxb_id from
                    jw_pk_jxrwlsb a where a.xnm = vXnm
                                      and a.dxqm = vXqm
                                      and a.njdm_id = sNjdm_id
                                      and a.zyh_id = sZyh_id
                                      and a.bh_id = sBh_id
                                      --and a.fjxb_id is null
                                      and not exists
                                          (select 'X' from jw_pk_tjkbjgb b
                                                 where a.jxb_id = b.jxb_id
                                                   and b.xnm = vXnm
                                                   and b.dxqm= vXqm
                                                   and a.xnm = b.xnm
                                                   and a.xqm = b.xqm
                                                   and b.njdm_id = sNjdm_id
                                                   and b.zyh_id = sZyh_id
                                                   and b.bh_id = sBh_id)
             ) t1,
             (select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,zyfx_id,rs from
                                   jw_pk_tjkbjgb where xnm = vXnm
                                                   and dxqm= vXqm
                                                   and njdm_id = sNjdm_id
                                                   and zyh_id = sZyh_id
                                                   and bh_id = sBh_id
             ) t2 where case when t1.zyfx_id = 'wfx' then t2.zyfx_id else t1.zyfx_id end = t2.zyfx_id;
        end;
        end if;
      end;
      else
      begin
        select count(1) into iPkgs from jw_pk_kbsjb t1
              where exists
                    (select 'X' from jw_pk_jxrwlsb t2
                            where t2.xnm =vXnm
                              and t2.dxqm= vXqm
                              and t2.njdm_id = sNjdm_id
                              and t2.zyh_id = sZyh_id
                              and t2.bh_id = sBh_id
                              and t1.jxb_id = t2.jxb_id
                     )
                and t1.xnm = vXnm
                and t1.xqm =vXqm;
        if iPkgs = 0 then
        begin
        Pk_SetJxrwBrs(vXnm ,vXqm ,sZyh_id ,sNjdm_id ,sBh_id);
        Pk_SetTjkbJzxx(vXnm ,vXqm ,sZyh_id ,sNjdm_id,sBh_id);
        end;
        end if;
      end;
      end if;
      end;
      end if;
      end if;

  begin
     delete from jw_pk_cshztb where xnm = vXnm
                                and dxqm = vXqm
                                and bj = '2'
                                and njdm_id = sNjdm_id
                                and zyh_id = sZyh_id
                                and bh_id = sBh_id;
    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,2 bj from jw_pk_jxrwlsb t1 -----已初始但有新教学任务状态
           where t1.xnm = vXnm
             and t1.dxqm = vXqm
             --and t1.fjxb_id is null
             and t1.zyh_id = sZyh_id
             and t1.njdm_id = sNjdm_id
             and t1.bh_id = sBh_id
             and not exists
                 (select 'X' from jw_pk_tjkbjgb t2
                         where t1.jxb_id = t2.jxb_id
                           and t1.njdm_id = t2.njdm_id
                           and t1.zyh_id = t2.zyh_id
                           and t1.bh_id = t2.bh_id
                           and t2.xnm = t1.xnm
                           and t2.xqm = t1.xqm
                           and t2.xnm = vXnm
                           and t2.dxqm = vXqm
                  );
    commit;
  end;
  end loop;
  close Get_Tjkb;

  <<Exend>>
 null;
end PK_JXRWJTJKBJZ;

/

