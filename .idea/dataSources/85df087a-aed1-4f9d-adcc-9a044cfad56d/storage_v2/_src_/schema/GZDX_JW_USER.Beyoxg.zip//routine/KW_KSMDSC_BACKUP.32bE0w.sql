create procedure Kw_ksmdsc_backup(vPkValue in varchar2,vSczwhgz in varchar2)-----考试名单生成(主键，排序类型<1:按班级学号排序;2:随机;>)
    as
    v_cd_id      varchar2(32);
    v_sjbh_id    varchar2(32);
    v_ksmcdmb_id varchar2(32);
    v_xnm        varchar2(4);
    v_xqm        varchar2(4);
    v_apfs       varchar2(2); --安排方式
    v_yqrs       number; --要求人数
    v_yprs       number; --已排人数
    v_zwh_max    number; --最大座位号
    v_bksfayjxbpk number; --补考是否按原教学班排考(0：正考或补考不按原教学班;1:补考且按原教学班;)
    v_axzbpksfqfjxb number; --按行政班排考是否区分教学班(0：否;1:是;)
    v_sfbkbj     number; --是否补考标记
    v_axzbpkfssz number; --按行政班排考方式设置(1：合班班级;2:学生班级;)
begin
    select t1.ksmcdmb_id,t6.sjbh_id,t6.cd_id,t6.yqrs,t1.apfs,t1.xnm,t1.xqm into v_ksmcdmb_id,v_sjbh_id,v_cd_id,v_yqrs,v_apfs,v_xnm,v_xqm
    from jw_kw_kssjb t1,
    (select t3.sjbh_id,t3.xnm,t3.xqm,t4.cd_id,sum(t4.rs) yqrs from
      (select sjbh_id,kshkbj_id,xnm,xqm from jw_kw_ksddbjdzb
        group by sjbh_id,kshkbj_id,xnm,xqm
      )t3,jw_kw_ksddb t4
        where t3.xnm = t4.xnm and t3.xqm = t4.xqm and t3.kshkbj_id = t4.kshkbj_id
        group by t3.sjbh_id,t3.xnm,t3.xqm,t4.cd_id
     ) t6 where t1.sjbh_id=t6.sjbh_id and t1.xnm=t6.xnm and t1.xqm=t6.xqm
            and t1.ksmcdmb_id||t1.sjbh_id||t6.cd_id=vPkValue;

    select count(*) into v_yprs from jw_kw_xsksxxb a
    where a.ksmcdmb_id=v_ksmcdmb_id and a.sjbh_id=v_sjbh_id and a.cd_id=v_cd_id and a.xnm=v_xnm and a.xqm=v_xqm;

    select nvl(max(to_number(a.zwh)),0) into v_zwh_max from jw_kw_xsksxxb a,jw_kw_kssjb sj1,jw_kw_kssjb sj2,jw_kw_ksccb cc1,jw_kw_ksccb cc2
    where a.ksmcdmb_id=v_ksmcdmb_id and a.cd_id=v_cd_id and a.xnm=v_xnm and a.xqm=v_xqm
      and a.sjbh_id=sj1.sjbh_id and sj1.ksccb_id=cc1.ksccb_id
      and sj2.sjbh_id=v_sjbh_id and sj2.ksccb_id=cc2.ksccb_id
      and cc1.ksrq=cc2.ksrq and cc1.kskssj<cc2.ksjssj and cc1.ksjssj>cc2.kskssj;

    select count(*) into v_sfbkbj from jw_kw_ksmcdmb ksmc where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12','21','22');

    select count(*) into v_bksfayjxbpk from jw_kw_ksmcdmb ksmc,zftal_xtgl_xtszb szb
    where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12') and szb.zdm='BKSFAYJXBPK' and szb.zdz='1';

    select count(*) into v_axzbpksfqfjxb from zftal_xtgl_xtszb szb where szb.zdm='AXZBPKSFQFJXB' and szb.zdz='1';

    select decode(count(1),1,'1','2') into v_axzbpkfssz from zftal_xtgl_xtszb szb where szb.zdm='AXZBPKFSSZ' and szb.zdz='1';

    if v_yqrs>v_yprs then--有学生未安排
       if v_sfbkbj>0 then --补考
          if vSczwhgz = '2' then --随机
               if v_apfs='0' then --按试卷
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                      (
                      select bk.xh_id,bk.jxb_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb
                       where bk.xnm=v_xnm and bk.xqm=v_xqm
                             and dzb.jxb_id=bk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and bk.bkqrbj='1'
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                       order by ceil(dbms_random.value(0,99))
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='1' then --按行政班
                  if v_axzbpksfqfjxb > 0 then --区分教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id,bh_id from (
                        select bk.xh_id,bk.jxb_id,xs.bh_id,row_number() over (partition by t3.bh_id,t3.jxb_id order by bk.xh_id) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and dzb.jxb_id=bk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and bk.bkqrbj='1'
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and bk.xh_id=xs.xh_id
                               and t3.bh_id=xs.bh_id
                               and t3.jxb_id=dzb.jxb_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                  else --不区分教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id,bh_id from (
                        select bk.xh_id,bk.jxb_id,xs.bh_id,row_number() over (partition by t3.bh_id order by bk.xh_id) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and dzb.jxb_id=bk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and bk.bkqrbj='1'
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and bk.xh_id=xs.xh_id
                               and t3.bh_id=xs.bh_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='2' then --按教学班
                  if v_bksfayjxbpk > 0 then --按原教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id from (
                        select bk.xh_id,bk.jxb_id,row_number() over (partition by t3.jxb_id,t3.yjxb_id order by bk.xh_id) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and t3.jxb_id=bk.jxb_id
                               and t3.yjxb_id=bk.yjxb_id
                               and bk.bkqrbj='1'
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                  else --按补考教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id from (
                        select bk.xh_id,bk.jxb_id,row_number() over (partition by t3.jxb_id order by bk.xh_id) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and t3.jxb_id=bk.jxb_id
                               and bk.bkqrbj='1'
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='3' then --按学院
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                      (
                      select bk.xh_id,bk.jxb_id,xs.jg_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                       where bk.xnm=v_xnm and bk.xqm=v_xqm
                             and dzb.jxb_id=bk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and bk.bkqrbj='1'
                             and t3.kshkbj_id=t4.kshkbj_id
                             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                             and bk.xh_id=xs.xh_id
                             and t3.jg_id=xs.jg_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                        order by ceil(dbms_random.value(0,99))
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
          else --按班级学号排序
               if v_apfs='0' then --按试卷
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                      (
                      select bk.xh_id,bk.jxb_id,xs.xh from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_xjgl_xsjbxxb xs
                       where bk.xnm=v_xnm and bk.xqm=v_xqm
                             and dzb.jxb_id=bk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and bk.bkqrbj='1'
                             and bk.xh_id=xs.xh_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                          where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                            and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                       order by jxb_id,xh
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='1' then --按行政班
                  if v_axzbpksfqfjxb > 0 then --区分教学班
                      insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                      select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                          (
                          select xh_id,jxb_id,bh_id,xh from (
                          select bk.xh_id,bk.jxb_id,xs.bh_id,xs.xh,row_number() over (partition by t3.bh_id,t3.jxb_id order by xs.xh) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                           where bk.xnm=v_xnm and bk.xqm=v_xqm
                                 and dzb.jxb_id=bk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and bk.bkqrbj='1'
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and bk.xh_id=xs.xh_id
                                 and t3.bh_id=xs.bh_id
                                 and t3.jxb_id=dzb.jxb_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                           ) where rn <= rs
                           order by bh_id,jxb_id,xh
                           ) a
                        where to_number(rownum+v_yprs)<=v_yqrs;
                   else --不区分教学班
                      insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                      select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                          (
                          select xh_id,jxb_id,bh_id,xh from (
                          select bk.xh_id,bk.jxb_id,xs.bh_id,xs.xh,row_number() over (partition by t3.bh_id order by xs.xh) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                           where bk.xnm=v_xnm and bk.xqm=v_xqm
                                 and dzb.jxb_id=bk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and bk.bkqrbj='1'
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and bk.xh_id=xs.xh_id
                                 and t3.bh_id=xs.bh_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                           ) where rn <= rs
                           order by bh_id,jxb_id,xh
                           ) a
                        where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='2' then --按教学班
                  if v_bksfayjxbpk > 0 then --按原教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id,xh from (
                        select bk.xh_id,bk.jxb_id,xs.xh,row_number() over (partition by t3.jxb_id,t3.yjxb_id order by xs.xh) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and t3.jxb_id=bk.jxb_id
                               and t3.yjxb_id=bk.yjxb_id
                               and t3.kshkbj_id=t4.kshkbj_id
                               and bk.bkqrbj='1'
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and bk.xh_id=xs.xh_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by jxb_id,xh
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                  else --按补考教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                        (
                        select xh_id,jxb_id,xh from (
                        select bk.xh_id,bk.jxb_id,xs.xh,row_number() over (partition by t3.jxb_id order by xs.xh) rn,t4.rs from jw_kw_bkmdb bk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                         where bk.xnm=v_xnm and bk.xqm=v_xqm
                               and t3.jxb_id=bk.jxb_id
                               and t3.kshkbj_id=t4.kshkbj_id
                               and bk.bkqrbj='1'
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and bk.xh_id=xs.xh_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                         ) where rn <= rs
                         order by jxb_id,xh
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='3' then --按学院
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id from
                      (
                      select bk.xh_id,bk.jxb_id,xs.jg_id,xs.xh from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs
                       where bk.xnm=v_xnm and bk.xqm=v_xqm
                             and dzb.jxb_id=bk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and bk.bkqrbj='1'
                             and t3.kshkbj_id=t4.kshkbj_id
                             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                             and bk.xh_id=xs.xh_id
                             and t3.jg_id=xs.jg_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=bk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                        order by jg_id,jxb_id,xh
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
          end if;
       else --正考
          if vSczwhgz = '2' then --随机
               if v_apfs='0' then --按试卷
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                      (
                       select xk.xh_id,xk.jxb_id,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_cj_bzdmb bz
                       where xk.xnm=v_xnm and xk.xqm=v_xqm
                             and dzb.jxb_id=xk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                             and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                       order by ceil(dbms_random.value(0,99))
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='1' then --按行政班
                  if v_axzbpkfssz='1' then --按合班班级区分教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                        (
                        select xh_id,jxb_id,ksbz,ceil(dbms_random.value(0,99)) px from (
                        select xk.xh_id,xk.jxb_id,xs.bh_id,row_number() over (partition by t3.bh_id,t3.jxb_id order by xk.xh_id) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                          from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                         where xk.xnm=v_xnm and xk.xqm=v_xqm
                               and dzb.jxb_id=xk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and xk.xh_id=xs.xh_id
                               and t3.bh_id=xs.bh_id
                               and t3.jxb_id=dzb.jxb_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                            where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                              and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                              and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                         ) where rn <= rs
                        union all
                        select xh_id,jxb_id,ksbz,ceil(dbms_random.value(0,99)) px from (
                        select distinct xk.xh_id,xk.jxb_id,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                          from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                         where xk.xnm=v_xnm and xk.xqm=v_xqm
                               and dzb.jxb_id=xk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and xk.xh_id=xs.xh_id
                               and not exists(select 'X' from jw_jxrw_jxbhbxxb hb where hb.jxb_id=t3.jxb_id and hb.bh_id=xs.bh_id)
                               and t3.jxb_id=dzb.jxb_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                            where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                              and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                              and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                         )
                         order by px
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                  elsif v_axzbpksfqfjxb > 0 then --学生班级区分教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                        (
                        select xh_id,jxb_id,ksbz from (
                        select xk.xh_id,xk.jxb_id,xs.bh_id,row_number() over (partition by t3.bh_id,t3.jxb_id order by xk.xh_id) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                          from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                         where xk.xnm=v_xnm and xk.xqm=v_xqm
                               and dzb.jxb_id=xk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and xk.xh_id=xs.xh_id
                               and t3.bh_id=xs.bh_id
                               and t3.jxb_id=dzb.jxb_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                            where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                              and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                              and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                  else --学生班级不区分教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                        (
                        select xh_id,jxb_id,ksbz from (
                        select xk.xh_id,xk.jxb_id,xs.bh_id,row_number() over (partition by t3.bh_id order by xk.xh_id) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                          from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                         where xk.xnm=v_xnm and xk.xqm=v_xqm
                               and dzb.jxb_id=xk.jxb_id
                               and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                               and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and xk.xh_id=xs.xh_id
                               and t3.bh_id=xs.bh_id
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                            where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                              and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                              and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                         ) where rn <= rs
                         order by ceil(dbms_random.value(0,99))
                         ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='2' then --按教学班
                    insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                    select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                        (
                        select xh_id,jxb_id,ksbz from (
                        select xk.xh_id,xk.jxb_id,row_number() over (partition by t3.jxb_id order by xk.xh_id) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                          from jw_xk_xsxkb xk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_cj_bzdmb bz
                         where xk.xnm=v_xnm and xk.xqm=v_xqm
                               and t3.jxb_id=xk.jxb_id
                               and t3.kshkbj_id=t4.kshkbj_id
                               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                               and not exists(select 'X' from jw_kw_xsksxxb t1
                             where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                               and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                               and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                        ) where rn <= rs
                        order by ceil(dbms_random.value(0,99))
                        ) a
                      where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='3' then --按学院
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                      (
                      select xk.xh_id,xk.jxb_id,xs.jg_id,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                        from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                       where xk.xnm=v_xnm and xk.xqm=v_xqm
                             and dzb.jxb_id=xk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and t3.kshkbj_id=t4.kshkbj_id
                             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                             and xk.xh_id=xs.xh_id
                             and t3.jg_id=xs.jg_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                             and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                        order by ceil(dbms_random.value(0,99))
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
          else --按班级学号排序
               if v_apfs='0' then --按试卷
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                      (
                      select xk.xh_id,xk.jxb_id,xs.xh,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                        from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_xjgl_xsjbxxb xs,jw_jxrw_jxbjsrkb rkb,jw_cj_bzdmb bz
                       where xk.xnm=v_xnm and xk.xqm=v_xqm
                             and dzb.jxb_id=xk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and xk.xh_id=xs.xh_id
                             and dzb.jxb_id=rkb.jxb_id
                             and nvl(rkb.sfjxrllrjs,rkb.sfcjlrjs) = '1'
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                             and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                       group by xk.jxb_id,xk.xh_id,xs.xh,bz.ksxs, xk.ksbz
                       order by min(rkb.jgh_id),xk.jxb_id,xs.xh
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='1' then --按行政班
                  if v_axzbpkfssz='1' then --按合班班级区分教学班
                      insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                      select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                          (
                          select xh_id,jxb_id,bh_id,xh,bjbj,ksbz from (
                          select xk.xh_id,xk.jxb_id,xs.bh_id,xs.xh,1 bjbj,row_number() over (partition by t3.bh_id,t3.jxb_id order by xs.xh) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                            from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                           where xk.xnm=v_xnm and xk.xqm=v_xqm
                                 and dzb.jxb_id=xk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and xk.xh_id=xs.xh_id
                                 and t3.bh_id=xs.bh_id
                                 and t3.jxb_id=dzb.jxb_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                                 and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                           ) where rn <= rs
                          union all
                          select distinct xk.xh_id,xk.jxb_id,xs.bh_id,xs.xh,2 bjbj,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                            from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                           where xk.xnm=v_xnm and xk.xqm=v_xqm
                                 and dzb.jxb_id=xk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and xk.xh_id=xs.xh_id
                                 and not exists(select 'X' from jw_jxrw_jxbhbxxb hb where hb.jxb_id=t3.jxb_id and hb.bh_id=xs.bh_id)
                                 and t3.jxb_id=dzb.jxb_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                                 and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                           order by bjbj,bh_id,jxb_id,xh
                           ) a
                        where to_number(rownum+v_yprs)<=v_yqrs;
                  elsif v_axzbpksfqfjxb > 0 then --学生班级区分教学班
                      insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                      select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                          (
                          select xh_id,jxb_id,bh_id,xh,ksbz from (
                          select xk.xh_id,xk.jxb_id,xs.bh_id,xs.xh,row_number() over (partition by t3.bh_id,t3.jxb_id order by xs.xh) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                            from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                           where xk.xnm=v_xnm and xk.xqm=v_xqm
                                 and dzb.jxb_id=xk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and xk.xh_id=xs.xh_id
                                 and t3.bh_id=xs.bh_id
                                 and t3.jxb_id=dzb.jxb_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                                 and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                           ) where rn <= rs
                           order by bh_id,jxb_id,xh
                           ) a
                        where to_number(rownum+v_yprs)<=v_yqrs;
                   else --学生班级不区分教学班
                      insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                      select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                          (
                          select xh_id,jxb_id,bh_id,xh,ksbz from (
                          select xk.xh_id,xk.jxb_id,xs.bh_id,xs.xh,row_number() over (partition by t3.bh_id order by xs.xh) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                            from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                           where xk.xnm=v_xnm and xk.xqm=v_xqm
                                 and dzb.jxb_id=xk.jxb_id
                                 and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                                 and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                                 and t3.kshkbj_id=t4.kshkbj_id
                                 and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                                 and xk.xh_id=xs.xh_id
                                 and t3.bh_id=xs.bh_id
                                 and not exists(select 'X' from jw_kw_xsksxxb t1
                               where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                                 and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                                 and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                           ) where rn <= rs
                           order by bh_id,jxb_id,xh
                           ) a
                        where to_number(rownum+v_yprs)<=v_yqrs;
                   end if;
               end if;
               if v_apfs='2' then --按教学班
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                      (
                      select xh_id,jxb_id,xh,ksbz from (
                      select xk.xh_id,xk.jxb_id,xs.xh,row_number() over (partition by t3.jxb_id order by xs.xh) rn,t4.rs,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                        from jw_xk_xsxkb xk,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                       where xk.xnm=v_xnm and xk.xqm=v_xqm
                             and t3.jxb_id=xk.jxb_id
                             and t3.kshkbj_id=t4.kshkbj_id
                             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                             and xk.xh_id=xs.xh_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                             and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                      ) where rn <= rs
                      order by jxb_id,xh
                      ) a
                  where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
               if v_apfs='3' then --按学院
                  insert into jw_kw_xsksxxb(ksmcdmb_id,xh_id,jxb_id,zwh,xnm,xqm,cd_id,sjbh_id,ksbz)
                  select v_ksmcdmb_id,a.xh_id,a.jxb_id,(rownum+v_zwh_max),v_xnm,v_xqm,v_cd_id,v_sjbh_id,a.ksbz from
                      (
                      select xk.xh_id,xk.jxb_id,xs.jg_id,xs.xh,(case when nvl(bz.ksxs,'2')='1' then xk.ksbz else '' end) ksbz
                        from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_xjgl_xsjbxxb xs,jw_cj_bzdmb bz
                       where xk.xnm=v_xnm and xk.xqm=v_xqm
                             and dzb.jxb_id=xk.jxb_id
                             and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                             and dzb.xnm=v_xnm and dzb.xqm=v_xqm
                             and t3.kshkbj_id=t4.kshkbj_id
                             and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                             and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                             and xk.xh_id=xs.xh_id
                             and t3.jg_id=xs.jg_id
                             and not exists(select 'X' from jw_kw_xsksxxb t1
                           where t1.xh_id=xk.xh_id and t1.xnm=v_xnm and t1.xqm=v_xqm
                             and t1.ksmcdmb_id=v_ksmcdmb_id and t1.sjbh_id=v_sjbh_id)
                             and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                        order by jg_id,jxb_id,xh
                       ) a
                    where to_number(rownum+v_yprs)<=v_yqrs;
               end if;
          end if;
       end if;
    end if;
end Kw_ksmdsc;
/

