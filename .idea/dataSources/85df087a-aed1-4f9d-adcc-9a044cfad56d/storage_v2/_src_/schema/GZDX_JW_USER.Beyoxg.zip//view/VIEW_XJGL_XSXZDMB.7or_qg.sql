create view VIEW_XJGL_XSXZDMB as
  select a.XSXZM,a.XSXZMC,a.XSXZMS,a.QYZT from jw_xjgl_xsxzdmb a where a.qyzt = '1'
/

