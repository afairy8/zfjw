create function my_sum(piv_str in varchar2, piv_delimiter in varchar2)
  --piv_str 为字符串，piv_delimiter 为分隔符
  return number is
  j        int := 0;
  i        int := 1;
  len      int := 0;
  len1     int := 0;
  str      varchar2(4000);
  out_count number := 0;
begin
  len  := length(piv_str);
  len1 := length(piv_delimiter);
  while j < len loop
    j := instr(piv_str, piv_delimiter, i);
    if j = 0 then
      j   := len;
      str := substr(piv_str, i);
      out_count := out_count + to_number(str);
      if i >= len then
        exit;
      end if;
    else
      str := substr(piv_str, i, j - i);
      i   := j + len1;
      out_count := out_count + to_number(str);
    end if;
  end loop;
  return out_count;
end my_sum;

/

