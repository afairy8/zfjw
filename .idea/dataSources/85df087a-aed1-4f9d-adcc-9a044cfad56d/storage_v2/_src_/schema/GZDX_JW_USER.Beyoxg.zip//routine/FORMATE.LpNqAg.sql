create function formate(val in number)
return varchar2 is res varchar2(6);
begin
  if val=1 then res:='一';
  elsif val=2 then res:='二';
  elsif val=3 then res:='三';
  elsif val=4 then res:='四';
  elsif val=5 then res:='五';
  elsif val=6 then res:='六';
  elsif val=7 then res:='七';
  elsif val=8 then res:='八';
  elsif val=9 then res:='九';
  elsif val=10 then res:='十';
  elsif val=11 then res:='十一';
  elsif val=12 then res:='十二';
  elsif val=13 then res:='十三';
  elsif val=14 then res:='十四';
  elsif val=15 then res:='十五';
  elsif val=16 then res:='十六';
  elsif val=17 then res:='十七';
  elsif val=18 then res:='十八';
  elsif val=19 then res:='十九';
  elsif val=20 then res:='二十';
  else
    res:='';
  end if;
  return res;
end;

/

