create FUNCTION get_zjgid( vJg_id in varchar)  ----主机构ID
  RETURN VARCHAR2 IS zjg_id varchar(32);
BEGIN
select case when wm_concat(jg_id) like '%,%' then substr(wm_concat(jg_id), 1, instr(wm_concat(jg_id), ',', 1) - 1)
            else wm_concat(jg_id) end into zjg_id from
 (select * from
    (select t.* from zftal_xtgl_jgdmb t
          start with t.jg_id = vJg_id
          connect by prior t.lssjjgid = t.jg_id
     ) t order by decode(t.lssjjgid, null, '0', '1'), t.jgdm
  );

  RETURN zjg_id;
END;

/

