create function fn_jsgzlByTimeScope(vJxb_id varchar2,
                                    vJgh_id varchar2,
                                    vXnm    varchar2,
                                    vXqm    varchar2,
                                    vBj     varchar2,
                                    vStartTime varchar2,
                                    vEndTime   varchar2) return varchar2 /**---计算教师工作量有时间范围----**/
 as
  jsgzl varchar2(5); /**---教师工作量**/
  icount integer;
begin
  jsgzl := null;
  icount:=0;
  begin
    if vBj='y' then
    select count(1)  into icount from jw_pk_ttksqb where xnm=vXnm and xqm=vXqm and jxb_id= vJxb_id;
    end if;
    if icount=0 then
    select count(distinct b.dxqzc || '-' || c.rn || '-' || t.xqj) gzl
      into jsgzl
      from jw_pk_kbsjb t,
           jw_pk_xlb a,
           jw_pk_rcmxb b,
           (select rownum rn from zftal_xtgl_jcsjlxb) c
     where t.xnm = a.xnm
       and t.xqm = b.dxqm
       and a.xl_id = b.xl_id
       and bitand(t.zcd, power(2, b.dxqzc - 1)) > 0
       and b.xqj = t.xqj
       and bitand(t.jc, power(2, c.rn - 1)) > 0
       and jxb_id = vJxb_id
       and t.jgh_id = vJgh_id
       and t.xnm = vXnm
       and t.xqm = vXqm
       and to_date(b.rq, 'yyyy-mm-dd') >= to_date(vStartTime, 'yyyy-mm-dd')
       and to_date(b.rq, 'yyyy-mm-dd') <= to_date(vEndTime, 'yyyy-mm-dd');
  end if;
  exception
    When others then
      jsgzl :=  0;
  end;
  if jsgzl = 0 then
    return null;
    else
  return jsgzl;
  end if;
end fn_jsgzlByTimeScope;

/

