create function FN_NUM_FORMAT(vStr in varchar2,vBj in varchar2)
return varchar2 is
 sStr varchar2(4000);
begin
 if vBj = '0' then
    select to_char(vStr,substr('FM9999990.999999999',1,10+length(substr(vStr,instr(vStr,'.')+1,100))))
    	into sStr from dual;
    return sStr;
 end if;
 null;
end;

/

