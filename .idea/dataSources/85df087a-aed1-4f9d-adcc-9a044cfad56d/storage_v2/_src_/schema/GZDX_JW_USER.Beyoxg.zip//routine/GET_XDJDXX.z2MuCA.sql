create FUNCTION get_xdjdxx(vXfyqjd_id in varchar,vXfyqjdmc in varchar,vLx in varchar,vBj in varchar)  ----修读节点信息
 RETURN VARCHAR2 IS sXfyqjdmc varchar(2000);
 iCount integer;
BEGIN
 select count(*) into iCount from jw_jcdml_xtnzb where zdm = 'XDJDXSFS' and zdz = '1';
 ----修读节点显示方式1表示【修读节点显示方式针对培养方案、执行计划课程信息列表内修读节点显示1表示末节点+父节点名称一起显示 0表示只显示末节点名称】
 if iCount > 0 then
   if vBj = '0' then
      if vLx = 'jh' then
        select replace(wm_concat(xfyqjdmc),',','~') into sXfyqjdmc  from (
          select * from (
          select rownum rn ,t.* from jw_jh_jxzxjhxfyqxxb t
             start with t.xfyqjd_id = vXfyqjd_id
                connect by  prior  t.fxfyqjd_id = t.xfyqjd_id
                ) t  order by rn desc
          );
      end if;

      if vLx = 'py' then
        select replace(wm_concat(xfyqjdmc),',','~') into sXfyqjdmc  from (
          select * from (
          select rownum rn ,t.* from jw_jh_pyfaxfyqxxb t
             start with t.xfyqjd_id = vXfyqjd_id
                connect by  prior  t.fxfyqjd_id = t.xfyqjd_id
                ) t  order by rn desc
          );
      end if;
   end if;
 else
  sXfyqjdmc := vXfyqjdmc;
 end if;
 RETURN sXfyqjdmc;
END;

/

