create function FN_BITTOZDZC(int_ZC in int) return varchar2 is
  i       int;
  LoopCount int;
begin
   /**通过周次二进制计算出，最大周次**/
  if int_ZC = 0 then
    return '';
  end if;
  i := 1;
  LoopCount:=round(log(2,int_ZC*2));
  i := LoopCount;
  while i >= 0 Loop
    if bitand (power(2,i),int_ZC*2)<>0 then
       return to_char(i);
    End if;
    i := i - 1;
  End Loop;
  return '';
end FN_BITTOZDZC;

/

