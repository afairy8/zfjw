create view JSVIEW_TEMP as
  select t1.xnm,t1.xqm,t1.jxb_id,t1.jgh_id,t2.cd_id,t1.xqj,t1.zcd,get_bitorsunion(wm_concat(t1.jc)) jc from
jw_pk_kbsjb t1,jw_pk_kbcdb t2 where t1.kb_id = t2.kb_id group by t1.xnm,t1.xqm,t1.jxb_id,t1.jgh_id,t2.cd_id,t1.xqj,t1.zcd
/

