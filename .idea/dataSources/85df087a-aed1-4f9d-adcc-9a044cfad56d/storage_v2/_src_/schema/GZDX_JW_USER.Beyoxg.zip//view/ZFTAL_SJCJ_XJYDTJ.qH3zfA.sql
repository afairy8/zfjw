create view ZFTAL_SJCJ_XJYDTJ as
  select yd.xjyd_id,(select t.jgmc
              from zftal_xtgl_jgdmb t
             where t.jgyxbs = '1'
               and t.jglb = '1'
               and t.lssjjgid is null and t.jg_id  = yd.ydqjg_id) ydqxy,
        lb.xjydmc ydlb,count(1) rs
from JW_XJGL_XJYDB yd, JW_XJGL_XJYDLBDMB lb
where yd.ydlbm = lb.ydlbm
and yd.shzt='3'
group by yd.xjyd_id,lb.xjydmc,yd.ydqjg_id
/

