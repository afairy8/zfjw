create procedure proc_sp_fzyw(in_ywdm  in varchar2,
                                         in_id in varchar2,
                                         out_ywdm out varchar2) as
  /*该存储过程检测是否需要走分支业务*/
  var_count number; --计数
  v_sql     varchar2(4000); --总的sql语句
  v_fz_sql  varchar2(4000); --分支组成sql语句
  cursor cur_fz_sql is ----游标---
    select 'select ''' || fzywdm || ''' ywdm,' || fzyxj || ' yxj from ' || tab || ' where ' || cx_id || '=''' || in_id || ''' and ' ||
           decode(gx,
                  'like', zd || ' like ''%''' || zdz || '''%'' ',
                  'bitand', 'bitand( my_sum('||zd||','','') ,''' || zdz || ''') >0',
                  '=', zd || ' = ''' || zdz || '''')
      from sp_fzywb where ywdm = in_ywdm;
begin
  select count(1) into var_count from sp_fzywb where ywdm = in_ywdm;

  if var_count = 0 then
    out_ywdm := in_ywdm;
  else
    v_sql := 'select ''' || in_ywdm || ''' ywdm, 0 yxj from dual ';
    open cur_fz_sql;
    loop
      fetch cur_fz_sql into v_fz_sql;
      exit when cur_fz_sql%notfound;
      v_sql := v_sql || ' union all ' || v_fz_sql;
    end loop;
    close cur_fz_sql;

    v_sql := 'select ywdm from (select ywdm,row_number() over (partition by 1 order by yxj desc) rn from(' || v_sql || ')) where rn = 1';
    execute immediate v_sql
      into out_ywdm;
  end if;
end proc_sp_fzyw;

/

