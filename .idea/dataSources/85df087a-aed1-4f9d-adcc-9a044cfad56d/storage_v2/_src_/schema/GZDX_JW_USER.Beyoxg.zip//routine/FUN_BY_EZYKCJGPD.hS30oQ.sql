create function fun_by_ezykcjgpd(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);-----辅修二专业 成绩合格判断
   sqlstr varchar2(2000);
begin
    sJg := '合格';
    begin
     sqlstr:= 'select count(a.kch_id)bjgms '||
        'from jw_jh_xsjxzxjhkcxxfxezyb a ,jw_jh_xsjxzxjhxfyqxxfxezyb b '||
        'where a.xfyqjd_id = b.xfyqjd_id'||
        ' and a.xh_id = b.xh_id '||
        ' and nvl(a.bfzcj,0) < 60'||
        ' and a.xh_id ='''||v_xh_id||'''';

         execute immediate sqlstr into sJg;
         if sJg >0 then
            sJg:= '辅修、二专业有'||sJg||'门不合格！';
         else
            sJg:= '辅修、二专业成绩全部合格！';
         end if;
       exception
      When others then
        sJg := '查询出错，不合格！';
  end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_ezykcjgpd;

/

