create function fun_by_fxezyByycnx(v_xh_id varchar2,v_tjsjz varchar2) return varchar2 --辅修二专最长毕业延迟年限【】年
as
   sJg varchar2(2000);   ---最终返回结果
   v_flag int;
   v_dqnd int;  --当前系统设置年份
   v_xsbynf int;--学生毕业年份
   v_zcbynf int;--最迟毕业年份

begin
    sJg := '合格';
    begin

        select t.zdz into v_dqnd from zftal_xtgl_xtszb t WHERE t.ssmk = 'GGMK' and zdm = 'DQND';

        if v_dqnd is null then
           return '请前去系统设置维护当前年度！';
        end if;

        select b.njdm+a.xz into v_xsbynf from jw_xjgl_xsjbxxb a, zftal_xtgl_njdmb b  where a.njdm_id = b.njdm_id and a.xh_id = v_xh_id ;

       if v_xsbynf is null then
           return '请维护学生年级和学制信息！';
        end if;

        v_zcbynf := v_xsbynf+v_tjsjz;

         if v_zcbynf>v_dqnd then
            sJg:= '合格！';
         else
            sJg:= '辅修二专毕业延迟年限截至'||v_zcbynf||'<'||v_dqnd||'年，不合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_fxezyByycnx;

/

