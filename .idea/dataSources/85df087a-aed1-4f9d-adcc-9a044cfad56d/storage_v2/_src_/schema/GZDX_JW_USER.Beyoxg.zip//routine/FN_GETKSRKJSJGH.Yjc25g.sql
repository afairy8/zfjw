create function fn_getKsrkjsjgh(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_apfs in varchar2,v_cd_id in varchar2)-----获取考试任课教师
return varchar2 is
    v_sfbk number; --是否补考
    v_axzbpksfqfjxb number; --按行政班排考是否区分教学班(0：否;1:是;)
    v_rkjs varchar2(2000):= ''; --任课教师
begin
    select count(1) into v_sfbk from jw_kw_ksmcdmb ksmc where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12','21','22');
    if v_sfbk>0 then
       if v_apfs='0' then --按试卷
          select wm_concat(jsxx) into v_rkjs from(
          select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksmcjxbdzb dzb,jw_kw_bkmdb bk
           where dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id and dzb.xnm=v_xnm and dzb.xqm=v_xqm
             and dzb.jxb_id=bk.jxb_id and bk.bkqrbj='1' and bk.yjxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
       end if;
       if v_apfs='1' then --按行政班
          select count(1) into v_axzbpksfqfjxb from zftal_xtgl_xtszb where (zdm='AXZBPKSFQFJXB' and zdz='1') or (zdm='AXZBPKFSSZ' and zdz='1');
          if v_axzbpksfqfjxb > 0 then --区分教学班
             select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_bkmdb bk,jw_xjgl_xsjbxxb xs
             where t3.kshkbj_id=t4.kshkbj_id
               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t3.jxb_id=bk.jxb_id and bk.xh_id=xs.xh_id and t3.bh_id=xs.bh_id and bk.bkqrbj='1'
               and bk.yjxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
          else --不区分教学班
            select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_ksmcjxbdzb t5,jw_kw_bkmdb bk,jw_xjgl_xsjbxxb xs
             where t3.kshkbj_id=t4.kshkbj_id
               and t5.sjbh_id = v_sjbh_id and t5.xnm=v_xnm and t5.xqm=v_xqm
               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t5.jxb_id=bk.jxb_id and bk.xh_id=xs.xh_id and t3.bh_id=xs.bh_id and bk.bkqrbj='1'
               and bk.yjxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
           end if;
       end if;
       if v_apfs='2' then --按教学班
             select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_kw_bkmdb bk
             where t3.kshkbj_id=t4.kshkbj_id
               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t3.jxb_id=bk.jxb_id and bk.bkqrbj='1'
               and bk.yjxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
       end if;
       if v_apfs='3' then --按学院
          v_rkjs := '';
       end if;
    else
       if v_apfs='0' then --按试卷
          select wm_concat(jsxx) into v_rkjs from(
          select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksmcjxbdzb dzb
           where dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id and dzb.xnm=v_xnm and dzb.xqm=v_xqm
             and dzb.jxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
       end if;
       if v_apfs='1' then --按行政班
          select count(1) into v_axzbpksfqfjxb from zftal_xtgl_xtszb where (zdm='AXZBPKSFQFJXB' and zdz='1') or (zdm='AXZBPKFSSZ' and zdz='1');
          if v_axzbpksfqfjxb > 0 then --区分教学班
             select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
             where t3.kshkbj_id=t4.kshkbj_id
               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t3.jxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
          else --不区分教学班
            select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb,jw_kw_ksmcjxbdzb t5
             where t3.kshkbj_id=t4.kshkbj_id and t3.bh_id=hb.bh_id
               and t5.jxb_id = hb.jxb_id
               and t5.sjbh_id = v_sjbh_id
               and t5.xnm=v_xnm
               and t5.xqm=v_xqm
               and t3.sjbh_id=v_sjbh_id
               and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and hb.jxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
           end if;
       end if;
       if v_apfs='2' then --按教学班
             select wm_concat(jsxx) into v_rkjs from(
             select distinct a.jgh jsxx from jw_jg_jzgxxb a,jw_jxrw_jxbjsrkb b,jw_kw_ksddbjdzb t3,jw_kw_ksddb t4
             where t3.kshkbj_id=t4.kshkbj_id
               and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t3.jxb_id=b.jxb_id and a.jgh_id=b.jgh_id);
       end if;
       if v_apfs='3' then --按学院
          v_rkjs := '';
       end if;
    end if;
    return v_rkjs;
end fn_getKsrkjsjgh;

/

