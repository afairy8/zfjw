create Procedure Jh_jxrwrsSx(vXnm in varchar2,vXqm in varchar2,vClbj in varchar2)----教学任务人数刷新
as
  sXsyxbj varchar2(2);
  sKch_id  varchar2(32);
  sXsdm    varchar2(32);
  sNjdm_id varchar2(32);
  sZyh_id  varchar2(32);
  sBh_id   varchar2(32);
  sZyfx_id varchar2(32);
  iJxbgs   number;
  iRsc     number;

  sJxb_id varchar2(50);
  iJxbrs number;
  iKrrl number;
  iCdzws number;
  iRs number;
  iJxbhbgs number;
  iZrs number;
  iRn  number;
  iJgbj number;


  cursor Get_YcJxrwrs is     ----取异常教学任务信息。----游标---
  select distinct a.kch_id,a.xsdm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.jxbgs,a.rsc From jw_jh_jxrwhbrsycb a
                                                                     where a.xnm = vXnm
                                                                       and a.xqm = vXqm
                                                                       and a.clbj = vClbj;
  Cur_YcJxrwrs Get_YcJxrwrs%rowtype;

  cursor Get_YcJxrwxx is     ----取异常教学任务信息。----游标---
  select rownum rn,a.jxb_id,a.jxbrs,a.krrl,a.cdzws,a.rs,a.jxbhbgs From jw_jh_jxrwhbxxb a
                                                       where a.xnm = vXnm
                                                         and a.xqm = vXqm
                                                         and a.xsdm = sXsdm
                                                         and a.kch_id = sKch_id
                                                         and a.njdm_id = sNjdm_id
                                                         and a.zyh_id = sZyh_id
                                                         and a.bh_id  = sBh_id
                                                         and a.zyfx_id = sZyfx_id
                                                         and a.clbj = vClbj;
  Cur_YcJxrwxx Get_YcJxrwxx%rowtype;
 --------------------------------------------------------------------------------
begin
  -------------------------------------------------------------------------------
  select case when count(*) >0 then '1' else '0' end into sXsyxbj from jw_jcdml_xtnzb where zdm = 'XSYXBJ' and zdz = '1';
  --初始化---全部数据
  delete from jw_jh_jxrwhbxxb a Where a.xnm  = vXnm
                                  and a.xqm = vXqm;
  commit;
  insert into jw_jh_jxrwhbxxb(xnm,xqm,xqh_id,kch_id,xsdm,jxb_id,jxbrs,krrl,cdzws,njdm_id,zyh_id,bh_id,zyfx_id,rs,jxbhbgs,clbj)
  select t1.xnm,t1.xqm,t1.xqh_id,t1.kch_id,t1.xsdm,t1.jxb_id,t1.jxbrs,t1.krrl,
         fn_jxbCdrs(t1.jxb_id,t1.xnm,t1.xqm,'0') as cdzws,
         --30 as cdzws,
         t2.njdm_id,t2.zyh_id,t2.bh_id,nvl(t2.zyfx_id,'wfx') as zyfx_id,t2.rs,
         count(*) over (partition by t1.jxb_id) as jxbhbgs,vClbj
    from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2
   where t1.xnm=vXnm
     and t1.xqm=vXqm
     and t1.jxb_id = t2.jxb_id
     and t1.kklxdm = '01'
     and t1.kkzt = '1';

  commit;

  delete from jw_jh_jxrwhbrsb a Where a.xnm  = vXnm
                                  and a.xqm = vXqm;
  commit;
  insert into jw_jh_jxrwhbrsb(xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id,jxbgs,rs,clbj)
  select xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id,count(jxb_id) as jxbgs,
  --(select jxbrs from jw_jxrw_jxbxxb where jxb_id=hbb.jxb_id)/count(jxb_id) as rs,
  sum(rs) as rs,
  vClbj from
         jw_jh_jxrwhbxxb hbb
   where xnm = vXnm
     and xqm = vXqm
     and clbj = vClbj
     group by xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id;
  commit;

  -------学生人数统计-----------------------------------
  delete from jw_jh_tjxsrsb where xnm = vXnm and xqm = vXqm;
  commit;
  insert into jw_jh_tjxsrsb(xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs,clbj)--学籍信息表内学生人数统计包括有方向及无方向人数
        select xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,nvl(zyfx_id,'wfx') as zyfx_id,count(xh_id) rs,vClbj from
               jw_xjgl_xsxjxxb
         where xnm = vXnm
           and xqm = vXqm
           and sfzx = '1'
           and nvl(zyfx_id,'wfx') != 'wfx'
         group by xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,nvl(zyfx_id,'wfx')
        union all
        select xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,'wfx' as zyfx_id,count(xh_id) rs,vClbj from
               jw_xjgl_xsxjxxb
         where xnm = vXnm
           and xqm = vXqm
           and sfzx = '1'
        group by xnm,xqm,jg_id,njdm_id,zyh_id,bh_id;
   commit;

   insert into jw_jh_tjxsrsb(xnm,xqm,jg_id,njdm_id,zyh_id,bh_id,zyfx_id,rs,clbj)--当学籍信息表内无学生时，从班级代码表内统计无方向人数
               select vXnm,vXqm,jg_id,njdm_id,zyh_id,bh_id,'wfx',zxrs,vClbj from zftal_xtgl_bjdmb a
                where not exists(select 'X' from jw_jh_tjxsrsb b where a.bh_id = b.bh_id and b.zyfx_id = 'wfx' and b.clbj = vClbj);
   commit;
  -------任务合班人数小于学生实际人数统计【教学任务合班人数异常表】-----------------------------------
  delete from jw_jh_jxrwhbrsycb a where a.xnm = vXnm and a.xqm = vXqm;
  if sXsyxbj = '1' then  ---当存在课程预选时，统计预选学生对应课程预选人数
  insert into jw_jh_jxrwhbrsycb(xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id,jxbgs,rs,xsskrs,rsc,xsrs,yxxsrs,clbj)
  select distinct xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id,jxbgs,rs,xsskrs,xsskrs-rs as rsc,xsrs,yxxsrs,vClbj from
  (select a.xnm,a.xqm,a.kch_id,a.xsdm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.jxbgs,a.rs,b.rs as xsrs,c.rs as yxxsrs,
       nvl(case when c.rs = 0 then null else c.rs end,b.rs) as xsskrs from
        jw_jh_jxrwhbrsb a, jw_jh_tjxsrsb b,JW_JH_KCYXRSTJB c
   where a.xnm = vXnm
     and a.xqm = vXqm
     and b.xnm = vXnm
     and b.xqm = vXqm
     and a.njdm_id = b.njdm_id
     and a.zyh_id = b.zyh_id
     and a.bh_id = b.bh_id
     and a.zyfx_id = b.zyfx_id
     and a.xnm = c.xnm(+)
     and a.xqm = c.xqm(+)
     and a.kch_id = c.kch_id(+)
     and a.njdm_id = c.njdm_id(+)
     and a.zyh_id = c.zyh_id(+)
     and a.bh_id = c.bh_id(+)
     ) where rs < xsskrs;
  else  ---不存在课程预选
  insert into jw_jh_jxrwhbrsycb(xnm,xqm,kch_id,xsdm,njdm_id,zyh_id,bh_id,zyfx_id,jxbgs,rs,xsskrs,rsc,xsrs,yxxsrs,clbj)
  select distinct a.xnm,a.xqm,a.kch_id,a.xsdm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.jxbgs,a.rs,b.rs as xsskrs,b.rs - a.rs as rsc,b.rs as xsrs,null as yxxsrs,vClbj from
        jw_jh_jxrwhbrsb a, jw_jh_tjxsrsb b
   where a.xnm = vXnm
     and a.xqm = vXqm
     and b.xnm = vXnm
     and b.xqm = vXqm
     and a.njdm_id = b.njdm_id
     and a.zyh_id = b.zyh_id
     and a.bh_id = b.bh_id
     and a.zyfx_id = b.zyfx_id
     --and (a.rs<b.rs or a.rs>b.rs+10);
     and a.rs < b.rs;
  end if;
  commit;
  -------------------------------------------------------------------------------

  open Get_YcJxrwrs;
  loop
    fetch Get_YcJxrwrs into Cur_YcJxrwrs;
     exit when Get_YcJxrwrs%notfound;
     sKch_id :=Cur_YcJxrwrs.kch_id;
     sXsdm   :=Cur_YcJxrwrs.xsdm;
     sNjdm_id:=Cur_YcJxrwrs.njdm_id;
     sZyh_id :=Cur_YcJxrwrs.zyh_id;
     sBh_id  :=Cur_YcJxrwrs.bh_id;
     sZyfx_id:=Cur_YcJxrwrs.zyfx_id;
     iJxbgs  :=Cur_YcJxrwrs.jxbgs;
     iRsc    :=Cur_YcJxrwrs.rsc;
    ----------------------------1---------------------------------------
    open Get_YcJxrwxx;
    loop
    fetch Get_YcJxrwxx into Cur_YcJxrwxx;
     exit when Get_YcJxrwxx%notfound;
     sJxb_id  :=Cur_YcJxrwxx.jxb_id;
     iJxbrs   :=Cur_YcJxrwxx.jxbrs;
     iKrrl    :=Cur_YcJxrwxx.krrl;
     iCdzws   :=Cur_YcJxrwxx.cdzws;
     iRs      :=Cur_YcJxrwxx.rs;
     iJxbhbgs :=Cur_YcJxrwxx.jxbhbgs;
     iRn      :=Cur_YcJxrwxx.rn;
     select nvl(jgbj,0) into iJgbj from jw_jh_jxrwhbxxb where jxb_id = sJxb_id and xsdm = sXsdm and njdm_id = sNjdm_id and zyh_id = sZyh_id and bh_id = sBh_id and zyfx_id = sZyfx_id;
    if iJgbj != 2 then ----iJgbj结果标记0表示默认值，1表示不超出场地座位数或无场地座位数平均分配人数成功，2表示在同课程同一组教学班内
    if iJxbgs = 1 and iJxbhbgs = 1  then ---一个教学班也没有合班情况
      if iCdzws is null or (iRs+iRsc <= iCdzws) then
        update jw_jh_jxrwhbxxb set jgrs = iRs+iRsc,jgbj = '1' where jxb_id = sJxb_id and clbj = vClbj;
        else
        update jw_jh_jxrwhbxxb set jgbj = '2' where jxb_id = sJxb_id and clbj = vClbj;
      end if;
    ELSIF iJxbgs = 1 and iJxbhbgs > 1 then ---一个教学班有多个合班情况
      select sum(rs) into iZrs from jw_jxrw_jxbhbxxb where jxb_id = sJxb_id;
      if iCdzws is null or (iZrs+iRsc <= iCdzws) then
        update jw_jh_jxrwhbxxb set jgrs = iRs+iRsc,jgbj = '1' where jxb_id = sJxb_id and njdm_id = sNjdm_id and zyh_id = sZyh_id and bh_id = sBh_id and zyfx_id = sZyfx_id and clbj = vClbj;
        else
        update jw_jh_jxrwhbxxb set jgbj = '2' where jxb_id = sJxb_id and clbj = vClbj;
      end if;
     ELSIF iJxbgs > 1 and iJxbhbgs = 1 then ---多个教学班有一个合班情况
      if iCdzws is null or (iRs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end) <= iCdzws) then
       update jw_jh_jxrwhbxxb set jgrs = iRs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end),jgbj = '1' where jxb_id = sJxb_id and clbj = vClbj;
       else
       update jw_jh_jxrwhbxxb set jgbj = '2' where jxb_id = sJxb_id and clbj = vClbj;
      end if;
     ELSIF iJxbgs > 1 and iJxbhbgs > 1 then ---多个教学班有多个合班情况
       select sum(nvl(jgrs,rs)) into iZrs from jw_jh_jxrwhbxxb where jxb_id = sJxb_id and clbj = vClbj;
      if iCdzws is null or (iZrs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end) <= iCdzws) then
        update jw_jh_jxrwhbxxb set jgrs = iRs+trunc(iRsc/iJxbgs)+ (case when iRn <= mod(iRsc,iJxbgs) then 1 else 0 end),jgbj = '1' where jxb_id = sJxb_id and njdm_id = sNjdm_id and zyh_id = sZyh_id and bh_id = sBh_id and zyfx_id = sZyfx_id and clbj = vClbj;
        else
        update jw_jh_jxrwhbxxb a set jgbj = '2' where xnm = vXnm and xqm = vXqm and kch_id = sKch_id and clbj = vClbj
                                                and exists(select 'X' from jw_jh_jxrwhbxxb b
                                                                     where b.xnm = vXnm
                                                                       and b.xqm = vXqm
                                                                       and b.jxb_id = sJxb_id
                                                                       and a.njdm_id = b.njdm_id
                                                                       and a.zyh_id  = b.zyh_id
                                                                       and a.bh_id   = b.bh_id
                                                                       and a.zyfx_id = b.zyfx_id
                                                                       and b.clbj = vClbj);
      end if;

     end if;
     end if;
     end loop;

    close Get_YcJxrwxx;
     ----------------------------1---------------------------------------


    /* ----------------------------2---------------------------------------
     if iJxbgs = 1 then
     update jw_jh_jxrwbhxxb set jgrs = rs + iRsc
                          where kch_id  = sKch_id
                            and xsdm    = sXsdm
                            and njdm_id = sNjdm_id
                            and zyh_id  = sZyh_id
                            and bh_id   = sBh_id
                            and zyfx_id = sZyfx_id;
     commit;
     else
     update jw_jh_jxrwbhxxb set jgrs = rs +  trunc(iRsc/iJxbgs) + case when rownum <= mod(iRsc,iJxbgs) then 1 else 0 end
                          where kch_id  = sKch_id
                            and xsdm    = sXsdm
                            and njdm_id = sNjdm_id
                            and zyh_id  = sZyh_id
                            and bh_id   = sBh_id
                            and zyfx_id = sZyfx_id;
     commit;
     end if;
     ----------------------------2---------------------------------------*/
  end loop;
  close Get_YcJxrwrs;

  /*  --------处理教学任务合班表对应人数及教学任务信息表对应教学班人数
  update jw_jxrw_jxbhbxxb a set rs = (select jgrs from jw_jh_jxrwhbxxb b where a.jxb_id  = b.jxb_id
                                                                           and a.njdm_id = b.njdm_id
                                                                           and a.zyh_id  = b.zyh_id
                                                                           and a.bh_id   = b.bh_id
                                                                           and a.zyfx_id = b.zyfx_id
                                                                           and b.xnm     = vXnm
                                                                           and b.xqm     = vXqm
                                                                           and b.clbj = vClbj)
                          where exists(select 'X' from jw_jh_jxrwhbxxb c where a.jxb_id  = c.jxb_id
                                                                           and a.njdm_id = c.njdm_id
                                                                           and a.zyh_id  = c.zyh_id
                                                                           and a.bh_id   = c.bh_id
                                                                           and a.zyfx_id = c.zyfx_id
                                                                           and c.xnm     = vXnm
                                                                           and c.xqm     = vXqm
                                                                           and c.jgrs is not null
                                                                           and c.jgbj = '1'
                                                                           and c.clbj = vClbj);

     commit;
     update jw_jxrw_jxbxxb a set jxbrs = (select sum(rs) from jw_jxrw_jxbhbxxb b where a.jxb_id = b.jxb_id)
                           where exists(select 'X' from jw_jh_jxrwhbxxb c where a.jxb_id  = c.jxb_id
                                                                           and c.xnm     = vXnm
                                                                           and c.xqm     = vXqm
                                                                           and c.jgrs is not null
                                                                           and c.jgbj = '1'
                                                                           and c.clbj = vClbj );
     commit;
     */
  null;
-----------------------------------------------------------------------------------------------------------------------
end;

/

