create Function Get_BinaryDescYw(vBinary in integer, vUnit in Varchar)
Return varchar2
as
  type Type_weekArray is table of int;
  aWeek integer;  ---周变量
  WeeksDesc varchar2(100); ---周显示组合
  firstWeek integer;--第一周
  currWeek integer; --当前的周
  prevWeek integer; --前一个周
  weekCount integer;--周数
  aPrevArrayType integer;  --前一个组合类型（1单，0双）
  i integer;
  weekArray Type_weekArray := Type_weekArray(); ---周数组
  v_Binary integer;
begin
   v_Binary :=vBinary;
  if nvl(v_Binary,0) = 0 then
    return '无';
  end if;

  WeeksDesc := null;
  firstWeek := -1;
  currWeek := -1;
  prevWeek := -1;
  aPrevArrayType := 2;
  i := 1;
  for aWeek in 0..log(2,v_Binary)  loop  ---log(2,vBinary)取整
    if bitand(v_Binary, power(2, aWeek))=power(2,aWeek) then  ---利用位运算取出二进制数对应的第几周次
      weekArray.Extend;
      weekArray(i) :=  aWeek+1;
      weekCount := i;
      i := i + 1;
    end if;
  end loop;

  for i in 0..weekCount loop
    --处理第一周
    if firstWeek=-1 then
      firstWeek := weekArray(i+1);
    else
      if i=weekCount then
        currWeek := 0;
      else
        currWeek := weekArray(i+1);
      end if;

      if prevWeek = firstWeek then
        if(currWeek - prevWeek = 1) then
          aPrevArrayType := 2;
        else
          aPrevArrayType := prevWeek mod 2;
        end if;
      end if;
    end if;

    --处理后续
    if(i = weekCount)
      or(currWeek - prevWeek > 2)
      or((currWeek - prevWeek = 2)and(aPrevArrayType <> currWeek mod 2))
      or((currWeek - prevWeek = 1)and(aPrevArrayType <> 2))
    then
      if WeeksDesc is null then
        WeeksDesc := to_char(firstWeek);
      else
        WeeksDesc := WeeksDesc ||','|| to_char(firstWeek);
      end if;
      if(prevWeek <> -1)and(prevWeek > firstWeek) then
        WeeksDesc := WeeksDesc  || '-'|| to_char(prevWeek) || vUnit;

        if aPrevArrayType = 1 then WeeksDesc := WeeksDesc || '(S)'; end if;
        if aPrevArrayType = 0 then WeeksDesc := WeeksDesc|| '(D)'; end if;
      else
        WeeksDesc := WeeksDesc ||vUnit;
      end if;
      firstWeek := currWeek;
      prevWeek := currWeek;
    else
      prevWeek := weekArray(i+1);
    end if;
  end loop;
  return WeeksDesc;
end;

/

