create function FN_GETEXAMWORK(v_xnm varchar2,v_xqm varchar2,v_jgh_id varchar2,v_ksxzmc varchar2) return varchar2
/****查询考试工作量 实时计算 kwy ****/
as
   ksgzl varchar2(20);
begin
     /*没有传入 考试性质*/
    if v_ksxzmc ='' or v_ksxzmc is null then
       select to_char(sum(nvl((sbb.cjfs * jc.cjgzl + sbb.jkcc * jc.jkgzl + sbb.yjfs * jc.yjgzl),0)),'fm990.00') into ksgzl
        from JW_JG_KSGZLSBB sbb, JW_JG_GZLJCSJ jc
       where sbb.xnm = jc.xnm(+)
         and sbb.xqm = jc.xqm(+)
         and sbb.shzt ='3'
         and sbb.xnm = v_xnm
         and sbb.xqm = v_xqm
         and sbb.jgh_id = v_jgh_id;
     else
     /*存在考试性质*/
       select to_char(sum(nvl((sbb.cjfs * jc.cjgzl + sbb.jkcc * jc.jkgzl + sbb.yjfs * jc.yjgzl),0)),'fm990.00') into ksgzl
        from JW_JG_KSGZLSBB sbb, JW_JG_GZLJCSJ jc
       where sbb.xnm = jc.xnm(+)
         and sbb.xqm = jc.xqm(+)
         and sbb.shzt ='3'
         and sbb.xnm = v_xnm
         and sbb.xqm = v_xqm
         and sbb.jgh_id = v_jgh_id
         and sbb.ksxzdm = (select a.dm from zftal_xtgl_jcsjb a where a.lx = '0034' and a.mc = v_ksxzmc);
     end if;

    if ksgzl is null then
       ksgzl := 0;
    end if;
    return ksgzl;
end FN_GETEXAMWORK;

/

