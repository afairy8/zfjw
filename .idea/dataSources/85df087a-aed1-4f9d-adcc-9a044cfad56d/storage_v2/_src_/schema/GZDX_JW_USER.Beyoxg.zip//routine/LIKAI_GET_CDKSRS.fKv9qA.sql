create function likai_get_cdksrs(v_cd_id     in varchar2, v_xnm in varchar2, v_xqm in varchar2,
                                            v_kshkbj_id in varchar2, v_scfs in varchar2
)
  return varchar2 is
  v_jkjgid varchar2(255);
  --返回场地的监考学院
  --v_scfs='2'表示从考试名单中生成派监考学院
  --call statement:update jw_kw_ksddb ddb set ddb.jg_id=likai_get_cdksrs(ddb.cd_id,ddb.xnm,ddb.xqm,ddb.kshkbj_id,v_scfs) where ddb.jg_id is null and ddb.xnm='' and ddb.xqm='';
  begin
    if v_scfs = '2'
    then
      select t.jg_id
      into v_jkjgid
      from (
             select
               t.JG_ID,
               row_number()
               over (
                 partition by t.cd_id
                 order by crs desc ) rn
             from (
                    select
                      xsj.JG_ID,
                      xkb.cd_id,
                      count(xsj.XH_ID) crs
                    from JW_KW_XSKSXXB xkb, JW_XJGL_XSJBXXB xsj
                    where xkb.XH_ID = xsj.XH_ID
                          and xkb.XNM = v_xnm
                          and xkb.xqm = v_xqm
                          and xkb.SJBH_ID in (select dzb.SJBH_ID
                                              from JW_KW_KSDDBJDZB dzb
                                              where
                                                dzb.XNM = v_xnm and dzb.XQM = v_xqm and dzb.KSHKBJ_ID = v_kshkbj_id)
                          and xkb.CD_ID = v_cd_id
                    group by xkb.CD_ID, xsj.JG_ID
                    order by xsj.JG_ID) t) t
      where t.rn = 1;
    else
      select jg_id
      into v_jkjgid
      from (select
              kshkbj_id,
              jg_id
            from (select
                    KSHKBJ_ID,
                    jg_id,
                    xkrs,
                    row_number()
                    over (
                      partition by KSHKBJ_ID
                      order by xkrs desc ) rn
                  from (select
                          kshkbj_id,
                          jg_id,
                          xkrs
                        from (select
                                dzb.KSHKBJ_ID,
                                xjb.jg_id,
                                count(xkb.xh_id) xkrs
                              from jw_kw_ksddbjdzb dzb,
                                jw_xk_xsxkb xkb,
                                jw_xjgl_xsxjxxb xjb
                              where dzb.XNM = v_xnm
                                    and dzb.xqm = v_xqm
                                    and dzb.jxb_id = xkb.jxb_id
                                    and dzb.apfs = '2'
                                    and dzb.xnm = xkb.xnm
                                    and dzb.xqm = xkb.xqm
                                    and xkb.xnm = xjb.xnm
                                    and xkb.xqm = xjb.xqm
                                    and xkb.xh_id = xjb.xh_id
                              group by dzb.KSHKBJ_ID, xjb.JG_ID
                              union
                              select
                                dzb.KSHKBJ_ID,
                                xjb.jg_id,
                                count(xkb.xh_id) xkrs
                              from jw_kw_ksddbjdzb dzb,
                                JW_KW_BKMDB xkb,
                                jw_xjgl_xsxjxxb xjb
                              where dzb.XNM = v_xnm
                                    and dzb.xqm = v_xqm
                                    and
                                    dzb.jxb_id = xkb.jxb_id
                                    and dzb.apfs = '2'
                                    and dzb.xnm = xkb.xnm
                                    and dzb.xqm = xkb.xqm
                                    and xkb.xnm = xjb.xnm
                                    and xkb.xqm = xjb.xqm
                                    and xkb.xh_id = xjb.xh_id
                              group by dzb.KSHKBJ_ID, xjb.JG_ID
                        )) t) t
            where t.rn = 1) t
      where t.KSHKBJ_ID = v_kshkbj_id;
    end if;
    return v_jkjgid;
  end;
/

