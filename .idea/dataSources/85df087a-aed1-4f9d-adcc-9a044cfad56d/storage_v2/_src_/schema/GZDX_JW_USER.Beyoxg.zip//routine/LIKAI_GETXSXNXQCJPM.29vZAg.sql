create function likai_getXsXnxqCjPm(v_xh   varchar2,
                                    v_xn   varchar2,
                                    v_xn_2 varchar2
)
  return varchar2 as
  v_pjxfjd varchar2(255);
  /*
  计算规则：
  1、有学籍的参与排名；
  2、所有主修专业成绩均参与统计（包含作废）
  3、按年级专业计算排名
  4、学生课程成绩取最大值
  参数：
  v_xh:学生学号
  v_xn:指计算范围截止学年，为空表示默认：截止于9999年(包含）
  v_xn_2：指计算范围开始学年,为空表示默认：开始于1000年（不包含)
  结果:
  平均学分绩点#年级专业排名#有无补考
  如输入：
  v_xh='1701100027'
  v_xn='2018'
  v_xn_2='2017'
  示例参数含义：统计'1701100027'在(2017,2018]学年范围内
  返回结果为：3.50#22#无
  */
  begin
    select t.xfjqpjjd || '#' || t.pm4
    into v_pjxfjd
    from (
           select
             xh,
             xm,
             zf,
             ms,
             zxf,
             hdxf,
             bjgxf,
             tgl,
             jgmc,
             zymc,
             njmc,
             zyfxmc,
             bj,
             sspjf,
             xfjqpjf,
             pjjd,
             xfjqpjjd,
             hdpjxfjd,
             gpa,
             tsjqxfcj,
             xfjdh,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(sspjf, 0)) desc )    as pm1,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(xfjqpjf, 0)) desc )  as pm2,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(pjjd, 0)) desc )     as pm3,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(xfjqpjjd, 0)) desc ) as pm4,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(xfjdh, 0)) desc )    as pm5,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(hdpjxfjd, 0)) desc ) as pm6,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(gpa, 0)) desc )      as pm7,
             rank()
             over (
               partition by njdm_id, zyh_id
               order by to_number(nvl(tsjqxfcj, 0)) desc ) as pm8,
             bjgmc
           from (select
                   t.xh,
                   t.xm,
                   trim(to_char(sum(t.maxbfzcj), '9999990.99'))                        as zf,
                   count(t.kch_id)                                                     as ms,
                   sum(t.xf)                                                           as zxf,
                   sum(case when t.maxbfzcj >= 60
                     then t.xf
                       else '0' end)                                                   as hdxf,
                   sum(case when t.maxbfzcj < 60
                     then t.xf
                       else '0' end)                                                   as bjgxf,
                   round(count(case when t.maxbfzcj >= 60
                     then kch_id
                               else null end) / count(t.kch_id) * 100, 2) || '%'       as tgl,
                   trim(to_char(avg(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                     then null
                                    else t.maxbfzcj end), '9999990.99'))               as sspjf,
                   trim(
                       to_char(case when nvl(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                         then null
                                                 else t.xf end), '0') = '0'
                         then null
                               else sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                 then null
                                        else t.maxbfzcj * t.xf end) /
                                    sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                      then null
                                        else t.xf end) end, '9999990.99'))             as xfjqpjf,
                   trim(
                       to_char(case when nvl(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                         then null
                                                 else t.xf end), '0') = '0'
                         then null
                               else sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                 then null
                                        else (case when t.maxbfzcj < 60
                                          then 0
                                              else t.maxbfzcj end) * t.xf end) /
                                    sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                      then null
                                        else t.xf end) end, '9999990.99'))             as tsjqxfcj,
                   trim(
                       to_char(case when nvl(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                         then null
                                                 else to_char(t.maxjd) end), '0') = '0'
                         then null
                               else sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                 then null
                                        else t.maxjd * maxbfzcj end) /
                                    sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                      then null
                                        else to_char(t.maxjd) end) end, '9999990.99')) as gpa,
                   trim(to_char(avg(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                     then null
                                    else t.maxjd end), '9999990.99'))                  as pjjd,
                   trim(
                       to_char(case when nvl(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                         then null
                                                 else (case when t.maxjd is null
                                                   then '0'
                                                       else t.xf end) end), '0') = '0'
                         then null
                               else sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                 then null
                                        else t.maxjd * t.xf end) /
                                    sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                      then null
                                        else (case when t.maxjd is null
                                          then '0'
                                              else t.xf end) end) end, '9999990.99'))  as xfjqpjjd,
                   trim(to_char(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                     then null
                                    else t.maxjd * t.xf end), '9999990.99'))           as xfjdh,
                   trim(
                       to_char(case when nvl(sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                         then null
                                                 else (case when t.maxbfzcj >= 60
                                                   then (case when t.maxjd is null
                                                     then '0'
                                                         else t.xf end)
                                                       else '0' end) end), '0') = '0'
                         then null
                               else sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                 then null
                                        else t.maxjd * (case when t.maxbfzcj >= 60
                                          then t.xf
                                                        else '0' end) end) /
                                    sum(case when instr(',' || 'wbz' || ',', ',' || t.maxcjbz || ',') > 0
                                      then null
                                        else (case when t.maxbfzcj >= 60
                                          then (case when t.maxjd is null
                                            then '0'
                                                else t.xf end)
                                              else '0' end) end) end, '9999990.99'))   as hdpjxfjd,
                   count(case when t.maxbfzcj < 60
                     then t.kch_id
                         else null end)                                                as bjgmc,
                   t.njdm_id,
                   t.zyh_id,
                   t.bh_id,
                   (select jgmc
                    from zftal_xtgl_jgdmb
                    where jg_id = t.jg_id)                                                jgmc,
                   (select zymc
                    from zftal_xtgl_zydmb
                    where zyh_id = t.zyh_id)                                              zymc,
                   (select njmc
                    from zftal_xtgl_njdmb
                    where njdm_id = t.njdm_id)                                            njmc,
                   (select zyfxmc
                    from zftal_xtgl_zyfxdmb
                    where zyfx_id = t.zyfx_id)                                            zyfxmc,
                   (select bj
                    from zftal_xtgl_bjdmb
                    where bh_id = t.bh_id)                                                bj
                 from (select
                         'cjb'                                                               as             ly,
                         t.xnm,
                         t.xqm,
                         t.jg_id,
                         t.njdm_id,
                         t.zyh_id,
                         t.zyfx_id,
                         t.bh_id,
                         t.xh_id,
                         t.xh,
                         t.xm,
                         t.xbm,
                         t.kcxzdm,
                         t.kclbdm,
                         t.kcgsdm,
                         t.sskch_id,
                         t.kch_id,
                         t.kch,
                         t.kcmc,
                         t.kcywmc,
                         t.xf,
                         t.jxb_id,
                         t.kcbj,
                         t.cj,
                         t.bfzcj,
                         t.cjbz,
                         t.hkcj,
                         fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm,
                                 t.kclbdm, t.cjxzm, t.kcbj, null, t.cjbz, t.jd, t.bfzcj, case when t.tdkcbj = '1'
                           then 'cjb-dtkc'
                                                                                         when t.btdkcbj = '1'
                                                                                           then 'cjb-bdtkc'
                                                                                         else 'cjb' end, 'tj',
                                 '0')                                                        as             jd,
                         t.cjxzm,
                         decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkcj,
                                nvl(t.mbybfzcj, 0), t.mbycj)                                 as             mbkcj,
                         decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkbfzcj,
                                nvl(t.mbybfzcj, 0),
                                t.mbybfzcj)                                                  as             mbkbfzcj,
                         decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkjd,
                                nvl(t.mbybfzcj, 0), t.mbyjd)                                 as             mbkjd,
                         decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkcjbz,
                                nvl(t.mbybfzcj, 0),
                                t.mbycjbz)                                                   as             mbkcjbz,
                         t.mbkcj                                                             as             mbkcj1,
                         mbkbfzcj                                                            as             mbkbfzcj1,
                         t.mbkjd                                                             as             mbkjd1,
                         t.mbkcjbz                                                           as             mbkcjbz1,
                         t.mbycj,
                         t.mbybfzcj,
                         t.mbyjd,
                         t.mbycjbz,
                         t.mcxcj,
                         t.mcxbfzcj,
                         t.mcxjd,
                         t.mcxcjbz,
                         nvl(t.bkcs, 0)                                                                     bkcs,
                         nvl(t.cxcs, 0)                                                                     cxcs,
                         t.cxcj1,
                         t.cxbfzcj1,
                         t.cxjd1,
                         t.cxcj2,
                         t.cxbfzcj2,
                         t.cxjd2,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cj, nvl(mbkbfzcj, 0),
                                mbkcj)                                                       as             mzbcj,
                         GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj,
                                                     0))                                     as             mzbbfzcj,
                         fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm,
                                 t.kclbdm, t.cjxzm, t.kcbj, null,
                                 decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cjbz,
                                        nvl(mbkbfzcj, 0), mbkcjbz),
                                 decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), jd,
                                        nvl(mbkbfzcj, 0), mbkjd), GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)),
                                 case when t.tdkcbj = '1'
                                   then 'cjb-dtkc'
                                 when t.btdkcbj = '1'
                                   then 'cjb-bdtkc'
                                 else 'cjb' end, 'tj', '0')                                  as             mzbjd,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0),
                                mbkcjbz)                                                     as             mzbcjbz,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0),
                                (case when cjxzm in ('16')
                                  then 'cx'
                                 when cjxzm in ('21', '22')
                                   then 'bybk'
                                 when cjbz = '缓考' or hkcj is not null
                                   then 'hk'
                                 else 'zk' end), nvl(mbkbfzcj, 0),
                                'bk')                                                        as             mzbcjbj,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                                nvl(bfzcj, 0), nvl(cj, 0), nvl(mbkbfzcj, 0), mbkcj, nvl(mcxbfzcj, 0), mcxcj,
                                nvl(mbybfzcj, 0), mbycj)                                     as             maxcj,
                         GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj,
                                                                                         0)) as             maxbfzcj,
                         fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm,
                                 t.kclbdm, t.cjxzm, t.kcbj, null, decode(
                                     GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0),
                                              nvl(mbybfzcj, 0)), nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0), mbkcjbz,
                                     nvl(mcxbfzcj, 0), mcxcjbz, nvl(mbybfzcj, 0), mbycjbz), decode(
                                     GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0),
                                              nvl(mbybfzcj, 0)), nvl(bfzcj, 0), jd, nvl(mbkbfzcj, 0), mbkjd,
                                     nvl(mcxbfzcj, 0), mcxjd, nvl(mbybfzcj, 0), mbyjd),
                                 GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                                 case when t.tdkcbj = '1'
                                   then 'cjb-dtkc'
                                 when t.btdkcbj = '1'
                                   then 'cjb-bdtkc'
                                 else 'cjb' end, 'tj', '0')                                  as             maxjd,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                                nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0), mbkcjbz, nvl(mcxbfzcj, 0), mcxcjbz,
                                nvl(mbybfzcj, 0),
                                mbycjbz)                                                     as             maxcjbz,
                         decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                                nvl(bfzcj, 0), (case when cjxzm in ('16')
                           then 'cx'
                                                when cjxzm in ('21', '22')
                                                  then 'bybk'
                                                when cjbz = '缓考' or hkcj is not null
                                                  then 'hk'
                                                else 'zk' end), nvl(mbkbfzcj, 0), 'bk', nvl(mcxbfzcj, 0), 'cx',
                                nvl(mbybfzcj, 0),
                                'bybk')                                                      as             maxcjbj,
                         t.tdkcbj,
                         t.btdkcbj,
                         (select count(1)
                          from jw_jh_jxzxjhkcxxb
                          where
                            njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc
                       from (select
                               t1.xnm,
                               t1.xqm,
                               t1.kcxzdm,
                               t1.xf,
                               t1.jg_id,
                               t1.njdm_id,
                               t1.zyh_id,
                               t1.zyfx_id,
                               t1.bh_id,
                               t1.xh_id,
                               t1.xh,
                               t1.xm,
                               t1.xbm,
                               t1.kclbdm,
                               t1.kcgsdm,
                               t1.sskch_id,
                               t1.kch_id,
                               t1.kch,
                               t1.kcmc,
                               t1.kcywmc,
                               t1.jxb_id,
                               t1.kcbj,
                               t1.hkcj,
                               (select count(1)
                                from jw_cj_xsgrcjdtb cjdtb
                                where cjdtb.zszt = '3' and t1.xh_id = cjdtb.xh_id and
                                      (case when length(t1.sskch_id) = 1 or t1.sskch_id is null
                                        then t1.kch_id
                                       else t1.sskch_id end) = cjdtb.kch_id and cjdtb.kcthzbm = 'xnkc' and
                                      rownum = 1)                                                     as tdkcbj,
                               (select count(1)
                                from jw_cj_xsgrdtzb m, jw_cj_xsgrjhdtb n
                                where m.kcthzh_id = n.kcthzh_id and m.kcthzbm = 'xnkc' and m.zszt = '3' and
                                      n.kch_id = (case when length(t1.sskch_id) = 1 or t1.sskch_id is null
                                        then t1.kch_id
                                                  else t1.sskch_id end) and n.xh_id = t1.xh_id and rownum =
                                                                                                   1) as btdkcbj,
                               case when t1.cjxzm in ('16', '21', '22')
                                 then null
                               else (case when t1.hkcj is null
                                 then nvl(t1.cj, t1.cjbz)
                                     else t1.hkcj end) end                                            as cj,
                               case when t1.cjxzm in ('16', '21', '22')
                                 then null
                               else (case when t1.hkcj is null
                                 then t1.bfzcj
                                     else t1.hkbfzcj end) end                                         as bfzcj,
                               case when t1.cjxzm in ('16', '21', '22')
                                 then null
                               else (case when t1.hkcj is null
                                 then t1.cjbz
                                     else t1.hkbz end) end                                            as cjbz,
                               case when t1.cjxzm in ('16', '21', '22')
                                 then null
                               else (case when t1.hkcj is null
                                 then t1.jd
                                     else t1.hkjd end) end                                            as jd,
                               t1.cjxzm,
                               t1.bkcj                                                                as mbkcj,
                               t1.bkbfzcj                                                             as mbkbfzcj,
                               t1.bkbz                                                                as mbkcjbz,
                               t1.bkjd                                                                as mbkjd,
                               t2.mbycj                                                               as mbycj,
                               t2.mbybfzcj                                                            as mbybfzcj,
                               t2.mbyjd                                                               as mbyjd,
                               t2.mbycjbz                                                             as mbycjbz,
                               t3.mcxcj                                                               as mcxcj,
                               t3.mcxbfzcj                                                            as mcxbfzcj,
                               t3.mcxjd                                                               as mcxjd,
                               t3.mcxcjbz                                                             as mcxcjbz,
                               t1.bkcs,
                               t3.cxcs,
                               t3.cxcj1,
                               t3.cxbfzcj1,
                               t3.cxjd1,
                               t3.cxcj2,
                               t3.cxbfzcj2,
                               t3.cxjd2
                             from (select
                                     XNM,
                                     XQM,
                                     njdm_id,
                                     jg_id,
                                     zyh_id,
                                     zyfx_id,
                                     bh_id,
                                     XH_ID,
                                     xh,
                                     xm,
                                     xbm,
                                     sskch_id,
                                     KCH_ID,
                                     KCH,
                                     KCMC,
                                     KCYWMC,
                                     XF,
                                     KCXZDM,
                                     KCLBDM,
                                     KCGSDM,
                                     JXB_ID,
                                     CJ,
                                     BFZCJ,
                                     CJBZ,
                                     JD,
                                     CJXZM,
                                     KCBJ,
                                     BZXX,
                                     bkcj,
                                     bkbfzcj,
                                     bkbz,
                                     bkjd,
                                     hkcj,
                                     hkbfzcj,
                                     hkbz,
                                     hkjd,
                                     bkcs
                                   from (select
                                           a.XNM,
                                           a.XQM,
                                           b.jg_id,
                                           b.njdm_id,
                                           b.zyh_id,
                                           nvl(b.zyfx_id, 'wfx')                   zyfx_id,
                                           b.bh_id,
                                           a.XH_ID,
                                           b.xh,
                                           b.xm,
                                           b.xbm,
                                           a.sskch_id,
                                           a.KCH_ID,
                                           nvl(kc.kch, a.KCH)                   as kch,
                                           nvl(kc.kcmc, a.KCMC)                 as kcmc,
                                           nvl(kc.kcywmc, a.KCYWMC)             as kcywmc,
                                           a.XF,
                                           a.KCXZDM,
                                           a.KCLBDM,
                                           a.KCGSDM,
                                           a.JXB_ID,
                                           a.CJ,
                                           a.BFZCJ,
                                           a.CJBZ,
                                           a.JD,
                                           a.CJXZM,
                                           a.KCBJ,
                                           a.BZXX,
                                           a.bkcj,
                                           a.bkbfzcj,
                                           a.bkbz,
                                           fn_jdjs(a.xnm, a.xqm, a.sskch_id, a.kch_id, a.kcmc, a.jxb_id, a.xh_id,
                                                   a.kcxzdm, a.kclbdm, '11', a.kcbj, null, a.bkbz, a.bkjd,
                                                   a.bkbfzcj, 'cjb', 'tj', '0') as bkjd,
                                           a.hkcj,
                                           a.hkbfzcj,
                                           a.hkbz,
                                           a.hkjd,
                                           a.bkcs,
                                           row_number()
                                           over (
                                             partition by a.xh_id, case when length(a.sskch_id) = 1
                                               then a.sskch_id || '-' || a.kch_id
                                                                   else nvl(a.sskch_id, a.kch_id) end
                                             order by to_number(a.cjxzm), to_number(nvl(a.hkbfzcj, a.bfzcj)) desc,
                                               a.xnm, to_number(a.xqm) )           rn
                                         from JW_CJ_XSCJB a, jw_xjgl_xsjbxxb b, jw_jh_kcdmb kc
                                         where a.xh_id = b.xh_id and a.cjxzm in ('01', '16', '21', '22') and
                                               a.kch_id = kc.kch_id (+) and not exists(select 1
                                                                                       from jw_cj_bzdmb c
                                                                                       where
                                                                                         (case when a.hkcj is null
                                                                                           then a.cjbz
                                                                                          else a.hkbz end) =
                                                                                         c.cjbzmc and
                                                                                         c.cjtjfx = '0') and
                                               a.cjxzm = '01' and
                                               b.jg_id = (select jg_id
                                                          from JW_XJGL_XSJBXXB
                                                          where xh = v_xh)
                                               and b.njdm_id = (select njdm_id
                                                                from JW_XJGL_XSJBXXB
                                                                where xh = v_xh)
                                               and b.zyh_id = (select zyh_id
                                                               from JW_XJGL_XSJBXXB
                                                               where xh = v_xh)
                                               and b.xjztdm in (select xjztdm
                                                                from jw_xjgl_xjztdmb
                                                                where sfyxj = '1') and
                                               to_number(a.xnm) <= to_number(nvl(v_xn, '9999')) and
                                               to_number(a.xnm) > to_number(nvl(v_xn_2, '1000')) and
                                               a.kcbj in ('0'))
                                   where rn = '1') t1 left join (select
                                                                   XH_ID,
                                                                   sskch_id,
                                                                   KCH_ID,
                                                                   CJ    as MBYCJ,
                                                                   BFZCJ as MBYBFZCJ,
                                                                   JD    as MBYJD,
                                                                   CJBZ  as MBYCJBZ
                                                                 from (select
                                                                         t1.XH_ID,
                                                                         t1.sskch_id,
                                                                         t1.KCH_ID,
                                                                         t1.CJ,
                                                                         t1.BFZCJ,
                                                                         fn_jdjs(t1.xnm, t1.xqm, t1.sskch_id,
                                                                                 t1.kch_id, t1.kcmc, t1.jxb_id,
                                                                                 t1.xh_id, t1.kcxzdm, t1.kclbdm,
                                                                                 t1.cjxzm, t1.kcbj, null, t1.cjbz,
                                                                                 t1.jd, t1.bfzcj, 'cjb', 'tj',
                                                                                 '0') as            JD,
                                                                         t1.CJBZ,
                                                                         row_number()
                                                                         over (
                                                                           partition by t1.xh_id, case when
                                                                             length(t1.sskch_id) = 1
                                                                             then t1.sskch_id || '-' || t1.kch_id
                                                                                                  else nvl(
                                                                                                      t1.sskch_id,
                                                                                                      t1.kch_id) end
                                                                           order by t1.bfzcj desc ) rn
                                                                       from JW_CJ_XSCJB t1, jw_xjgl_xsjbxxb t2
                                                                       where t1.xh_id = t2.xh_id and
                                                                             t1.cjxzm in ('21', '22') and
                                                                             t2.jg_id = (select jg_id
                                                                                         from JW_XJGL_XSJBXXB
                                                                                         where xh = v_xh) and
                                                                             t2.njdm_id = (select njdm_id
                                                                                           from JW_XJGL_XSJBXXB
                                                                                           where xh = v_xh) and
                                                                             t2.zyh_id = (select zyh_id
                                                                                          from JW_XJGL_XSJBXXB
                                                                                          where xh = v_xh) and
                                                                             t2.xjztdm in (select xjztdm
                                                                                           from jw_xjgl_xjztdmb
                                                                                           where sfyxj = '1'))
                                                                 where rn = '1') t2
                                 on t1.xh_id = t2.xh_id and case when length(t1.sskch_id) = 1
                                 then t1.sskch_id || '-' || t1.kch_id
                                                            else nvl(t1.sskch_id, t1.kch_id) end =
                                                            case when length(t2.sskch_id) = 1
                                                              then t2.sskch_id || '-' || t2.kch_id
                                                            else nvl(t2.sskch_id, t2.kch_id) end
                               left join (select
                                            XH_ID,
                                            sskch_id,
                                            case when length(sskch_id) = 1
                                              then sskch_id || '-' || kch_id
                                            else nvl(sskch_id, kch_id) end as KCH_ID,
                                            MAX(decode(rn, '1', CJ))       as MCXCJ,
                                            MAX(decode(rn, '1', BFZCJ))    as MCXBFZCJ,
                                            MAX(decode(rn, '1', JD))       as MCXJD,
                                            MAX(decode(rn, '1', CJBZ))     as MCXCJBZ,
                                            cxcs,
                                            MAX(decode(minrn, '1', CJ))    as CXCJ1,
                                            MAX(decode(minrn, '1', BFZCJ)) as CXBFZCJ1,
                                            MAX(decode(minrn, '1', JD))    as CXJD1,
                                            MAX(decode(minrn, '2', CJ))    as CXCJ2,
                                            MAX(decode(minrn, '2', BFZCJ)) as CXBFZCJ2,
                                            MAX(decode(minrn, '2', JD))    as CXJD2
                                          from (select
                                                  t1.XH_ID,
                                                  t1.sskch_id,
                                                  t1.KCH_ID,
                                                  nvl(t1.hkcj, t1.cj)   as                               CJ,
                                                  (case when t1.hkcj is null
                                                    then t1.bfzcj
                                                   else t1.hkbfzcj end) as                               BFZCJ,
                                                  fn_jdjs(t1.xnm, t1.xqm, t1.sskch_id, t1.kch_id, t1.kcmc,
                                                          t1.jxb_id, t1.xh_id, t1.kcxzdm, t1.kclbdm, t1.cjxzm,
                                                          t1.kcbj, null, (case when t1.hkcj is null
                                                    then t1.cjbz
                                                                          else t1.hkbz end),
                                                          (case when t1.hkcj is null
                                                            then t1.jd
                                                           else t1.hkjd end), (case when t1.hkcj is null
                                                    then t1.bfzcj
                                                                               else t1.hkbfzcj end), 'cjb', 'tj',
                                                          '0')          as                               JD,
                                                  (case when t1.hkcj is null
                                                    then t1.cjbz
                                                   else t1.hkbz end)    as                               CJBZ,
                                                  row_number()
                                                  over (
                                                    partition by t1.xh_id, case when length(t1.sskch_id) = 1
                                                      then t1.sskch_id || '-' || t1.kch_id
                                                                           else nvl(t1.sskch_id, t1.kch_id) end
                                                    order by to_number(nvl(t1.hkbfzcj, t1.bfzcj)) desc ) rn,
                                                  row_number()
                                                  over (
                                                    partition by t1.xh_id, case when length(t1.sskch_id) = 1
                                                      then t1.sskch_id || '-' || t1.kch_id
                                                                           else nvl(t1.sskch_id, t1.kch_id) end
                                                    order by t1.xnm, to_number(t1.xqm) )                 minrn,
                                                  count(distinct case when instr(',' || nvl('null', 'y') || ',',
                                                                                 ',' || nvl(t1.cjbz, 'xx') || ',')
                                                                           = 0 and t1.cjxzm = '16'
                                                    then t1.jxb_id
                                                                 else null end)
                                                  over (
                                                    partition by t1.xh_id, nvl(t1.sskch_id, t1.kch_id) ) cxcs
                                                from JW_CJ_XSCJB t1, jw_xjgl_xsjbxxb t2
                                                where t1.xh_id = t2.xh_id and t1.cjxzm in ('16', '17') and
                                                      t2.jg_id = (select jg_id
                                                                  from JW_XJGL_XSJBXXB
                                                                  where xh = v_xh)
                                                      and t2.njdm_id = (select njdm_id
                                                                        from JW_XJGL_XSJBXXB
                                                                        where xh = v_xh)
                                                      and t2.zyh_id = (select zyh_id
                                                                       from JW_XJGL_XSJBXXB
                                                                       where xh = v_xh)
                                                      and t2.xjztdm in (select xjztdm
                                                                        from jw_xjgl_xjztdmb
                                                                        where sfyxj = '1'))
                                          where (rn = '1' or minrn in ('1', '2'))
                                          group by XH_ID, sskch_id, case when length(sskch_id) = 1
                                            then sskch_id || '-' || kch_id
                                                                    else nvl(sskch_id, kch_id) end, cxcs) t3
                                 on t1.xh_id = t3.xh_id and case when length(t1.sskch_id) = 1
                                 then t1.sskch_id || '-' || t1.kch_id
                                                            else nvl(t1.sskch_id, t1.kch_id) end = t3.kch_id) t) t
                 where 1 = 1
                 group by t.xh, t.xm, t.xh_id, t.zyfx_id, t.njdm_id, t.jg_id, t.zyh_id, t.bh_id,
                   t.jg_id)) t
    where t.xh = v_xh;


select v_pjxfjd || '#' || case when nvl(count(*),0) > 0
      then '有'
                              else '无' end
    into v_pjxfjd
    from jw_cj_xscjb a
    where a.xh_id = (select xh_id
                     from jw_xjgl_xsjbxxb
                     where xh = v_xh)  and a.CJXZM  not in ('02','20') and a.BFZCJ<60 and to_number(a.xnm) <= to_number(nvl(v_xn,'9999')) and
          to_number(a.xnm) > to_number(nvl(v_xn_2, '1000'))
  and not exists(select 'x' from jw_cj_xscjb b where b.XH_ID=a.XH_ID and b.KCH_ID=a.KCH_ID and b.CJXZM in ('02','20') and b.BFZCJ>=60);
    return v_pjxfjd;
  end;
/

