create function fn_jsktsbshmxxx(vKtjbxxid varchar2,vBj varchar2) return varchar2  ---教师课题申报审核面向信息----
as
  sMxxx varchar2(4000);--面向信息
begin
    sMxxx :='';
    begin
      --获取年级信息
       if vBj='1' then
         select
             wm_concat((select njmc from zftal_xtgl_njdmb where njdm_id=b.njdm_id)) into sMxxx
         from
          jw_bysj_kt_mxnjxyzy b where b.kt_jbxx_id=vKtjbxxid  order by  b.njdm_id,b.jg_id,b.zyh_id;
         --赋值
       end if;

        --获取专业信息
       if vBj='2' then
         select
             wm_concat((select zymc from zftal_xtgl_zydmb where zyh_id=b.zyh_id)) into sMxxx
         from
          jw_bysj_kt_mxnjxyzy b where b.kt_jbxx_id=vKtjbxxid  order by  b.njdm_id,b.jg_id,b.zyh_id;
         --赋值
       end if;


        --获取学院信息
       if vBj='3' then
         select
               wm_concat((select jgmc from zftal_xtgl_jgdmb where jg_id=b.jg_id)) into sMxxx
         from
          jw_bysj_kt_mxnjxyzy b where b.kt_jbxx_id=vKtjbxxid  order by  b.njdm_id,b.jg_id,b.zyh_id;
         --赋值
       end if;

      exception
      When others then
      sMxxx := '';
    end;


    if sMxxx is null then
    return '' ;
    else
    return sMxxx ;
    end if ;
end fn_jsktsbshmxxx;

/

