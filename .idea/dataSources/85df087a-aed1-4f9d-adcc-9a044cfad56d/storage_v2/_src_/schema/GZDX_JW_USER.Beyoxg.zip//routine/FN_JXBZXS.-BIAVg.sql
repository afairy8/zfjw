create function fn_jxbzxs(fn_jxbid varchar2) return number
/****查询教学班应该安排的总学时****/
as
   /***总学时***/
   zxs number;
   xsfpsfcf varchar2(2);
   jls number;
begin
    select nvl(a.xsfpsfcf,'0'),a.rwzxs,(select count(1) from jw_pk_xsfpb where jxb_id=a.jxb_id)
    into xsfpsfcf,zxs,jls from jw_jxrw_jxbxxb a where a.jxb_id=fn_jxbid;
    /**判断有无学时分配***/
    if jls>0 then
      if  xsfpsfcf=1 then
          select sum(ks) into zxs from (
          select zc,max(ks) as ks
           from jw_pk_xsfpb m,jw_jg_jzgxxb n where m.jgh_id=n.jgh_id
           and m.jxb_id=fn_jxbid and m.ks>0 group by zc
           );
      else
          select sum(ks) into zxs
           from jw_pk_xsfpb m,jw_jg_jzgxxb n where m.jgh_id=n.jgh_id
           and m.jxb_id=fn_jxbid and m.ks>0;
      end if;
    end if;
    if zxs is null then
       zxs := 0;
    end if;
    return zxs;
end fn_jxbzxs;

/

