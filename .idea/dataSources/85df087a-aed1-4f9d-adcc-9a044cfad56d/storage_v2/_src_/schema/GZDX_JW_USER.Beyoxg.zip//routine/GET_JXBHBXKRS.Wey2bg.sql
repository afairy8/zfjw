create function Get_Jxbhbxkrs(vJxb_id varchar2) return number ----获取教学班合班选课人数
as
sXkrs number; ---选课人数
sCount number;
begin
select count(1) into sCount from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1';---查询有无合班
if sCount>0 then
 select count(distinct xk.xh_id) into sXkrs
	 from jw_xk_xsxkb xk, jw_pk_bbfzb b, jw_pk_bbfzb c
	where xk.jxb_id = b.jxb_id
	  and b.bbfz_id = c.bbfz_id
	  and c.bbbj = '1'
	  and c.jxb_id = vJxb_id;
else
 select count(xk.xh_id) into sXkrs from jw_xk_xsxkb xk where xk.jxb_id = vJxb_id;
end if;
return sXkrs;
end Get_Jxbhbxkrs;

/

