create function likai_getNextXn(v_xqm  varchar2)
  return varchar2
  as
  v_nextxnxq varchar2(255);
  --从当前学年学期返回下一个学年学期
begin
  if v_xqm='12' then
    select to_char((to_number(zdz)+1))||'#3' into v_nextxnxq  from ZFTAL_XTGL_XTSZB where zs='当前学年';
  else
    select zdz||'#12' into v_nextxnxq  from ZFTAL_XTGL_XTSZB where zs='当前学年';
  end if;
  return v_nextxnxq;
end;
/

