create function fn_cx_jckcxzmc(
  vNjdm_id varchar2,
  vZyh_id varchar2,
  vKch_id varchar2,
  vJxb_id varchar2,
  vBj varchar2
) return varchar2
as
   v_kcxzmc varchar2(500);   ---课程性质名称
   v_sfqkck varchar2(2);--是否取课程库:1-取课程库;0-不取课程库     SFQKCK
   v_kckywkcxzkz varchar2(2);--课程库有无课程性质控制:0-无;1-有    KCKYWKCXZKZ
begin
    begin
      v_kcxzmc := '无';
      select a.zdz into v_sfqkck from jw_jcdml_xtnzb a where zdm ='SFQKCK';
      select a.zdz into v_kckywkcxzkz from jw_jcdml_xtnzb a where zdm = 'KCKYWKCXZKZ';
      if vBj = '0' then /*取课程性质名称全称*/
        if v_sfqkck = '1' and v_kckywkcxzkz = '1' then
          /*课程性质取课程库*/
          select t.kcxzmc into v_kcxzmc from jw_jh_kcxzdmb t,jw_jh_kcdmb kc where t.kcxzdm = kc.kcxzdm and kc.kch_id=vKch_id;
        else
          /*优先取计划，再取任务，最后取课程库*/
          select nvl(max(t.kcxzmc),'无') into v_kcxzmc from jw_jh_jxzxjhkcxxb jhkc, jw_jh_kcxzdmb t where t.kcxzdm = jhkc.kcxzdm and jhkc.kcxzdm is not null and jhkc.njdm_id=vNjdm_id and jhkc.zyh_id=vZyh_id and jhkc.kch_id=vKch_id and rownum=1;
          if v_kcxzmc = '无' then
            /*取任务中的课程性质*/
            select nvl(max(t.kcxzmc),'无') into v_kcxzmc from jw_jxrw_jxbhbxxb jxb, jw_jh_kcxzdmb t where jxb.kcxzdm = t.kcxzdm and decode(jxb.njdm_id,'wnj',vNjdm_id,jxb.njdm_id)=vNjdm_id and decode(jxb.zyh_id,'wzy',nvl(vZyh_id,'wzy'),jxb.zyh_id)=nvl(vZyh_id,'wzy') and jxb.jxb_id=nvl(vJxb_id,'wjxb') and rownum=1;
            if v_kcxzmc = '无' then
              /*最后取课程库中的课程性质*/
              select t.kcxzmc into v_kcxzmc from jw_jh_kcdmb kc,jw_jh_kcxzdmb t where kc.kcxzdm = t.kcxzdm and kc.kch_id=vKch_id;
            end if;
          end if;
        end if;
      end if;

      if vBj = '1' then/*取课程性质简称*/
        if v_sfqkck = '1' and v_kckywkcxzkz = '1' then
          /*课程性质取课程库*/
          select t.kcxzjc into v_kcxzmc from jw_jh_kcxzdmb t,jw_jh_kcdmb kc where t.kcxzdm = kc.kcxzdm and kc.kch_id=vKch_id;
        else
          /*优先取计划，再取任务，最后取课程库*/
          select nvl(max(t.kcxzjc),'无') into v_kcxzmc from jw_jh_jxzxjhkcxxb jhkc,jw_jh_kcxzdmb t where t.kcxzdm = jhkc.kcxzdm and jhkc.kcxzdm is not null and jhkc.njdm_id=vNjdm_id and jhkc.zyh_id=vZyh_id and jhkc.kch_id=vKch_id and rownum=1;
          if v_kcxzmc = '无' then
            /*取任务中的课程性质*/
            select nvl(max(t.kcxzmc),'无') into v_kcxzmc from jw_jxrw_jxbhbxxb jxb, jw_jh_kcxzdmb t where jxb.kcxzdm = t.kcxzdm and decode(jxb.njdm_id,'wnj',vNjdm_id,jxb.njdm_id)=vNjdm_id and decode(jxb.zyh_id,'wzy',nvl(vZyh_id,'wzy'),jxb.zyh_id)=nvl(vZyh_id,'wzy') and jxb.jxb_id=nvl(vJxb_id,'wjxb') and rownum=1;
            if v_kcxzmc = '无' then
              /*最后取课程库中的课程性质*/
              select t.kcxzjc into v_kcxzmc from jw_jh_kcdmb kc,jw_jh_kcxzdmb t where kc.kcxzdm = t.kcxzdm and kc.kch_id=vKch_id;
            end if;
          end if;
        end if;
      end if;

    exception
        When others then
          v_kcxzmc := '无';
    end;
    return v_kcxzmc;
end fn_cx_jckcxzmc;

/

