create function fun_by_pyfaxdxf(v_xh_id varchar2,v_xdlx varchar2)
return varchar2 as
sJg    varchar2(4000); ---返回审核是否通过描述
v_flag number;
v_xxdm varchar2(10);
sqlstr varchar2(8000);
sqlstr_temp varchar2(8000);
begin
  sJg := '合格';
  begin
  --查询学校代码
  select xxdm into  v_xxdm from zftal_xtgl_xxxxszb;

    if v_xxdm = '10484' then
       sqlstr_temp :='select nvl(instr(a.zt, ''N''), ''1'') from (select wm_concat(zgshzt) zt from '||
                    ' (select zgshzt,xh_id,sfmjd,yxjd,xdlx,fxfyqjd_id from jw_jh_xsjxzxjhxfyqxxb union all select zgshzt,xh_id,sfmjd,yxjd,xdlx,fxfyqjd_id from jw_jh_xsjxzxjhxfyqxxfxezyb) '||
                    ' where xh_id = '''||v_xh_id||''' and (sfmjd=''1'' or fxfyqjd_id is null) and yxjd=''1''';
                    if v_xdlx is not null and v_xdlx !='qb' then
                     sqlstr_temp:=sqlstr_temp||' and xdlx =  '''||v_xdlx||''' ';
                    end if;
       sqlstr_temp:=sqlstr_temp||') a';

    else
       sqlstr_temp :='select nvl(instr(a.zt, ''N''), ''1'') from (select wm_concat(zgshzt) zt from '||
                     ' (select zgshzt,xh_id,fxfyqjd_id,xdlx from jw_jh_xsjxzxjhxfyqxxb union all select zgshzt,xh_id,fxfyqjd_id,xdlx from jw_jh_xsjxzxjhxfyqxxfxezyb) '||
                     ' where xh_id = '''||v_xh_id||''' and fxfyqjd_id is null ';
                    if v_xdlx is not null and v_xdlx !='qb' then
                     sqlstr_temp:=sqlstr_temp||' and xdlx =  '''||v_xdlx||''' ';
                    end if;
       sqlstr_temp:=sqlstr_temp||') a';
     end if;

     execute immediate sqlstr_temp into v_flag;

      if v_flag > 0 then
        sqlstr:='select nvl(wm_concat(t.xfyqjdmc || ''要求'' || t.yqzdxf || ''学分'' || '',实际获得'' || nvl(t.hdxf, ''0'') || ''学分(未合格课程:'' || '||
                   '(select wm_concat((kc.kcmc||''/''||a.bfzcj)) '||
                   '   from jw_jh_kcdmb kc, JW_JH_xsJXZXJHkcXXB a '||
                   '  where kc.kch_id = a.kch_id '||
                   '    and a.xfyqjd_id = t.xfyqjd_id '||
                   '    and a.xh_id = '''||v_xh_id||''' '||
                   '    and (a.hdxf is null or a.hdxf = ''0'')) || '')''),''无数据'') '||
               '  from (select zgshzt, xh_id, sfmjd, yxjd,xdlx,xfyqjd_id,hdxf,yqzdxf,xfyqjdmc,fxfyqjd_id from jw_jh_xsjxzxjhxfyqxxb union all '||
                      ' select zgshzt, xh_id, sfmjd, yxjd,xdlx,xfyqjd_id,hdxf,yqzdxf,xfyqjdmc,fxfyqjd_id from jw_jh_xsjxzxjhxfyqxxfxezyb)t  '||
               '  where t.xh_id = '''||v_xh_id||'''';

               if v_xdlx is not null and v_xdlx !='qb' then
                sqlstr:=sqlstr|| 'and t.xdlx = '''||v_xdlx||''' ';
               end if;

         if v_xxdm = '10484' or v_xxdm='13201' then--沈阳工学院，河南财经政法
             sqlstr:= sqlstr||' and (t.sfmjd = ''1'' or fxfyqjd_id is null) and t.yxjd = ''1'' and t.zgshzt = ''N'' ';
         else
              sqlstr:= sqlstr||' and t.sfmjd = ''1'' and t.yxjd = ''1'' and t.zgshzt = ''N'' ';
         end if;


        execute immediate sqlstr into sJg;
        sJg := sJg||',不合格！';
      else
        sJg := '合格！';
      end if;

  exception
    When others then
      sJg := '查询出错，不合格！';
  end;

  if sJg is null then
    return '系统无数据，不合格！';
  else
    return sJg;
  end if;
end fun_by_pyfaxdxf;

/

