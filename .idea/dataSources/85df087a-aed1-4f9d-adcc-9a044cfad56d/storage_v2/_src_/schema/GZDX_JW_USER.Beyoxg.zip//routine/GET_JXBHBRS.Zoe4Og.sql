create function Get_Jxbhbrs----获取教学班合班人数
(vJxb_id varchar2) return varchar2
as
sJxbrs varchar2(10); ---教学班人数
sCount number;
begin

select count(1) into sCount from jw_pk_bbfzb where jxb_id = vJxb_id and bbbj = '1';---查询有无合班
if sCount>0 then
 select to_char(sum(a.jxbrs+nvl(a.krrl,0))) into sJxbrs
	 from jw_jxrw_jxbxxb a, jw_pk_bbfzb b, jw_pk_bbfzb c
	where a.jxb_id = b.jxb_id
	  and b.bbfz_id = c.bbfz_id
	  and b.bbbj = '1'
	  and c.bbbj = '1'
	  and c.jxb_id = vJxb_id;
else
 select to_char(jxbrs+nvl(krrl,0)) into sJxbrs from jw_jxrw_jxbxxb where jxb_id = vJxb_id;
end if;

return sJxbrs;
end Get_Jxbhbrs;

/

