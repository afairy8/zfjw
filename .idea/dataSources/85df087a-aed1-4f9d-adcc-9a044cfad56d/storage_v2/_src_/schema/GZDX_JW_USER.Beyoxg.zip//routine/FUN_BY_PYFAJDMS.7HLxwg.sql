create function fun_by_pyfajdms(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
  -- v_flag int;
begin
    sJg := '';
    begin
       /* select count(1) into v_flag
          from (select count(a.kch_id) kcms,
                       a.xfyqjd_id,
                       b.xfyqjdmc,
                       nvl(b.kczdms, 0) kczdms
                  from jw_jh_xsjxzxjhkcxxb a, JW_JH_xsJXZXJHXFYQXXB b
                 where a.xfyqjd_id = b.xfyqjd_id
                   and a.xh_id = b.xh_id
                   and a.xh_id = v_xh_id
                   and a.bfzcj >= 60
                 group by a.xfyqjd_id, b.kczdms, b.xfyqjdmc) a
         where a.kcms < a.kczdms;

         if v_flag>0 then
            sJg:= '学生执行计划节点课程门数不符合要求，不合格！';
         else
            sJg:= '合格！';
         end if;*/

 select wm_concat(b.xfyqjdmc || '通过门数' || nvl(a.kcms, 0) || '小于' || '要求' ||
                  b.kczdms) into sJg
   from (select count(a.kch_id) kcms,

                a.xfyqjd_id
           from jw_jh_xsjxzxjhkcxxb a, JW_JH_xsJXZXJHXFYQXXB b
          where a.xfyqjd_id = b.xfyqjd_id
            and a.xh_id = b.xh_id
            and a.xh_id = v_xh_id
            and a.bfzcj >= 60

          group by a.xfyqjd_id) a,
        (select a.xfyqjd_id, b.xfyqjdmc, nvl(b.kczdms, 0) kczdms
           from jw_jh_xsjxzxjhkcxxb a, JW_JH_xsJXZXJHXFYQXXB b
          where a.xfyqjd_id = b.xfyqjd_id
            and a.xh_id = b.xh_id
            and a.xh_id = v_xh_id
          group by a.xfyqjd_id, b.kczdms, b.xfyqjdmc) b
  where a.xfyqjd_id(+) = b.xfyqjd_id
    and nvl(a.kcms, 0) < b.kczdms;

         if sJg is not null then
            sJg:= sJg||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_pyfajdms;

/

