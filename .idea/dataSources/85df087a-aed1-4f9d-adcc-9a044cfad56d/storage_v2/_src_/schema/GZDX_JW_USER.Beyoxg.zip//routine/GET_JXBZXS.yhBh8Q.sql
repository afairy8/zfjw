create function get_jxbzxs
(vXnm varchar2,
 vXqm varchar2,
 vKklxdm varchar2,
 vKch_id varchar2,
 vJxb_id varchar2,
 vXsdm varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vBh_id varchar2,
 vZyfx_id varchar2,
 vBj varchar2) return varchar2  ---班级组合----
as
   vZt varchar2(2);   ---状态
begin
    vZt := '无';
    begin
       if vBj = '0' then
         select max(bj) into vZt
         from (select jxb_id,fjxb_id,xsdm,rwzxs,rn,case when max(rwzxs_s) over( partition by 1) = rwzxs_s then '1' else '0' end bj
              from (select jxb_id,fjxb_id,xsdm,rwzxs,rn,
                           sum(case when rn = 1 then rwzxs else '0' end) over( partition by nvl(fjxb_id,jxb_id)) rwzxs_s
                   from (select t1.jxb_id ,t1.fjxb_id,t1.xsdm,t1.rwzxs,
                                row_number() over (partition by nvl(t1.fjxb_id,t1.jxb_id) ,t1.xsdm order by t1.rwzxs desc) rn
                        from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2
                       where t1.jxb_id = t2.jxb_id
                         and t1.xnm = vXnm
                         and t1.xqm = vXqm
                         and t1.kch_id = vKch_id
                         and t2.njdm_id = nvl(vNjdm_id,t2.njdm_id)
                         and t2.zyh_id = nvl(vZyh_id,t2.zyh_id)
                         )
              )
          ) where jxb_id = vJxb_id;
       end if ;
       exception
       When others then
          vZt := '无';
    end;
    return vZt;
end get_jxbzxs;
/

