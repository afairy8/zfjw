create view V_BZKS_BJXX as
  select
bh,
(select njmc from zftal_xtgl_njdmb where njdm_id = t.njdm_id) nj,
(select jgdm from zftal_xtgl_jgdmb where jg_id = t.jg_id) yxdm,
(select zyh from zftal_xtgl_zydmb where zyh_id = t.zyh_id) zydm,
'' zykldm,'' xslbdm,'' rxsj,'' yjbyny,
(select xz from zftal_xtgl_zydmb where zyh_id = t.zyh_id) xz,zxrs rs,
(select jgh from jw_jg_jzgxxb where jgh_id = t.bzrjgh_id) bzrzgh from zftal_xtgl_bjdmb t
/

