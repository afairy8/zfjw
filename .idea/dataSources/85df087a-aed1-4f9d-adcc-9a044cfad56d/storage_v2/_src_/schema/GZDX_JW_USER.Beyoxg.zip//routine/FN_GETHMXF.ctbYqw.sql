create function FN_GETHMXF(v_xh_id varchar2,v_xfyqjd_id varchar2) return varchar2
/****查询节点总共的豁免学分 kwy****/
as
   hmxf varchar2(20);
begin
        select
                -- 校内被替代课程数据
              ((select nvl(sum(kcxx.xf),0)
                  from jw_cj_xsgrdtzb zb,jw_cj_xsgrjhdtb t,jw_jh_xsjxzxjhkcxxb kcxx
                 where zb.zszt='3'
                   and zb.kcthzh_id = t.kcthzh_id
                   and zb.kcthzbm = 'xnkc'
                   and t.xh_id = v_xh_id
                   and t.kch_id = kcxx.kch_id
                   and t.xh_id  = kcxx.xh_id
                   and kcxx.xfyqjd_id = v_xfyqjd_id)
                +
                -- 校内课程节点替代
               (select nvl(sum(t.xf),0)
                  from jw_cj_xsgrdtzb zb,jw_cj_xsgrjhjddtb t
                 where zb.zszt='3'
                   and zb.kcthzh_id = t.kcthzh_id
                   and zb.kcthzbm = 'xnkcxfjd'
                   and t.xh_id = v_xh_id
                   and t.xfyqjd_id = v_xfyqjd_id)
                +
                 -- 校内节点与节点替代
                (select nvl(sum(a.xf),0)
                from jw_cj_xsgrdtzb t, jw_cj_xsgrjhjddtb a
               where t.zszt = '3'
                 and t.kcthzh_id = a.kcthzh_id
                 and t.kcthzbm = 'xnxfjd'
                 and a.xh_id = v_xh_id
                 and a.xfyqjd_id = v_xfyqjd_id)
                +
                -- 校内课程学分认定
                (select nvl(sum(kcxx.xf),0)
                 from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b,jw_jh_xsjxzxjhkcxxb kcxx
                where b.xrdz_id = t.rdz_id
                  and b.shjg='3'
                  and b.xh_id = v_xh_id
                  and b.xh_id  = kcxx.xh_id
			            and t.kch_id = kcxx.kch_id
			            and kcxx.xfyqjd_id = v_xfyqjd_id)) into hmxf
           from dual;

    if hmxf is null then
       hmxf := 0;
    end if;
    return hmxf;
end FN_GETHMXF;

/

