create function Get_Xshdfz_zjjc(
vXnm varchar2,
vXqm varchar2,
vXh_id varchar2,      ---学号ID
vXmlbmc varchar2      ---项目类别名称
) return number
as
type xssq_cursor is ref cursor; --定义一个游标变量
v_sq_cursor xssq_cursor;
icount number;   ---记录数
vHdfz number;
vXmflmc varchar2(500);
vXmlxmc varchar2(500);
vXmnr varchar2(500);
vXmdj1 varchar2(500);
vXmdj2 varchar2(500);
vSfydj varchar2(500);
vSbxmmc varchar2(500);
vBz varchar2(500);
vXmfzxssqid varchar2(500);
begin
   vHdfz:=0;
   select count(1) into icount from jw_cj_xmfzxssqb sqb ,jw_cj_xmbmqkb bmb where bmb.xmbmqk_id = sqb.xmbmqk_id and bmb.xmlbmc=vXmlbmc and sqb.xh_id = vXh_id and sqb.qrfzsj is not null and bmb.xnm= vXnm and bmb.xqm=vXqm ;
   if icount = 0 then
      return vHdfz ;
   else
      open v_sq_cursor for  select bmb.xmflmc,bmb.xmlxmc,bmb.xmnr,bmb.xmdj1,bmb.xmdj2,nvl(bmb.sfydj,0)sfydj,bmb.sbxmmc,bmb.bz,sqb.xmfzxssq_id from jw_cj_xmfzxssqb sqb ,jw_cj_xmbmqkb bmb where bmb.xmbmqk_id = sqb.xmbmqk_id and bmb.xmlbmc=vXmlbmc and sqb.xh_id = vXh_id  and sqb.qrfzsj is not null and bmb.xnm= vXnm and bmb.xqm=vXqm ;
      loop
           fetch v_sq_cursor into vXmflmc,vXmlxmc,vXmnr,vXmdj1,vXmdj2,vSfydj,vSbxmmc,vBz,vXmfzxssqid;
            --判断当前游标是否到达最后
            exit when v_sq_cursor%notfound;
            vHdfz:=vHdfz+get_Hdfz(vXmlbmc,vXmflmc,vXmlxmc,vXmnr,vXmdj1,vXmdj2,vSfydj,vSbxmmc,vBz,vXmfzxssqid);
      end loop;
      --关闭游标
      close v_sq_cursor;
   end if;
  return vHdfz ;
end Get_Xshdfz_zjjc;

/

