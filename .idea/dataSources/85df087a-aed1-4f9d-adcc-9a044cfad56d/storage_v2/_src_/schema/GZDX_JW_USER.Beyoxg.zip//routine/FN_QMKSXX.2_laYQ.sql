create function fn_qmksxx(vJxb_id varchar2,vXnm varchar2,vXqm varchar2,lx varchar2) return varchar2 /**---期末考试信息----**/
 as
  sKsxx varchar2(32);/**-考试信息-**/
  sQmkssj varchar2(32);/** 期末考试时间**/
  sQmksdd varchar2(32);/** 期末考试地点**/
begin
  sKsxx := '';
     begin
     /** 期末考试时间 **/
     if lx = 'kssj' then
       select t4.ksrq || ' ' || t4.kskssj || '-' || t4.ksjssj into sQmkssj
            from jw_kw_ksmcdmb t1,jw_kw_ksmcjxbdzb t2, jw_kw_kssjb t3, jw_kw_ksccb t4
             where t1.ksmcdmb_id = t2.ksmcdmb_id
               and t1.ksmcdmb_id = t3.ksmcdmb_id
               and t1.ksmcdmb_id = t4.ksmcdmb_id
               and t2.sjbh_id = t3.sjbh_id
               and t3.ksccb_id = t4.ksccb_id
               and t2.jxb_id = vJxb_id
               and t1.sfqmks ='1'
               and t1.xnm = vXnm
               and t1.xqm = vXqm
               and t2.xnm = vXnm
               and t2.xqm = vXqm
               and t3.xnm = vXnm
               and t3.xqm = vXqm
               and t4.xnm = vXnm
               and t4.xqm = vXqm;

     --进行赋值
     sKsxx := sQmkssj;

     end if;

     /** 期末考试地点 **/
     if lx = 'ksdd'  then
       select wm_concat(ksdd) into sQmksdd from (
     select  t5.cdmc as ksdd
            from jw_kw_ksmcdmb t1,jw_kw_ksmcjxbdzb t2, jw_kw_ksddbjdzb t3, jw_kw_ksddb t4 ,jw_jcdm_cdxqxxb t5
             where t1.ksmcdmb_id = t2.ksmcdmb_id
               and t2.sjbh_id = t3.sjbh_id
               and t2.jxb_id = case when t3.apfs = '2' then t3.jxb_id else t2.jxb_id end
               and t3.apfs != '1'
               and t3.kshkbj_id = t4.kshkbj_id
               and t4.xnm = t5.xnm
               and t4.xqm = t5.xqm
               and t4.cd_id = t5.cd_id
               and t2.jxb_id = vjxb_id
               and t1.sfqmks ='1'
               and t1.xnm = vXnm
               and t1.xqm = vXqm
               and t2.xnm = vXnm
               and t2.xqm = vXqm
               and t3.xnm = vXnm
               and t3.xqm = vXqm
               and t4.xnm = vXnm
               and t4.xqm = vXqm
               and t5.xnm = vXnm
               and t5.xqm = vXqm
      union
      select t5.cdmc as ksdd
                  from jw_kw_ksmcdmb t1,jw_kw_ksmcjxbdzb t2, jw_kw_ksddbjdzb t3, jw_kw_ksddb t4 ,jw_jcdm_cdxqxxb t5,jw_jxrw_jxbhbxxb t6
                   where t1.ksmcdmb_id = t2.ksmcdmb_id
                     and t2.sjbh_id = t3.sjbh_id
                     and t2.jxb_id = t6.jxb_id
                     and t3.bh_id = t6.bh_id
                     and t3.apfs = '1'
                     and t3.kshkbj_id = t4.kshkbj_id
                     and t4.xnm = t5.xnm
                     and t4.xqm = t5.xqm
                     and t4.cd_id = t5.cd_id
                     and t2.jxb_id = vJxb_id
                     and t1.sfqmks ='1'
                     and t1.xnm = vXnm
                     and t1.xqm = vXqm
                     and t2.xnm = vXnm
                     and t2.xqm = vXqm
                     and t3.xnm = vXnm
                     and t3.xqm = vXqm
                     and t4.xnm = vXnm
                     and t4.xqm = vXqm
                     and t5.xnm = vXnm
                     and t5.xqm = vXqm
                     );

     --进行赋值
     sKsxx := sQmksdd;

     end if;

     exception
       When others then
         sKsxx := '';
     end;
  return sKsxx;
end fn_qmksxx;

/

