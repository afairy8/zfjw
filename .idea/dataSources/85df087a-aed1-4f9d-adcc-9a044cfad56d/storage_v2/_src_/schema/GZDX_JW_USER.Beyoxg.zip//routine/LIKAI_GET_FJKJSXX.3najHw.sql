create function likai_get_fjkjsxx(v_ksdd_id in varchar2, v_rn in int)
  --返回辅监考教师信息
  return varchar2 is
  v_fjkjsxx varchar2(255); --记载成绩的教学班ID，成绩，绩点以及课程性质代码
  begin
    select nvl(jzg.jgh || '#xm' || jzg.xm || '#jg' || jg.jgmc,'')
    into v_fjkjsxx
    from (select
            row_number()
            over (
              partition by jkb.KSDD_ID
              order by
                jkb.JKLX ) rn,
            jkb.KSDD_ID,
            jkb.JGH_ID
          from
            (select ksdd_id,jklx,jgh_id from JW_KW_KSDDJKB) jkb) t, JW_JG_JZGXXB jzg, ZFTAL_XTGL_JGDMB jg
    where
      t.rn = v_rn and t.KSDD_ID = v_ksdd_id
      and t.JGH_ID = jzg.JGH_ID and jzg.JG_Id = jg.JG_ID;
    return v_fjkjsxx;
  end;
/

