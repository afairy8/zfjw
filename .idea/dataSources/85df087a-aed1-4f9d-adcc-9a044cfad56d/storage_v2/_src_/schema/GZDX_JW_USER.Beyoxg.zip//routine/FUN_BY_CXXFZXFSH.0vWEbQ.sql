create function fun_by_cxxfzxfsh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---重修学分小于总学分三分之一
   v_cxxf number;
   v_zxf number;
   v_bl varchar2(6);
begin
    sJg := '合格';
    begin
        select sum(to_number(nvl(xf,'0'))) into v_zxf from (
            select cj.*, row_number() over(partition by cj.xh_id, cj.kch_id order by cj.BFZCJ desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id = v_xh_id
            )where rn=1
            and bfzcj>=60 ;

            select nvl(sum(to_number(nvl(xf,'0'))),0) into v_cxxf from (
            select cj.*, row_number() over(partition by cj.xh_id, cj.kch_id order by cj.BFZCJ desc) rn from
            jw_cj_xscjb cj
            where cj.xh_id = v_xh_id and cj.cjxzm in('16','17')
            )where rn=1
            and bfzcj>=60 ;
         select to_char(v_cxxf/v_zxf,'fm9999999990.00') into v_bl  from dual;
         if to_number(v_bl)>to_number(v_tjsjz) then
            sJg:= '重修总学分'||v_cxxf||'和总学分'||v_zxf||'比例'||v_bl||'大于'||v_tjsjz||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;
    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_cxxfzxfsh;

/

