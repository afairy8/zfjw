create view SGW_BHXY_BYSHZHCJ as
  SELECT bsfxf,dektxf,fxxf,ezyxf,exwxf,zdxf,jg_id, zyh_id,bh_id,njdm_id, zyxy,xy,zymc,bjmc,dqszj,xh,xm,xb,mz,zzmm,xjzt,cc,xz,zjhm,  xh_id, kch_id,kch,kcmc, xf, kcxzdm, kcxzmc,bfzcj, jybfzcj,jd FROM
(SELECT bsfxf,dektxf,fxxf,ezyxf,exwxf,  ZDXF, C.*,A.kch_id, A.xf, A.kcxzdm, bfzcj, JYBFZCJ,KCXZMC,KCMC,KCH,jd
  FROM (select kch_id,
               xh_id,
               max(bfzcj) bfzcj,
               max(xf) xf,max(jd) jd,
               min(nvl(kcxzdm,'26') ) kcxzdm
          from jw_cj_xscjb a where kch_id not in (select kch_id  from jw_bysh_cfjfkc)
         group by kch_id, xh_id
         union all
        select kch_id,
               xh_id,
               bfzcj,
                xf,  jd,
               kcxzdm
          from jw_cj_xscjb a where cjxzm='01' and   kch_id   in (select kch_id  from jw_bysh_cfjfkc)  and bfzcj>=60) A,
       (SELECT kch_id, xh_id, MAX(JYBFZCJ) JYBFZCJ
          FROM (select kch_id,
                       xh_id,
                       NVL(NVL(JYBFZCJ,
                               DECODE(TRIM(JYCJ),
                                      'P',
                                      60,
                                      'F',
                                      1,
                                      'H',
                                      2,
                                      'Q',
                                      3,
                                      'U',
                                      4,
                                      'W',
                                      5,
                                      ' ',
                                      0)),
                           '8') JYBFZCJ
                  from jw_cj_JYCJB where  jybkbfzcj is null
                  union all
                  select kch_id,
                       xh_id, greatest(nvl(jybfzcj,0),jybkbfzcj) jybfzcj  from jw_cj_JYCJB where  jybkbfzcj is not null
                  )
         group by kch_id, xh_id) B,SGW_XSJBXXB C ,JW_JH_KCDMB KC ,JW_JH_KCXZDMB XZ ,JW_JH_JXZXJHXXB JH
 WHERE A.XH_ID = B.XH_ID
   AND A.KCH_ID = B.KCH_ID AND A.XH_ID=C.XH_ID  AND A.KCH_ID=KC.KCH_ID  AND XZ.KCXZDM=nvl(A.KCXZDM,'26') AND JH.NJDM_ID=C.NJDM_ID AND JH.ZYH_ID=C.ZYH_ID
   ) WHERE 1=1
/

