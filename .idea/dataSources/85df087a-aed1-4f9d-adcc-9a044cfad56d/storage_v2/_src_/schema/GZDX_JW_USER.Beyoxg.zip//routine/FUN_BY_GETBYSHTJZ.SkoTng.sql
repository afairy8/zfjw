create function fun_by_getbyshtjz(                     ----判断毕业及学位审核条件值
v_xh_id varchar2,             ----学号
v_bynd varchar2,              ----毕业年度
v_xdlx varchar2,              ----主修或者辅修:1-主修,2-辅修
v_shlx varchar2,              ----毕业审核或者学位审核:1-毕业审核,2-学位审核
v_tj_id varchar2              ----条件ID
)
Return varchar2
as
tname  varchar2(200);         -----要查询的表名
sqlstr varchar2(4000);        -----执行语句
num    number;                -----数量
lsbl   varchar2(20);          -----临时变量
jg     varchar2(4000);        -----结果
begin
     if v_xh_id is not null and
        v_bynd is not null and
        v_xdlx is not null and
        v_shlx is not null and
        v_tj_id is not null       then
        if v_xdlx = '1' and v_shlx = '1' then
          tname:='jw_bygl_byshb';
        elsif v_xdlx = '1' and v_shlx = '2' then
          tname:='jw_bygl_xwshb';
        elsif v_xdlx = '2' and v_shlx = '1' then
          tname:='jw_bygl_fxshb';
        elsif v_xdlx = '2' and v_shlx = '2' then
          tname:='jw_bygl_fxxwshb';
        end if;

        if tname is not null then
            for i in 1..20 loop
              if i<10 then
                 lsbl := '0'||i;
              end if;
              sqlstr:= 'select count(*) from '||tname||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and tj'||lsbl||'_id='''||v_tj_id||'''';
                execute immediate sqlstr into num;
              if num >0 then
                 sqlstr:= 'select tj'||lsbl||' from '||tname||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||'''';
                 execute immediate sqlstr into jg;
                 return jg;
              end if;
            end loop;
        end if;
     end if;
  return jg;
end;

/

