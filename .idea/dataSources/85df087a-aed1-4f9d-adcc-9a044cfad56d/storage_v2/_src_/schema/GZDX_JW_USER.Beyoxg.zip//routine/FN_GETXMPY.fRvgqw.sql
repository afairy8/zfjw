create FUNCTION fn_getxmpy(p_str IN VARCHAR2) RETURN VARCHAR2 AS
  v_length  INT := 0;
  v_xLength INT := 1;
  v_subStr  varchar2(100);
  v_fxStr   varchar2(600);
  v_return  VARCHAR2(4000);
BEGIN
  IF p_str IS NULL THEN
    RETURN '';
  END IF;

  v_length := length(p_str);
  if v_length > 2 then
    v_fxStr := '|欧阳|太史|端木|上官|司马|东方|独孤|南宫|万俟|闻人|夏侯|诸葛|尉迟|公羊|赫连|澹台|皇甫|宗政' ||
               '|濮阳|公冶|太叔|申屠|公孙|慕容|仲孙|钟离|长孙|宇文|司徒|鲜于|司空|闾丘|子车|亓官|司寇|巫马|公西' ||
               '|颛孙|壤驷|公良|漆雕|乐正|宰父|谷梁|拓跋|夹谷|轩辕|令狐|段干|百里|呼延|东郭|南门|羊舌|微生|公户' ||
               '|公玉|公仪|梁丘|公仲|公上|公门|公山|公坚|左丘|公伯|西门|公祖|第五|公乘|贯丘|公皙|南荣|东里|东宫' ||
               '|仲长|子书|子桑|即墨|达奚|褚师|';
    if instr(v_fxStr, '|' || substr(p_str, 1, 2) || '|') > 0 then
      v_xLength := 2;
    end if;
  end if;

  for i in 1 .. v_length loop
    case
      when i = 1 then
        v_return := fn_getpy(substr(p_str, i, 1), 2);
      when i <= v_xLength then
        v_return := v_return || fn_getpy(substr(p_str, i, 1), 5);
      when i = v_xLength + 1 then
        v_subStr := fn_getpy(substr(p_str, i, 1), 2);
        if v_subStr = substr(p_str, i, 1) then
          v_return := v_return || v_subStr;
        else
          v_return := v_return || ' ' || v_subStr;
        end if;
      else
        v_return := v_return || fn_getpy(substr(p_str, i, 1), 5);
    end case;
  end loop;
  return v_return;
END fn_getxmpy;

/

