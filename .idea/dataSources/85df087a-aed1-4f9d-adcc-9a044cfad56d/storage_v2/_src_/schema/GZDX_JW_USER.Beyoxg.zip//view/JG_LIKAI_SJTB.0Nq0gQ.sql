create view JG_LIKAI_SJTB as
  select t2.jgh,t1.JG_ID from ZFTAL_XTGL_JGDMB t1,LIKAI_SJTB_JZGXXB t2
where t1.JGDM=t2.JGDM
/

