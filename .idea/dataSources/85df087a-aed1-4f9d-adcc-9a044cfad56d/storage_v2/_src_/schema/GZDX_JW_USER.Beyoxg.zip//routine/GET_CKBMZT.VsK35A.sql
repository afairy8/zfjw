create function get_ckbmzt(vXh_id varchar2,vXkxnm varchar2,vXkxqm varchar2)---重考报名状态
Return varchar2
as
 sSzb_id varchar2(32);
 sXqh_id varchar2(32);
 sJg_id varchar2(32);
 sNjdm_id varchar2(32);
 sZyh_id varchar2(32);
 sZyfx_id varchar2(32);
 sBh_id varchar2(32);
 sXbm varchar2(32);
 sXslbm varchar2(32);
 sCcdm varchar2(32);
 sXsbj varchar2(32);
 icount number;
 imx number;
 ixz number;
 icount_mx number;
 icount_xz number;

begin
 select max(t.szb_id) into sSzb_id from JW_CJ_CKBMSZB t
         where xnm = vXkxnm
           and xqm = vXkxqm
           and t.zt = '1'
           and sysdate between t.kssj and t.jssj;
 if sSzb_id is not null then
   select nvl((select xqh_id from zftal_xtgl_bjdmb where bh_id = t2.bh_id),-1),
              nvl(t2.jg_id,-1),nvl(t2.njdm_id,-1),nvl(t2.zyh_id,-1),nvl(t2.zyfx_id,-1),
              nvl(t2.bh_id,-1),nvl(t1.xbm,-1),nvl(t2.xslbdm,-1),nvl(t2.pyccdm,-1),nvl(t1.xsbj,4294967296)
              into sXqh_id,sJg_id,sNjdm_id,sZyh_id,sZyfx_id,sBh_id,sXbm,sXslbm,sCcdm,sXsbj from
              jw_xjgl_xsjbxxb t1,jw_xjgl_xsxjxxb t2
                           where t1.xh_id = t2.xh_id
                             and t2.xh_id = vXh_id
                             and t2.xnm = vXkxnm
                             and t2.xqm = vXkxqm;

   select count(*),nvl(max(decode(xzlb,'mx',1)),0) ,nvl(max(decode(xzlb,'xz',1)),0) into icount,imx,ixz from JW_CJ_CKBMMXDXB where szb_id = sSzb_id;

   if icount > 0 then
     select count(*) into icount_mx from JW_CJ_CKBMMXDXB
      where szb_id = sSzb_id
        and xzlb = 'mx'
        and nvl(xqh_id,sxqh_id) = sxqh_id
        and nvl(jg_id,sJg_id) = sJg_id
        and nvl(njdm_id,snjdm_id) = snjdm_id
        and nvl(zyh_id,szyh_id) = szyh_id
        and nvl(zyfx_id,sZyfx_id) = szyfx_id
        and nvl(bh_id,sbh_id) = sbh_id
        and nvl(xbm,sxbm) = sXbm
        and nvl(xslbm,sxslbm) = sxslbm
        and nvl(ccdm,sccdm) = sccdm
        and bitand(nvl(xsbj,sxsbj),sxsbj) >0
        and nvl(xh_id,vXh_id) = vXh_id;

      select count(*) into icount_xz from JW_CJ_CKBMMXDXB
      where szb_id = sSzb_id
        and xzlb = 'xz'
        and nvl(xqh_id,sxqh_id) = sxqh_id
        and nvl(jg_id,sJg_id) = sJg_id
        and nvl(njdm_id,snjdm_id) = snjdm_id
        and nvl(zyh_id,szyh_id) = szyh_id
        and nvl(zyfx_id,sZyfx_id) = szyfx_id
        and nvl(bh_id,sbh_id) = sbh_id
        and nvl(xbm,sxbm) = sXbm
        and nvl(xslbm,sxslbm) = sxslbm
        and nvl(ccdm,sccdm) = sccdm
        and bitand(nvl(xsbj,sxsbj),sxsbj) >0
        and nvl(xh_id,vXh_id) = vXh_id;

     if (imx > 0 and icount_mx <= 0) or (ixz > 0 and icount_xz > 0 ) then
       return '0';--被限制
     else
       return '1';--被面向
     end if;
   else
     return '1';
   end if;
 else
   return '-1';
 end if;
end;
/

