create view V_GD_JW_JH_PYFAXXB as
  select distinct njdm_id||(select v.zyh from zftal_xtgl_zydmb v where v.zyh_id=s.zyh_id )  pyfaxx_id
,njdm_id||'01'bbh,s.zyh_id ,njdm_id||'01'||
(select v.zymc from zftal_xtgl_zydmb v where v.zyh_id=s.zyh_id )pyfamc
,(select v.DLBS from zftal_xtgl_zydmb v where v.zyh_id=s.zyh_id ) dlbs

 ,'0'sqzt,'admin'czr,'0'shzt,''syxw  from zftal_xtgl_bjdmb s where njdm_id='2018'
/

