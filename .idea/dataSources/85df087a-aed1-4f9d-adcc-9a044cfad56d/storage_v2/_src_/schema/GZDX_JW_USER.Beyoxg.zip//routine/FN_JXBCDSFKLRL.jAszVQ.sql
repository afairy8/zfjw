create function fn_jxbCdsfklrl(vJxb_id varchar2,vXnm varchar2,vXqm varchar2,vBj varchar2)
---教学班取场地类别是否考虑容量
return varchar2
as
   sfklrl varchar2(30);
begin
    sfklrl := '';
    begin
       if vBj = '0' then
        select nvl(
               --如果排过场地就取场地对应类别是否考虑容量
              (select  wm_concat(t5.sfklrl)
                    from jw_jcdm_cdxqxxb t1,jw_jxrw_jxbxxb t2, jw_pk_kbsjb t3, jw_pk_kbcdb t4,jw_jcdm_cdlbdmb t5
                               where t1.cd_id = t4.cd_id
                                 and t4.kb_id = t3.kb_id
                                 and t3.jxb_id = t2.jxb_id
                                 and t1.xnm = t2.xnm
                                 and t1.xqm = t2.xqm
                                 and t2.xnm = t3.xnm
                                 and t2.xqm = t3.xqm
                                 and t1.cdlb_id = t5.cdlb_id
                                 and t1.xnm = vXnm
                                 and t1.xqm = vXqm
                                 and t2.xnm = vXnm
                                 and t2.xqm = vXqm
                                 and t3.xnm = vXnm
                                 and t3.xqm = vXqm
                                 and t2.jxb_id = vJxb_id

              ),
              (
                  select nvl(
                      --没有排过场地就取任务对应二级场地类别是否考虑容量
                     (select  t1.sfklrl
                             from jw_jcdm_cdlbdmb t1,jw_jxrw_jxbxxb t2
                               where t1.cdlb_id = t2.cdejlb_id
                                 and t2.jxb_id = vJxb_id
                     ),
                     (
                     --以上两者都为空就取任务对应场地类别是否考虑容量
                     select  t1.sfklrl
                             from jw_jcdm_cdlbdmb t1,jw_jxrw_jxbxxb t2
                               where t1.cdlb_id = t2.cdlb_id
                                 and t2.jxb_id = vJxb_id
                     )

                 ) from dual
              )) sf into sfklrl from dual;

       end if ;
     exception
        When others then
          sfklrl := '';
    end;
    if sfklrl is null then
     return '' ;
    else
    return sfklrl ;
    end if ;
end fn_jxbCdsfklrl;

/

