create view VIEW_CJ_CXBMSZ as
  select
szb_id,
xnm,
(select xnmc from jw_jcdm_xnb where xnm=t1.XNM) xnmc,
xqm,
(select mc from zftal_xtgl_jcsjb where lx = '0001' and dm=t1.xqm) xqmc,
kssj,
to_char(kssj,'yyyy-mm-dd hh24:mi:ss') xskssj,
jssj,
to_char(jssj,'yyyy-mm-dd hh24:mi:ss') xsjssj,
bmsm,
dkbcxctkg,
decode(dkbcxctkg,'1','是','0','否') dkbcxctkgmc,
gbcxctkg,
decode(gbcxctkg,'1','是','0','否') gbcxctkgmc,
jfsj,
decode(jfsj,'1','选课前','2','选课后') jfsjmc,
bz
from
jw_cj_cxbmszb t1
/

