create procedure p_cx_save_cxbm
(
  in_xh_id in varchar2,
  in_jxb_id in varchar2,
  in_bmsj in varchar2,
  in_cxbmlx in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
v_count number;
v_jxbrl number;
v_yxrs number;
v_kch_id varchar2(32);
v_xkxnm varchar2(5);
v_xkxqm varchar2(2);
begin
     out_flag := 1;
     select max(case when lower(zdm)='xkxnm' then zdz end) xkxnm,max(case when lower(zdm)='xkxqm' then zdz end) xkxqm into v_xkxnm,v_xkxqm from zftal_xtgl_xtszb;
     select count(*) into v_count from jw_xmgl_jxxmbmszb t where t.jxxmlbdm='1008' and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between t.kssj and t.jssj;
     if v_count=0 then
        out_flag := 0;
        out_msg := '对不起，当前时间不可报名，如有需要，请与管理员联系！';
        goto nextOne;
     end if;

     select kch_id,nvl(jxbrs,0)+nvl(krrl,0) into v_kch_id,v_jxbrl from jw_jxrw_jxbxxb where jxb_id=in_jxb_id;

     select count(*) into v_count from jw_xk_xsxkb where xh_id=in_xh_id and kch_id=v_kch_id and xnm=v_xkxnm and xqm=v_xkxqm;
     if v_count>0 then
        out_flag := 0;
        out_msg := '对不起，同一门课程只可报一个重修教学班！';
        goto nextOne;
     end if;

     select count(*) into v_yxrs from jw_xk_xsxkb where jxb_id=in_jxb_id and xnm=v_xkxnm and xqm=v_xkxqm;
     if v_jxbrl<=v_yxrs then
        out_flag := -1;
        out_msg := '对不起，当前教学班已无余量，不可再报！';
        goto nextOne;
     end if;

     insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,cxbmlx,xnm,xqm,kch_id) values (in_jxb_id,in_xh_id,'1',in_bmsj,in_xh_id,1,0,'1','10','0','1',in_cxbmlx,v_xkxnm,v_xkxqm,v_kch_id);

     <<nextOne>>

     if out_flag = '-1' then
         rollback;
     else
         commit;
     end if;
end;

/

