create function get_bylwwjjlj(vxtb_id varchar2) return varchar2
as
   wjjlj varchar2(2000);   ---毕业过程资料文件夹命名,文件夹路径需要用'/'隔开
begin
    wjjlj := null;
    begin
    select xs_jg_mc||'/'||xs_zy_mc||'/'||xs_bj_mc||'/'||xs_xh as lj into wjjlj from view_bysj_xs_xtxx where xtb_id=vxtb_id;
     exception
        When others then
          wjjlj := null;  --返回值
    end;
    return wjjlj;
end get_bylwwjjlj;

/

