create function get_cjlrcgts(vJxb_id varchar2) return varchar2 ---成绩录入超过天数
 as
  sCgts        varchar2(32); /*---返回的超过天数*/
  sRq          varchar2(32); /*日期 */
  sSjcgts      varchar2(32); /*实际超过天数 */
begin
  sCgts := '';
  begin
        ----获取教学班最后上课日期
        select fn_kcjssj(vJxb_id) into sRq from dual;

        ----获取教学周最后一天
        if sRq is null then
            select max(b.rq) into sRq from jw_pk_xlb a, jw_pk_rcmxb b
             where a.xl_id = b.xl_id
               and a.xnm = (select xnm from jw_jxrw_jxbxxb where jxb_id = vJxb_id)
               and b.dxqm = (select xqm from jw_jxrw_jxbxxb where jxb_id = vJxb_id);
        end if;

        if sRq is not null then
           select to_date(substr(sRq,1,10),'yyyy-mm-dd')-to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd') into sSjcgts from dual;
           select to_char(sSjcgts-zdz) into sCgts from jw_jcdml_xtnzb where XTNZ_ID = 'CJLRJGTS';---成绩录入警告天数（sCgts大于0距离提醒的天数；sCgts为0刚好提醒的天数；sCgts小于0超过提醒时间）
        end if;

  exception
    When others then
      sCgts := '-99.9';
  end;
  return sCgts;
end get_cjlrcgts;

/

