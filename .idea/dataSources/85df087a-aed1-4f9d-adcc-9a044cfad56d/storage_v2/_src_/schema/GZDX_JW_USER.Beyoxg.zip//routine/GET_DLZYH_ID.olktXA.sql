create FUNCTION Get_Dlzyh_Id(vNjdm_id IN VARCHAR2,vZyh_id IN VARCHAR2) RETURN VARCHAR2 IS
  sDlzyh_Id VARCHAR2(32);
  i integer;
  iCount integer;
BEGIN
  i := 1;
   select count(*)-1 into iCount from jw_jcdm_ztcsb where ywlx = 'zylb';
  sDlzyh_Id := vZyh_id;
  while i <= iCount Loop
  select nvl((select dldm from jw_jh_dlzydzb t1 where t1.njdm_id = vNjdm_id and t1.zyh_id = sDlzyh_Id),sDlzyh_id) into sDlzyh_id from dual;
  i := i+1;
  end Loop;
  RETURN sDlzyh_Id;
END Get_Dlzyh_Id;

/

