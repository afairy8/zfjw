create function fn_kccjInfo(vXnm varchar2, vXqm varchar2,vKch_id varchar2,vXh_id varchar2) return  varchar2 --返回课程成绩 是否>60 的相关信息
as
  icount number;   --记录数
  sMs varchar2(1000); --描述
  vKcmc varchar2(32); --课程名称
  vBfzcj   varchar2(32); --百分制成绩
begin
     sMs :='';
     vKcmc :='';
     vBfzcj :='';

     begin
     select count(1) into icount from JW_CJ_XSCJB where xnm = vXnm and xqm = vXqm and xh_id = vXh_id and to_number(bfzcj) >=60 and kch_id = vKch_id;

     select (select b.kcmc from jw_jh_kcdmb b where b.kch_id =s.kch_id )kch,s.bfzcj into vKcmc,vBfzcj
     from JW_CJ_XSCJB s
     where s.xnm = vXnm and s.xqm = vXqm and s.xh_id = vXh_id and to_number(s.bfzcj) >=60 and s.kch_id = vKch_id;

     if icount = 0 then
        select icount || '|' || vKcmc ||'的成绩为'|| vBfzcj into sMs from dual;
     else
        select icount || '|' || vKcmc ||'的成绩为'|| vBfzcj ||',无需补选!' into sMs from dual;
     end if;

    exception
        When others then
        sMs :='error';
    end;

    if sMs is null then
     return null ;
    else
    return sMs ;
    end if ;
end fn_kccjInfo;

/

