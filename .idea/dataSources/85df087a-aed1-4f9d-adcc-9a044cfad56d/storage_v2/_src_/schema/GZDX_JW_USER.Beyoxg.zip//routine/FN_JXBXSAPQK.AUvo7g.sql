create function fn_jxbxsapqk(izxs number,iypxs number,izhxs number) return varchar2  ---教学班学时安排情况
as
   apqk varchar2(2000);
   v_zhxs number;
   v_bj number;
begin
   if izhxs>5 then
      v_zhxs := 5;
   elsif izhxs>1 then
      v_zhxs :=izhxs-1;
   else
      v_zhxs := izhxs;
   end if;
   select count(*) into v_bj from jw_jcdml_xtnzb where zdm='PKYPXSJSFS' and zdz='2';
   if v_bj>0 then
      v_zhxs := 0;
   end if;
   if iypxs<=0 then
        apqk:='未排';
   elsif iypxs>izxs then
        apqk:='超排'||(iypxs-izxs)||'学时';
   elsif iypxs+v_zhxs>=izxs then
        apqk:='已排';
   else
        apqk:='未排'||(izxs-iypxs)||'学时';
   end if;
   return apqk;
end fn_jxbxsapqk;

/

