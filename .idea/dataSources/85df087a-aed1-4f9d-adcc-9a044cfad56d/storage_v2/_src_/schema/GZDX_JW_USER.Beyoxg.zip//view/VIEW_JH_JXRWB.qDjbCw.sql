create view VIEW_JH_JXRWB as
  select a.xnm,
                       a.xqm,
                       a.njdm_id,
                       a.zyh_id,
                       a.dlbs,
                       a.rwbj,
                       a.xfyqjd_id,
                       a.xfyqjdmc,
                       a.zyfx_id,
                       a.kch_id,
                       a.xbx,
                       a.zxbj,
                       a.fxbj,
                       a.ezybj,
                       a.exwbj,
                       nvl(a.rs, 0) jhrs,
                       nvl(b.rs, 0) rwrs,
                       (select zxs
                          from jw_jh_kcdmb c
                         where a.kch_id = c.kch_id) zxs,
                       nvl(c.maxzxs, 0) maxzxs,
                       nvl(c.minzxs, 0) minzxs,
                       (select jg.jg_id
                          from zftal_xtgl_jgdmb jg, zftal_xtgl_zydmb zy
                         where jg.jg_id = zy.jg_id
                           and zy.zyh_id = a.zyh_id) jg_id
                  from (select a.xnm,
                               a.xqm,
                               a.njdm_id,
                               a.zyh_id,
                               a.dlbs,
                               a.rwbj,
                               a.xfyqjd_id,
                               a.xfyqjdmc,
                               a.zyfx_id,
                               a.kch_id,
                               a.xbx,
                               a.zxbj,
                               a.fxbj,
                               a.ezybj,
                               a.exwbj,
                               b.rs
                          from (select c.jyxdxnm xnm,
                                       c.jyxdxqm xqm,
                                       a.njdm_id,
                                       a.zyh_id,
                                       a.dlbs,
                                       'zy' rwbj,
                                       b.xfyqjd_id,
                                       b.xfyqjdmc,
                                       b.zyfx_id,
                                       c.kch_id,
                                       c.xbx,
                                       c.zxbj,
                                       c.fxbj,
                                       c.ezybj,
                                       c.exwbj
                                  from jw_jh_jxzxjhxxb     a,
                                       jw_jh_jxzxjhxfyqxxb b,
                                       jw_jh_jxzxjhkcxxb   c
                                 where c.jyxdxnm = '09'
                                   and c.jyxdxqm = '12'
                                   and a.jxzxjhxx_id = b.jxzxjhxx_id
                                   and b.xfyqjd_id = c.xfyqjd_id) a
                          left join (select xnm,
                                           xqm,
                                           jg_id,
                                           njdm_id,
                                           zyh_id,
                                           'wfx' zyfx_id,
                                           sum(rs) rs
                                      from (select xnm,
                                                   xqm,
                                                   jg_id,
                                                   njdm_id,
                                                   zyh_id,
                                                   zyfx_id,
                                                   sum(rs) rs
                                              from (select xnm,
                                                           xqm,
                                                           jg_id,
                                                           njdm_id,
                                                           zyh_id,
                                                           bh_id,
                                                           zyfx_id,
                                                           count(distinct xh_id) rs
                                                      from jw_xjgl_xsxjxxb
                                                     where xnm = '09'
                                                       and xqm = '12'
                                                     group by xnm,
                                                              xqm,
                                                              jg_id,
                                                              njdm_id,
                                                              zyh_id,
                                                              bh_id,
                                                              zyfx_id)
                                             group by xnm,
                                                      xqm,
                                                      jg_id,
                                                      njdm_id,
                                                      zyh_id,
                                                      zyfx_id)
                                     group by xnm, xqm, jg_id, njdm_id, zyh_id
                                    union all
                                    select xnm,
                                           xqm,
                                           jg_id,
                                           njdm_id,
                                           zyh_id,
                                           zyfx_id,
                                           sum(rs) rs
                                      from (select xnm,
                                                   xqm,
                                                   jg_id,
                                                   njdm_id,
                                                   zyh_id,
                                                   bh_id,
                                                   zyfx_id,
                                                   count(distinct xh_id) rs
                                              from jw_xjgl_xsxjxxb
                                             where xnm = '09'
                                               and xqm = '12'
                                               and zyfx_id <> 'wfx'
                                             group by xnm,
                                                      xqm,
                                                      jg_id,
                                                      njdm_id,
                                                      zyh_id,
                                                      bh_id,
                                                      zyfx_id)
                                     group by xnm,
                                              xqm,
                                              jg_id,
                                              njdm_id,
                                              zyh_id,
                                              zyfx_id) b on (a.xnm = b.xnm and
                                                            a.xqm = b.xqm and
                                                            a.njdm_id =
                                                            b.njdm_id and
                                                            a.zyh_id =
                                                            b.zyh_id and
                                                            a.zyfx_id =
                                                            b.zyfx_id)) a
                  left join (select xnm,
                                   xqm,
                                   njdm_id,
                                   zyh_id,
                                   kch_id,
                                   zyfx_id,
                                   sum(rs) rs
                              from (select b.xnm,
                                           b.xqm,
                                           a.njdm_id,
                                           a.zyh_id,
                                           b.kch_id,
                                           b.jxb_id,
                                           b.fjxb_id,
                                           a.zyfx_id,
                                           a.bh_id,
                                           a.rs,
                                           b.xsdm
                                      from jw_jxrw_jxbhbxxb a,
                                           jw_jxrw_jxbxxb   b,
                                           jw_jh_kcdmb      kc
                                     where a.jxb_id = b.jxb_id
                                       and b.kch_id = kc.kch_id
                                       and b.xnm = '09'
                                       and b.xqm = '12'
                                       and a.zyh_id <> 'wzy'
                                       and fjxb_id is null)
                             group by xnm,
                                      xqm,
                                      njdm_id,
                                      zyh_id,
                                      kch_id,
                                      zyfx_id) b on (a.xnm = b.xnm and
                                                    a.xqm = b.xqm and
                                                    a.njdm_id = b.njdm_id and
                                                    a.zyh_id = b.zyh_id and
                                                    a.kch_id = b.kch_id and
                                                    decode(a.zyfx_id,b.zyfx_id,0,'wfx',1,2) <= 1
                                                    --(a.zyfx_id = b.zyfx_id or
                                                    --a.zyfx_id = 'wfx')
                                                   )
       left join (
                            select kch_id,max(maxzxs) maxzxs,min(minzxs) minzxs from (
                            select jxb_id,kch_id,sum(maxzxs) maxzxs,sum(minzxs) minzxs from (
                            select jxb_id,kch_id,xsdm,max(zxs) maxzxs,min(zxs) minzxs from (
                            select  jxb_id,kch_id,xsdm,case when rwxssfcf = 0 then sum(zzcs)*zhxs else max(zzcs)*zhxs end zxs from (
                                     select nvl(a.fjxb_id,a.jxb_id) jxb_id,a.kch_id,xsdm,nvl(zhxs,0) zhxs,
                                     a.rwxssfcf,
                                     case when a.rwxssfcf = 0 then
                                     fn_jszs(b.qsjsz)
                                     else
                                     fn_jszs(get_bitorsunion(wm_concat(b.qsjsz) over (partition by b.jxb_id))) end zzcs
                                    from jw_jxrw_jxbxxb a,
                                    jw_jxrw_jxbjsrkb b
                                    where a.xnm='09' and a.xqm='12' and a.jxb_id = b.jxb_id
                                   ) group by jxb_id,kch_id,xsdm,zhxs,rwxssfcf
                                   ) group by jxb_id,kch_id,xsdm
                                   ) group by jxb_id,kch_id
                                   ) group by kch_id

                                    ) c on
                                    ( a.kch_id = c.kch_id)
/

