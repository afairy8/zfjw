create function Get_Bkjl(vJxb_id varchar2,vXnm varchar2,vXqm varchar2) ---停课返回有无补课记录---
  return  varchar2 as Bkjl varchar2(500) ;----补课记录信息
begin
     select wm_concat((a.xqjmc||'第'||a.jc||'{'||a.zcd||'}'||'/'||a.jgmc||'（补）')) into Bkjl
      from (
             select get_weeksdesc_xnxq(vXnm,vXqm,sqb.xzcd)zcd,get_jcbinarydesc(sqb.xjc,'节')jc,
                (select mc from zftal_xtgl_jcsjb where lx = '0036' and dm = sqb.xxqj) xqjmc,
                (select xm from JW_JG_JZGJBXXB where jgh_id = sqb.xjgh_id)jgmc
             from jw_pk_ttksqb sqb
             where sqb.tklxdm = '02'
              and sqb.shzt = '3'
              and sqb.jxb_id = vJxb_id
             )a;
  return bkjl;
end;

/

