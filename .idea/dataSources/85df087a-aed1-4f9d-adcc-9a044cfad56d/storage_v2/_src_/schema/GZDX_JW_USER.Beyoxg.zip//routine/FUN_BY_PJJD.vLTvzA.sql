create function fun_by_pjjd(v_xh_id varchar2,v_tjmc varchar2,v_tjsjcs varchar2,v_tjsjz varchar2,
                                       v_tjsjly varchar2,v_tjsjlymc varchar2,v_tjsjgx varchar2,
                                       v_tjpx varchar2,v_tjsjmc varchar2,v_tjkcxz varchar2,v_btjkc varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   sqlstr VARCHAR2(2000);
   v_pjf varchar2(10);
begin
    sJg := '合格';
    begin
       --根据类型获得平均绩点
    sqlstr:= 'select '||v_tjsjlymc||'('''||v_xh_id||''','''||v_tjpx||''','''||v_tjkcxz||''','''||v_btjkc||''') from dual';
    execute immediate sqlstr into v_pjf;

    sqlstr:='select (case when '||v_pjf||v_tjsjgx||v_tjsjz||' then ''合格'' else '''||v_tjsjmc||v_tjmc||v_pjf||',低于'||v_tjsjz||',不合格！'' end) from dual';
    execute immediate sqlstr into sJg;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_pjjd;

/

