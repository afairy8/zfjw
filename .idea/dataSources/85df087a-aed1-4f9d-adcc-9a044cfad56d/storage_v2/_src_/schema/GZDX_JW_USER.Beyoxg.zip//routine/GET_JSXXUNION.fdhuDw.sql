create function Get_JsxxUnion(jxb_ids IN varchar2)
return varchar2  ---教学班教师信息----
as
   sJsxx varchar2(2000) := '';   ---教师信息
begin
    begin
       select replace(wm_concat(jsxx),',',';') into sJsxx from (
       select distinct b.jgh||'/'||b.xm as jsxx from
            jw_jxrw_jxbjsrkb a,jw_jg_jzgxxb b
              where a.jgh_id = b.jgh_id
                and ','||jxb_ids||',' like '%,'||a.jxb_id||',%'
        );
       if sJsxx is null then
         sJsxx := '无';
       end if;
     exception
        When others then
          sJsxx := '无';
    end;
    return sJsxx;
end Get_JsxxUnion;
/

