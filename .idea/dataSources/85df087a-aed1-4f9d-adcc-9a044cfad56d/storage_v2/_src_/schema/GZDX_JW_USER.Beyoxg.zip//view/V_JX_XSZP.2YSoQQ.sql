create view V_JX_XSZP as
  select t2.xh,t1.rxhzp zp from jw_xjgl_xszpb t1,jw_xjgl_xsjbxxb t2 where t1.xh_id = t2.xh_id
/

