create function get_JxbPkXq(vJxb_id varchar2)---教学班排课校区
Return varchar2
as
sPkXq varchar2(32);
sCount number;
begin
   select count(*) into sCount from jw_pk_kbcdb t1 where t1.kb_id in(select kb_id from jw_pk_kbsjb where jxb_id = vJxb_id);
   if sCount> 0 then
      select min(cd.xqh_id) into sPkXq from jw_jcdm_cdjbxxb cd, jw_pk_kbcdb t1 where t1.kb_id in(
          select kb_id from jw_pk_kbsjb where jxb_id = vJxb_id
      ) and cd.cd_id = t1.cd_id;
      if sPkXq is null then
          select jxb.xqh_id into sPkXq from jw_jxrw_jxbxxb jxb where jxb.jxb_id = vJxb_id;
      end if;
   else
      select jxb.xqh_id into sPkXq from jw_jxrw_jxbxxb jxb where jxb.jxb_id = vJxb_id;
   end if;
   return sPkXq;
end;

/

