create PROCEDURE PROC_SC_BYYSH(
   V_BYND in VARCHAR2,
   V_NJDM_ID in VARCHAR2,
   V_ZYH_ID in VARCHAR2,
   V_TJSY in VARCHAR2,
   V_XH_ID in VARCHAR2
)
IS
--定义审核结果数组
type  arr_tj_type is varray(20) of varchar2(2);
tj_table arr_tj_type;
--定义原因数组
type  arr_result_type is varray(20) of varchar2(4000);
result_table arr_result_type;

--定义条件id
type  arr_tjid_type is varray(20) of varchar2(50);
tjid_table arr_tjid_type;
--游标类型
--TYPE xsjbxx_cursor_type IS REF CURSOR;
TYPE byshtj_cursor_type IS REF CURSOR;
--游标变量
--xsjbxx_cursor xsjbxx_cursor_type;
byshtj_cursor byshtj_cursor_type;
--审核条件
TYPE byshtj_record_type IS RECORD(
tjzd      int,
tjmc      jw_bygl_shtjb.tjmc%TYPE,
tj_id     jw_bygl_shtjb.tj_id%TYPE,
tjsy      jw_bygl_shtjsjsyb.tjsy%TYPE,
tjxz      jw_bygl_shtjsjsyb.tjxz%TYPE,
tjsjz     jw_bygl_shtjsjb.tjsjz%TYPE,
tjsjcs    jw_bygl_shtjsjb.tjsjcs%TYPE,
tjsj_id   jw_bygl_shtjsjsyb.tjsjsy_id%TYPE,
tjsjly    jw_bygl_shtjsjb.tjsjly%TYPE,
tjsjgx    jw_bygl_shtjsjb.tjsjgx%TYPE,
tjsjmc    jw_bygl_shtjsjb.tjsjmc%TYPE,
tjsjlymc  jw_bygl_shtjsjb.tjsjlymc%TYPE,
jxzxjhxx_id jw_bygl_shtjsjsyzyb.jxzxjhxx_id%TYPE,
tjpx      jw_bygl_shtjsjb.tjpx%TYPE,
tjsjz1    jw_bygl_shtjsjb.tjsjz1%TYPE,
tjsjgx1   jw_bygl_shtjsjb.tjsjgx1%TYPE,
tjkcxz   jw_bygl_shtjsjsyzyb.tjkcxz%TYPE,
btjkc   jw_bygl_shtjsjsyzyb.btjkc%TYPE,
xdlx   jw_bygl_shtjsjsyzyb.xdlx%TYPE
);
--RECORD变量
byshtj_record byshtj_record_type;
--动态SQL语句
v_sql VARCHAR2(2000);
--xs_sql VARCHAR2(2000);
v_result  varchar2(3000);
V_FLAG VARCHAR2(1);
V_NUMBER NUMBER;

BEGIN

 tj_table:=arr_tj_type('0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0');
 result_table:=arr_result_type('','','','','','','','','','','','','','','','','','','','');
 tjid_table:=arr_tjid_type('','','','','','','','','','','','','','','','','','','','');
 /*查询出审核条件*/
 v_sql:='select a.tjzd, a.tjmc,b.* from (select rownum tjzd,t.* from (select  b.tj_id,b.tjmc from jw_bygl_shtjb b where b.tjlx =''1''  and  exists (select 1 from jw_bygl_shtjsjb a, jw_bygl_shtjsjsyb c  where b.tj_id = a.tj_id  and a.tjsj_id = c.tjsj_id  and c.tjsy =  '''||V_TJSY||''') order by to_number(b.tjpx),b.tj_id )t) a, ';
 v_sql:=v_sql||' (select t.tj_id,t1.tjsy,t1.tjxz,t1.tjsjz,t2.tjsjcs,t2.tjsj_id, t2.tjsjly,t2.tjsjgx,t2.tjsjmc,t2.tjsjlymc,t1.jxzxjhxx_id,t2.tjpx,t1.tjsjz1,t2.tjsjgx1,t1.tjkcxz,t1.btjkc,t1.xdlx ';
 v_sql:=v_sql||' from jw_bygl_shtjb  t,jw_bygl_shtjsjsyzyb t1, jw_bygl_shtjsjb t2,  jw_bygl_shtjsjsyb t3';
 v_sql:=v_sql||' where t1.tjsjsy_id = t3.tjsjsy_id  and t3.tjsj_id = t2.tjsj_id  and t2.tj_id = t.tj_id and t.tjlx=''1'' ';
 v_sql:=v_sql||' and t1.tjsy = '''||V_TJSY||'''';
 v_sql:=v_sql||' and exists (select 1 from jw_jh_jxzxjhxxb jh where jh.jxzxjhxx_id = t1.jxzxjhxx_id';
 v_sql:=v_sql||' and jh.njdm_id = '''||V_NJDM_ID||''' and jh.zyh_id = '''||V_ZYH_ID||''')';
 --v_sql:=v_sql||' and instr('''||V_TJ_ID||''', t.tj_id  )> 0
 v_sql:=v_sql||' )b';
 v_sql:=v_sql||' where a.tj_id = b.tj_id(+) order by tjzd';

 V_FLAG :='2';

 /*审核条件*/
 OPEN byshtj_cursor FOR v_sql;
 LOOP
	FETCH byshtj_cursor INTO byshtj_record;
	EXIT WHEN byshtj_cursor%NOTFOUND;
	if byshtj_record.jxzxjhxx_id is not null then
	   tjid_table(byshtj_record.tjzd):=byshtj_record.tj_id;

		/* 0,课程性质学分*/
	   if byshtj_record.tj_id like '%kcxz%' or byshtj_record.tj_id like '%kclb%' or byshtj_record.tj_id like '%kcgs%'
			  or byshtj_record.tj_id like '%kjxm%' or byshtj_record.tj_id like '%pycc%' then
			v_result := fun_byysh_kcxzxfsh(V_XH_ID,byshtj_record.tj_id,byshtj_record.tjmc,byshtj_record.tjsjz,
		 byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,byshtj_record.btjkc,byshtj_record.tjsjcs,byshtj_record.tjkcxz);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			   tj_table(byshtj_record.tjzd):= '2';
			else
			   tj_table(byshtj_record.tjzd):= '1';
			end if;
	   /*1,平均学分绩点*/
	   elsif byshtj_record.tj_id='20000001' then
		 v_result := fun_byysh_pjxfjd(V_XH_ID,byshtj_record.tjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,
				byshtj_record.tjsjly,byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx,byshtj_record.tjsjmc,
				byshtj_record.tjkcxz,byshtj_record.btjkc,byshtj_record.xdlx);
		  result_table(byshtj_record.tjzd):= v_result;
		  if instr(v_result, '不合格') > 0 then
			tj_table(byshtj_record.tjzd):= '2';
		  else
			tj_table(byshtj_record.tjzd):= '1';
		  end if;

		/*2学分要求主节点1-N*/
		elsif byshtj_record.tj_id='20000002' then
			 v_result := fun_byysh_xfyqzjd(V_XH_ID);
			 result_table(byshtj_record.tjzd):= v_result;
			 if instr(v_result, '不合格') > 0 then
				tj_table(byshtj_record.tjzd):= '2';
			 else
				 tj_table(byshtj_record.tjzd):= '1';
			 end if;
		/*3重修总学分/总学分*/
		elsif byshtj_record.tj_id='20000003' then
			 v_result := fun_by_cxxfzxfsh(V_XH_ID,byshtj_record.tjsjz);
			 result_table(byshtj_record.tjzd):= v_result;
			 if instr(v_result, '不合格') > 0 then
				tj_table(byshtj_record.tjzd):= '2';
			 else
				 tj_table(byshtj_record.tjzd):= '1';
			 end if;
		/*4,成绩库成绩全部合格*/
		elsif byshtj_record.tj_id='20000004' then
			v_result := fun_by_kcxzcjsh(V_XH_ID,byshtj_record.tjsjz,byshtj_record.tjkcxz,byshtj_record.btjkc);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			   tj_table(byshtj_record.tjzd):= '2';
			else
			   tj_table(byshtj_record.tjzd):= '1';
			end if;
		/*5,处分*/
		elsif byshtj_record.tj_id='20000005' then
			v_result := fun_by_cf(V_XH_ID);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			  tj_table(byshtj_record.tjzd):= '2';
			else
			  tj_table(byshtj_record.tjzd):= '1';
			end if;
		/*6,(毕业要求学分—实践平台学分)<=(学生修读获得学分（不包含实践平台学分）+除实践平台课程外的在修学分）*/
		elsif byshtj_record.tj_id='20000006' then
			v_result := fun_byysh_hdxfsh(V_XH_ID);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			  tj_table(byshtj_record.tjzd):= '2';
			else
			  tj_table(byshtj_record.tjzd):= '1';
			end if;
		/*7,学生获得学分/本专业要求最低毕业学分*/
		elsif byshtj_record.tj_id='20000007' then
			v_result := fun_byysh_hdxfbl(V_XH_ID,byshtj_record.tjsjz);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			  tj_table(byshtj_record.tjzd):= '2';
			else
			  tj_table(byshtj_record.tjzd):= '1';
			end if;
		 /*8,CET*/
		elsif byshtj_record.tj_id='20000008' then
			v_result := fun_by_cet(V_XH_ID,byshtj_record.tjsjmc,byshtj_record.tjsjcs,byshtj_record.tjsjz,byshtj_record.tjsjly,
				byshtj_record.tjsjlymc,byshtj_record.tjsjgx,byshtj_record.tjpx);
			result_table(byshtj_record.tjzd):= v_result;
			if instr(v_result, '不合格') > 0 then
			  tj_table(byshtj_record.tjzd):= '2';
			else
			  tj_table(byshtj_record.tjzd):= '1';
			end if;
	   end if;

	  end if;

  END LOOP;
CLOSE byshtj_cursor;

/*判断 当全部条件符合时候，机审结果将为通过*/
if ( tj_table(1)!='2' and tj_table(2)!='2' and tj_table(3)!='2' and tj_table(4)!='2' and tj_table(5)!='2' and tj_table(6)!='2' and tj_table(7)!='2' and tj_table(8)!='2' and tj_table(9)!='2' and tj_table(10)!='2') then
		   V_FLAG:='1';
end if;
if  V_TJSY='1' then
   select count(1) into V_NUMBER  from JW_BYGL_BYYSHB where xh_id = V_XH_ID;
   if V_NUMBER = 0 then
	 insert into JW_BYGL_BYYSHB(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
	 result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
	 result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
	 TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,
	 JSBYF,XYZS,XYZS_GHID,XYZSSJ,XXYSH,XXYSH_GHID,XXYSHSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
	 values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
	 tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
	 result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
	 result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
	 result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
	 tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
	 tjid_table(19),tjid_table(20),
	 V_FLAG,'','','','','','','','','','','');
   else
	  update JW_BYGL_BYYSHB set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
	  TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
	  TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
	  result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
	  result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
	  result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
	  result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
	  TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
	  TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
	  TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
	  TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
	  JSBYF = V_FLAG
	  where xh_id = V_XH_ID;
   end if;
elsif V_TJSY='2' then
   select count(1) into V_NUMBER  from jw_bygl_xwyshb where xh_id = V_XH_ID;
   if V_NUMBER = 0 then
	 insert into jw_bygl_xwyshb(XH_ID,BYND,TJ01,TJ02,TJ03,TJ04,TJ05,TJ06,TJ07,TJ08,TJ09,TJ10,TJ11,TJ12,TJ13,TJ14,TJ15,TJ16,TJ17,TJ18,TJ19,TJ20,
	 result01,result02,result03,result04,result05,result06,result07,result08,result09,result10,result11,result12,result13,result14,result15,
	 result16,result17,result18,result19,result20,TJ01_ID,TJ02_ID,TJ03_ID,TJ04_ID,TJ05_ID,TJ06_ID,TJ07_ID,TJ08_ID,TJ09_ID,TJ10_ID,
	 TJ11_ID,TJ12_ID,TJ13_ID,TJ14_ID,TJ15_ID,TJ16_ID,TJ17_ID,TJ18_ID,TJ19_ID,TJ20_ID,JSsyF,XYZS,XYZS_GHID,XYZSSJ,XXSH,XXSH_GHID,XXSHSJ,XW,BSYXWYY)
	 values(V_XH_ID,V_BYND,tj_table(1),tj_table(2),tj_table(3),tj_table(4),tj_table(5),tj_table(6),tj_table(7),tj_table(8),tj_table(9),tj_table(10),
	 tj_table(11),tj_table(12),tj_table(13),tj_table(14),tj_table(15),tj_table(16),tj_table(17),tj_table(18),tj_table(19),tj_table(20),
	 result_table(1),result_table(2),result_table(3),result_table(4),result_table(5),result_table(6),result_table(7),result_table(8),result_table(9),
	 result_table(10),result_table(11),result_table(12),result_table(13),result_table(14),result_table(15),result_table(16),result_table(17),result_table(18),
	 result_table(19),result_table(20),tjid_table(1),tjid_table(2),tjid_table(3),tjid_table(4),tjid_table(5),tjid_table(6),tjid_table(7),tjid_table(8),
	 tjid_table(9),tjid_table(10),tjid_table(11),tjid_table(12),tjid_table(13),tjid_table(14),tjid_table(15),tjid_table(16),tjid_table(17),tjid_table(18),
	 tjid_table(19),tjid_table(20),V_FLAG,'','','','','','','','');
   else
	 update jw_bygl_xwyshb set TJ01=tj_table(1),TJ02=tj_table(2),TJ03=tj_table(3),TJ04=tj_table(4),TJ05=tj_table(5),TJ06=tj_table(6),
	  TJ07=tj_table(7),TJ08=tj_table(8),TJ09=tj_table(9),TJ10=tj_table(10),TJ11=tj_table(11),TJ12=tj_table(12),TJ13=tj_table(13),
	  TJ14=tj_table(14),TJ15=tj_table(15),TJ16=tj_table(16),TJ17=tj_table(17),TJ18=tj_table(18),TJ19=tj_table(19),TJ20=tj_table(20),
	  result01=result_table(1),result02=result_table(2),result03=result_table(3),result04=result_table(4),result05=result_table(5),
	  result06=result_table(6),result07=result_table(7),result08=result_table(8),result09=result_table(9),result10=result_table(10),
	  result11=result_table(11),result12=result_table(12),result13=result_table(13),result14=result_table(14),result15=result_table(15),
	  result16=result_table(16),result17=result_table(17),result18=result_table(18),result19=result_table(19),result20=result_table(20),
	  TJ01_ID=tjid_table(1),TJ02_ID=tjid_table(2),TJ03_ID=tjid_table(3),TJ04_ID=tjid_table(4),TJ05_ID=tjid_table(5),
	  TJ06_ID=tjid_table(6),TJ07_ID=tjid_table(7),TJ08_ID=tjid_table(8),TJ09_ID=tjid_table(9),TJ10_ID=tjid_table(10),
	  TJ11_ID=tjid_table(11),TJ12_ID=tjid_table(12),TJ13_ID=tjid_table(13),TJ14_ID=tjid_table(14),TJ15_ID=tjid_table(15),
	  TJ16_ID=tjid_table(16),TJ17_ID=tjid_table(17),TJ18_ID=tjid_table(18),TJ19_ID=tjid_table(19),TJ20_ID=tjid_table(20),
	  JSsyF = V_FLAG
	  where xh_id = V_XH_ID;
   end if;
end if;
END;

/

