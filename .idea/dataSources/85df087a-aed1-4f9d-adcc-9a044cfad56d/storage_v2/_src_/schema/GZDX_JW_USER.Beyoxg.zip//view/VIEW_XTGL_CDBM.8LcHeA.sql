create view VIEW_XTGL_CDBM as
  select t.jg_id as cdbm_id,
       t.lssjjgid,
       t.jgdm as cdbmdm,
       t.jgmc as cdbmmc,
       t.jgywmc as cdbmywmc,
       t.jgjc   as cdbmjc,
       t.jgjp   as cdbmjp,
       t.jgdz   as cdbmjz,
       t.lsxqid,
       t.sfjxbm,
       t.sfst,
       t.kkxy
  from zftal_xtgl_jgdmb t
 where t.jgyxbs = '1'
/

