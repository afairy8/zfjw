create function likai_kcgs_zxf(v_xh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_kcgsdm in varchar2) return float is
kcxz_zxf float;
begin
   /**计算一个学年学生的相应课程归属的总学分**/
select case when sum(t.xf) is null then 0.0 else sum(t.xf) end  zxf
  into kcxz_zxf
  from (select distinct jxb.jxb_id, jxb.xf, hbb.kcgsdm
          from jw_jxrw_jxbxxb jxb, jw_jxrw_jxbhbxxb hbb
         where jxb.jxb_id = hbb.jxb_id
           and (jxb.fjxb_id is null or jxb.fjxb_id = '1')) t,
       jw_xk_xsxkb xkb
 where xkb.xh_id =v_xh_id and xkb.xnm = v_xnm and xkb.xqm = v_xqm and t.kcgsdm = v_kcgsdm and
  xkb.jxb_id = t.jxb_id;

  return (kcxz_zxf);
end likai_kcgs_zxf;
/

