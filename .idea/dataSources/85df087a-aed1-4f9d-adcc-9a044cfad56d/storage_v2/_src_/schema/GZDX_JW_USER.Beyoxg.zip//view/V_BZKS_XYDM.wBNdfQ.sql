create view V_BZKS_XYDM as
  select jgdm xydm,jgmc xymc,jgywmc xyywmc from zftal_xtgl_jgdmb
/

