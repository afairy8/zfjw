create function fun_by_zxjhkcxzsh(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_jxzxjhxx_id varchar2(32);--执行计划id
  v_num number;
  v_flag number;
begin
    sJg := '合格';
    begin
      select count(1)  into v_num from zftal_xtgl_xxxxszb where xxdm='10656';
    select t.jxzxjhxx_id into v_jxzxjhxx_id from jw_jh_jxzxjhxxb t where exists(
           select 1 from jw_xjgl_xsjbxxb xs where xs.zyh_id = t.zyh_id and xs.njdm_id = t.njdm_id
           and xs.xh_id = v_xh_id
    );
    if v_num<1 then
      select nvl(wm_concat(kcxzmc||'不合格(应获'||zxf||'分，实获'||nvl(hdxf,0)||'分)'),'合格') into sJg from (
      select decode(sign(nvl(e2.hdxf,0) - e1.zxf), '-1', 'N', '0', 'Y', '1', 'Y') zgshzt,
             e1.kcxzdm,e1.zxf,e2.hdxf,nvl((select kcxzmc from jw_jh_kcxzdmb kcxz where kcxz.kcxzdm = e1.kcxzdm),'XX')kcxzmc
        from (
             select t.yqzdxf zxf,t.kcxzdm from jw_jh_jxzxjhxfyqxxb t where t.jxzxjhxx_id=v_jxzxjhxx_id and t.sfmjd='1'
        ) e1,
             (select a.xh_id, a.kcxzdm, sum(xf) hdxf
                from (select nvl(a.sskch_id,a.kch_id), a.xh_id, max(a.bfzcj) bfzcj, a.kcxzdm, a.xf
                        from jw_cj_xscjb a
                       where xh_id = v_xh_id
                       group by  a.xh_id,nvl(a.sskch_id,a.kch_id), a.kcxzdm, a.xf

                       ) a
               where bfzcj >= 60
               group by a.xh_id, a.kcxzdm) e2
               where e1.kcxzdm = e2.kcxzdm(+)
               order by kcxzdm
      )
      where zgshzt='N';
    else
       select  nvl(instr(a.zt,'N'),'1') into v_flag from  (select wm_concat(zgshzt)zt  from JW_JH_xsJXZXJHXFYQXXB where xh_id=v_xh_id and yxjd='1' and fxfyqjd_id is not null)a;
           if v_flag>0 then
              select wm_concat(t.xfyqjdmc || '要求' || t.yqzdxf || ',实际获得' ||
                 nvl(t.hdxf, '0')) into sJg
                  from JW_JH_xsJXZXJHXFYQXXB t
                 where t.xh_id = v_xh_id
                   and t.xdlx = 'zx'
                   and t.zgshzt = 'N'
                   and t.yxjd='1'
                   and t.fxfyqjd_id is not null;
              sJg := sJg||',不合格!';
           else
              sJg:= '合格！';
           end if;

      end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_zxjhkcxzsh;

/

