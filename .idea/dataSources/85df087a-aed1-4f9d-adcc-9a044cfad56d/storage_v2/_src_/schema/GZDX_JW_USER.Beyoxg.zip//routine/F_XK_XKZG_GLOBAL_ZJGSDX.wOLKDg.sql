create function f_xk_xkzg_global_zjgsdx(
    in_zh_en in varchar2,
    in_xkxnm in varchar2,
    in_xkxqm in varchar2,
    in_xh_id in varchar2,
    in_bj in varchar2  --返回类型：1：返回描述信息，其他：返回数字标记
) return varchar2 as
    v_count number;
begin
    select count(1) into v_count from jw_xk_xskxszb where xnm=in_xkxnm and xqm=in_xkxqm;
    if v_count>0 then
        select count(1) into v_count from jw_xk_xskxszb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;
        if v_count=0 then
            if in_bj='1' then
                if in_zh_en='en_US' then
                    return 'Sorry, you can’t choose the course. If you need, please contact the administrator!';
                else
                    return '对不起，您不可选课，如有需要，请与管理员联系！';
                end if;
            else
                return '2'; --不是指定的可选课的学生
            end if;
        end if;
    end if;
    return '1';
end;

/

