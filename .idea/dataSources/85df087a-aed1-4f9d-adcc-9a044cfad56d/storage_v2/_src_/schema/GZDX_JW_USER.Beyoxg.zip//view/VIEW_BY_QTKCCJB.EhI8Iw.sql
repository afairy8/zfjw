create view VIEW_BY_QTKCCJB as
  select b.lbdm, c."KCLX",c."XNM",c."XQM",c."XH_ID",c."KCH_ID",c."KCH",c."KCMC",c."XF",c."CJ",c."BFZCJ",c."BZ",c."CZRJGH_ID",c."CZSJ",c."XSQTCJ_ID"
  from jw_cj_xsqtcjlxdmb a, jw_cj_xsqtcjlbdmb b, jw_cj_xsqtcjb c
 where a.lb = b.lbdm
   and a.lxdm = c.kclx
/

