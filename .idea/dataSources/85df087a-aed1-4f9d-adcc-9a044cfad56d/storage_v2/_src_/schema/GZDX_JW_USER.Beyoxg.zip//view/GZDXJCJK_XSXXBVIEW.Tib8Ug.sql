create view GZDXJCJK_XSXXBVIEW as
  select xh,
     xm,
     xb,
     csrq,
     mz,
     xy,
     xy_xsxy,
     xi,
     zydm,
     zymc,
     zyfx,
     xzb,
     xz,
     dqszj,
     cc,
     sfzx,
     sfzc,
     xjzt,
     byf,
     kx
from (
select xh,
     xm,
     xb,
     csrq,
     mz,
     xy,
     xy_xsxy,
     xi,
     zydm,
     zymc,
     t2.zyfxmc zyfx,
     xzb,
     xz,
     dqszj,
     cc,
     sfzx,
     sfzc,
     xjzt,
     byf,
     kx
  from ((select a.xh,
                a.xm,
                case
                  when xbm = '1' then
                   '男'
                  else
                   '女'
                end xb,
                '' mz,
                '' csrq,
                d.jgmc xy,
                d.jgmc xy_xsxy,
                c.zyh_id zydm,
                c.zymc zymc,
                b.bj xzb,
                '' xi,
                e.njmc dqszj,
                '本科' cc,
                '有' xjzt,
                '' sfzc,
                case
                  when a.sfzx = '1' then
                   '是'
                  else
                   '否'
                end sfzx,
                '' kx,
                a.xz,
                a.zyfx_id,
                '' byf
           from jw_xjgl_xsjbxxb  a,
                zftal_xtgl_bjdmb b,
                zftal_xtgl_zydmb c,
                zftal_xtgl_jgdmb d,
                zftal_xtgl_njdmb e
          where a.jg_id = d.jg_id
            and a.zyh_id = c.zyh_id
            and a.bh_id = b.bh_id
            and a.xjztdm in
                (select xjztdm from jw_xjgl_xjztdmb where sfyxj = '1')
            and e.njdm_id = a.njdm_id) t1 left join zftal_xtgl_zyfxdmb t2 on
        t1.zyfx_id = t2.zyfx_id))
/

