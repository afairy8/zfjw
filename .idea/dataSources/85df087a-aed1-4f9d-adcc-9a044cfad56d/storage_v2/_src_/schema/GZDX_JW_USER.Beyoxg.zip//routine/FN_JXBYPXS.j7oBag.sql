create function fn_jxbypxs(fn_jxbid varchar2) return number  ---教学班已排学时
as
   v_ypxs number;
begin
   select count(1) into v_ypxs
   from
   (select b.rn zc,a.xqj,c.rn jc from
     (select zcd ,xqj,jc from jw_pk_kbsjb where jxb_id = fn_jxbid) a ,
     (select power(2,rownum-1) rn from zftal_xtgl_jcsjlxb where rownum<=40) b,
     (select power(2,rownum-1) rn from zftal_xtgl_jcsjlxb where rownum<=40) c
     where bitand(a.zcd,b.rn) > 0 and bitand(a.jc,c.rn)>0
     group by b.rn,a.xqj,c.rn
   );
   return v_ypxs;
end fn_jxbypxs;

/

