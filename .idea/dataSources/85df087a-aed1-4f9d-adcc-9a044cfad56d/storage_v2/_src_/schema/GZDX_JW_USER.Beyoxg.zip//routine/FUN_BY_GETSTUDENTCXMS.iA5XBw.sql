create function fun_by_getStudentCxms(v_xh_id varchar2,v_lx varchar2,v_tjkcxz varchar2,v_btjkc varchar2,v_xdlx varchar2)
Return varchar2 ------------------获取学生重修门数
as
StudentCxms varchar2(100);
sqlstr varchar2(8000);
v_xdlx_temp varchar2(5000);
begin
     begin

      sqlstr :='select count(distinct kch_id) from jw_cj_xscjb cjb where cjb.xh_id = '''||v_xh_id||''' and cjb.cjxzm = ''16''';

      --学位课
      if v_lx='2' then
            sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = cjb.kch_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
      end if;

      --课程性质
      if v_tjkcxz is not null and v_tjkcxz!='qb' then
         sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||cjb.kcxzdm||'','' )>0 ';
      end if;

      --修读类型
      if v_xdlx is not null and v_xdlx!='qb' then
        v_xdlx_temp :='AND EXISTS (select 1 from (SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxb xfyq,JW_JH_xsJXZXJHKCXXB kcxx'||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id union all '||
                      ' SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxfxezyb xfyq,Jw_Jh_Xsjxzxjhkcxxfxezyb kcxx '||
                      ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id) a '||
                      ' WHERE a.XH_ID=cjb.XH_ID  AND a.KCH_ID=nvl(cjb.sskch_id,cjb.KCH_ID) AND ('||

                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                      ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 ))';
            sqlstr:= sqlstr||''||v_xdlx_temp;
       end if;

       --不统计课程
       if v_btjkc is not null then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||cjb.kch_id||'','' )<1 ';
       end if;

    execute immediate sqlstr into StudentCxms;

    exception
          When others then
            StudentCxms := '查询出错，不合格！';
    end;

  return StudentCxms;
end;

/

