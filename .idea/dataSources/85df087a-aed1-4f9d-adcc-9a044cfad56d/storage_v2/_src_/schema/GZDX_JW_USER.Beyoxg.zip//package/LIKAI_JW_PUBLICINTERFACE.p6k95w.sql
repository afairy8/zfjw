create package likai_jw_publicInterface is
  --update_successSign varchar2(2):='0';
  procedure update_zsjhrsAndbjzxrs(v_njdm_id varchar2);
  --update the students jd
  procedure update_xsCjJd(v_grade varchar2);
  --返回按考试人数的派监考学院
  function return_cdjkxyAnKsrs(v_cd_id in varchar2, v_xnm in varchar2, v_xqm in varchar2,v_kshkbj_id in varchar2) return varchar2;
  --返回按选课人数的派监考学院
  --function return_cdjkxyAnxkrs(v_cd_id in varchar2, v_xnm in varchar2, v_xqm in varchar2,v_kshkbj_id in varchar2) return varchar2;
  --返回常规的学年学期名称
  function return_xnOrXqmc(v_xnorxqm varchar2) return varchar2;
  --返回场地预约的时间集合
  function return_cdyyxq(v_yub_id varchar2,v_sign varchar2) return varchar2;
  --检测课程代码是否已经被落实，返回0则表示没有被落实，否则返回一个随机正整数
  function jwKcdmIsUsed(v_kch varchar2) return int;
  --计算学时分项周学时、非集中性实践教学环节的，集中性实践教学环节zhxs为1
  function jwKcXsfxZhxs(v_xs varchar2) return varchar2;
  --根据同步的教师信息更新教师出生日期，职称，并插入新用户
  procedure updateAndinsertJzg(sign varchar2);
  --备份学业预警
  procedure insertBackUpXyyj(sign varchar2);
  --更新成绩比例（13级默认3:7,18级之后默认4:6）
  procedure updateJxbCjBl(sign varchar2);
  --计算考试安排人数
  function getKsaprs(v_xnm varchar2,v_xqm varchar2,v_sjbh_id varchar2,v_cd_id varchar2) return int;
  --学院评价平均分
  function getPjXyPjf(v_xnm varchar2,v_xqm varchar2,v_jg_id varchar2)  return varchar2;
  --根据模板名称返回理论，实验，实践听课类型
  function getTklxByMbmc(v_mbid varchar2) return varchar2;
  --根据学年学期院级督导，领导返回听课的总次数
  function getXnXqTklxZcs(v_xnm varchar2,v_xqm varchar2,v_jgh_id varchar2) return int;
  --更新小班研讨课的面向对象
  procedure updateXbJxbMxdx(sign varchar2);
  --删除毕业年份中不在毕业生辅助信息表中的毕业审核、学位审核记录
  procedure deleteXwandBySh(sign varchar2); 
  --屏蔽当前学年学期不在校或无学籍的学生可评价记录
  procedure updateSfkp(sign varchar2);
  ---补充课程替代学生基本信息，进入备注
  function kctdsqxsxxbz(v_xh_id varchar2) return varchar2;
  ---计算学业完成情况
  procedure likai_xywcqk(t_xh_id varchar2);
end;
/

