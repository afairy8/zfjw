create function fun_by2015_kcxzsh(v_xh_id varchar2,v_zyh_id varchar2,v_njdm_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
  v_pyfaxx_id varchar2(32);--培养方案
  v_jxzxjhxx_id varchar(32);---教学执行计划
  v_sfsfs varchar2(2);--是否师范生 1是 0 否
  v_tjgx varchar2(2000);--条件关系
  v_zxf varchar2(100);---总学分
  v_hdxf varchar2(100);----获得学分
  v_tjid  varchar2(100);----条件id
  v_kcxzjc  varchar2(1000);----课程性质名称
  v_tjgs varchar2(200);----每个条件里面的公式
  v_exec_sql varchar2(1000);--要执行的语句
  v_exec_sql_result varchar2(2000); --执行语句的结果
  v_fxjg    varchar2(1000);-- 分项 课程性质结果
  v_num     varchar2(32);
  v_gzNum   varchar2(32);
  TJ1       number(2);
  TJ2       number(2);
  TJ3       number(2);
  TJ4       number(2);
  TJ5       number(2);
  TJ6       number(2);
  TJ7       number(2);
  TJ8       number(2);
  TJ9       number(2);
  TJ10      number(2);
  TJ11      number(2);
  TJ12      number(2);
  TJ13      number(2);
  TJ14      number(2);
  TJ15      number(2);

  v_finalJgSql varchar2(2000); --最终结果SQL
  v_finalJg    varchar2(2000); --最终结果
  v_gs         varchar2(100);  --公式

  TYPE v_gz_REC IS RECORD(
    tjid    varchar2(100),
    tjzh    varchar2(100),
    xsbj    varchar2(100),
    kcxzmc  varchar2(100),
    tjgs    varchar2(200)
    );

  type my_cursor is ref cursor; --定义一个Ref游标变量
  v_gz_cursor my_cursor; --规则游标
  v_gz        v_gz_REC;

begin

   TJ1:=1;
   TJ2:=1;
   TJ3:=1;
   TJ4:=1;
   TJ5:=1;
   TJ6:=1;
   TJ7:=1;
   TJ8:=1;
   TJ9:=1;
   TJ10:=1;
   TJ11:=1;
   TJ12:=1;
   TJ13:=1;
   TJ14:=1;
   TJ15:=1;

    select t.pyfaxx_id into v_pyfaxx_id from jw_jh_pyfaxxb t where t.zyh_id=v_zyh_id
    and exists(select 1 from jw_jh_pyfasynjb nj where nj.pyfaxx_id = t.pyfaxx_id and nj.njdm_id=v_njdm_id);

    select xxb.jxzxjhxx_id into v_jxzxjhxx_id from jw_jh_jxzxjhxxb xxb where xxb.zyh_id = v_zyh_id and xxb.njdm_id = v_njdm_id;

    --select (case when instr('401,411,412,416,418,420,425,428,430,432,434,438,441,443,445,496',
    --(select zyh_id from jw_xjgl_xsjbxxb xs  where  xs.xh_id=v_xh_id))>0 then 1 else 0 end ) into v_sfsfs  from dual;

    ---培养方案课程性质审核，只统计学分分布中的课程性质学分

      open v_gz_cursor for
        select  tjid,tjzh,xsbj,max(kcxzmc),tjgs from(
 select tjid,tjzh,xsbj,wm_concat(kcxzmc) over(partition by tjzh order by num) kcxzmc,tjgs from
  (select rownum num ,a.* from (select distinct xb.tjid,xb.tjzh,xb.xsbj,case when xb.sfjc = '1' then
                                                   kcxzjc
                                                  when xb.sfjc = '0' then
                                                   kcxzmc
                                                end as kcxzmc,nvl(tjgs,'(1=1)')tjgs
        from jw_bygl_zykcxzshmxb xb,jw_jh_kcxzdmb kcxz where kcxz.sfty = '0' and ','||xb.tjzh||',' like '%,'||kcxz.kcxzdm||',%'
        and xb.jxzxjhxx_id = v_jxzxjhxx_id and xb.sfqy = '1'
        and exists (select 1
                    from jw_xjgl_xsjbxxb jbxx, jw_jh_jxzxjhxxb jh
                   where jbxx.xh_id = v_xh_id
                   and jh.jxzxjhxx_id = xb.jxzxjhxx_id
                   and jh.njdm_id = jbxx.njdm_id
                   and jh.zyh_id = jbxx.zyh_id
                     and bitand(jbxx.xsbj,
                                (case
                                  when 'all' = xb.xsbj then
                                   jbxx.xsbj
                                  else
                                   xb.xsbj
                                end)) > 0)
                                order by tjid
        )a
        order by  rownum,tjzh
        )
        )
 group by tjid,tjzh,xsbj,tjgs
 order by tjid;

     loop
     fetch v_gz_cursor  into v_gz;
     --判断当前游标是否到达最后
      exit when v_gz_cursor%notfound;

      v_zxf :='';
      v_hdxf :='';
      v_tjid :='';
      v_tjgx :='';
      v_kcxzjc :='';
      v_tjgs := v_gz.tjgs;


     select nvl(sum(temp.zxf),0),
            nvl(sum(temp.hdxf),0),
            max(temp.tjid),
            max(temp.tjgx),
            --wm_concat(temp.kcxzjc),
            v_gz.kcxzmc,
            count(1)
       into v_zxf,
            v_hdxf,
            v_tjid,
            v_tjgx,
            v_kcxzjc,
            v_num
      from (
       select zxf,hdxf,tjid,tjgx,wm_concat(kcxzjc) as kcxzjc from
           ( select sum(nvl(a.zxf,0)) as zxf ,sum(nvl(hdxf,0)) as hdxf ,mxb.tjid as tjid  ,mxb.tjgx as tjgx,
            case when mxb.sfjc = '1' then kcxzjc when mxb.sfjc = '0' then kcxzmc end kcxzjc
            from(
                 select e2.hdxf, e1.zxf,e1.kcxzdm ,decode(sign(nvl(e2.hdxf,0) - e1.zxf), '-1', 'N', '0', 'Y', '1', 'Y') zgshzt
                 from (
                       select b.kcxzdm ,(to_char(nvl(sum(zxf), 0), 'fm99990.09')) zxf
                       from(
                              select t.pyfaxx_id,t.kcxzdm,(to_char(nvl(sum(temp.xf), 0), 'fm99990.09')) zxf,temp.sftj
                              from jw_jh_pyfaxfyqxxb t,
                                 (select nvl(t2.pyfaxx_id, t1.pyfaxx_id) pyfaxx_id,
                                         nvl(t2.xfyqjd_id, t1.xfyqjd_id) xfyqjd_id,
                                         nvl(t2.xq, t1.xq) xq,
                                         nvl(t2.xf, t1.xf) xf,
                                         t2.sftj
                                    from (select t.pyfaxx_id,t.xfyqjd_id,t.xq,nvl(sum(xf), 0) xf
                                          from (select t1.pyfaxx_id,t1.xfyqjd_id,
                                                         to_number(nvl((select t3.xf from jw_jh_kcdmb t3 where t3.kch_id = t2.kch_id),'0')) xf,
                                                         t2.jyxdnjdm || '-' || t2.jyxdxqm xq
                                                from jw_jh_pyfaxfyqxxb t1, jw_jh_pyfakcxxb t2
                                                where t1.xfyqjd_id = t2.xfyqjd_id(+)
                                                  and t1.pyfaxx_id = v_pyfaxx_id) t
                                           group by t.pyfaxx_id, t.xfyqjd_id, t.xq) t1
                                        full join (select * from jw_jh_pyfaxffb where pyfaxx_id = v_pyfaxx_id) t2
                                        on (t1.pyfaxx_id =t2.pyfaxx_id and t1.xfyqjd_id = t2.xfyqjd_id and t1.xq = t2.xq)
                                   ) temp
                               where temp.xfyqjd_id = t.xfyqjd_id
                                 and t.pyfaxx_id = v_pyfaxx_id
                                 and t.xdlx = 'zx'
                                 and t.sfmjd = '1'
                                 and temp.sftj = '1'
                               group by t.pyfaxx_id, t.kcxzdm, temp.sftj, t.sfmjd)a,jw_jh_kcxzdmb b
                               where b.kcxzdm = a.kcxzdm(+)
                            group by b.kcxzdm) e1,
                         (select xh_id, kcxzdm, sum(xf) hdxf
                            from
                            (select kch_id,xh_id,bfzcj, t.kcxzdm,xf from
                            (select a.kch_id, a.xh_id, max(a.bfzcj) bfzcj, a.kcxzdm, a.xf
                                    from jw_cj_xscjb a
                                   where xh_id = v_xh_id
                                   and kcbj='0'
                                   and bfzcj >= 60
                                   and exists(select 1 from jw_xjgl_xsjbxxb jbxx where a.xh_id = jbxx.xh_id and bitand(jbxx.xsbj,(case when 'all'=v_gz.xsbj then jbxx.xsbj else v_gz.xsbj end))>0)
                                   and not exists(select 1 from jw_cj_xsgrdtzb t1,jw_cj_xsgrcjdtb tt where t1.zszt = '3' and t1.kcthzh_id = tt.kcthzh_id and tt.jxb_id = a.jxb_id and tt.xh_id=v_xh_id)---替代
                                   and not exists(select 1 from jw_cj_xsgrdtzb t1,jw_cj_xsgrjhdtb bb where t1.zszt = '3' and t1.kcthzh_id = bb.kcthzh_id and bb.kch_id = a.kch_id and bb.xh_id=v_xh_id)--被替代
                                   group by a.xh_id, a.kch_id, a.kcxzdm, a.xf

                           union all
                           /* select t2.kch_id,
                                   t2.xh_id,
                                   t3.bfzcj,
                                   t4.kcxzdm,
                                   to_char(nvl(t4.xf,t3.xf))xf
                              from jw_cj_xsgrdtzb t1, jw_cj_xsgrcjdtb t2 ,jw_cj_xscjb t3, jw_cj_xsgrjhdtb t4
                             where t1.zszt = '3'
                               and t1.kcthzh_id = t2.kcthzh_id
                               and t1.kcthzh_id = t4.kcthzh_id
                               and t3.xh_id = t2.xh_id
                               and t3.jxb_id = t2.jxb_id
                               and t2.xh_id = v_xh_id*/

                               select distinct t4.kch_id,
                                            t2.xh_id,
                                            t4.bfzcj,
                                            t4.kcxzdm,
                                            to_char(nvl(t4.xf, t3.xf)) xf
                              from jw_cj_xsgrdtzb  t1,
                                   jw_cj_xsgrcjdtb t2,
                                   jw_cj_xscjb     t3,
                                   jw_cj_xsgrjhdtb t4
                             where t1.zszt = '3'
                               and t1.kcthzh_id = t2.kcthzh_id
                               and t1.kcthzh_id = t4.kcthzh_id
                               and t3.xh_id = t2.xh_id
                               and t3.jxb_id = t2.jxb_id
                               and t2.xh_id = v_xh_id
                               and exists(select 1 from jw_xjgl_xsjbxxb jbxx where t2.xh_id = jbxx.xh_id and bitand(jbxx.xsbj,(case when 'all'=v_gz.xsbj then jbxx.xsbj else v_gz.xsbj end))>0)
                            )t
                            )
                           group by xh_id, kcxzdm) e2
             where e1.kcxzdm = e2.kcxzdm(+)

             ) a,jw_bygl_zykcxzshmxb mxb,jw_jh_kcxzdmb kcxz
             where kcxz.sfty = '0' and ','||mxb.tjzh||',' like '%,'||kcxz.kcxzdm||',%'
             and  instr(mxb.tjzh,a.kcxzdm)>0
             and a.kcxzdm = kcxz.kcxzdm
             and  mxb.jxzxjhxx_id = v_jxzxjhxx_id
               and mxb.tjid = v_gz.tjid
               group by mxb.tjid,mxb.tjzh,mxb.tjgx,mxb.sfjc,case when mxb.sfjc = '1' then kcxzjc when mxb.sfjc = '0' then kcxzmc end
               ) group by zxf,hdxf,tjid,tjgx ) temp;

        if v_num > '0' then

           v_exec_sql :='select (case when '||v_hdxf ||v_tjgx||v_zxf||' and '||v_tjgs||' then 1 else 0 end)  from ';
           v_exec_sql:=v_exec_sql||'(select '||TJ1||' as TJ1,'||TJ2||' as TJ2,'||TJ3||' as TJ3,'||TJ4||' as TJ4,'||TJ5||' as TJ5,';
           v_exec_sql:=v_exec_sql||TJ6||' as TJ6,'||TJ7||' as TJ7,'||TJ8||' as TJ8,'||TJ9||' as TJ9,'||TJ10||' as TJ10,'||TJ11||' as TJ11,';
           v_exec_sql:=v_exec_sql||TJ12||' as TJ12,'||TJ13||' as TJ13,'||TJ14||' as TJ14,'||TJ15||' as TJ15  from dual)';
           Execute Immediate v_exec_sql into v_exec_sql_result;

             if v_exec_sql_result = '0' then

                v_fxjg:='不合格';

                 if 'TJ1' = v_gz.tjid then
                    TJ1 := 0;
                 elsif 'TJ2' = v_gz.tjid then
                    TJ2 := 0;
                 elsif 'TJ3' = v_gz.tjid then
                    TJ3 := 0;
                 elsif 'TJ4' = v_gz.tjid then
                    TJ4 := 0;
                 elsif 'TJ5' = v_gz.tjid then
                    TJ5 := 0;
                 elsif 'TJ6' = v_gz.tjid then
                    TJ6 := 0;
                 elsif 'TJ7' = v_gz.tjid then
                    TJ7 := 0;
                 elsif 'TJ8' = v_gz.tjid then
                    TJ8 := 0;
                 elsif 'TJ9' = v_gz.tjid then
                    TJ9 := 0;
                 elsif 'TJ10' = v_gz.tjid then
                    TJ10 := 0;
                 elsif 'TJ11' = v_gz.tjid then
                    TJ11 := 0;
                 elsif 'TJ12' = v_gz.tjid then
                    TJ12 := 0;
                 elsif 'TJ13' = v_gz.tjid then
                    TJ13 := 0;
                 elsif 'TJ114' = v_gz.tjid then
                    TJ14 := 0;
                 elsif 'TJ15' = v_gz.tjid then
                    TJ15 := 0;

                 end if;
             else
               v_fxjg:='合格';
            end if;
         else
            v_zxf := '0';
            v_hdxf:= '0';
            v_fxjg :='不合格';
            v_kcxzjc:= v_gz.kcxzmc;
        end if;

          sJg:= sJg||v_kcxzjc||'(应获'||v_zxf||'分，实获'||v_hdxf||'分)'||v_fxjg||'@';

      end loop;
    --关闭规则游标
    close v_gz_cursor;

    select count(1) into v_gzNum  from jw_bygl_zykcxzshzb where jxzxjhxx_id =v_jxzxjhxx_id;

    if v_gzNum >0 then
       select gs into v_gs  from jw_bygl_zykcxzshzb where jxzxjhxx_id =v_jxzxjhxx_id;
    end if;

     if v_gs is null then
        sjg :='未设置规则，请前去【课程性质审核规则维护】页面进行初始!';
        return sJg ;
     else
       v_finalJgSql:='select (case when '||v_gs||' then 1 else 0 end) from  ';
       v_finalJgSql:=v_finalJgSql||'(select '||TJ1||' as TJ1,'||TJ2||' as TJ2,'||TJ3||' as TJ3,'||TJ4||' as TJ4,'||TJ5||' as TJ5,';
       v_finalJgSql:=v_finalJgSql||TJ6||' as TJ6,'||TJ7||' as TJ7,'||TJ8||' as TJ8,'||TJ9||' as TJ9,'||TJ10||' as TJ10,'||TJ11||' as TJ11,';
       v_finalJgSql:=v_finalJgSql||TJ12||' as TJ12,'||TJ13||' as TJ13,'||TJ14||' as TJ14,'||TJ15||' as TJ15  from dual)';
       Execute Immediate v_finalJgSql into v_finalJg;
       sJg:= sJg||'$'||v_finalJg;
     end if;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end;

/

