create function fn_ttkTkbh(vTtk_id  varchar2,vXnm varchar2,vXqm varchar2,vFlag  varchar2 ) return varchar2 --返回调停课编码信息
as
   sTkbh varchar2(20);--调停课编码信息
begin
   sTkbh :='';
      begin
        --不同调动类型 按天的维度 分开计数
        if vFlag = '2' then
            select x.tkbh into sTkbh from (
             select sqb.ttk_id,
                   (select s.tklxmc from jw_pk_tklxdmb s where s.tklxdm = sqb.tklxdm) || '-' ||
                    to_char(to_date(sqb.sqtjsj, 'yyyy-mm-dd hh24:mi:ss'), 'mmdd') || '-' ||
                    row_number() OVER(PARTITION BY sqb.xnm,sqb.xqm,sqb.tklxdm,to_date(substr(sqb.sqtjsj,1,10),'yyyy-mm-dd') ORDER BY to_date(to_char(sqb.sqtjsj),'yyyy-mm-dd hh24:mi:ss')) as tkbh
              from (select distinct ttk_id ,tklxdm,sqtjsj,xnm,xqm from jw_pk_ttksqb )sqb
              where sqb.xnm = vXnm
                and sqb.xqm = vXqm
              )x where x.ttk_id = vTtk_id;
        end if;
  exception
        When others then
        sTkbh :='';
  end;

 if sTkbh is null then
     return '';
  else
     return sTkbh;
  end if;
end fn_ttkTkbh;

/

