create procedure p_xk_choose_qzkc
(
  in_ids in varchar2,
  in_xh_id in varchar2,
  in_xkxnm in varchar2,
  in_xkxqm in varchar2,
  in_qz in varchar2,
  in_xklc in varchar2,
  out_flag out varchar2,
  out_xsdm out varchar2,
  out_xsmc out varchar2
)
as
    v_count number;
    v_qz number;
    isfjxb varchar2(40);
    jxb_id_array mytype;
begin
    out_flag := '1';
    out_xsdm := '01';
    out_xsmc := '讲课';
    jxb_id_array := my_split(in_ids,',');
    --判断学生所选教学班的上课时间有无和其他已选课程冲突
    FOR i IN 1..jxb_id_array.count LOOP
        v_count := 0;
        select count(*) into v_count from (select b.* from jw_xk_xsxkb a,jw_pk_kbsjb b where a.jxb_id = b.jxb_id and a.xh_id=in_xh_id and b.xnm=in_xkxnm and b.xqm=in_xkxqm) t1,(select * from jw_pk_kbsjb where jxb_id=jxb_id_array(i)) t2 where t1.xqj=t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0;
        if v_count>0 then
           out_flag := '0';
           select a.xsdm,b.xsmc into out_xsdm,out_xsmc from jw_jxrw_jxbxxb a,jw_jh_kcxsxxdmb b where a.xsdm=b.xsdm and a.jxb_id=jxb_id_array(i);
           goto nextOne; --跳出循环
        end if;
    end LOOP;
    <<nextOne>>

    --没有冲突时将教学班加入学生的选课表中
    if out_flag = '1' then
        FOR i IN 1..jxb_id_array.count LOOP
          select nvl(fjxb_id,'0') into isfjxb from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(i);
          if isfjxb != '0' then
             v_qz := 0;
          else
              v_qz := in_qz;
          end if;
          insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,qz) values (jxb_id_array(i),in_xh_id,in_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_qz);
        end LOOP;
    end if;
end;

/

