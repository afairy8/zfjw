create view LIKAI_TKCX3_VIEW as
  select "XNM","XQM","JGH_ID","停课","补课","换时间","其它"
from
  (select t.xnm,t.xqm,t.jgh_id,t.ttlb,sum(t.tdxs) tdzxs from
(select
     ttk.xnm,
     ttk.XQM,
     case when ttk.YJGH_ID is null then ttk.xjgh_id else ttk.yjgh_id end                                                                                jgh_id,
     ttk.CJTKLTJ,
     case when ttk.tklxdm='02'
       then '补课'
     when ttk.tklxdm='03'
       then '停课'
     when ttk.YZCD || ttk.YXQJ || ttk.YJC <> ttk.XZCD || ttk.XXQJ || ttk.Xjc
       then '换时间'
     else '其它'
     end                                                                                         ttlb,
     (length(FN_BITTOSTR(case when yjc is null or to_char(yjc) = '0'
       then xjc
                         else yjc end)) - length(replace(FN_BITTOSTR(case when yjc is null or to_char(yjc) = '0'
       then xjc
                                                                     else yjc end), '1', ''))) *
     (length(FN_BITTOSTR(case when yzcd is null or to_char(yzcd) = '0'
       then xzcd
                         else yzcd end)) - length(replace(FN_BITTOSTR(case when yzcd is null or to_char(yzcd) = '0'
       then xzcd
                                                                      else yzcd end), '1', ''))) tdxs
   from JW_PK_TTKSQB ttk where ttk.CJTKLTJ='1' and ttk.shzt='3'
and exists(select 1 from JW_JXRW_JXBXXB jxb where ttk.JXB_ID=jxb.JXB_ID)) t group by t.xnm,t.xqm,t.jgh_id,t.cjtkltj,t.ttlb) t
  pivot (max(tdzxs) for ttlb in ('停课' as 停课,'补课' as 补课,'换时间' as 换时间,'其它' as 其它))
/

