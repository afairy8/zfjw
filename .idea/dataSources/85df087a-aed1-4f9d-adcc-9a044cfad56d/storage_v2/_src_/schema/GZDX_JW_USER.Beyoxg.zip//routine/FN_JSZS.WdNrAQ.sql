create FUNCTION FN_JSZS(V_NUM NUMBER)
RETURN NUMBER IS V_RTN NUMBER(2);
  V_N1  NUMBER;
  V_N2  NUMBER;
BEGIN
IF (V_NUM IS NULL) THEN return 0;
else
V_RTN := 0;
V_N1 := V_NUM;
    LOOP
      V_N2  := MOD(V_N1, 2);
      V_N1  := ABS(TRUNC(V_N1 / 2));
      IF (V_N2 = 1) THEN V_RTN := V_RTN + 1;
      END IF;
      EXIT WHEN V_N1 = 0;
    END LOOP;
return V_RTN;
END IF;
end;

/

