create function fn_jsgzlKcsjzcskks
(vXnm    varchar2,
 vXqm    varchar2,
 vJgh_id varchar2,
 vZc     varchar2,
 vKssj   varchar2,
 vJssj   varchar2,
 vBj     varchar2) return number /**---计算教师工作量课程设计周次上课课时----**/
 as
  iSkks number; /**---周次内上课课时**/
begin
  iSkks := 0;
  begin
  if vBj = '0' then
   select count(distinct b.dxqzc||t.xqj||c.rn) into iSkks
     from jw_pk_kbsjb t,jw_pk_xlb a,jw_pk_rcmxb b,
           (select rownum rn from zftal_xtgl_jcsjlxb) c
     where t.xnm = a.xnm
       and t.xqm = b.dxqm
       and a.xl_id = b.xl_id
       and bitand(t.zcd, power(2, b.dxqzc - 1)) > 0
       and b.xqj = t.xqj
       and bitand(t.jc, power(2, c.rn - 1)) > 0
       and t.xnm = vXnm
       and t.xqm = vXqm
       and t.jgh_id = vJgh_id
       and b.dxqzc = vZc
       and b.rq >= nvl(vKssj,b.rq)
       and b.rq <= nvl(vJssj,b.rq);
  end if;
  exception
    When others then
      iSkks :=  0;
  end;
  return iSkks;
end fn_jsgzlKcsjzcskks;

/

