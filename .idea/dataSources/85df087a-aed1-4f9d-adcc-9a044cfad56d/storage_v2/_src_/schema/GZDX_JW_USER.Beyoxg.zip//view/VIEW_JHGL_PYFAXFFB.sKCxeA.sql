create view VIEW_JHGL_PYFAXFFB as
  select pyfaxx_id,xq,djxn,xqm,xqzxf,zyh_id,njdm_id,njdm,(djxn+njdm-1) xndm,(select njdm_id from zftal_xtgl_njdmb where njdm=(t1.djxn+t1.njdm-1)) xndm_id from
(select xqxf.pyfaxx_id,
xqxf.xq,substr(xqxf.xq,1,instr(xqxf.xq,'-')-1) djxn,substr(xqxf.xq,instr(xqxf.xq,'-')+1,length(xqxf.xq)-instr(xqxf.xq,'-')) xqm,
xqxf.xqzxf,pyfa.zyh_id,synj.njdm_id,(select njdm from zftal_xtgl_njdmb where njdm_id=synj.njdm_id) njdm from
(select pyfaxx_id,xq,sum(nvl(xf,0)) xqzxf from jw_jh_pyfaxffb a where sftj='1' group by pyfaxx_id,xq) xqxf,
jw_jh_pyfaxxb pyfa,JW_JH_PYFASYNJB synj
where xqxf.pyfaxx_id=pyfa.pyfaxx_id and pyfa.pyfaxx_id=synj.pyfaxx_id) t1
/

comment on table VIEW_JHGL_PYFAXFFB
is '视图_计划管理_培养方案学分分配'
/

