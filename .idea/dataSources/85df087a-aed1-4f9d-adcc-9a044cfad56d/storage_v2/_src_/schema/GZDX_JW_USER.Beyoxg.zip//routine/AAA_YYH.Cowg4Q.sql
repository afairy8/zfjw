create procedure aaa_yyh is
begin
  
/*
 
            update   jw_jh_jxzxjhkcxxb v set bz=(select p.bls from  yyh_jw_jxrw_wxlsrwkcb p where v.kch_id=p.kch_id and v.zyh_id=p.zyh_id and p.jxzxjhkcxx_id=v.jxzxjhkcxx_id
            and v.jyxdxnm=p.jyxdxnm and v.jyxdxqm=p.jyxdxqm ) where  v.kch_id||v.zyh_id||v.JXZXJHKCXX_ID in(
            select  kch_id||zyh_id||JXZXJHKCXX_ID from  yyh_jw_jxrw_wxlsrwkcb)
            
            */
      

insert into rs 
select to_char(sysdate,'YYYYMMDD W HH24:MI:SS') ,count(*) from jw_xk_xsxkb;
      
            


end aaa_yyh;

/

