create function fn_getKcxszc(vJxb_id varchar2,vKch_id varchar2) return  varchar2--返回课程学时组成信息
as
  sKcxszcxx varchar2(200);--课程学时组成信息
  sJhnkcFlag number;
begin
  sKcxszcxx :='';
  begin
        select count(1) into sJhnkcFlag from jw_jh_jxzxjhkcxxb t1,jw_jxrw_jxbhbxxb t3
              where t1.njdm_id = t3.njdm_id
              and t1.zyh_id = t3.zyh_id
              and t3.jxb_id = vJxb_id
              and t1.kch_id = vKch_id;

        if sJhnkcFlag > 0 then --计划内
          select wm_concat(a.xsmc||':'||t.zxs) into sKcxszcxx  from (
               select t2.xsdm,t2.zxs,row_number() over (partition by t2.xsdm order by t3.njdm_id,t3.zyh_id,t3.bh_id) rn
               from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcxsdzb t2,jw_jxrw_jxbhbxxb t3
                 where t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                   and t1.njdm_id = t3.njdm_id
                   and t1.zyh_id = t3.zyh_id
                   and t2.sjbj is null
                   and t3.jxb_id = vJxb_id
                   and t1.kch_id = vKch_id
            ) t ,jw_jh_kcxsxxdmb a
            where t.rn = 1 and a.xsdm = t.xsdm and a.sfqy='1' order by a.xsdm;
        else  --计划外
           select wm_concat(a.xsmc||':'||t.zxs) into sKcxszcxx from jw_jh_kcxsdzb t ,jw_jh_kcxsxxdmb a
           where a.xsdm = t.xsdm and a.sfqy='1' and t.kch_id = vKch_id and t.sjbj is null order by a.xsdm;
        end if;

  exception
        When others then
        sKcxszcxx :='';
  end;

  if sKcxszcxx is null then
     return '';
  else
     return sKcxszcxx;
  end if;
end fn_getKcxszc;

/

