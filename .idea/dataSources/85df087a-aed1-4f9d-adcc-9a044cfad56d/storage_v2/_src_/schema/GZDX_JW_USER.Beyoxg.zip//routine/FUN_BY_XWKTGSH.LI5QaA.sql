create function fun_by_xwktgsh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---学位课每门合格分
   sqlstr varchar2(2000);
   v_flag int;
begin
    sJg := '合格';
    begin

        sqlstr:= 'select wm_concat(t1.kcmc||''(''||nvl(t.bfzcj,0)||'')'')  from jw_jh_xsjxzxjhkcxxb t,jw_jh_kcdmb t1 where '||
        ' exists(select 1 from jw_jh_jxzxjhkcxxb a ,jw_xjgl_xsjbxxb b  where  a.njdm_id = b.njdm_id and a.zyh_id = b.zyh_id '||
        ' and a.kch_id = t.kch_id and a.zyzgkcbj=''1'' and b.xh_id='''||v_xh_id||''') and t.kch_id = t1.kch_id '||
        ' and nvl(t.bfzcj,0)<'''||v_tjsjz||'''  and t.xh_id='''||v_xh_id||'''';

        execute immediate sqlstr into sJg;
         if sJg is not null then
            sJg:= sJg||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_xwktgsh;

/

