create package body likai_jw_static is
  -----------------------------------------
  function pj_findpjcs(v_count varchar2, v_left varchar2, v_right varchar2)
    return varchar2
  is
    v_res       varchar2(255);
    v_left_pos  int;
    v_right_pos int;
    v_length    int;
    begin
      if v_left is null
      then
        v_left_pos := 1;
      else
        select instr(v_count, v_left) into v_left_pos from dual;
      end if;
      if v_right is null
      then
        v_right_pos := length(v_count) + 1;
      else
        select instr(v_count, v_right) into v_right_pos from dual;
      end if;
      select substr(v_count, v_left_pos, v_right_pos - v_left_pos + 1) into v_res from dual;
      return v_res;
    end;
  --------------------------
  function pj_gettklxzcs(v_xnm varchar2, v_xqm varchar2, v_jgh_id varchar2, v_cpdxdm varchar2)
    return varchar
  is
    v_count  varchar2(255);
    v_count2 varchar2(255);
    v_count3 varchar2(255);
    v_count4 varchar2(255);
    begin
      ---次数计算部分
      select 'zcs' || count(1) into v_count
      from JW_PJ_JXBPFB pfb
      where pfb.XNM = v_xnm
        and pfb.XQM = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      select 'lrk' || count(1) into v_count2
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%理论%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count2 is null
      then
        v_count2 := 'lrk/';
      end if;
      select 'syk' || count(1) into v_count3
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%实验%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count3 is null
      then
        v_count := 'syk/';
      end if;
      select 'qnj' || count(1) into v_count4
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) = 0;
      if v_count4 is null
      then
        v_count4 := 'qnj/';
      end if;
      v_count := v_count || v_count2 || v_count3 || v_count4;
      ----------------平均值，最大值，最小值计算部分
      select 'lma' || to_char(nvl(max(to_number(nvl(bfzpf,0))),0)) into v_count2
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%理论%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count2 is null
      then
        v_count2 := 'lma/';
      end if;
      select 'lmi' || to_char(nvl(min(to_number(nvl(bfzpf,0))),0)) into v_count3
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%理论%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count3 is null
      then
        v_count3 := 'lmi/';
      end if;
      select 'lav' ||to_char(round(nvl(avg(to_number(nvl(bfzpf,0.000))),0.000)),2) into v_count4
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%理论%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count4 is null
      then
        v_count4 := 'lav/';
      end if;
      v_count := v_count || v_count2 || v_count3 || v_count4;
      select 'sma' || to_char(nvl(max(to_number(nvl(bfzpf,0))),0)) into v_count2
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%实验%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count2 is null
      then
        v_count2 := 'sma/';
      end if;
      select 'smi' || to_char(nvl(min(to_number(nvl(bfzpf,0))),0)) into v_count3
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%实验%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count3 is null
      then
        v_count3 := 'smi/';
      end if;
      select 'sav' || to_char(round(nvl(avg(to_number(nvl(bfzpf,0.000))),0.000)),2) into v_count4
      from jw_pj_jxbpfb pfb,
           JW_PJ_PJMBMCB mcb
      where pfb.PJMBMCB_ID = mcb.PJMBMCB_ID
        and mcb.PJMBMC like '%实验%'
        and pfb.XNM = v_xnm
        and pfb.xqm = v_xqm
        and pfb.JGH_ID = v_jgh_id
        and pfb.CPDXDM = v_cpdxdm
        and to_number(nvl(BFZPF, 0)) > 0;
      if v_count4 is null
      then
        v_count4 := 'sav/';
      end if;
      v_count := v_count || v_count2 || v_count3 || v_count4;
      return v_count;
    end;
  -----------------------------------------
end;
/

