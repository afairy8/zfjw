create view V_JW_JSKBSJ as
  select
  jzg.jgh jsgh,
  jzg.xm jsxm,
  kc.kcmc,
  kc.kch kcdm,
  null as skbj,
  (select xnmc from JW_JCDM_XNB where xnm=jxb.xnm) xn,
  (select mc from ZFTAL_XTGL_JCSJB where lx='0001' and dm=jxb.xqm  ) xq,
 get_jcbinarydesc(nvl(cd.zcd,sj.zcd),'') zc,
  case when get_weeksdesc(nvl(cd.zcd,sj.zcd)) like '%双%' then '双'
  when get_weeksdesc(nvl(cd.zcd,sj.zcd)) like '%单%' then '单'
    else '全' end dsz,
  (select cdmc from JW_JCDM_CDJBXXB  where cd_id=cd.CD_ID) skdd,
  jxb.jxb_id ,
  jxb.jxbmc,
  jxb.xf,
  jxb.jxbrs,
  jxb.rwzxs,
  case when kkzt='1' then '0' else '1' end zt,
 GET_JXBZC(jxb.JXB_ID) jxbzc,
  sj.xqj ,
 get_jcbinarydesc(nvl(cd.jc,sj.jc),'')  sksj,
  (select kcxzmc from JW_JH_KCXZDMB where kcxzdm=kc.KCXZDM) kcxz,
  kc.KCXZDM kcxzm,
  (select mc from ZFTAL_XTGL_JCSJB where lx='0037' and dm=jxb.KHFSDM) khfs
  from JW_PK_KBSJB sj, JW_PK_KBCDB cd, JW_JG_JZGXXB jzg,JW_JXRW_JXBXXB jxb,JW_JH_KCDMB kc
  where  sj.xqm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXQM') and sj.xnm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXNM'
) and sj.KB_ID=cd.KB_ID(+) and sj.JGH_ID=jzg.JGH_ID and jxb.JXB_ID=sj.JXB_ID and kc.KCH_ID=jxb.KCH_ID
and  nvl(jxb.shzt ,3)=3 and jxb.kkzt='1'
/

