create function fn_jxgs(vJfgs varchar2) return varchar2
as
    sqlStr varchar2(2000);
   v_jfgs varchar2(500);
   sJxjg varchar2(2000);
begin
    sJxjg := '无';
    begin
            select replace(vJfgs,'cj','100') into v_jfgs from dual;
              sqlStr := 'select round('||v_jfgs||',2) from dual';
              Execute Immediate sqlStr into sJxjg;

    end;
    return sJxjg ;
end fn_jxgs;

/

