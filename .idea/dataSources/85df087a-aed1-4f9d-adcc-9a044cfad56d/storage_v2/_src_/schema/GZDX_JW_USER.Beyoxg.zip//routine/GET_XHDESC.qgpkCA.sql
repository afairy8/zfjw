create Function Get_XhDesc(vMinXh in integer,vMaxXh in integer, vXhs in Varchar)--最小序号，最大序号，序号字串
Return varchar2
as
  xhsDesc varchar2(100) := null; ---序号显示组合
  startXh integer := -1; --开始序号
  endXh integer := -1; --结束序号
  currDesc varchar2(10) := null; ---当前循环描述
  iBj integer;
begin
select count(*) into iBj from zftal_xtgl_xxxxszb where xxdm = '13684';---吉林大学珠海学院
if ibj > 0 then
  if vXhs = null then --字串为空
    return '';
  end if;
  if vMinXh > vMaxXh then --最小序号小于最大序号
    return '';
  end if;
  if vMinXh = vMaxXh then --最小序号等于最大序号
    return to_char( lpad(vMinXh,2,'0'));
  end if;
  --循环处理
  for i in vMinXh..(vMaxXh+1) loop --加1是为了能将最后一个统计到描述中
      if instr(','||vXhs||',' , ','||to_char(i)||',') > 0 then -- 当前序号存在字串中
         endXh := i;
         if startXh = -1 then
            startXh := i;
         end if;
      else -- 不存在
           if startXh > 0 and endXh >0 then
               if startXh = endXh then
                  currDesc := lpad(startXh,2,'0');
               else
                  currDesc := lpad(startXh,2,'0')||'-'||lpad(endXh,2,'0');
               end if;
               if xhsDesc is null then
                  xhsDesc := currDesc;
               else
                  xhsDesc := xhsDesc||','||currDesc;
               end if;
               startXh := -1; --重置为-1
               endXh := -1;   --重置为-1
           end if;
      end if;
  end loop;
else  ---吉林建筑大学
  if vXhs = null then --字串为空
    return '';
  end if;
  if vMinXh > vMaxXh then --最小序号小于最大序号
    return '';
  end if;
  if vMinXh = vMaxXh then --最小序号等于最大序号
    return to_char(vMinXh);
  end if;
  --循环处理
  for i in vMinXh..(vMaxXh+1) loop --加1是为了能将最后一个统计到描述中
      if instr(','||vXhs||',' , ','||to_char(i)||',') > 0 then -- 当前序号存在字串中
         endXh := i;
         if startXh = -1 then
            startXh := i;
         end if;
      else -- 不存在
           if startXh > 0 and endXh >0 then
               if startXh = endXh then
                  currDesc := to_char(startXh);
               else
                  currDesc := startXh||'-'||endXh;
               end if;
               if xhsDesc is null then
                  xhsDesc := currDesc;
               else
                  xhsDesc := xhsDesc||','||currDesc;
               end if;
               startXh := -1; --重置为-1
               endXh := -1;   --重置为-1
           end if;
      end if;
  end loop;
end if;
  return xhsDesc;
end;

/

