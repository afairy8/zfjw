create function get_Jflxjf(v_jfgs varchar2, v_jfz varchar2, v_bfzcj varchar2)
 Return varchar2 as
  out_jfhfs    varchar2(4000);
  sqlStr       varchar2(2000);
  v_zhhgs      varchar2(50);
begin
  out_jfhfs    := v_bfzcj;

  if v_jfgs is not null then --公式对应计算分数
     select replace(v_jfgs,v_jfz,v_bfzcj) into v_zhhgs from dual;
        sqlStr := 'select round('||v_zhhgs||') from dual';
        Execute Immediate sqlStr into out_jfhfs;
  end if;

  return out_jfhfs;
end get_Jflxjf;

/

