create procedure p_cx_check_cxxk_jndx
(
  in_xh_id in varchar2,
  in_jxb_id in varchar2,
  in_xqh_id in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
v_count number;
v_xkzgxf number;
v_xkzgmc number;
v_total_xf number;
v_total_kc number;
v_xf number;
v_njdm_id varchar2(32);
v_kch_id varchar2(32);
v_xkxnm varchar2(5);
v_xkxqm varchar2(2);
begin
     out_flag := 1;
     --select max(case when lower(zdm)='xkxnm' then zdz end) xkxnm,max(case when lower(zdm)='xkxqm' then zdz end) xkxqm into v_xkxnm,v_xkxqm from zftal_xtgl_xtszb;
     --select count(*) into v_count from jw_xmgl_jxxmbmszb t where t.jxxmlbdm='1008' and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between t.kssj and t.jssj;
     select count(*) into v_count from jw_cj_cxbmszb t where zt = '1' and sysdate between t.kssj and t.jssj;
     if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，当前时间不可报名，如有需要，请与管理员联系！';
        goto nextOne;
     end if;

     select xnm,xqm into v_xkxnm,v_xkxqm from jw_cj_cxbmszb where zt = '1';

     select kch_id,xf into v_kch_id,v_xf from jw_jxrw_jxbxxb where jxb_id=in_jxb_id;
	 --select  from JW_XK_XKKZB a,JW_XK_XKKZXMB b where a.xkkz_id=b.xkkz_id and xnm=(select zdz from zftal_xtgl_xtszb where zdm='XKXNM') and xqm=(select zdz from zftal_xtgl_xtszb where zdm='XKXQM') and kklxdm=v_kklxdm and njdm=v_njdm_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
	 select count(*) into v_count from JW_XK_QTXKGZB where xnm=v_xkxnm and xqm=v_xkxqm and xh_id = in_xh_id;
	 if v_count=0 then
		select nvl(xkzgxf,0),nvl(xkzgmc,0) into v_xkzgxf,v_xkzgmc from JW_XK_QTXKGZB where xnm=v_xkxnm and xqm=v_xkxqm and xh_id = 'tongyi';
	 else
		select nvl(xkzgxf,0),nvl(xkzgmc,0) into v_xkzgxf,v_xkzgmc from JW_XK_QTXKGZB where xnm=v_xkxnm and xqm=v_xkxqm and xh_id = in_xh_id;
	 end if;

	 if v_xkzgxf>0 or v_xkzgmc>0 then
		select sum(nvl(t1.xf,0)),count(t1.kch_id) into v_total_xf,v_total_kc from jw_jh_kcdmb t1 where exists(select 1 from jw_jxrw_jxbxxb t2,jw_xk_xsxkb t3 where t1.kch_id=t2.kch_id and t2.jxb_id=t3.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and t2.kklxdm not in ('02','03','04') and t3.xh_id=in_xh_id);
		if v_xkzgmc > 0 and v_total_kc >= v_xkzgmc then
			out_flag := -1;
			out_msg := '对不起，已超过最大选课门次要求！不可选！';
			goto nextOne;
		end if;
		if v_xkzgxf>0 and (v_total_xf+v_xf) > v_xkzgxf then
			out_flag := -1;
			out_msg := '对不起，已超过最大选课学分要求！不可选！';
			goto nextOne;
		end if;
	 end if;

     select count(*) into v_count from jw_xk_xsxkb where xh_id=in_xh_id and kch_id=v_kch_id and xnm=v_xkxnm and xqm=v_xkxqm;
     if v_count>0 then
        out_flag := -1;
        out_msg := '对不起，同一门课程只可选一个教学班！';
        goto nextOne;
     end if;

     select
            count(*) into v_count
     from jw_jxrw_jxbxxb a
     where a.jxb_id=in_jxb_id and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xqh_id=in_xqh_id;
     if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，您所在校区和该教学班上课校区不同，不可选！';
        goto nextOne;
     end if;

	 select njdm_id into v_njdm_id from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
     if v_njdm_id>='2014' then
         select count(*) into v_count
         from
              (
                  select a.jxb_id, b.xqj, b.zcd, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                  where a.jxb_id = b.jxb_id and a.kch_id != v_kch_id
                        and a.xh_id = in_xh_id and b.xnm = v_xkxnm
                        and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm
               ) t1,
              (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where jxb_id=in_jxb_id) t2
         where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd)>0 and bitand(t1.jc, t2.jc)>0;

         if v_count>0 then
            out_flag := -1;
            out_msg := '对不起，所选教学班与其他教学班的上课时间有冲突！不可选！';
            goto nextOne;
         end if;
     end if;

     <<nextOne>>

     if out_flag = '-1' then
         rollback;
     else
         commit;
     end if;
end;

/

