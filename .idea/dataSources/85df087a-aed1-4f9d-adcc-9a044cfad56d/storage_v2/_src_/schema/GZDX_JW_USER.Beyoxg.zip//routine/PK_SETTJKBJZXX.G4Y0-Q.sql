create Procedure Pk_SetTjkbJzxx(vXnm in varchar2,vXqm in varchar2,vzyh_Id varchar2,vnjdm_id varchar2,vbh_id varchar2)
as
  i number;     ----定义数值型变量----i---
  v_jls number; ----记录数
  v_zjls number; ----子记录数
  v_wzjls number;----无子记录数
  v_tjkbdm varchar2(10); ----推荐课表代码----
  v_ztjkbdm varchar2(10); ----子推荐课表代码----
  sKbgsbj varchar2(8);    ----课表个数标记
  cursor get_RwKbxx is     ----取排课任务信息，除子学时任务信息。----游标---
   select count(*) jls From jw_pk_jxrwb Where fjxb_id is null
                                          and rs<>'0'
                                          and xnm  =vXnm
                                          and dxqm =vXqm
                                          and njdm_id =vnjdm_id
                                          and zyh_id  =vzyh_Id
                                          and bh_id   =vbh_id;
  Cur_RwKbxx get_RwKbxx%rowtype;
  ------------------------------------------------------------------------------
 cursor get_Rwkbzxx is     ----取排课任务信息，除子学时任务信息。----游标---
             select count(*) zjls From jw_pk_tjkbdmb a Where a.xnm  =vXnm
                                                         and a.dxqm = vXqm
                                                         and a.njdm_id=vnjdm_id
                                                         and a.zyh_id =vzyh_Id
                                                         and a.bh_id  =vbh_id
                                                         and exists (select 'X' from jw_pk_jxrwb b
                                                                               where b.xnm=a.xnm
                                                                                 and b.xqm=a.xqm
                                                                                 and b.fjxb_id is not null
                                                                                 and b.rs <> '0'
                                                                                 and b.fjxb_id =a.jxb_id
                                                                                 and b.zyh_id=a.zyh_id
                                                                                 and b.bh_id=a.bh_id
                                                                                 and b.njdm_id=a.njdm_id
                                                                                 and b.xnm = vXnm
                                                                                 and b.dxqm = vXqm)
                                                          and a.rs<>'0';

  Cur_Rwkbzxx get_Rwkbzxx%rowtype;
  ------------------------------------------------------------------------------
  cursor get_Rwkbwzxx is     ----取排课任务信息，除子学时任务信息。----游标---
   select count(*) wzjls From jw_pk_tjkbdmb Where xnm =vXnm
                                              and dxqm=vXqm
                                              and njdm_id=vnjdm_id
                                              and zyh_id =vzyh_Id
                                              and bh_id  =vbh_id
                                              and rs = '0';
  Cur_Rwkbwzxx get_Rwkbwzxx%rowtype;
 --------------------------------------------------------------------------------
begin
  select nvl((select zdz from jw_jcdml_xtnzb  where zdm = 'KBGSBJ'),0) into sKbgsbj from dual;
  if sKbgsbj = '1' then

  UPDATE jw_pk_tjkbjgb A SET RS = (SELECT rs FROM jw_pk_jxrwlsb B
                                    WHERE a.xnm = b.xnm
                                      and a.xqm = b.xqm
                                      and a.njdm_id = b.njdm_id
                                      and a.zyh_id = b.zyh_id
                                      and a.bh_id = b.bh_id
                                      and a.kch_id = b.kch_id
                                      and a.jxb_id = b.jxb_id
                                      and a.zyfx_id = b.zyfx_id )
                          WHERE EXISTS (SELECT 'x' FROM jw_pk_jxrwlsb C
                                         WHERE a.xnm = c.xnm
                                           and a.xqm = c.xqm
                                           and a.njdm_id = c.njdm_id
                                           and a.zyh_id = c.zyh_id
                                           and a.bh_id = c.bh_id
                                           and a.kch_id = c.kch_id
                                           and a.jxb_id = c.jxb_id
                                           and a.zyfx_id = c.zyfx_id)
                            and a.xnm = vXnm
                            and a.xqm = vXqm
                            and a.njdm_id = vNjdm_id
                            and a.zyh_id = vZyh_id
                            and a.bh_id = vBh_id
                            and a.tjkbzdm = '1'
                            and a.tjkbzxsdm = '0';
   commit;
   insert into jw_pk_tjkbjgb(xnm,xqm,dxqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
        select xnm,xqm,dxqm,njdm_id,zyh_id,bh_id,'1','0',kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from jw_pk_jxrwlsb a where
          not exists (select 'X' from jw_pk_tjkbjgb b where a.xnm = b.xnm
                                                        and a.xqm = b.xqm
                                                        and a.kch_id = b.kch_id
                                                        and a.jxb_id = b.jxb_id
                                                        and a.njdm_id = b.njdm_id
                                                        and a.zyh_id = b.zyh_id
                                                        and a.bh_id = b.bh_id
                                                        and a.zyfx_id = b.zyfx_id
                                                        --and b.tjkbzdm = '1'
                                                        --and b.tjkbzxsdm ='0'
                                                        )
         and a.xnm = vXnm
         and a.xqm = vXqm
         and a.njdm_id = vNjdm_id
         and a.zyh_id = vZyh_id
         and a.bh_id = vBh_id;

   commit;
  else
  i:=1;
  v_wzjls:=0;
  <<NextReCord>>
  v_jls:=0;
  open get_RwKbxx;
  loop
    fetch get_RwKbxx into Cur_RwKbxx;
     exit when get_RwKbxx%notfound;
     v_jls:=Cur_RwKbxx.jls;
     if v_jls > 0 then
      v_tjkbdm:=to_char(i);
       delete from jw_pk_tjkbjglsb where xnm =vXnm
                                     and dxqm=vXqm
                                     and njdm_id=vnjdm_id
                                     and zyh_id =vzyh_Id
                                     and bh_id  =vbh_id;
       commit;
      begin
        insert into jw_pk_tjkbjglsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,xsdm,zyfx_id,rs)
        --取出各课程最大教学班人数后按其中取出列表人数--begin-----
         select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,v_tjkbdm,kch_id,jxb_id,xsdm,zyfx_id,
                min(to_number(rs)) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) tjrs from    ---按最小人数分别显示在各教学班列表人数--（tjrs:推荐人数）--
            (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,--无方向课程与有方向课程合并----begin-------------
                    row_number()over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                         order by to_number(rs) desc) rn --各课程中的教学班人数倒序排序rn
                     FROM jw_pk_jxrwb where xnm  =vXnm
                                        and dxqm =vXqm
                                        and njdm_id=vnjdm_id
                                        and zyh_id =vzyh_Id
                                        and bh_id  =vbh_id
                                        and fjxb_id is null --列表信息内不包涵学时类型的教学班信息（如实验课、上机课等分学时类型的教学班）
                                        and zyfx_id = 'wfx' --取出无方向课程
                                        and rs <> '0'       --人数不为零判断（过滤掉分配推荐课表已经完成的教学任务信息，见下面更新人数）

                    union all
                    --------------------------------------------------
                    select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,
                           rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,rn1,rn order by zyfx_id ) rn
                           from (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,zrs,
                                        rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id
                                                        order by to_number(zrs) desc ) rn1,
                                        row_number()over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                                             order by to_number(zrs) desc) rn  --取出各方向中课程的教学班人数倒序排序rn
                                    from (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,xsdm,rs,
                                                 sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id) zrs
                                                       FROM jw_pk_jxrwb where xnm=vXnm
                                                                          and dxqm=vXqm
                                                                          and zyh_id=vzyh_Id
                                                                          and bh_id=vbh_id
                                                                          and njdm_id=vnjdm_id
                                                                          and fjxb_id is null   --列表信息内不包涵学时类型的教学班信息（如实验课、上机课等分学时类型的教学班）
                                                                          and zyfx_id <> 'wfx'  --取出有方向课程
                                                                          and rs <> '0'        --人数不为零判断（过滤掉分配推荐课表已经完成的教学任务信息，见下面更新人数）
                                           )
                               ) where rn1 = '1'
                                   and rn = '1'             --取出各方向中某一课程的教学班最大人数的信息列表
                      --无方向课程与有方向课程合并-------end---------
            ) where rn = '1';
---------取出各课程最大教学班人数后按其中取出列表人数--end----

-----------------------------------------------------------------------------------------------------------------------
     --拆分后的小课表数据插入到推荐课表代码表内--begin--
     insert into jw_pk_tjkbdmb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                        select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs
                         from jw_pk_tjkbjglsb where xnm=vXnm
                                                and dxqm = vXqm
                                                and njdm_id=vnjdm_id
                                                and zyh_id=vzyh_Id
                                                and bh_id=vbh_id;
     --拆分后的小课表数据插入到推荐课表代码表内--begin--
------------------------------------------------------------------------------------------------------------------------
      --更新排课任务中的已拆分出小课表的数据，人数要在原排课任务中剪掉--begin--------------
      UPDATE jw_pk_jxrwb A SET RS = RS -(SELECT rs FROM jw_pk_tjkbjglsb b
                                                      WHERE a.xnm = b.xnm
                                                        and a.xqm = b.xqm
                                                        and a.njdm_id = b.njdm_id
                                                        and a.zyh_id = b.zyh_id
                                                        and a.bh_id = b.bh_id
                                                        and a.kch_id = b.kch_id
                                                        and a.jxb_id = b.jxb_id
                                                        and a.zyfx_id = b.zyfx_id
                                                        and b.xnm = vXnm
                                                        and b.dxqm = vXqm)
                                  WHERE xnm=vXnm
                                    and dxqm=vXqm
                                    and njdm_id=vnjdm_id
                                    and zyh_id=vzyh_Id
                                    and bh_id=vbh_id
                                    and EXISTS
                                    (SELECT 'X' FROM jw_pk_tjkbjglsb c
                                               WHERE a.xnm = c.xnm
                                                 and a.xqm = c.xqm
                                                 and a.njdm_id = c.njdm_id
                                                 and a.zyh_id = c.zyh_id
                                                 and a.bh_id = c.bh_id
                                                 and a.kch_id = c.kch_id
                                                 and a.jxb_id = c.jxb_id
                                                 and a.zyfx_id = c.zyfx_id
                                                 and c.xnm = vXnm
                                                 and c.dxqm = vXqm);

      --更新排课任务中的已拆分出小课表的数据，人数要在原排课任务中剪掉----end--------------
        commit;
      exception
        When others then
          Rollback;
          Goto Exend;
      end;
     else
       Goto Exend;
     end if;
  end loop;
  close get_RwKbxx;
  i:=i+1;
  Goto NextReCord;
  <<Exend>>
  null;

  -------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------
  -------------------------------------第二步处理--------------------------------------------

   i:=1;
  <<NextSecReCord>> --第二记录集----
  v_zjls:=0;
  open get_RwKbzxx; --任务课表子信息课表---
  loop
    fetch get_RwKbzxx into Cur_RwKbzxx;
     exit when get_RwKbzxx%notfound;
     v_zjls:=Cur_RwKbzxx.zjls;
     if v_zjls > 0 then
      v_ztjkbdm:=to_char(i);
      delete from jw_pk_tjkbjglsb where xnm=vXnm
                                    and dxqm=vXqm
                                    and njdm_id=vnjdm_id
                                    and zyh_id=vzyh_Id
                                    and bh_id=vbh_id;
      delete from jw_pk_tjkbdmlsb where xnm=vXnm
                                    and dxqm=vXqm
                                    and njdm_id=vnjdm_id
                                    and zyh_id=vzyh_Id
                                    and bh_id=vbh_id;
      commit;

      begin
        ----------------------------------------------------------------------------------------------------------
        insert into jw_pk_tjkbdmlsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn)
        select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn from
               (select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.tjkbzdm,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.zyfx_id,a.rs,
                       dense_rank() over(partition by a.xnm,a.dxqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.zyfx_id
                                         order by to_number(a.rs) desc ) rn
                      from jw_pk_tjkbdmb a,jw_pk_jxrwb b
                                           where a.xnm=vXnm
                                             and a.dxqm=vXqm
                                             and a.njdm_id=vnjdm_id
                                             and a.zyh_id=vzyh_Id
                                             and a.bh_id=vbh_id
                                             and a.xnm = b.xnm
                                             and a.xqm = b.xqm
                                             and a.njdm_id=b.njdm_id
                                             and a.zyh_id=b.zyh_id
                                             and a.bh_id=b.bh_id
                                             and a.rs <> '0'
                                             and b.fjxb_id is not null
                                             and b.rs <> 0
                                             and a.jxb_id = b.fjxb_id
                                             and exists(select 'X' from
                                                        (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,
                                                                max(tjkbzdm) over (partition by xnm,nvl(dxqm,xqm),njdm_id,zyh_id,bh_id) tjkbzdm from
                                                          (select distinct a.dxqm,a.xnm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.tjkbzdm,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.zyfx_id,a.rs,
                                                                  dense_rank() over(partition by a.xnm,a.dxqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.zyfx_id
                                                                                        order by to_number(a.rs) desc) rn
                                                            from jw_pk_tjkbdmb a ,jw_pk_jxrwb b  where a.xnm = vXnm
                                                                                                   and a.dxqm = vXqm
                                                                                                   and a.xnm = b.xnm
                                                                                                   and a.xqm = b.xqm
                                                                                                   and a.njdm_id = b.njdm_id
                                                                                                   and a.zyh_id = b.zyh_id
                                                                                                   and a.bh_id = b.bh_id
                                                                                                   and a.rs <> '0'
                                                                                                   and b.fjxb_id is not null
                                                                                                   and b.rs <> '0'
                                                                                                   and a.jxb_id = b.fjxb_id
                                                                                                   and b.xnm = vXnm
                                                                                                   and b.dxqm = vXqm
                                                           ) where rn = '1'
                                                         ) c where a.xnm = c.xnm
                                                              and a.xqm = c.xqm
                                                              and a.njdm_id = c.njdm_id
                                                              and a.zyh_id = c.zyh_id
                                                              and a.bh_id = c.bh_id
                                                              and a.zyfx_id = c.zyfx_id
                                                              and a.tjkbzdm = c.tjkbzdm )
               ) where rn = '1';
        -------------------------------------------------------------------------------------
        insert into jw_pk_tjkbjglsb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
        select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,
               max(to_number(tjkbzdm)) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) tjkbzdm,
               v_ztjkbdm tjkbzxsdm,kch_id,jxb_id, fjxb_id, xsdm,zyfx_id,
               min(to_number(rs)) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) tjrs
               from ( select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id, 0 tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                            row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id,xsdm
                                                  order by to_number(rs) desc ) rn
                            from  jw_pk_jxrwb a where a.fjxb_id is not null
                                                  and a.rs <> 0
                                                  and a.xnm=vXnm
                                                  and a.dxqm =vXqm
                                                  and a.njdm_id=vnjdm_id
                                                  and a.zyh_id=vzyh_Id
                                                  and a.bh_id=vbh_id
                                                  ---------------------------------------------------------
                           --------只能取出在最大人数对应的课程教学班---------与下面UNION ALL教学任务有关------
                                                  and exists(select 'X' from jw_pk_tjkbdmlsb b
                                                                       where a.xnm= b.xnm
                                                                         and a.xqm =b.xqm
                                                                         and a.njdm_id = b.njdm_id
                                                                         and a.zyh_id= b.zyh_id
                                                                         and a.bh_id =b.bh_id
                                                                         and a.zyfx_id = b.zyfx_id
                                                                         and a.fjxb_id = b.jxb_id
                                                                         and b.xnm = vXnm
                                                                         and b.dxqm = vXqm)
                                                  ---------------------------------------------------------
                     union all
                     select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,rn from
                       (select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.tjkbzdm,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.zyfx_id,a.rs,
                               dense_rank() over(partition by a.xnm,a.dxqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.zyfx_id
                                                     order by to_number(a.rs) desc) rn
                                        from jw_pk_tjkbdmb a,jw_pk_jxrwb b where a.rs <> '0'
                                                                             and a.xnm=vXnm
                                                                             and a.dxqm=vXqm
                                                                             and a.xnm = b.xnm
                                                                             and a.xqm = b.xqm
                                                                             and a.njdm_id=vnjdm_id
                                                                             and a.zyh_id=vzyh_Id
                                                                             and a.bh_id=vbh_id
                                                                             and a.njdm_id=b.njdm_id
                                                                             and a.zyh_id=b.zyh_id
                                                                             and a.bh_id=b.bh_id
                                                                             and b.fjxb_id is not null
                                                                             and b.rs <> '0'
                                                                             and a.jxb_id = b.fjxb_id
                             ----------------------------------------------------------------------------------
                              ----------------------------取最大人数的主教学班所对应的推荐课表子代码-------
                                            and exists (select 'X' from
                                                        (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,
                                                                max(tjkbzdm) over (partition by xnm,dxqm,njdm_id,zyh_id,bh_id) tjkbzdm from
                                                          (select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.tjkbzdm,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.zyfx_id,a.rs,
                                                                  dense_rank() over(partition by a.xnm,a.dxqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.zyfx_id
                                                                                        order by to_number(a.rs) desc) rn
                                                           from jw_pk_tjkbdmb a,jw_pk_jxrwb b
                                                                       where a.xnm = vXnm
                                                                         and a.dxqm = vXqm
                                                                         and a.xnm = b.xnm
                                                                         and a.xqm = b.xqm
                                                                         and a.njdm_id = b.njdm_id
                                                                         and a.zyh_id = b.zyh_id
                                                                         and a.bh_id = b.bh_id
                                                                         and a.rs <> '0'
                                                                         and b.fjxb_id is not null
                                                                         and b.rs <> 0
                                                                         and a.jxb_id = b.fjxb_id
                                                          ) where rn = '1'
                                                         ) c where a.xnm = c.xnm
                                                               and a.xqm = c.xqm
                                                               and a.njdm_id = c.njdm_id
                                                               and a.zyh_id = c.zyh_id
                                                               and a.bh_id = c.bh_id
                                                               and a.zyfx_id = c.zyfx_id
                                                               and a.tjkbzdm = c.tjkbzdm
                                                      )
                             -----------------------------------------------------------------------------------
                                 ) where rn = '1'
                   ) where rn = '1'; --order by xnm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id;
-------------------------------------------------------------------------------

  insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                     select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from
                                      jw_pk_tjkbjglsb where xnm=vXnm
                                                        and dxqm=vXqm
                                                        and njdm_id=vnjdm_id
                                                        and zyh_id=vzyh_Id
                                                        and bh_id=vbh_id;

------------------------------------------------------------------------------------------------------------------------------
       UPDATE jw_pk_jxrwb A SET RS = RS - ( SELECT rs FROM jw_pk_tjkbjglsb b
                                                     WHERE a.xnm = b.xnm
                                                       and a.xqm = b.xqm
                                                       and a.njdm_id = b.njdm_id
                                                       and a.zyh_id = b.zyh_id
                                                       and a.bh_id = b.bh_id
                                                       and a.kch_id = b.kch_id
                                                       and a.jxb_id = b.jxb_id
                                                       and a.zyfx_id = b.zyfx_id
                                                       and b.xnm = vXnm
                                                       and b.dxqm = vXqm)
                             WHERE fjxb_id is not null
                               and xnm=vXnm
                               and dxqm=vXqm
                               and njdm_id=vnjdm_id
                               and zyh_id=vzyh_Id
                               and bh_id=vbh_id
                               and EXISTS
                               (SELECT 'x' FROM jw_pk_tjkbjglsb c
                                          WHERE a.xnm = c.xnm
                                            and a.xqm = c.xqm
                                            and a.njdm_id = c.njdm_id
                                            and a.zyh_id = c.zyh_id
                                            and a.bh_id = c.bh_id
                                            and a.kch_id = c.kch_id
                                            and a.jxb_id = c.jxb_id
                                            and a.zyfx_id = c.zyfx_id
                                            and c.xnm = vXnm
                                            and c.dxqm = vXqm);
----------------------------------------------------------------------------------------------------------------------------------
       UPDATE jw_pk_tjkbdmb A SET RS = RS - (SELECT rs FROM jw_pk_tjkbjglsb b
                                                      WHERE a.xnm = b.xnm
                                                        and a.xqm = b.xqm
                                                        and a.njdm_id = b.njdm_id
                                                        and a.zyh_id = b.zyh_id
                                                        and a.bh_id = b.bh_id
                                                        and a.tjkbzdm = b.tjkbzdm
                                                        and a.kch_id = b.kch_id
                                                        and a.jxb_id = b.jxb_id
                                                        and a.zyfx_id = b.zyfx_id
                                                        and b.xnm = vXnm
                                                        and b.dxqm = vXqm)
                              WHERE fjxb_id is null
                                and xnm=vXnm
                                and dxqm=vXqm
                                and njdm_id=vnjdm_id
                                and  zyh_id=vzyh_Id
                                and bh_id=vbh_id
                                and EXISTS
                                (SELECT 'x' FROM jw_pk_tjkbjglsb c
                                           WHERE a.xnm = c.xnm
                                             and a.xqm = c.xqm
                                             and a.njdm_id = c.njdm_id
                                             and a.zyh_id = c.zyh_id
                                             and a.bh_id = c.bh_id
                                             and a.tjkbzdm = c.tjkbzdm
                                             and a.kch_id = c.kch_id
                                             and a.jxb_id = c.jxb_id
                                             and a.zyfx_id = c.zyfx_id
                                             and c.xnm = vXnm
                                             and c.dxqm = vXqm);

        commit;
      exception
        When others then
          Rollback;
          Goto ExSecend;
      end;
     else
       Goto ExSecend;
     end if;
  end loop;
  close get_RwKbzxx;
  i:=i+1;
  Goto NextSecReCord;
  <<ExSecend>>
  null;

  -------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------
  -------------------------------------第三部处理--------------------------------------------

----------------------------------------------------------------------------------------------------------------------
  open get_RwKbwzxx;
  fetch get_RwKbwzxx into Cur_RwKbwzxx;
   v_wzjls:=Cur_RwKbwzxx.wzjls;
  if v_wzjls = 0 then
     insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
                        select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,0 tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from
                         jw_pk_tjkbdmb where xnm=vXnm
                                         and dxqm=vXqm
                                         and njdm_id=vnjdm_id
                                         and zyh_id=vzyh_Id
                                         and bh_id=vbh_id;
     commit;

     close get_RwKbwzxx;
     else
      insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
      select b.xnm,b.dxqm,b.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.tjkbzdm,a.tjkbzxsdm,b.kch_id,b.jxb_id,b.fjxb_id,b.xsdm,b.zyfx_id,a.rs
                     from jw_pk_tjkbjgb a ,jw_pk_tjkbdmb b where a.xnm=vXnm
                                                             and a.dxqm=vXqm
                                                             and a.zyh_id=vzyh_Id
                                                             and a.bh_id=vbh_id
                                                             and a.njdm_id=vnjdm_id
                                                             and b.rs <> '0'
                                                             and a.fjxb_id is null
                                                             and a.kch_id <> b.kch_id
                                                             and a.xnm = b.xnm
                                                             and a.xqm = b.xqm
                                                             and a.njdm_id = b.njdm_id
                                                             and a.zyh_id = b.zyh_id
                                                             and a.bh_id = b.bh_id
                                                             and a.tjkbzdm = b.tjkbzdm
                                                             and b.xnm = vXnm
                                                             and b.dxqm = vXqm
      group by b.xnm,b.dxqm,b.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.tjkbzdm,a.tjkbzxsdm,b.kch_id,b.jxb_id,b.fjxb_id,b.xsdm,b.zyfx_id,a.rs
      order by b.xnm,b.dxqm,b.xqm,b.njdm_id,b.zyh_id,b.bh_id,b.tjkbzdm,a.tjkbzxsdm,b.kch_id;


      insert into jw_pk_tjkbjgb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,tjkbzxsdm,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs)
      select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,'0',kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs from
             jw_pk_tjkbdmb a where a.xnm=vXnm
                               and a.dxqm = vXqm
                               and a.zyh_id=vzyh_Id
                               and a.bh_id=vbh_id
                               and a.njdm_id=vnjdm_id
                               and exists
                               (select 'X' from
                                 (select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,zyfx_id from
                                                  jw_pk_tjkbdmb where rs <> 0
                                                                  and xnm = vXnm
                                                                  and dxqm = vXqm
                                  minus
                                  select xnm,xqm,njdm_id,zyh_id,bh_id,tjkbzdm,kch_id,jxb_id,zyfx_id from
                                                  jw_pk_tjkbjgb where fjxb_id is null
                                                                  and xnm = vXnm
                                                                  and dxqm = vXqm
                                 ) b where a.xnm = b.xnm
                                       and a.xqm = b.xqm
                                       and a.njdm_id = b.njdm_id
                                       and a.zyh_id = b.zyh_id
                                       and a.bh_id = b.bh_id
                                       and a.tjkbzdm = b.tjkbzdm
                                       and a.kch_id = b.kch_id
                                       and a.jxb_id = b.jxb_id
                                       and a.zyfx_id = b.zyfx_id );

  commit;
  end if;
  end if;
-----------------------------------------------------------------------------------------------------------------------
  begin
     delete from jw_pk_cshztb where xnm = vXnm
                                and dxqm= vXqm
                                and bj in ('1', '2')
                                and njdm_id = vNjdm_id
                                and zyh_id = vZyh_id
                                and bh_id = vbh_id;
     commit;
    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,1 bj from jw_pk_tjkbjgb    -----已初始化状态
    where xnm = vXnm
      and dxqm = vXqm
      and njdm_id = vNjdm_id
      and zyh_id = vZyh_id
      and bh_id = vbh_id;

    insert into jw_pk_cshztb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,bj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,'2' bj from jw_pk_jxrwlsb t1 -----已初始但有新教学任务状态
           where t1.xnm = vXnm
             and t1.dxqm =vXqm
             and t1.fjxb_id is null
             and t1.zyh_id = vZyh_id
             and t1.njdm_id = vNjdm_id
             and t1.bh_id = vBh_id
             and not exists (select 'X' from jw_pk_tjkbjgb t2
                                       where t1.jxb_id = t2.jxb_id
                                         and t1.njdm_id = t2.njdm_id
                                         and t1.zyh_id = t2.zyh_id
                                         and t1.bh_id = t2.bh_id
                                         and t2.xnm = t1.xnm
                                         and t2.xqm = t1.xqm
                                         and t2.xnm = vXnm
                                         and t2.dxqm = vXqm);
    commit;
  end;
end;

/

