create Function Get_WeeksDesczyw(vWeeksBinary in integer,vZyw varchar2) ---周二进制流对应十进制数
Return varchar2
as
begin
  if vZyw='en_US' then
    return Get_BinaryDesc(vWeeksBinary, 'week'); ---生成周信息
  else
    return Get_BinaryDesc(vWeeksBinary, '周'); ---生成周信息
  end if;
end;

/

