create function get_xsxjyjjg(
vXnm varchar2,--学年码
vXqm varchar2, --学期码
vXh_id varchar2,--学号
vXxdm varchar2,--学校dm
vBj varchar2
)
return varchar2 is
sYjlbm varchar2(20);
sDqYjlbm varchar2(20);--当前预警类别
iLxxq integer;--连续学期
cxcs integer;--出现次数
igs integer;--预警的个数
ijb integer;
iDqjb integer;--当前级别
iSjjb integer;--升级级别
sSjjglb varchar2(20);--升级预警类别
sDqjgid varchar2(1000);--返回对应的xyyjjg_id
iYjsfyx integer (10);--预警是否有效的的个数
sGdyjbl varchar2 (10);--过渡预警变量
cursor Get_XsXjyjlb is     ----取学生学籍预警类别。----游标---
select a.yjlbm ,(select yjjb from jw_cj_xyyjjbszb where yjlbm = a.yjlbm) as jb,
    count(a.yjlbm) as gs  from ( select distinct a.yjlbm ,(select yjjb from jw_cj_xyyjjbszb where yjlbm = a.yjlbm) as jb
    from jw_cj_xyyjjgb a
    where a.tjxnm = vXnm
      and a.tjxqm = vXqm
      and a.xh_id = vXh_id
   group by a.yjlbm)a
group by a.yjlbm;

Cur_XsXjyjlb Get_XsXjyjlb%rowtype;

cursor Get_XsXjyjlcxx is     ----取学生学籍预警历次（相同预警类别）。----游标---
select distinct xnxqm from (
    select t.xnm||(case when t.xqm = '3'  then '1'
              when t.xqm = '12' then '2'
              when t.xqm = '16' then '3' else '' end) xnxqm,t.yjlbm,t.xh_id ,t.xyyjjg_id
    from jw_cj_xyyjcljgb t
    where t.xnm||lpad(t.xqm,2,'0')< vXnm||lpad(vXqm,2,'0')
      and t.xh_id = vXh_id
      and t.yjlbm in (
      select sjjglb as yjlbm from jw_cj_xyyjjbszb where yjlbm = sYjlbm
      union all
      select sYjlbm as yjlbm from dual
      union all
      select sjjglb as yjlbm from jw_cj_xyyjjbszb where yjlbm = (select sjjglb from jw_cj_xyyjjbszb where yjlbm = sYjlbm )
      )--获得该学生、对应的预警类别已处理的学年学期
    union all
    select tjxnm||(case when tjxqm = '3'  then '1'
              when tjxqm = '12' then '2'
              when tjxqm = '16' then '3' else '' end) xnxqm,t.yjlbm,t.xh_id,t.xyyjjg_id
    from jw_cj_xyyjjgb t
    where tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
      and t.xh_id = vXh_id
      and t.yjlbm = sYjlbm
      --and t.clzt = '0'
    ) t
order by t.xnxqm ASC;--获得该学生、对应的预警类别已统计的学年学期

Cur_XsXjyjlcxx Get_XsXjyjlcxx%rowtype;

axnxqm   varchar2(100) := '1';
bxnxqm   varchar2(100) := '1';
cxnxqm   varchar2(100) := '0';--学年学期之差
dxnxqm   varchar2(100) := '0';
begin
cxcs := 0;
sDqYjlbm := '0';
open Get_XsXjyjlb;
loop
fetch Get_XsXjyjlb into Cur_XsXjyjlb;
 exit when Get_XsXjyjlb%notfound;
 sYjlbm := Cur_XsXjyjlb.yjlbm;
 ijb  := Cur_XsXjyjlb.jb;
 igs :=  Cur_XsXjyjlb.gs;
 select lxxq,sjjglb,(select yjjb from jw_cj_xyyjjbszb where yjlbm = a.sjjglb) into iLxxq,sSjjglb,iSjjb
 from jw_cj_xyyjjbszb a
 where a.yjlbm = sYjlbm;--查询当前预警类别码的连续学期设置，升级预警类别设置

 if iLxxq is not null then --存在设置的连续学期
     open Get_XsXjyjlcxx;
      loop
        fetch Get_XsXjyjlcxx into Cur_XsXjyjlcxx;
         exit when Get_XsXjyjlcxx%notfound;
         axnxqm := Cur_XsXjyjlcxx.xnxqm;
        if bxnxqm = '1' then
        bxnxqm := axnxqm;
        continue;--如果是第一次判断学年学期则跳过
        else cxnxqm:=axnxqm-bxnxqm;

        end if;

        if cxnxqm = '1' or cxnxqm = '9' then--判断是否是连续学年学期
        cxcs:=cxcs+1;
        if dxnxqm != '0' then
           dxnxqm := dxnxqm||','||axnxqm;
        else
           dxnxqm := axnxqm||','||bxnxqm;
        end if;
        bxnxqm := axnxqm;
      /*  if  iLxxq = cxcs+1 then --如果连续次数到了，则跳出
          Goto Exend;
         end if;*/
        else
        Goto Exend;
         end if;

       end loop;
       <<Exend>>
       close Get_XsXjyjlcxx;

   if igs = 1 then --当前预警类别的个数
    if iLxxq = cxcs+1 then
     sDqYjlbm := sSjjglb;
     select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
     where yjlbm = sYjlbm
       and xh_id = vXh_id
       and instr(dxnxqm,tjxnm||(case when tjxqm = '3'  then '1'
                  when tjxqm = '12' then '2'
                  when tjxqm = '16' then '3' else '' end))>0;
     cxcs := 0;
     elsif  iLxxq < cxcs+1 then--指的是钱江学院的第三次及以上出现预警
         select sjjglb into sDqYjlbm from jw_cj_xyyjjbszb where yjlbm = sSjjglb;
         select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
         where yjlbm = sYjlbm
           and xh_id = vXh_id
           and instr(dxnxqm,tjxnm||(case when tjxqm = '3'  then '1'
                      when tjxqm = '12' then '2'
                      when tjxqm = '16' then '3' else '' end))>0;
     cxcs := 0;
     else
       sDqYjlbm := sYjlbm;
       select wm_concat(xyyjjg_id) into sDqjgid
        from jw_cj_xyyjjgb
        where yjlbm = sDqYjlbm
           and xh_id = vXh_id
           and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
        ;--如果只有单个预警并且不存在连续，返回当前预警的结果id
    end if;
  else --当前预警级别类别个数>1
    if sDqYjlbm = 0 then
      if iLxxq = cxcs+1 then
         iDqjb :=  iSjjb;
         sDqYjlbm := sSjjglb;
         cxcs := 0;
      elsif iLxxq < cxcs+1 then--指的是钱江学院的第三次及以上出现预警
         select sjjglb, yjjb into sDqYjlbm,iDqjb from jw_cj_xyyjjbszb where yjlbm = sSjjglb;
         cxcs := 0;
       else
         iDqjb :=  ijb;
         sDqYjlbm := sYjlbm;
      end if;
     else
       if iLxxq = cxcs+1 then
         if iSjjb > iDqjb then
           iDqjb :=  iSjjb;
           sDqYjlbm := sSjjglb;
           select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
           where yjlbm = sYjlbm
               and xh_id = vXh_id
               and instr(dxnxqm,tjxnm||(case when tjxqm = '3'  then '1'
                          when tjxqm = '12' then '2'
                          when tjxqm = '16' then '3' else '' end))>0;
           cxcs := 0;
         end if;
       elsif iLxxq < cxcs+1 then--指的是钱江学院的第三次出现预警
         select sjjglb, yjjb into sDqYjlbm,iDqjb from jw_cj_xyyjjbszb where yjlbm = sSjjglb;
         select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
         where yjlbm = sYjlbm
           and xh_id = vXh_id
           and instr(dxnxqm,tjxnm||(case when tjxqm = '3'  then '1'
                      when tjxqm = '12' then '2'
                      when tjxqm = '16' then '3' else '' end))>0;
          cxcs := 0;
       else
         if ijb > iDqjb then
           iDqjb :=  ijb;
           sDqYjlbm := sYjlbm;
           select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
           where yjlbm = sYjlbm
               and xh_id = vXh_id
               and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
         end if;
      end if;
     end if;
  end if;

 else--不存在连续的学年学期设置
  if sDqYjlbm = 0 then
     iDqjb :=  ijb;
     sDqYjlbm := sYjlbm;
     if vXxdm = '10248' then --上海交通大学
      select wm_concat(xyyjjg_id),count(*)  into sDqjgid ,igs
      from (select xyyjjg_id from jw_cj_xyyjjgb
          where yjlbm = sDqYjlbm
              and xh_id = vXh_id
              and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
           union all
          select xyyjjg_id
          from jw_cj_xyyjcljgb
          where yjlbm >= sDqYjlbm
          and xh_id = vXh_id
          and xnm||lpad(xqm,2,'0') < vXnm||lpad(vXqm,2,'0'));
         if igs > 2 then--若是含有2次以上直接退学处理
         sDqYjlbm := sSjjglb;
         end if;
      /*elsif  vXXdm = '10005' then --北京工业大学，预警为1，取消预警为-1，和为2时，做退学处理
           select sum(nvl(YJSFYX,0)) into iYjsfyx  from jw_cj_xyyjcljgb where xh_id = vXh_id and yjlbm = sYjlbm;
           if iYjsfyx >= 2 then
             sDqYjlbm := sSjjglb;
           end if; */
       elsif vXxdm = '10252' then --上海理工大学有过预警则升级预警
           select count(*)into  igs from jw_cj_xyyjcljgb where  xh_id = vXh_id and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0');
           select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb where yjlbm = sDqYjlbm and xh_id = vXh_id and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
           if igs > 0 then
               select yjlbm into sGdyjbl
               from (select yjlbm,row_number() over (partition by yjlbm order by yjlbm asc ) rn
                from jw_cj_xyyjcljgb
                where  xh_id = vXh_id
                and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0'))
                where rn = 1;
               if sDqYjlbm >= sGdyjbl then
                  select wm_concat(xyyjjg_id) into sDqjgid
                  from (select xyyjjg_id from jw_cj_xyyjjgb
                      where yjlbm = sDqYjlbm
                          and xh_id = vXh_id
                          and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
                       union all
                      select xyyjjg_id
                      from jw_cj_xyyjcljgb
                      where yjlbm = sGdyjbl
                      and xh_id = vXh_id
                      and xnm||lpad(xqm,2,'0') < vXnm||lpad(vXqm,2,'0'));
                      select SJJGLB into sDqYjlbm from jw_cj_xyyjjbszb where yjlbm = sGdyjbl;
               end if;
           end if;
        elsif vXxdm = '10427' then --济南大学
          select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb where yjlbm >= sDqYjlbm
              and xh_id = vXh_id and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
          select count(*) into  igs from jw_cj_xyyjcljgb where  xh_id = vXh_id
                 and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0') and yjlbm = sDqYjlbm and sfqr = '1';
          if sSjjglb is not null and igs >= 1 then
            select wm_concat(xyyjjg_id) into sDqjgid
             from (select xyyjjg_id from jw_cj_xyyjjgb
              where yjlbm = sDqYjlbm
                  and xh_id = vXh_id
                  and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
               union all
              select xyyjjg_id
              from jw_cj_xyyjcljgb
              where yjlbm = sDqYjlbm
              and xh_id = vXh_id
              and xnm||lpad(xqm,2,'0') < vXnm||lpad(vXqm,2,'0'));
              sDqYjlbm := sSjjglb;
           end if;
        else
              select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
              where yjlbm >= sDqYjlbm
                 and xh_id = vXh_id
                 and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
         end if;
     else
       if ijb > iDqjb then
         iDqjb :=  ijb;
         sDqYjlbm := sYjlbm;
         if vXxdm = '10252' then
            select count(*) into igs from jw_cj_xyyjcljgb where  xh_id = vXh_id and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0');
           select  wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb where yjlbm >= sDqYjlbm and xh_id = vXh_id and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
           if igs > 0 then
               select yjlbm into sGdyjbl
               from (select yjlbm,row_number() over (partition by yjlbm order by yjlbm asc ) rn
                from jw_cj_xyyjcljgb
                where  xh_id = vXh_id
                and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0'))
                where rn = 1;
               if sDqYjlbm >= sGdyjbl then
                  select wm_concat(xyyjjg_id) into sDqjgid
                  from (select xyyjjg_id from jw_cj_xyyjjgb
                      where yjlbm = sDqYjlbm
                          and xh_id = vXh_id
                          and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
                       union all
                      select xyyjjg_id
                      from jw_cj_xyyjcljgb
                      where yjlbm = sGdyjbl
                      and xh_id = vXh_id
                      and xnm||lpad(xqm,2,'0') < vXnm||lpad(vXqm,2,'0'));
                  select SJJGLB into sDqYjlbm from jw_cj_xyyjjbszb where yjlbm = sGdyjbl;
               end if;
           end if;
        elsif vXxdm = '10427' then --济南大学
          select count(*) into  igs from jw_cj_xyyjcljgb where  xh_id = vXh_id
                 and xnm||lpad(xqm,2,'0') <=vXnm||lpad(vXqm,2,'0') and yjlbm = sDqYjlbm and sfqr = '1';
          select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb where yjlbm = sDqYjlbm
              and xh_id = vXh_id and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
          if sSjjglb is not null and igs >= 1 then
            select wm_concat(xyyjjg_id) into sDqjgid
             from (select xyyjjg_id from jw_cj_xyyjjgb
                   where yjlbm = sDqYjlbm
                     and xh_id = vXh_id and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0')
                  union all
                  select xyyjjg_id
                  from jw_cj_xyyjcljgb
                  where yjlbm = sDqYjlbm
                  and xh_id = vXh_id
                  and xnm||lpad(xqm,2,'0') < vXnm||lpad(vXqm,2,'0'));
              sDqYjlbm := sSjjglb;
           end if;
         else
           select wm_concat(xyyjjg_id) into sDqjgid from jw_cj_xyyjjgb
           where yjlbm >= sDqYjlbm
             and xh_id = vXh_id
             and tjxnm||lpad(tjxqm,2,'0')= vXnm||lpad(vXqm,2,'0');
         end if;
       end if;
     end if;
 end if;
end loop;
close Get_XsXjyjlb;
return sDqYjlbm||'_'||sDqjgid;
null;
end get_xsxjyjjg;

/

