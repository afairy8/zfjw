create function fun_by_getpjxfj_zgcj(v_xh_id varchar2,v_lx varchar2,v_tjkcxz varchar2,v_btjkc varchar2)
Return varchar2
as
pjxfj varchar2(100);
sqlstr varchar2(4000);
begin
--------------计算最高成绩平均学分绩
sqlstr:= 'select to_char((case when t6.cj_zxf=0 then 0 else nvl(round(t6.zxfj/t6.cj_zxf,2),0) end),''fm9999999990.09'') from ('||
     ' select nvl(sum(to_number(nvl(xf,0))*to_number(nvl(bfzcj,0))),0) zxfj,'||
     ' nvl(sum(to_number(nvl((case when bfzcj is null then 0 else to_number(nvl(xf,0)) end),0))),0) cj_zxf  from '||
     ' (select a.kcxzdm,nvl(a.xf,''0'') xf,nvl(a.bfzcj,0) bfzcj,a.xh_id,a.kch_id,row_number() over(partition by a.xh_id, a.kch_id order by nvl(a.bfzcj,0) desc) rn '||
     ' from jw_cj_xscjb a where a.kcbj=''0'' and a.xh_id = '''||v_xh_id||''' and nvl(a.bfzcj,0) >= 60 '||
     ' and nvl(a.cjbz,''-1'')!=''缓考'' '||
     ' and not exists(select ''X'' from jw_cj_cjjglxsqb zfb where zfb.cjjglx = ''01'' and zfb.shzt = ''3'' and zfb.xh_id = a.xh_id and zfb.kch_id = a.kch_id) ';
     if v_lx='2' then
        sqlstr:= sqlstr||' and exists (select 1 from jw_jxrw_jxbhbxxb b, jw_jh_jxzxjhkcxxb c where b.jxb_id = a.jxb_id and c.zyh_id = b.zyh_id and c.njdm_id = b.njdm_id and
c.zyzgkcbj = ''1'') ';
     end if;
     sqlstr:= sqlstr||') e where rn = 1 ';
     if v_tjkcxz is not null and v_tjkcxz!='qb' then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||kcxzdm||'','' )>0 ';
     end if;
     if v_btjkc is not null then
        sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||kch_id||'','' )<1 ';
     end if;
     sqlstr:= sqlstr||' ) t6';
execute immediate sqlstr into pjxfj;
  return pjxfj;
end;

/

