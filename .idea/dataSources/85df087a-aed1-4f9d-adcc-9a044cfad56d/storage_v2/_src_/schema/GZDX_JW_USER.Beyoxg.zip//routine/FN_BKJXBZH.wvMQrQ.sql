create function fn_bkjxbzh(vJxb_id varchar2,vJgh_id varchar2,vBj varchar2) return varchar2  ---补考教学班组合----
as
   sJxbzh varchar2(2000);   ---补考教学班组合
begin
    sJxbzh := '无';
    begin
       if vBj = '0' then
          if vJgh_id is null then
            select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
             (select Jxbzh from
              (select  distinct (case when a.bh_id = 'wbj' then
                                       (select njmc from zftal_xtgl_njdmb where njdm_id=a.njdm_id)||
                                       (select zymc from zftal_xtgl_zydmb where zyh_id=a.zyh_id)
                                    when a.zyh_id = 'wzy' then '无'
                                    else (select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) end) Jxbzh
                  from jw_jxrw_jxbhbxxb a,jw_kw_bkmdb b where b.jxb_id= vJxb_id and a.jxb_id=b.yjxb_id and b.bkqrbj='1'
                ) order by Jxbzh
              );
          else
            select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
             (select Jxbzh from
              (select  distinct (case when a.bh_id = 'wbj' then
                                       (select njmc from zftal_xtgl_njdmb where njdm_id=a.njdm_id)||
                                       (select zymc from zftal_xtgl_zydmb where zyh_id=a.zyh_id)
                                    when a.zyh_id = 'wzy' then '无'
                                    else (select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) end) Jxbzh
                  from jw_jxrw_jxbhbxxb a,jw_kw_bkmdb b where b.jxb_id= vJxb_id and a.jxb_id=b.yjxb_id and b.bkqrbj='1' and b.jgh_id=vJgh_id
                ) order by Jxbzh
              );
          end if;
       end if;
       ---专业组合
       if vBj = '1' then
          if vJgh_id is null then
             select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
                 (select Jxbzh from
                  (select  distinct (case
                                       when a.zyh_id = 'wzy' then '无'
                                      else
                                        (select zymc from zftal_xtgl_zydmb where zyh_id = a.zyh_id)
                                      end) Jxbzh
                      from jw_jxrw_jxbhbxxb a,jw_kw_bkmdb b where b.jxb_id= vJxb_id and a.jxb_id=b.yjxb_id and b.bkqrbj='1'
                    ) order by Jxbzh
                  );
           else
             select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
                 (select Jxbzh from
                  (select  distinct (case
                                       when a.zyh_id = 'wzy' then '无'
                                      else
                                        (select zymc from zftal_xtgl_zydmb where zyh_id = a.zyh_id)
                                      end) Jxbzh
                      from jw_jxrw_jxbhbxxb a,jw_kw_bkmdb b where b.jxb_id= vJxb_id and a.jxb_id=b.yjxb_id and b.bkqrbj='1' and b.jgh_id=vJgh_id
                    ) order by Jxbzh
                  );
           end if;
        end if;
     exception
        When others then
          sJxbzh := '无0';
    end;
    if sJxbzh is null then
     return '无' ;
    else
    return sJxbzh ;
    end if ;
end fn_bkjxbzh;

/

