create trigger TRI_JW_XJGL_XSJLXMXSSQB
  before insert or update
  on JW_XJGL_XSJLXMXSSQB
  for each row
  begin

if inserting then
update jw_xjgl_xsxjxxb  h set h.xjztdm='06',h.sfzx='0' where xh_id=:new.xh_id and :new.shjg='3'
and xnm||xqm in( select v.xnm||v.xqm from jw_xjgl_xsjlxmsbb v where  v.xsjlxmsb_id in
( select b.xsjlxmsb_id from jw_xjgl_xsjlxmxssqb b where xh_id=:new.xh_id));
update jw_xjgl_xsjbxxb set xjztdm='06',sfzx='0' 
where xh_id=:new.xh_id and :new.shjg='3';
end if;

if updating then
update jw_xjgl_xsxjxxb  h set h.xjztdm='06',h.sfzx='0' where 
 h.xnm=(select zdz from zftal_xtgl_xtszb where zdm='DQXNM')and h.xqm=
(select zdz from zftal_xtgl_xtszb where zdm='DQXQM')
and xh_id=:old.xh_id and  :new.shjg='3';

update jw_xjgl_xsjbxxb set xjztdm='06',sfzx='0' where xh_id=:old.xh_id and :new.shjg='3';
end if;



end;
/

