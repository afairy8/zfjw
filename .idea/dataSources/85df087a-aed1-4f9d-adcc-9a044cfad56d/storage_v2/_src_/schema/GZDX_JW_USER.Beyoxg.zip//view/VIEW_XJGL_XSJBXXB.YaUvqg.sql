create view VIEW_XJGL_XSJBXXB as
  select xs.xh_id,
       xs.xh,
       xs.xm||' ('||xs.xh || ')' as xm,
       xj.jg_id,
       xj.x_id,
       xj.zyh_id,
       xj.bh_id,
       xj.njdm_id
  from jw_xjgl_xsjbxxb xs, jw_xjgl_xsxjxxb xj
 where xs.xh_id = xj.xh_id
   and xj.xnm = (select zdz from zftal_xtgl_xtszb where zdm = 'DQXNM')
   and xj.xqm = (select zdz from zftal_xtgl_xtszb where zdm = 'DQXQM')
/

