create Procedure Pk_SetJxrwBrs
(
  vXnm in varchar2,
  vXqm in varchar2,
  vzyh_Id varchar2,
  vnjdm_id varchar2,
  vbh_id varchar2)
   is
--------------------------------------------------------------------------------
  sKbgsbj varchar2(8);----课表个数标记
begin
  select nvl((select zdz from jw_jcdml_xtnzb  where zdm = 'KBGSBJ'),0) into sKbgsbj from dual;
  if sKbgsbj != '1' then
 --补人数------------------------------------------------------begin------
 ---当推荐课表距阵没有被初始化时，排课任务表数据被删除----
  delete from jw_pk_jxrwb a Where a.xnm  = vXnm
                              and a.dxqm = vXqm
                              and a.njdm_id = vnjdm_id
                              and a.zyh_id  = vzyh_Id
                              and a.bh_id   = vbh_id
                              and not exists(select 'X' from jw_pk_tjkbjgb b
                                                        where b.xnm  = vXnm
                                                          and b.dxqm = vXqm
                                                          and a.xnm  = b.xnm
                                                          and a.xqm  = b.xqm
                                                          and a.njdm_id = b.njdm_id
                                                          and a.zyh_id  = b.zyh_id
                                                          and a.bh_id   = b.bh_id);

  delete from jw_pk_jxrwb a Where a.xnm  = vXnm
                              and a.dxqm = vXqm
                              and a.njdm_id = vnjdm_id
                              and a.zyh_id  = vzyh_Id
                              and a.bh_id   = vbh_id
                              and not exists(select 'X' from jw_pk_jxrwlsb b
                                                        where b.xnm  = vXnm
                                                          and b.dxqm = vXqm
                                                          and a.xnm  = b.xnm
                                                          and a.xqm  = b.xqm
														  and a.jxb_id = b.jxb_id
                                                          and a.njdm_id = b.njdm_id
                                                          and a.zyh_id  = b.zyh_id
                                                          and a.bh_id   = b.bh_id);
  ---当推荐课表距阵没有被初始化时，排课推荐课表数据被删除----
  delete from jw_pk_tjkbdmb a Where a.xnm  = vXnm
                                and a.dxqm = vXqm
                                and a.njdm_id = vnjdm_id
                                and a.zyh_id  = vzyh_Id
                                and a.bh_id   = vbh_id
                                and not exists(select 'X' from jw_pk_tjkbjgb b
                                                     where b.xnm  =vXnm
                                                       and b.dxqm =vXqm
                                                       and a.xnm  = b.xnm
                                                       and a.xqm  = b.xqm
                                                       and a.njdm_id = b.njdm_id
                                                       and a.zyh_id  = b.zyh_id
                                                       and a.bh_id   = b.bh_id);

	delete from jw_pk_tjkbdmb a Where a.xnm  = vXnm
                                and a.dxqm = vXqm
                                and a.njdm_id = vnjdm_id
                                and a.zyh_id  = vzyh_Id
                                and a.bh_id   = vbh_id
                                and not exists(select 'X' from jw_pk_jxrwlsb b
                                                     where b.xnm  =vXnm
                                                       and b.dxqm =vXqm
                                                       and a.xnm  = b.xnm
                                                       and a.xqm  = b.xqm
													   and a.jxb_id = b.jxb_id
                                                       and a.njdm_id = b.njdm_id
                                                       and a.zyh_id  = b.zyh_id
                                                       and a.bh_id   = b.bh_id);

  ---当推荐课表距阵被初始化但没有排课时，排课任务表数据原始人数更新人数字段信息----
  update jw_pk_jxrwb a set a.rs = a.ysrs Where
                       a.xnm=vXnm
                   and a.dxqm=vXqm
                   and a.njdm_id = vnjdm_id
                   and a.zyh_id = vzyh_Id
                   and a.bh_id = vbh_id
                   and exists(select 'X' from jw_pk_tjkbjgb b
                                    where b.xnm=vXnm
                                      and b.dxqm=vXqm
                                      and a.xnm = b.xnm
                                      and a.xqm = b.xqm
                                      and a.njdm_id = b.njdm_id
                                      and a.zyh_id = b.zyh_id
                                      and a.bh_id = b.bh_id )
                   and not exists(select 'X' from jw_pk_kbsjb m,jw_jxrw_jxbhbxxb n
                                            where m.jxb_id = n.jxb_id
                                              and m.xnm = vXnm
                                              and bitand(m.xqm,vXqm) > 0
                                              and a.xnm = m.xnm
                                              and bitand(a.xqm, m.xqm) > 0
                                              and a.njdm_id = n.njdm_id
                                              and a.zyh_id = n.zyh_id
                                              and a.bh_id = n.bh_id );


   ---当推荐课表距阵被初始化但没有排课时，排课任务表数据原始人数更新人数字段信息----
  delete from jw_pk_tjkbdmb a Where
                    a.xnm=vXnm
                and a.dxqm=vXqm
                and a.njdm_id = vnjdm_id
                and a.zyh_id = vzyh_Id
                and a.bh_id = vbh_id
                and exists(select 'X' from jw_pk_tjkbjgb b
                               where b.xnm=vXnm
                                 and b.dxqm = vXqm
                                 and a.xnm = b.xnm
                                 and a.xqm = b.xqm
                                 and a.njdm_id = b.njdm_id
                                 and a.zyh_id = b.zyh_id
                                 and a.bh_id = b.bh_id)
                and not exists(select 'X' from jw_pk_kbsjb m,jw_jxrw_jxbhbxxb n
                                       where m.jxb_id = n.jxb_id
                                         and m.xnm = vXnm
                                         and bitand(m.xqm,vXqm) >0
                                         and a.xnm = m.xnm
                                         and bitand(a.xqm,m.xqm) >0
                                         and a.njdm_id = n.njdm_id
                                         and a.zyh_id  = n.zyh_id
                                         and a.bh_id   = n.bh_id);

  ---当推荐课表距阵没有被初始化时，排课推荐课表数据被删除----
  delete from jw_pk_tjkbjgb a Where a.xnm=vXnm
                                and a.dxqm=vXqm
                                and a.njdm_id = vnjdm_id
                                and a.zyh_id = vzyh_Id
                                and a.bh_id = vbh_id
                                and not exists(select 'X' from jw_pk_kbsjb m,jw_jxrw_jxbhbxxb n
                                                     where m.jxb_id = n.jxb_id
                                                       and m.xnm = vXnm
                                                       and bitand(m.xqm,vXqm) > 0
                                                       and a.xnm = m.xnm
                                                       and bitand(a.xqm,m.xqm) >0
                                                       and a.njdm_id = n.njdm_id
                                                       and a.zyh_id  = n.zyh_id
                                                       and a.bh_id   = n.bh_id );

  insert into jw_pk_jxrwb(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id ,jxb_id,fjxb_id,xsdm,rs,ysrs)
  select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id ,jxb_id,fjxb_id,xsdm,rs,rs from
   (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id ,jxb_id,fjxb_id,xsdm,yrs,--rs,--zrs,glzzrs,zzrs,
       case when zyfx_id <> 'wfx' and zzrs = glzzrs then rs --当有专业方向，最终人数等于有方向求和最终人数时，直接取处理后的人数
            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs = 1
              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"1个，对专业方向人数最小"rn1"的补余数
              then   trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs) + rs
            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs > 1 and rn2 = 1
              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对专业方向人数最小"rn1"下的rn2补余数
              then trunc( (trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs))/zykcjxbs ) + mod(trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs),zykcjxbs) + rs
            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs > 1
              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对专业方向人数最小"rn1"下的rn2不为1取整
              then trunc( (trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs) )/zykcjxbs ) + rs
            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and zykcjxbs > 1 and rn2 = 1
              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对一专业方向人数最小rn2为1补余数
              then trunc( trunc( (zzrs - glzzrs)/kcjxbs) /zykcjxbs ) + mod(trunc( (zzrs - glzzrs)/kcjxbs),zykcjxbs) + rs
            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and zykcjxbs > 1
              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对一专业方向人数最小rn2不为1取整
              then trunc( trunc( (zzrs - glzzrs)/kcjxbs)/zykcjxbs ) + rs
            when zyfx_id <> 'wfx' and zzrs <> glzzrs
              --当有专业方向，最终人数不等于有方向求和最终人数，只给专业方向补人数，对专业方向人数取整
              then trunc( trunc( (zzrs - glzzrs)/kcjxbs) /zykcjxbs ) + rs
            when zzrs = zrs
              then rs     -----当课表最大课程人数 等于 当前课程总人数时 教学班人数不变
            when zyfx_id = 'wfx' and rn = 1 and zzrs<> zrs
              then trunc( (zzrs - zrs)/kcjxbs)+ mod((zzrs - zrs),kcjxbs) + rs  ----同一课程内教学班人数最小的一行 当 课表最大课程人数 不等于 当前课程总人数时 应补人数 平均分配的补充人数 外加上剩余人数 按最小的补余 再加上本身人数
            when zyfx_id = 'wfx'
              then  trunc( (zzrs - zrs)/kcjxbs) + rs
            else 0 end rs from
       (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,rs,zrs,zzrs glzzrs,
               max(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,rn,rn1,rn2,kcjxbs,zykcjxbs from
          (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs yrs,rs,zrs,
                  max(zrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,  ---课表内课程求和后的最大人数
                  row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id order by to_number(rs)) rn, ---课表课程内教学班人数最小的按第一排序
                  0 rn1,0 rn2,
                  count(*) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id ) kcjxbs   ----课表课程内教学班数-------------
                  ,0 zykcjxbs from
            (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                    sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id ) zrs from  ---课程求和人数
              (select t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.kch_id ,t1.jxb_id,t1.fjxb_id,t1.xsdm,t1.zyfx_id,t1.rs from
                      jw_pk_jxrwlsb t1 where t1.xnm=vXnm
                                         and t1.dxqm=vXqm
                                         and t1.njdm_id = vnjdm_id
                                         and t1.zyh_id = vzyh_id
                                         and t1.bh_id = vbh_id
                                         and not exists (select 'X' from jw_pk_jxrwyclsb t2
                                                         where t2.xnm=vXnm
                                                           and t2.dxqm=vXqm
                                                           and t2.njdm_id = vnjdm_id
                                                           and t2.zyh_id = vzyh_id
                                                           and t2.bh_id = vbh_id
                                                           and t1.xnm = t2.xnm
                                                           and t1.xqm = t2.xqm
                                                           and t1.njdm_id = t2.njdm_id
                                                           and t1.zyh_id = t2.zyh_id
                                                           and t1.bh_id = t2.bh_id )
                                         and not exists(select 'X' from jw_pk_tjkbjgb t3
                                                         where t3.xnm=vXnm
                                                           and t3.dxqm=vXqm
                                                           and t3.njdm_id = vnjdm_id
                                                           and t3.zyh_id = vzyh_id
                                                           and t3.bh_id = vbh_id
                                                           and t1.xnm = t3.xnm
                                                           and t1.xqm = t3.xqm
                                                           and t1.njdm_id = t3.njdm_id
                                                           and t1.zyh_id = t3.zyh_id
                                                           and t1.bh_id = t3.bh_id)
               ) where  fjxb_id is null  and zyfx_id = 'wfx'
              )
             union all
             select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id ,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,rs,zrs,
                    max(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,
                    rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id
                                    order by to_number(zrs)) rn, ---课表课程内教学班人数最小的按第一排序
                    rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id
                                    order by to_number(zrs),zyfx_id) rn1,---控制当专业方向人数不能平均分配时，只给一个专业方向补余数
                    row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                          order by to_number(rs),jxb_id ) rn2,
                                 count(distinct zyfx_id) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id ) kcjxbs   ----课表课程内教学班数（专业方向数）-------------
                                 ,zykcjxbs from
                  (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id ,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,
                                               case when zzrs = zrs then yrs     -----当课表最大课程人数 等于 当前课程总人数时 教学班人数不变
                                               when rn = 1 and zzrs<> zrs  then trunc((zzrs - zrs)/zykcjxbs)+ mod((zzrs - zrs),zykcjxbs) + yrs  ----同一课程内教学班人数最小的一行 当 课表最大课程人数 不等于 当前课程总人数时 应补人数 平均分配的补充人数 外加上剩余人数 按最小的补余 再加上本身人数
                                               else  trunc( (zzrs - zrs)/zykcjxbs) + yrs end rs ,zzrs zrs,
                                               sum(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,rn1 ) zzrs   ---其他情况 平均分配的补充人数 加上本身人数
                                               ,zykcjxbs from
                   (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id, rs yrs,zrs,
                           max(zrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id ) zzrs,  ---取出不同专业方向最大人数---
                           count(distinct jxb_id) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id ) zykcjxbs,
                           row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                                 order by to_number(rs),jxb_id ) rn,
                           row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id
                                                 order by to_number(rs) desc ) rn1 from
                      (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                              sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id ) zrs from ---取出同课程同专业方向求和人数
                         (select t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.kch_id ,t1.jxb_id,t1.fjxb_id,t1.xsdm,t1.zyfx_id,t1.rs from
                                 jw_pk_jxrwlsb t1 where t1.xnm=vXnm
                                                    and t1.dxqm=vXqm
                                                    and t1.njdm_id = vnjdm_id
                                                    and t1.zyh_id = vzyh_id
                                                    and t1.bh_id = vbh_id
                                                    and not exists (select 'X' from jw_pk_jxrwyclsb t2
                                                                              where t2.xnm=vXnm
                                                                                and t2.dxqm=vXqm
                                                                                and t2.njdm_id = vnjdm_id
                                                                                and t2.zyh_id = vzyh_id
                                                                                and t2.bh_id = vbh_id
                                                                                and t1.xnm = t2.xnm
                                                                                and t1.xqm = t2.xqm
                                                                                and t1.njdm_id = t2.njdm_id
                                                                                and t1.zyh_id = t2.zyh_id
                                                                                and t1.bh_id = t2.bh_id )
                                                   and not exists(select 'X' from jw_pk_tjkbjgb t3
                                                                            where t3.xnm=vXnm
                                                                              and t3.dxqm=vXqm
                                                                              and t3.njdm_id = vnjdm_id
                                                                              and t3.zyh_id = vzyh_id
                                                                              and t3.bh_id = vbh_id
                                                                              and t1.xnm = t3.xnm
                                                                              and t1.xqm = t3.xqm
                                                                              and t1.njdm_id = t3.njdm_id
                                                                              and t1.zyh_id = t3.zyh_id
                                                                              and t1.bh_id = t3.bh_id )
                          )  where fjxb_id is null
                               and zyfx_id <> 'wfx'
                       )
                     )
                  )
       )
     ) --order by kch_id,zyfx_id,yrs,rs
   union all
   ----begin-------------------------------------------------只存在子学时的教学任务，通过主任务的总人数平均分配到每个子学时教学班人数内---------------------------------------------
   select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id ,jxb_id,fjxb_id,xsdm,rs yrs,--rs,zrs,rn,kcjxbs,zzrs,
       case when zzrs = zrs then rs     -----当课表最大课程人数 等于 当前课程总人数时 教学班人数不变
            when rn =1 and zzrs<> zrs then trunc( (zzrs - zrs)/kcjxbs)+ mod((zzrs - zrs),kcjxbs) + rs  ----同一课程内教学班人数最小的一行 当 课表最大课程人数 不等于 当前课程总人数时 应补人数 平均分配的补充人数 外加上剩余人数 按最小的补余 再加上本身人数
            else trunc((zzrs - zrs)/kcjxbs) + rs end rs from    ---其他情况 平均分配的补充人数 加上本身人数  --,zrs
     (select a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.zyfx_id,a.rs,a.zrs,a.rn,a.kcjxbs,b.rs zzrs from
       (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,zrs,
               row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,xsdm,kch_id,fjxb_id,zyfx_id
                                     order by to_number(rs) asc ) rn, ---课表课程内教学班人数最小的按第一排序
               count(*) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,xsdm,kch_id,fjxb_id,zyfx_id ) kcjxbs from ----课表课程内教学班数-------------
          (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                  sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,xsdm,kch_id,fjxb_id,zyfx_id ) zrs from  ---课表课程实时求和人数
           (select t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.kch_id ,t1.jxb_id,t1.fjxb_id,t1.xsdm,t1.zyfx_id,t1.rs from
                   jw_pk_jxrwlsb t1 where t1.xnm=vXnm
                                      and t1.dxqm=vXqm
                                      and t1.njdm_id = vnjdm_id
                                      and t1.zyh_id = vzyh_id
                                      and t1.bh_id = vbh_id
                                      and not exists(select 'X' from jw_pk_jxrwyclsb t2
                                                               where t2.xnm=vXnm
                                                                 and t2.dxqm=vXqm
                                                                 and t2.njdm_id = vnjdm_id
                                                                 and t2.zyh_id = vzyh_id
                                                                 and t2.bh_id = vbh_id
                                                                 and t1.xnm = t2.xnm
                                                                 and t1.xqm = t2.xqm
                                                                 and t1.njdm_id = t2.njdm_id
                                                                 and t1.zyh_id = t2.zyh_id
                                                                 and t1.bh_id = t2.bh_id )
                                      and not exists(select 'X' from jw_pk_tjkbjgb t3
                                                               where t3.xnm=vXnm
                                                                 and t3.dxqm=vXqm
                                                                 and t3.njdm_id = vnjdm_id
                                                                 and t3.zyh_id = vzyh_id
                                                                 and t3.bh_id = vbh_id
                                                                 and t1.xnm = t3.xnm
                                                                 and t1.xqm = t3.xqm
                                                                 and t1.njdm_id = t3.njdm_id
                                                                 and t1.zyh_id = t3.zyh_id
                                                                 and t1.bh_id = t3.bh_id )
           )  where fjxb_id is not null
                and xsdm is not null
         )
        ) a,
         ----begin-----------------------------------------------无学时教学任务信息补任务人数--------------------------------------------------------------
        (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id ,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,--rs,--zrs,glzzrs,zzrs,
                       case when zyfx_id <> 'wfx' and zzrs = glzzrs then rs --当有专业方向，最终人数等于有方向求和最终人数时，直接取处理后的人数
                            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs = 1
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"1个，对专业方向人数最小"rn1"的补余数
                              then trunc((zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs) + rs
                            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs > 1 and rn2 = 1
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对专业方向人数最小"rn1"下的rn2补余数
                              then trunc((trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs))/zykcjxbs ) + mod(trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs),zykcjxbs) + rs
                            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and mod((zzrs - glzzrs),kcjxbs) >0 and rn1 = 1 and zykcjxbs > 1
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对专业方向人数最小"rn1"下的rn2不为1取整
                              then trunc((trunc( (zzrs - glzzrs)/kcjxbs)+ mod((zzrs - glzzrs),kcjxbs) )/zykcjxbs ) + rs
                            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and zykcjxbs > 1 and rn2 = 1
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对一专业方向人数最小rn2为1补余数
                              then trunc(trunc( (zzrs - glzzrs)/kcjxbs) /zykcjxbs ) + mod(trunc( (zzrs - glzzrs)/kcjxbs),zykcjxbs) + rs
                            when rn = 1 and zyfx_id <> 'wfx' and zzrs <> glzzrs and zykcjxbs > 1
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给一个"rn"专业方向补人数且专业方向课程教学班数为"zykcjxbs"大于1个，对一专业方向人数最小rn2不为1取整
                              then trunc(trunc( (zzrs - glzzrs)/kcjxbs)/zykcjxbs ) + rs
                            when zyfx_id <> 'wfx' and zzrs <> glzzrs
                              --当有专业方向，最终人数不等于有方向求和最终人数，只给专业方向补人数，对专业方向人数取整
                              then trunc(trunc( (zzrs - glzzrs)/kcjxbs) /zykcjxbs ) + rs
                            when zzrs = zrs
                              then rs     -----当课表最大课程人数 等于 当前课程总人数时 教学班人数不变
                            when zyfx_id = 'wfx' and rn = 1 and zzrs<> zrs
                              then trunc((zzrs - zrs)/kcjxbs)+ mod((zzrs - zrs),kcjxbs) + rs  ----同一课程内教学班人数最小的一行 当 课表最大课程人数 不等于 当前课程总人数时 应补人数 平均分配的补充人数 外加上剩余人数 按最小的补余 再加上本身人数
                            when zyfx_id = 'wfx'
                              then  trunc((zzrs - zrs)/kcjxbs) + rs
                            else 0 end rs from
           (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,rs,zrs,zzrs glzzrs,
                    max(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,rn,rn1,rn2,kcjxbs,zykcjxbs from
              (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs yrs,rs,zrs,
                      max(zrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,  ---课表内课程求和后的最大人数
                      row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id order by to_number(rs)) rn, ---课表课程内教学班人数最小的按第一排序
                      0 rn1,0 rn2,
                      count(*) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id ) kcjxbs,   ----课表课程内教学班数-------------
                      0 zykcjxbs from
                (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id, rs,
                        sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id ) zrs  from ---课程求和人数
                   (select t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.kch_id ,t1.jxb_id,t1.fjxb_id,t1.xsdm,t1.zyfx_id,t1.rs from
                            jw_pk_jxrwlsb t1 where t1.xnm=vXnm
                                               and t1.dxqm=vXqm
                                               and t1.njdm_id = vnjdm_id
                                               and t1.zyh_id = vzyh_id
                                               and t1.bh_id = vbh_id
                                               and not exists(select 'X' from jw_pk_jxrwyclsb t2
                                                                        where t2.xnm=vXnm
                                                                          and t2.dxqm=vXqm
                                                                          and t2.njdm_id = vnjdm_id
                                                                          and t2.zyh_id = vzyh_id
                                                                          and t2.bh_id = vbh_id
                                                                          and t1.xnm = t2.xnm
                                                                          and t1.xqm = t2.xqm
                                                                          and t1.njdm_id = t2.njdm_id
                                                                          and t1.zyh_id = t2.zyh_id
                                                                          and t1.bh_id = t2.bh_id )
                                               and not exists(select 'X' from jw_pk_tjkbjgb t3
                                                                        where t3.xnm=vXnm
                                                                          and t3.dxqm=vXqm
                                                                          and t3.njdm_id = vnjdm_id
                                                                          and t3.zyh_id = vzyh_id
                                                                          and t3.bh_id = vbh_id
                                                                          and t1.xnm = t3.xnm
                                                                          and t1.xqm = t3.xqm
                                                                          and t1.njdm_id = t3.njdm_id
                                                                          and t1.zyh_id = t3.zyh_id
                                                                          and t1.bh_id = t3.bh_id )
                    )  where  fjxb_id is null  and zyfx_id = 'wfx'
                   )
                   ------------------
                   union all
                   -------------------
                   select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id ,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,rs,zrs,
                          max(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id) zzrs,
                          rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id
                                          order by to_number(zrs)) rn, ---课表课程内教学班人数最小的按第一排序
                          rank() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id
                                          order by to_number(zrs),zyfx_id) rn1,---控制当专业方向人数不能平均分配时，只给一个专业方向补余数
                          row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                                order by to_number(rs),jxb_id ) rn2,
                          count(distinct zyfx_id) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id ) kcjxbs,   ----课表课程内教学班数（专业方向数）-------------
                          zykcjxbs from
                   (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id ,jxb_id,fjxb_id,xsdm,zyfx_id,yrs,
                           case when zzrs = zrs then yrs     -----当课表最大课程人数 等于 当前课程总人数时 教学班人数不变
                           when rn = 1 and zzrs<> zrs  then trunc((zzrs - zrs)/zykcjxbs)+ mod((zzrs - zrs),zykcjxbs) + yrs  ----同一课程内教学班人数最小的一行 当 课表最大课程人数 不等于 当前课程总人数时 应补人数 平均分配的补充人数 外加上剩余人数 按最小的补余 再加上本身人数
                           else  trunc((zzrs - zrs)/zykcjxbs) + yrs end rs ,zzrs zrs,
                           sum(zzrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,rn1 ) zzrs   ---其他情况 平均分配的补充人数 加上本身人数
                           ,zykcjxbs from
                      (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id, rs yrs,zrs,
                              max(zrs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id ) zzrs,  ---取出不同专业方向最大人数---
                              count(distinct jxb_id) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id) zykcjxbs,
                              row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id
                                                    order by to_number(rs),jxb_id ) rn,
                              row_number() over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,zyfx_id
                                                    order by to_number(rs) desc ) rn1 from
                           (select xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,kch_id,jxb_id,fjxb_id,xsdm,zyfx_id,rs,
                                   sum(rs) over(partition by xnm,dxqm,njdm_id,zyh_id,bh_id,kch_id,zyfx_id) zrs from   ---取出同课程同专业方向求和人数
                              (select t1.xnm,t1.dxqm,t1.xqm,t1.njdm_id,t1.zyh_id,t1.bh_id,t1.kch_id ,t1.jxb_id,t1.fjxb_id,t1.xsdm,t1.zyfx_id,t1.rs from
                                      jw_pk_jxrwlsb t1 where t1.xnm=vXnm
                                                         and t1.dxqm=vXqm
                                                         and t1.njdm_id = vnjdm_id
                                                         and t1.zyh_id = vzyh_id
                                                         and t1.bh_id = vbh_id
                                                         and not exists(select 'X' from jw_pk_jxrwyclsb t2
                                                                                  where t2.xnm=vXnm
                                                                                    and t2.dxqm=vXqm
                                                                                    and t2.njdm_id = vnjdm_id
                                                                                    and t2.zyh_id = vzyh_id
                                                                                    and t2.bh_id = vbh_id
                                                                                    and t1.xnm = t2.xnm
                                                                                    and t1.xqm = t2.xqm
                                                                                    and t1.njdm_id = t2.njdm_id
                                                                                    and t1.zyh_id = t2.zyh_id
                                                                                    and t1.bh_id = t2.bh_id)
                                                         and not exists(select 'X' from jw_pk_tjkbjgb t3
                                                                                  where t3.xnm=vXnm
                                                                                    and t3.xqm=vXqm
                                                                                    and t3.njdm_id = vnjdm_id
                                                                                    and t3.zyh_id = vzyh_id
                                                                                    and t3.bh_id = vbh_id
                                                                                    and t1.xnm = t3.xnm
                                                                                    and t1.xqm = t3.xqm
                                                                                    and t1.njdm_id = t3.njdm_id
                                                                                    and t1.zyh_id = t3.zyh_id
                                                                                    and t1.bh_id = t3.bh_id)
                                 )  where fjxb_id is null
                                      and zyfx_id <> 'wfx'
                            )
                          )
                     )
                 )
           ) --order by kch_id,zyfx_id,yrs,rs
      ------end-----------------------------------------------无子学时教学任务信息补任务人数--------------------------------------------------------------
        ) b where a.xnm = b.xnm
              and a.xqm = b.xqm
              and a.njdm_id = b.njdm_id
              and a.zyh_id = b.zyh_id
              and a.bh_id = b.bh_id
              and a.kch_id =b.kch_id
              and a.fjxb_id = b.jxb_id
              and a.zyfx_id = b.zyfx_id
   )
    ---------
  )
 -- order by kch_id,fjxb_id,zyfx_id,jxb_id
  ;
 ------end---------------------只存在子学时的教学任务，通过主任务的总人数平均分配到每个子学时教学班人数内-------------------------
 commit;
  --补人数--------------------------------------------------------end------
 null;
end if;
-----------------------------------------------------------------------------------------------------------------------
end;

/

