create function fun_by_getbyreason(                     ----得到毕业学位审核不通过原因
v_xh_id  varchar2,
v_bynd   varchar2,
v_xdlx   varchar2              ----主修或者辅修:1-主修,2-辅修
)
Return varchar2
as
tname1   varchar2(200);        -----要查询的表名1
tname2   varchar2(200);        -----要查询的表名2
sqlstr   varchar2(4000);       -----执行语句
sqlstrx  varchar2(4000);       -----执行语句2
num      number;               -----数量
tjid     varchar2(32);         -----条件id
lsbl     varchar2(20);         -----临时变量
temp_jg  varchar2(4000);       -----临时结果
jg       varchar2(4000);       -----结果
begin
     if v_xh_id is not null and
        v_bynd is not null  and
        v_xdlx is not null  then
        if v_xdlx = '1'     then
          tname1:='jw_bygl_byshb';
          tname2:='jw_bygl_xwshb';
        else
          tname1:='jw_bygl_fxshb';
          tname2:='jw_bygl_fxxwshb';
        end if;

       for i in 1..20 loop
          if i<10 then
             lsbl := '0'||i;
          else
            lsbl := i;
          end if;
          sqlstr:= 'select count(*) from '||tname2||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and tj'||lsbl||'=''2'' and tj'||lsbl||'_id is not null';
            execute immediate sqlstr into num;
          if num >0 then
             sqlstrx:= 'select tj'||lsbl||'_id from '||tname2||' where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and tj'||lsbl||'=''2''';
             execute immediate sqlstrx into tjid;
             if tjid = '77777777' then
                sqlstr:= 'select wm_concat(b.mc) from jw_xjgl_xscfb a,zftal_xtgl_jcsjb b where a.cfdm=b.dm and b.lx=''0018'' and xh_id='''||v_xh_id||'''';
                execute immediate sqlstr into temp_jg;
               jg := jg||' '||temp_jg;
               end if;
             if tjid = '00000028' then
               sqlstr:= 'select wm_concat(distinct cjbz) from jw_cj_xscjb where xh_id='''||v_xh_id||''' and  cjbz like ''%作弊%''';
                execute immediate sqlstr into temp_jg;
               jg := jg||' '||temp_jg;
               end if;
          end if;
        end loop;
        sqlstr:= 'select count(*) from jw_bygl_byxsjfqkb where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and jfzt=''0'' and qfe is not null';
        execute immediate sqlstr into num;
        if num>0 then
           sqlstr:= 'select qfe from jw_bygl_byxsjfqkb where xh_id='''||v_xh_id||''' and bynd='''||v_bynd||''' and jfzt=''0''';
           execute immediate sqlstr into temp_jg;
           jg := jg||' '||temp_jg;
        end if;
     end if;
  return jg;
end;

/

