create view V_JX_KCJBXX as
  select kch kcdm,kcmc,xf,get_kczhxszh(kch_id,'') xs,zxs zhxs,kcywmc,'' WSJXZK,zwkcjj kcjj,'' kcxz,'' xxk,
       (select jgdm from zftal_xtgl_jgdmb where jg_id = t.kkbm_id) jlkcyxdm,'' jlsj from jw_jh_kcdmb t
/

