create view ZFTAL_SJCJ_BKXSRSTJ as
  select jg.jgmc,
       zy.zymc,
       zy.xz,
       sum(case
             when xj.njdm_id = '2014' then
              1
             else
              0
           end) nj2014,
       sum(case
             when xj.njdm_id = '2014' and xs.xbm = '2' then
              1
             else
              0
           end) nj2014ns,
       sum(case
             when xj.njdm_id = '2013' then
              1
             else
              0
           end) nj2013,
       sum(case
             when xj.njdm_id = '2013' and xs.xbm = '2' then
              1
             else
              0
           end) nj2013ns,
       sum(case
             when xj.njdm_id = '2012' then
              1
             else
              0
           end) nj2012,
       sum(case
             when xj.njdm_id = '2012' and xs.xbm = '2' then
              1
             else
              0
           end) nj2012ns,
       sum(case
             when xj.njdm_id = '2011' then
              1
             else
              0
           end) nj2011,
       sum(case
             when xj.njdm_id = '2011' and xs.xbm = '2' then
              1
             else
              0
           end) nj2011ns,
       sum(case
             when xj.njdm_id = '2010' then
              1
             else
              0
           end) nj2010,
       sum(case
             when xj.njdm_id = '2010' and xs.xbm = '2' then
              1
             else
              0
           end) nj2010ns,
       sum(case
             when xj.njdm_id = '2009' then
              1
             else
              0
           end) nj2009,
       sum(case
             when xj.njdm_id = '2009' and xs.xbm = '2' then
              1
             else
              0
           end) nj2009ns,
       sum(case
             when xj.njdm_id = '2008' then
              1
             else
              0
           end) nj2008,
       sum(case
             when xj.njdm_id = '2008' and xs.xbm = '2' then
              1
             else
              0
           end) nj2008ns,
       sum(case
             when xj.njdm_id = '2007' then
              1
             else
              0
           end) nj2007,
       sum(case
             when xj.njdm_id = '2007' and xs.xbm = '2' then
              1
             else
              0
           end) nj2007ns,
       sum(case
             when xj.njdm_id = '2006' then
              1
             else
              0
           end) nj2006,
       sum(case
             when xj.njdm_id = '2006' and xs.xbm = '2' then
              1
             else
              0
           end) nj2006ns,
       sum(case
             when xj.njdm_id = '2005' then
              1
             else
              0
           end) nj2005,
       sum(case
             when xj.njdm_id = '2005' and xs.xbm = '2' then
              1
             else
              0
           end) nj2005ns,
       sum(case
             when xj.njdm_id = '2004' then
              1
             else
              0
           end) nj2004,
       sum(case
             when xj.njdm_id = '2004' and xs.xbm = '2' then
              1
             else
              0
           end) nj2004ns,
       sum(case
             when xj.njdm_id = '2003' then
              1
             else
              0
           end) nj2003,
       sum(case
             when xj.njdm_id = '2003' and xs.xbm = '2' then
              1
             else
              0
           end) nj2003ns,
       sum(case
             when xj.njdm_id = '2002' then
              1
             else
              0
           end) nj2002,
       sum(case
             when xj.njdm_id = '2002' and xs.xbm = '2' then
              1
             else
              0
           end) nj2002ns,
       sum(case
             when xj.njdm_id = '2001' then
              1
             else
              0
           end) nj2001,
       sum(case
             when xj.njdm_id = '2001' and xs.xbm = '2' then
              1
             else
              0
           end) nj2001ns,
       sum(case
             when xj.njdm_id = '2000' then
              1
             else
              0
           end) nj2000,
       sum(case
             when xj.njdm_id = '2000' and xs.xbm = '2' then
              1
             else
              0
           end) nj2000ns,
       sum(case
             when xj.njdm_id = '1999' then
              1
             else
              0
           end) nj1999,
       sum(case
             when xj.njdm_id = '1999' and xs.xbm = '2' then
              1
             else
              0
           end) nj1999ns,
           count(1) zj
  from jw_xjgl_xsxjxxb  xj,
       jw_xjgl_xsjbxxb  xs,
       zftal_xtgl_jgdmb jg,
       zftal_xtgl_zydmb zy
 where xj.njdm_id is not null
   and xj.jg_id is not null
   and xj.zyh_id is not null
   and xj.xh_id = xs.xh_id
   and xj.jg_id = jg.jg_id
   and zy.jg_id = jg.jg_id
   and xj.xnm = '2014'
   and xj.xqm = '3'
 group by jg.jgmc, zy.zymc, zy.xz, xj.jg_id, xj.zyh_id, jg.lsxqid
/

