create procedure proc_gcpjtj_10344(---浙江中医药大学过程评价统计  2018-11-28修改版
       v_xnm in varchar2,
       v_xqm in varchar2,
       v_gcpjszlcb_id in varchar2,
       v_jxb_id in varchar2,
       v_xsdm in varchar2,
       v_jgh_id in varchar2,
       v_xqh_id in varchar2,
       v_pjrs in varchar2
) as
v_sx_rs  number;
v_pfxm varchar(32767);
v_pfdj varchar(32767);
v_fxpf number;
begin

       v_sx_rs := round(to_number(v_pjrs)*0.05 ,0) ; --按比例计算应该筛掉的评价人数（得分排名前、后的5%）

       if v_xqh_id = 'qbxq_all' then
           update jw_pj_gcpjjspftjb a set (sx_zxzpf, sx_pjrs, sx_zxpjf) =  --计算并更新sx_zxzpf（筛选后正向总分） sx_pjrs（筛选后评价人数） sx_zxpjf（筛选后正向平均分）的值
           (select sum(zxpf) sx_zxzpf, count(*) sx_pjrs, round(sum(zxpf)/count(*),4) sx_zxpjf from
               (select zxpf,row_number() over(partition by xnm,xqm,gcpjszlcb_id,xsdm,jgh_id,jxb_id order by zxpf) px
                from jw_pj_gcpjxspftjb where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                and xsdm=v_xsdm and jgh_id=v_jgh_id and jxb_id=v_jxb_id)
           where to_number(px) > v_sx_rs and to_number(px)<= (to_number(v_pjrs) - v_sx_rs) )
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id
           and a.xsdm=v_xsdm and a.xqh_id=v_xqh_id and a.jgh_id=v_jgh_id and a.jxb_id=v_jxb_id;
       else
           update jw_pj_gcpjjspftjb a set (sx_zxzpf, sx_pjrs, sx_zxpjf) =  --计算并更新sx_zxzpf（筛选后正向总分） sx_pjrs（筛选后评价人数） sx_zxpjf（筛选后正向平均分）的值
           (select sum(zxpf) sx_zxzpf, count(*) sx_pjrs, round(sum(zxpf)/count(*),4) sx_zxpjf from
               (select zxpf,row_number() over(partition by xnm,xqm,gcpjszlcb_id,xsdm,xqh_id,jgh_id,jxb_id order by zxpf) px
                from jw_pj_gcpjxspftjb where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                and xsdm=v_xsdm and xqh_id=v_xqh_id and jgh_id=v_jgh_id and jxb_id=v_jxb_id)
           where to_number(px) > v_sx_rs and to_number(px)<= (to_number(v_pjrs) - v_sx_rs) )
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id
           and a.xsdm=v_xsdm and a.xqh_id=v_xqh_id and a.jgh_id=v_jgh_id and a.jxb_id=v_jxb_id;
       end if;

       if v_xqh_id = 'qbxq_all' then ---算反向评分 要按整个教学班来计算
           declare cursor pfxm_cur is     ---按教学班 遍历 有反向评分 的反向指标项目
               select pjzbxm_id,pjzbxm,pjrs,pjbl from jw_pj_gcpjfxpfhzb a where to_number(qzz)>0  and a.xnm=v_xnm and a.xqm=v_xqm
               and gcpjszlcb_id=v_gcpjszlcb_id and xsdm=v_xsdm and jgh_id=v_jgh_id and jxb_id=v_jxb_id;
           v_pfxm pfxm_cur%rowType;
           begin
                open pfxm_cur;
                loop
                    fetch pfxm_cur into v_pfxm;
                          exit when pfxm_cur%notfound;

                    v_fxpf := 0;
                    declare cursor pfdj_cur is----按教学班、反向指标 遍历 每个评分等级 (按扣分从高到低排序)
                        select pfdjdmxmb_id,pfdjmc,to_number(qzdyf) qzdyf,pjrs,pjbl from jw_pj_gcpjfxpftjb a
                        where a.xnm=v_xnm and a.xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                        and pjzbxm_id=v_pfxm.pjzbxm_id and to_number(qzz)>0 and to_number(qzdyf)<>0
                        and xsdm=v_xsdm and jgh_id=v_jgh_id and jxb_id=v_jxb_id
                        order by to_number(qzdyf) asc;
                    v_pfdj pfdj_cur%rowType;
                    begin
                         open pfdj_cur;
                         loop
                             fetch pfdj_cur into v_pfdj;       --按扣分从高到低 逐个比较该评分等级 的反向评价率
                                   exit when pfdj_cur%notfound;
                             if v_pfdj.pjbl >= 0.3 then         --如果某一评分等级的反向评价率超过 30%，则最终反向评分为该评分等级的扣分
                                v_fxpf := v_pfdj.qzdyf;
                                exit;
                             end if;
                         end loop;
                         close pfdj_cur;
                    end;

                    if v_fxpf = 0 and v_pfxm.pjbl >= 0.3 then    --如果单个评分等级的反向评价率都未超过 30%，并且该指标总的反向评价率超过30%
                       select to_number(qzdyf) into v_fxpf from (
                           select xnm,xqm,gcpjszlcb_id,jxb_id,xsdm,jgh_id,pjmbmcb_id,pjzbxm_id,pjzbxm,qzdyf,
                           row_number() over(partition by xnm,xqm,gcpjszlcb_id,jxb_id,xsdm,jgh_id,pjmbmcb_id,pjzbxm_id,pjzbxm order by to_number(qzdyf) desc) hh
                           from jw_pj_gcpjfxpftjb a where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                           and pjzbxm_id=v_pfxm.pjzbxm_id and to_number(qzz)>0 and to_number(qzdyf)<>0
                           and xsdm=v_xsdm and jgh_id=v_jgh_id and jxb_id=v_jxb_id
                       ) where hh=1;
                    end if;

                    update jw_pj_gcpjfxpfhzb set fxpf = v_fxpf where xnm=v_xnm and xqm=v_xqm and gcpjszlcb_id=v_gcpjszlcb_id
                    and pjzbxm_id=v_pfxm.pjzbxm_id and xsdm=v_xsdm and jgh_id=v_jgh_id and jxb_id=v_jxb_id;

                end loop;
                close pfxm_cur;
           end;
       end if;
       /**
       update jw_pj_gcpjjspftjb a set fxzpf =  --统计并更新fxzpf（反向总评分）
            nvl((select sum(fxpf) from jw_pj_gcpjfxpfhzb where xnm=v_xnm and xqm=v_xqm
            and gcpjszlcb_id=v_gcpjszlcb_id and jxb_id=v_jxb_id and xsdm=v_xsdm and jgh_id=v_jgh_id),0)
       where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id and a.jxb_id=v_jxb_id and a.xsdm=v_xsdm and a.jgh_id=v_jgh_id;

       if v_xqh_id = 'qbxq_all' then
           update jw_pj_gcpjjspftjb a set --统计并更新jxbrs（教学班总人数）
           a.jxbrs=(select count(*) from jw_xk_xsxkb where jxb_id=a.jxb_id)
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id and a.jxb_id=v_jxb_id
           and a.xsdm=v_xsdm and a.jgh_id=v_jgh_id and a.xqh_id=v_xqh_id;
       else
           update jw_pj_gcpjjspftjb a set --统计并更新jxbrs（教学班总人数）
           a.jxbrs=(select count(*) from jw_xk_xsxkb t,jw_xjgl_xsjbxxb t1,zftal_xtgl_bjdmb t2 where
           t.jxb_id=a.jxb_id and t.xh_id=t1.xh_id and t1.bh_id=t2.bh_id and t2.xqh_id=v_xqh_id)
           where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id and a.jxb_id=v_jxb_id
           and a.xsdm=v_xsdm and a.jgh_id=v_jgh_id and a.xqh_id=v_xqh_id;
       end if;

       update jw_pj_gcpjjspftjb a set --统计并更新pjbl（评价比率）,zzpf（最终评分）
       a.pjbl = round(a.pjrs/a.jxbrs*100,4), zzpf = (a.sx_zxpjf + nvl(a.fxzpf,0))
       where a.xnm=v_xnm and a.xqm=v_xqm and a.gcpjszlcb_id=v_gcpjszlcb_id and a.jxb_id=v_jxb_id
       and a.xsdm=v_xsdm and a.jgh_id=v_jgh_id;

      commit;**/

      EXCEPTION
            when others then
            rollback;
            commit;
end proc_gcpjtj_10344;

/

