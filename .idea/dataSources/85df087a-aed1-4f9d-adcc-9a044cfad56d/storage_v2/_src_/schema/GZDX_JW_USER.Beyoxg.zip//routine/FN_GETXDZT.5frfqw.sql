create function FN_GETXDZT(v_xh_id varchar2,v_kch_id varchar2,v_zzbfzcj varchar2,v_bfzcj varchar2) return varchar2
/****获取修读状态 码 kwy ****/
/*v_zzbfzcj 是 预警后 最终的百分制成绩  注意：有Maxbfzcj 请优先写入*/
/*v_bfzcj   是成绩表的成绩 注：在sql函数调用中无成绩表关联 将此值 写为 null 即可*/
/*1在修，2正考未过 最终成绩也未过 未过，21正考未过 已重修或补考 3未修，4已修通过，5校内被替代，6校内课程替代，7校内课程替代节点，8校外课程替换节点/校外认定课程，9校内被认定课程 10 学业预警不审核课程*/
as
   sXdzt varchar2(50);
   v_byshsfbshkc varchar2(50);
   v_njdm_id  varchar2(50);
   v_zyh_id   varchar2(50);
begin

   --获取学生年级 专业信息
   select nvl(xxb.bynjdm_id,xxb.njdm_id),nvl(xxb.byzyh_id,xxb.zyh_id) into v_njdm_id,v_zyh_id from jw_xjgl_xsjbxxb xxb where xxb.xh_id = v_xh_id;
   --判断内置项 是否存在
   select max(zdz) into v_byshsfbshkc from jw_jcdml_xtnzb where xtnz_id ='BYSHSFBSHKC';

    if v_byshsfbshkc is null then --当不存在 直接执行语句
              select
                 (case
                  when (select count(1)

                       from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                      where b.xrdz_id = t.rdz_id
                        and b.shjg='3'
                        and b.xh_id = v_xh_id
                        and t.kch_id = v_kch_id) > 0     then  '9' /*9校内被认定课程*/
                  when (select count(1)
                       from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                      where b.yrdz_id = t.rdz_id
                        and b.shjg='3'
                        and b.xh_id = v_xh_id
                        and t.kcmc = v_kch_id) > 0      then  '8' /*8校外课程替换节点/校外认定课程*/
                  when (select count(1)
                        from jw_cj_xsgrcjdtb t
                       where t.zszt = '3'
                         and t.xh_id = v_xh_id
                         and t.kcthzbm = 'xnkcxfjd'
                         and t.kch_id = v_kch_id) > 0   then '7'  /*7校内课程替代节点*/
                  when (select count(1)
                        from jw_cj_xsgrcjdtb t
                       where t.zszt='3'
                         and t.xh_id = v_xh_id
                         and t.kcthzbm = 'xnkc'
                         and t.kch_id = v_kch_id) > 0   then '6' /*6校内课程替代*/
                  when (select count(1)
                        from jw_cj_xsgrjhdtb t
                       where t.zszt='3'
                         and t.xh_id = v_xh_id
                         and t.kch_id = v_kch_id) > 0   then '5'/* 5校内被替代*/
                  when v_zzbfzcj >= 60                  then '4' /*4已修通过*/

                  when (v_bfzcj is null and  v_zzbfzcj is not null and v_zzbfzcj < 60) then '2' /*2未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60 and v_zzbfzcj< 60)    then '2' /*2正考未过 最终成绩也未过 未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60  and v_zzbfzcj>=60)    then '21' /*21正考未过 已重修或补考*/

                  when (select count(1)
                       from jw_xk_xsxkb t
                      where t.xh_id = v_xh_id
                        and t.kch_id = v_kch_id
                        and v_zzbfzcj is null ) > 0  then '1'  /*1在修*/
                        --and (v_zzbfzcj is null or v_cjbz is null) ) > 0  then '1'

                   else '3'                                     /* 3未修*/
                  end) into sXdzt
              from dual;

    else--否则 看值来做

            if v_byshsfbshkc ='1' then --控制点为1 需要考虑 学业预警不审核课程
                  select
                   (case
                   when(select count(1)
                       from JW_BYGL_XYYJBSHKCB t
                      where t.kch_id = v_kch_id
                        and t.njdm_id= v_njdm_id
                        and t.zyh_id= v_zyh_id )>0        then  '10'
                    when (select count(1)
                         from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                        where b.xrdz_id = t.rdz_id
                          and b.shjg='3'
                          and b.xh_id = v_xh_id
                          and t.kch_id = v_kch_id) > 0     then  '9'
                    when (select count(1)
                         from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                        where b.yrdz_id = t.rdz_id
                          and b.shjg='3'
                          and b.xh_id = v_xh_id
                          and t.kcmc = v_kch_id) > 0      then  '8'
                    when (select count(1)
                          from jw_cj_xsgrcjdtb t
                         where t.zszt = '3'
                           and t.xh_id = v_xh_id
                           and t.kcthzbm = 'xnkcxfjd'
                           and t.kch_id = v_kch_id) > 0   then '7'
                    when (select count(1)
                          from jw_cj_xsgrcjdtb t
                         where t.zszt='3'
                           and t.xh_id = v_xh_id
                           and t.kcthzbm = 'xnkc'
                           and t.kch_id = v_kch_id) > 0   then '6'
                    when (select count(1)
                          from jw_cj_xsgrjhdtb t
                         where t.zszt='3'
                           and t.xh_id = v_xh_id
                           and t.kch_id = v_kch_id) > 0   then '5'
                    when v_zzbfzcj >= 60                  then '4'

                    when (v_bfzcj is null and  v_zzbfzcj is not null and v_zzbfzcj < 60) then '2' /*2未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60 and v_zzbfzcj< 60)    then '2' /*2正考未过 最终成绩也未过 未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60  and v_zzbfzcj>=60)    then '21' /*21正考未过 已重修或补考*/

                    when (select count(1)
                         from jw_xk_xsxkb t
                        where t.xh_id = v_xh_id
                          and t.kch_id = v_kch_id
                          and v_zzbfzcj is null ) > 0  then '1'  /*1在修*/
                        --and (v_zzbfzcj is null or v_cjbz is null) ) > 0  then '1'

                     else '3'
                    end) into sXdzt
                from dual;

            else--控制点 不为1   不考虑 不审核 课程
                 select
                   (case
                    when (select count(1)
                         from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                        where b.xrdz_id = t.rdz_id
                          and b.shjg='3'
                          and b.xh_id = v_xh_id
                          and t.kch_id = v_kch_id) > 0     then  '9'
                    when (select count(1)
                         from JW_CJ_XFRDMXB t, JW_CJ_XFRDB b
                        where b.yrdz_id = t.rdz_id
                          and b.shjg='3'
                          and b.xh_id = v_xh_id
                          and t.kcmc = v_kch_id) > 0      then  '8'
                    when (select count(1)
                          from jw_cj_xsgrcjdtb t
                         where t.zszt = '3'
                           and t.xh_id = v_xh_id
                           and t.kcthzbm = 'xnkcxfjd'
                           and t.kch_id = v_kch_id) > 0   then '7'
                    when (select count(1)
                          from jw_cj_xsgrcjdtb t
                         where t.zszt='3'
                           and t.xh_id = v_xh_id
                           and t.kcthzbm = 'xnkc'
                           and t.kch_id = v_kch_id) > 0   then '6'
                    when (select count(1)
                          from jw_cj_xsgrjhdtb t
                         where t.zszt='3'
                           and t.xh_id = v_xh_id
                           and t.kch_id = v_kch_id) > 0   then '5'
                    when v_zzbfzcj >= 60                  then '4'

                    when (v_bfzcj is null and  v_zzbfzcj is not null and v_zzbfzcj < 60) then '2' /*2未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60 and v_zzbfzcj< 60)    then '2' /*2正考未过 最终成绩也未过 未过*/

                  when (v_bfzcj is not null and v_bfzcj is not null and v_bfzcj < 60  and v_zzbfzcj>=60)    then '21' /*21正考未过 已重修或补考*/

                    when (select count(1)
                         from jw_xk_xsxkb t
                        where t.xh_id = v_xh_id
                          and t.kch_id = v_kch_id
                          and v_zzbfzcj is null ) > 0  then '1'  /*1在修*/
                        --and (v_zzbfzcj is null or v_cjbz is null) ) > 0  then '1'

                     else '3'
                    end) into sXdzt
                from dual;

            end if;
    end if;

    if sXdzt is null then
       sXdzt := 0;
    end if;
    return sXdzt;
end FN_GETXDZT;

/

