create FUNCTION FN_STOE(V_NUM NUMBER)
RETURN VARCHAR2 IS V_RTN VARCHAR2(1000);
  V_N1  NUMBER;
  V_N2  NUMBER;
BEGIN
IF (V_NUM IS NULL) THEN return 0;
END IF;
V_RTN := '';
V_N1 := V_NUM;
    LOOP
      V_N2  := MOD(V_N1, 2);
      V_N1  := ABS(TRUNC(V_N1 / 2));
      IF (V_N2 = 1) THEN
      V_RTN := V_RTN||1;
      else
      V_RTN := V_RTN||0;
      END IF;
      EXIT WHEN V_N1 = '0';
    END LOOP;
return V_RTN;
end;
/

