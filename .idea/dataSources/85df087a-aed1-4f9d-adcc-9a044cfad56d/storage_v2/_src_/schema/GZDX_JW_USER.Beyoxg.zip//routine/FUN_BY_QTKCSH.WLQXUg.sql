create function fun_by_qtkcsh(v_xh_id varchar2,v_tjmc varchar2,v_tjsjcs varchar2,v_tjsjz varchar2,
                                       v_tjsjly varchar2,v_tjsjlymc varchar2,v_tjsjgx varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_count int;
   v_flag varchar2(2);
   sqlstr VARCHAR2(2000);
begin
    sJg := '合格';
    begin
    sqlstr := 'select count(1)  from ' || v_tjsjlymc||' where xh_id = '''||v_xh_id||''' and kclx=''' || v_tjsjcs||'''';--动态SQL
    execute immediate sqlstr into v_count;
    if v_count =  0 then
       sJg :='无成绩，不合格！';
    else
       sqlstr := 'select decode(wm_concat(e.kcmc || e.bfzcj || ''分''),'''',''合格''，wm_concat(e.kcmc || e.bfzcj || ''分'') ||''低于'|| v_tjsjz || '分，不合格！'')';
       sqlstr := sqlstr||' from (select * from ' || v_tjsjlymc||' a  where a.kclx = '''||v_tjsjcs||''' and xh_id = '''||v_xh_id||'''';
       sqlstr := sqlstr||' minus ';
       sqlstr := sqlstr||' select * from ' || v_tjsjlymc||' a where a.kclx = '''||v_tjsjcs||''' and xh_id = '''||v_xh_id||''' and a.bfzcj '||v_tjsjgx||v_tjsjz||') e ';
       execute immediate  sqlstr  into sJg;
    end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_qtkcsh;

/

