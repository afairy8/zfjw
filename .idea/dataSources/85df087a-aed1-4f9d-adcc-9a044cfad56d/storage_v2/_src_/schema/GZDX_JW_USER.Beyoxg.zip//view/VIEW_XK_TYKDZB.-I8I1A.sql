create view VIEW_XK_TYKDZB as
  select b.kch_id KCH_ID,a.kz_id DYKCH from jw_jh_kzjbxxb a,jw_jh_kzkcdmb b where a.kz_id = b.kz_id and a.kklxdm ='05'
/

