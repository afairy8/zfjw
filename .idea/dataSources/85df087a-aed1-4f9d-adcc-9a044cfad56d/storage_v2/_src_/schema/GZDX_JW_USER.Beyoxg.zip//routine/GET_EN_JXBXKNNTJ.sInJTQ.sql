create function get_en_jxbxknntj(---教学班选课条件状态
    vXnm varchar2,vXqm varchar2,vJxb_id varchar2,vXh_id varchar2
) Return varchar2
as
    yxgirlnum varchar2(20);
    yxboynum varchar2(20);
    girlnum varchar2(20);
    boynum varchar2(20);
    xsxb varchar2(20);
    nnrs varchar2(50);
begin
    yxgirlnum := '0';
    yxboynum := '0';
    girlnum := '0';
    boynum := '0';
    select nnrs into nnrs from jw_jxrw_jxbxxb where xnm=vXnm and xqm=vXqm and jxb_id=vJxb_id;

    select  count(a.xh_id) into yxgirlnum  from jw_xk_xsxkb a,jw_xjgl_xsjbxxb b
    where a.xnm=vXnm  and a.xh_id=b.xh_id and b.xbm='2' and a.xqm=vXqm and a.jxb_id=vJxb_id;

    select  count(a.xh_id) into  yxboynum  from jw_xk_xsxkb a,jw_xjgl_xsjbxxb b
    where a.xnm=vXnm  and a.xh_id=b.xh_id and b.xbm='1' and a.xqm=vXqm and a.jxb_id=vJxb_id;

    if nnrs is not null then
        girlnum :=nvl(subStr(nnrs,instr(nnrs,'|')+1,length(nnrs)-instr(nnrs,'|')),'9999');
        boynum :=nvl(subStr(nnrs,0,instr(nnrs,'|')-1),'9999');
        select xbm into xsxb from jw_xjgl_xsjbxxb where xh_id=vXh_id;
        if xsxb is not null then
            if xsxb='1' then
                if boynum is not null  then
                    if to_number(yxboynum) < to_number(boynum) then
                        Return '1';
                        goto Next_Null;
                    else
                        Return '0|'||'Boys are full!';
                        goto Next_Null;
                    end if;
                else
                    Return '1';
                    goto Next_Null;
                end if;
            elsif xsxb='2' then
                if yxgirlnum is not null then
                    if to_number(yxgirlnum) < to_number(girlnum) then
                        Return '1';
                        goto Next_Null;
                    else
                        Return '0|'||'Girls are full!';
                        goto Next_Null;
                    end if;
                else
                    Return '1';
                    goto Next_Null;
                end if;
            else
                Return '0|'||'Error in gender setting!';
                goto Next_Null;
            end if;
        else
            Return '0|'||'No gender!';
            goto Next_Null;
        end if;
    else
        Return '1';
        goto Next_Null;
    end if;
     <<Next_Null>>
     NULL;
end;
/

