create FUNCTION get_jglsywxx( vJg_id in varchar)  ----机构隶属信息
 RETURN VARCHAR2 IS sJglsywxx varchar(2000);
BEGIN
    select replace(wm_concat(jgywmc),',','~') into sJglsywxx  from (
      select * from (
      select t.* from zftal_xtgl_jgdmb t
         start with t.jg_id = vJg_id
            connect by prior  t.lssjjgid = t.jg_id
            ) t order by  decode(t.lssjjgid,null,'0','1'),t.jgdm
      );
    RETURN sJglsywxx;
END;

/

