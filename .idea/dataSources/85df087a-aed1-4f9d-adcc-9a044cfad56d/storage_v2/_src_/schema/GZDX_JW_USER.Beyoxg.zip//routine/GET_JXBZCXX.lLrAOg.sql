create function Get_JxbZcxx(vXnm varchar2,vXqm varchar2,vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班周次信息----
as
   sZcxx varchar2(2000);   ---周次信息
begin
    sZcxx := '无';
    begin
       if vBj = '0' then
         --dbms_output.put_line('vJxb_id:'||vJxb_id);
         select get_weeksdesc_xnxq(vXnm, vXqm,get_bitorsunion(wm_concat(a.qsjsz))) into sZcxx from
              jw_jxrw_jxbjsrkb a
                where  a.jxb_id= vJxb_id;
       end if ;

     if sZcxx is null then
         sZcxx := '无';
       end if;
     exception
        When others then
          sZcxx := '无';
    end;
    return sZcxx ;
end Get_JxbZcxx;
/

