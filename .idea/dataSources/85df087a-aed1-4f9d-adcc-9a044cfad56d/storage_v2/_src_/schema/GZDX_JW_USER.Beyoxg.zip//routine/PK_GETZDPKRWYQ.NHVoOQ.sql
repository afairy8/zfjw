create Procedure Pk_GetZdpkrwYq(  ---自动排课任务要求---
 vJxb_id in varchar2,
 vKch_ids out varchar2,
 vJgh_ids out varchar2,
 nQsjsz out number,         ----起始结束周
 nZhxs out number,          ----周学时
 nPkcs out number,          ----排课次数
 vPksjfb out varchar2,  ----排课时间分布
 vXqh_id out varchar2,  ----校区号ID
 vCdlb_id out varchar2, ----场地类别ID
 vBj out varchar2)
 as
 begin

  --3-取出最优先的教学班信息校区要求、平均周学时要求及课程排课要求、教师排课要求**begin**存在学时分配直接取出最大周学时及起始结束周----
   select xqh_id,kch_ids,jgh_ids,cdlb_id,zhxs,qsjsz,pkcsyq,pksjfb,bj into vXqh_id,vKch_ids,vJgh_ids,vCdlb_id,nZhxs,nQsjsz,nPkcs,vPksjfb,vbj from
          (select distinct xqh_id,cdlb_id||cdejlb_id as cdlb_id,    ---xnm,xqm,kch_id,jxbrs,
                       max(zhxs) over (partition by 1) as zhxs,
                       wm_concat(kch_id) over (partition by 2) as kch_ids,
                       --jgh_id,qsjsz,
                       wm_concat(jgh_id) over (partition by 3) as jgh_ids,
                       get_bitorsunion(wm_concat(qsjsz_zhzc) over (partition by 4)) as qsjsz,
                       --xsfpbj,zcjcbj,pkcsyq,pksjfb
                       max(pkcsyq) over (partition by 5) as pkcsyq,
                       max(pksjfb) over (partition by 6) as pksjfb,
                       count(distinct xqh_id||zhxs||pkcsyq||pksjfb) over (partition by 7) as bj
                       from --,ksfb,mtzdxs
                       ( select  a.xnm,a.xqm,a.kch_id,a.jxbrs,  a.xqh_id,a.cdlb_id,a.cdejlb_id,a.rwxssfcf,a.xsfpsfcf,
                                 nvl(b.zhxs,a.zhxs*b.gs) zhxs, b.jgh_id,b.qsjsz,b.qsjsz_zhzc,b.xsfpbj,b.zcjcbj,
                                 c.pkcsyq,c.pksjfb, d.ksfb,d.mtzdxs  from  jw_jxrw_jxbxxb a,
                                  (select t1.jxb_id,nvl(t2.jgh_id,t1.jgh_id) jgh_id,t1.gs,t2.zhxs,
                                   nvl(t2.qsjsz,t1.qsjsz) qsjsz,nvl(t2.qsjsz_zhzc,t1.qsjsz_zhzc) qsjsz_zhzc,
                                   case when t2.zhxs is null then 0 else 1 end xsfpbj,
                                   case when t2.gs is null and t1.gs >1 then 1
                                        when t2.gs >1 then 1
                                        else 0 end zcjcbj from
                                  (select distinct jxb_id,jgh_id,
                                         max(gs)  over(partition by jxb_id) gs,
                                          qsjsz,qsjsz_zhzc from
                                     (select m.jxb_id,m.jgh_id,l.zc,
                                           case when n.rwxssfcf = 1 then 1 else count(m.jgh_id) over(partition by m.jxb_id,l.zc) end gs,
                                           sum(distinct l.zc) over (partition by m.jxb_id,m.jgh_id) qsjsz,
                                           sum(distinct l.zc) over (partition by m.jxb_id) qsjsz_zhzc
                                           from jw_jxrw_jxbjsrkb m,jw_jxrw_jxbxxb n,
                                                (select power(2,rownum-1) zc from zftal_xtgl_jcsjb where rownum <= 26) l where
                                                m.jxb_id  in ( select jxb_id from  jw_pk_bbfzb where
                                                   bbfz_id =
                                                   (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                   union
                                                   select vJxb_id from dual ) and
                                                   m.jxb_id = n.jxb_id and bitand(m.qsjsz,l.zc) >0
                                      )
                                    ) t1, -----任务学时----
                                    (
                                    select distinct jxb_id,jgh_id,
                                         max(gs)  over(partition by jxb_id) gs,
                                         max(zhxs)  over(partition by jxb_id) zhxs,
                                          qsjsz,qsjsz_zhzc from
                                     (select m.jxb_id,m.jgh_id,m.zc,
                                           count(jgh_id) over(partition by m.jxb_id,m.zc)  gs,
                                           case when n.xsfpsfcf = 1 then max(nvl(m.ks,0)) over(partition by m.jxb_id,m.zc)
                                                                    else sum(nvl(m.ks,0)) over(partition by m.jxb_id,m.zc) end zhxs,
                                           sum(distinct power(2,m.zc-1)) over (partition by m.jxb_id,m.jgh_id) qsjsz,
                                           sum(distinct power(2,m.zc-1)) over (partition by m.jxb_id) qsjsz_zhzc
                                           from jw_pk_xsfpb m,jw_jxrw_jxbxxb n
                                                 where
                                                   m.jxb_id  in ( select jxb_id from  jw_pk_bbfzb where
                                                   bbfz_id =
                                                   (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                   union
                                                   select vJxb_id from dual )
                                                   and m.jxb_id = n.jxb_id

                                     )
                                    ) t2  -------学时分配----
                                    where t1.jxb_id = t2.jxb_id(+) and t1.jgh_id = t2.jgh_id(+)

                                  ) b,
                                  jw_jh_kcrwszb c,jw_jg_jzgrwszb d where
                                  a.jxb_id in ( select jxb_id from  jw_pk_bbfzb where
                                                   bbfz_id =
                                                   (select bbfz_id from jw_pk_bbfzb where jxb_id = vJxb_id )
                                                   union
                                                   select vJxb_id from dual )
                                                   and
                                  a.jxb_id = b.jxb_id and
                                  a.kch_id = c.kch_id and
                                  b.jgh_id = d.jgh_id
                      ));
---取出最优先的教学班信息校区要求、平均周学时要求及课程排课要求、教师排课要求****end**
  null;
 end;


/

