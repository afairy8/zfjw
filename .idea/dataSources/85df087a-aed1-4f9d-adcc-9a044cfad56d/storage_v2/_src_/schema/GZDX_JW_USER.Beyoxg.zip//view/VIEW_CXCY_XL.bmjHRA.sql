create view VIEW_CXCY_XL as
  select t1.xnm,
       t1.xqm,
       (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) xnmc,
       (select mc
          from zftal_xtgl_jcsjb
         where lx = '0001'
           and dm = t1.xqm) xqmc,
       t1.ksrq,
       t2.jsrq
  from (select a.xnm, a.xqm, a.ksrq
          from jw_pk_xlb a) t1,
       (select decode(a.xqm, '12', a.xnm, '3', a.xnm - 1) as xnm,
               decode(a.xqm, '12', '3', '3', '12') as xqm,
               to_char((to_date(a.ksrq, 'yyyy-mm-dd') - 1), 'yyyy-mm-dd') as jsrq
          from (select t.xnm, t.xqm, t.ksrq,t.jsrq
          from jw_pk_xlb t
          union all
          select decode(tt.xqm, '3', tt.xnm, '12', tt.xnm + 1) as xnm,
                 decode(tt.xqm, '3', '12', '12', '3') as xqm,
                 to_char(decode(tt.xqm,
                        '3',
                        (select add_months(to_date(max(t.ksrq), 'yyyy-mm-dd'), 12)
                           from jw_pk_xlb t
                          where t.xqm = '12'
                            and t.xnm = (tt.xnm - 1)),
                        '12',
                        (select add_months(to_date(max(t.ksrq), 'yyyy-mm-dd'), 12)
                           from jw_pk_xlb t
                          where t.xqm = '3'
                            and t.xnm = tt.xnm)),'yyyy-mm-dd') as ksrq,
                 to_char(decode(tt.xqm,
                        '3',
                        (select add_months(to_date(max(t.jsrq), 'yyyy-mm-dd'), 12)
                           from jw_pk_xlb t
                          where t.xqm = '12'
                            and t.xnm = (tt.xnm - 1)),
                        '12',
                        (select add_months(to_date(max(t.jsrq), 'yyyy-mm-dd'), 12)
                           from jw_pk_xlb t
                          where t.xqm = '3'
                            and t.xnm = tt.xnm)),'yyyy-mm-dd') as jsrq
            from (select *
                    from (select a.xnm, a.xqm
                            from jw_pk_xlb a
                           order by to_number(a.xnm) desc, to_number(a.xqm) desc)
                   where rownum = 1) tt) a) t2
 where t1.xnm = t2.xnm
   and t1.xqm = t2.xqm
 order by to_number(t1.xnm), to_number(t1.xqm) asc
 with read only
/

