create package likai_jw_static is
  --计算各教师的听课总次数，理论课听课次数，实验课听课次数，青年教师听课次数
  --v_count的格式为：zcs0lrk1syk2qnj3lma14lmi5lav6sma7smi8sav19
  function pj_findpjcs(v_count varchar2, v_left varchar2, v_right varchar2)
    return varchar2;
  ---返回一个教师一个学期的作为一个参评对象的听课字符串
  function pj_gettklxzcs(v_xnm varchar2, v_xqm varchar2, v_jgh_id varchar2, v_cpdxdm varchar2)
    return varchar;
end;
/

