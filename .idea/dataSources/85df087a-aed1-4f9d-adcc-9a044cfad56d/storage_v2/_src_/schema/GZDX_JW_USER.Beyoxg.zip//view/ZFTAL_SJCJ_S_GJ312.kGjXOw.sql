create view ZFTAL_SJCJ_S_GJ312 as
  select (select nvl(wm_concat(t.mc),'无学科') from ZFTAL_XTGL_JCSJB t where t.lx='0027' and t.dm=zy.xkmlm) xk,
         zyfx.zyfxmc zyfl,
         dlzy.xxzymc zymc,
         zy.zymc zzzymc,
         dlzy.xxzydm zydm,
         zy.zyh zzzydm,
         '否' issfzy,
         xj.xz nz,
         xj.byss,
         null syxws,
         xj.yjbys,
         xj.cjzs,
         xj.ykszr,
         xj.ynj,
         xj.enj,
         xj.snj,
         xj.sinj,
         xj.wnj,
         xj.yjbyss
    from zftal_xtgl_zydmb zy,
         (select zyh_id,
                 zyfx_id,
                 zsnddm,
                 xz,
                 sum(case when xjztdm='07' then 1 else 0 end) byss,
                 sum(case when zsnddm=(select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') and zsjd = '秋' then 1 else 0 end) yjbys,
                 sum(case when zsnddm=(select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') and zsjd = '春' then 1 else 0 end) cjzs,
                 null ykszr,
                 sum(case when zsnddm=(select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')  and sfzx='1' then 1 else 0 end) ynj,
                 sum(case when zsnddm=((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-1) and sfzx='1' then 1 else 0 end) enj,
                 sum(case when zsnddm=((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-2) and sfzx='1' then 1 else 0 end) snj,
                 sum(case when zsnddm=((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-3) and sfzx='1' then 1 else 0 end) sinj,
                 sum(case when zsnddm<((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')-3) and sfzx='1' then 1 else 0 end) wnj,
                 sum(case when zsnddm=((select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM') - xz + 1) and sfzx='1' then 1 else 0 end) yjbyss
            from jw_xjgl_xsxjxxb
            where xnm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')
            and xqm = (select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXQM')
            group by zyh_id,zyfx_id,zsnddm,xz
         ) xj,
         zftal_xtgl_zyfxdmb zyfx,
         JW_JH_DLZYDZB dlzy
    where zy.zyh_id = xj.zyh_id
     and xj.zyfx_id = zyfx.zyfx_id
     and zy.zyh_id = dlzy.zyh_id
     and xj.zsnddm = dlzy.njdm_id
/

