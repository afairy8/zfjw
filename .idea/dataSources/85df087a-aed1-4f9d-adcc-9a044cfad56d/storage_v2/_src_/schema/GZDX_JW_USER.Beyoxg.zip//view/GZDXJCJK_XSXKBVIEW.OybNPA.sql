create view GZDXJCJK_XSXKBVIEW as
  select (select xnmc from jw_jcdm_xnb t where xkb.xnm = t.xnm) xn,
(select mc  from zftal_xtgl_jcsjb t  where t.lx = '0001'  and t.dm = xkb.xqm) xq,
(select xh from jw_xjgl_xsjbxxb xsj where xsj.xh_id=xkb.xh_id) xh,
(select jxbmc from jw_jxrw_jxbxxb jxb where jxb.jxb_id=xkb.jxb_id) xkkh
from jw_xk_xsxkb xkb
/

