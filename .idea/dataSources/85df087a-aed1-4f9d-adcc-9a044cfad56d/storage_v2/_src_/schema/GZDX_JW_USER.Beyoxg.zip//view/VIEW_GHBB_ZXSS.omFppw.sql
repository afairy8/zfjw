create view VIEW_GHBB_ZXSS as
  select
  t.zyh_id,
  t.pyccdm,
  (select d.dlmc
            from zftal_xtgl_zydmb a,
                 jw_jh_dlzydzb    b,
                 zftal_xtgl_njdmb c,
                 JW_JH_DLDMB d
           where a.sfty = '0'
             and a.dlbs = 'dl'
             and a.zyh = b.dldm
             and d.dldm=d.dldm
             and b.njdm_id = c.njdm_id
             and c.njdm = (select zdz
                             from zftal_xtgl_xtszb
                            where xtsz_id = 'DQND')
             and b.zyh_id = t.zyh_id) zylb,
  (select a.jgmc from ZFTAL_XTGL_JGDMB a,zftal_xtgl_zydmb b where a.jg_id=b.jg_id and b.zyh_id=t.zyh_id) as jgmc,
  (select zymc from zftal_xtgl_zydmb where zyh_id=t.zyh_id) zymc,
  (select decode(sfsf,'1','师范','非师范') from zftal_xtgl_zydmb where zyh_id=t.zyh_id) sfsfzy,
  (select xz from zftal_xtgl_zydmb where zyh_id=t.zyh_id) xz,
  t.xnm,
  t.xqm,
  t.rn,
  t4.pyccdm pyccdm4,
  t4.bh_id bh_id4,
  t4.bj bj4,
  t4.xqh_id xqh_id4,
  t4.bjrs bjrs4,
  t4.girlrs girlrs4,
  t4.rn rn4,
  t3.pyccdm pyccdm3,
  t3.bh_id bh_id3,
  t3.bj bj3,
  t3.xqh_id xqh_id3,
  t3.bjrs bjrs3,
  t3.girlrs girlrs3,
  t3.rn rn3,
  t2.pyccdm pyccdm2,
  t2.bh_id bh_id2,
  t2.bj bj2,
  t2.xqh_id xqh_id2,
  t2.bjrs bjrs2,
  t2.girlrs girlrs2,
  t2.rn rn2,
  t1.pyccdm pyccdm1,
  t1.bh_id bh_id1,
  t1.bj bj1,
  t1.xqh_id xqh_id1,
  t1.bjrs bjrs1,
  t1.girlrs girlrs1,
  t1.rn rn1
  from --专业信息
    (select t1.zyh_id,xnm,xqm,pyccdm,t2.rn from
        (
        select zyh_id,xnm,xqm,pyccdm,max(bhgs) bhgs from (
               select zyh_id,njdm_id,xnm,xqm,pyccdm,count(distinct bh_id) bhgs
                      from jw_xjgl_xsxjxxb
                      where sfzx ='1' and pyccdm is not null and zyh_id is not null  and njdm_id between (select zdz -3 from zftal_xtgl_xtszb where xtsz_id = 'DQND') and (select zdz from zftal_xtgl_xtszb where xtsz_id = 'DQND')
                      group by zyh_id,njdm_id,xnm,xqm,pyccdm
        ) group by zyh_id,xnm,xqm,pyccdm) t1,
        (select rownum rn from zftal_xtgl_jcsjlxb) t2
        where t2.rn<=t1.bhgs
    ) t,    --大四
     (select
            xjb.jg_id,
            xjb.zyh_id,
            xjb.bh_id,
            (select nvl(bjjc,bj) from ZFTAL_XTGL_BJDMB where bh_id=xjb.bh_id) bj,
            (select xqh_id from ZFTAL_XTGL_BJDMB where zyh_id= xjb.zyh_id and bh_id=xjb.bh_id) xqh_id,
            xjb.xnm,
            xjb.xqm,
            xjb.pyccdm,
            count(*) bjrs,
            sum(decode(jbb.xbm,'2',1,0)) girlrs,
            row_number() over (partition by xjb.zyh_id,xjb.xnm,xjb.xqm,xjb.pyccdm order by xjb.bh_id) rn
       from JW_XJGL_XSXJXXB  xjb,JW_XJGL_XSjbXXB jbb
      where xjb.xh_id=jbb.xh_id
        and xjb.sfzx='1'
        and xjb.njdm_id+3=(select zdz from zftal_xtgl_xtszb where xtsz_id = 'DQND')
        and xjb.zyh_id is not null
        and xjb.bh_id is not null
        and xjb.pyccdm is not null
        group by xjb.jg_id,xjb.zyh_id,xjb.bh_id,xjb.xnm,xjb.xqm,xjb.pyccdm) t4,        --大三
        (select
            xjb.jg_id,
            xjb.zyh_id,
            xjb.bh_id,
            (select nvl(bjjc,bj) from ZFTAL_XTGL_BJDMB where bh_id=xjb.bh_id) bj,
            (select xqh_id from ZFTAL_XTGL_BJDMB where zyh_id= xjb.zyh_id and bh_id=xjb.bh_id) xqh_id,
            xjb.xnm,
            xjb.xqm,
            xjb.pyccdm,
            count(*) bjrs,
            sum(decode(jbb.xbm,'2',1,0)) girlrs,
            row_number() over (partition by xjb.zyh_id,xjb.xnm,xjb.xqm,xjb.pyccdm order by xjb.bh_id) rn
       from JW_XJGL_XSXJXXB  xjb,JW_XJGL_XSjbXXB jbb
      where xjb.xh_id=jbb.xh_id
        and xjb.sfzx='1'
        and xjb.njdm_id+2=(select zdz from zftal_xtgl_xtszb where xtsz_id = 'DQND')
        and xjb.zyh_id is not null
        and xjb.bh_id is not null
        and xjb.pyccdm is not null
        group by xjb.jg_id,xjb.zyh_id,xjb.bh_id,xjb.xnm,xjb.xqm,xjb.pyccdm) t3,        --大二
        (select
            xjb.jg_id,
            xjb.zyh_id,
            xjb.bh_id,
            (select nvl(bjjc,bj) from ZFTAL_XTGL_BJDMB where bh_id=xjb.bh_id) bj,
            (select xqh_id from ZFTAL_XTGL_BJDMB where zyh_id= xjb.zyh_id and bh_id=xjb.bh_id) xqh_id,
            xjb.xnm,
            xjb.xqm,
            xjb.pyccdm,
            count(*) bjrs,
            sum(decode(jbb.xbm,'2',1,0)) girlrs,
            row_number() over (partition by xjb.zyh_id,xjb.xnm,xjb.xqm,xjb.pyccdm order by xjb.bh_id) rn
       from JW_XJGL_XSXJXXB  xjb,JW_XJGL_XSjbXXB jbb
      where xjb.xh_id=jbb.xh_id
        and xjb.sfzx='1'
        and xjb.njdm_id+1=(select zdz from zftal_xtgl_xtszb where xtsz_id = 'DQND')
        and xjb.zyh_id is not null
        and xjb.bh_id is not null
        and xjb.pyccdm is not null
        group by xjb.jg_id,xjb.zyh_id,xjb.bh_id,xjb.xnm,xjb.xqm,xjb.pyccdm) t2,        --大一
       (select
            xjb.jg_id,
            xjb.zyh_id,
            xjb.bh_id,
            (select nvl(bjjc,bj) from ZFTAL_XTGL_BJDMB where bh_id=xjb.bh_id) bj,
            (select xqh_id from ZFTAL_XTGL_BJDMB where zyh_id= xjb.zyh_id and bh_id=xjb.bh_id) xqh_id,
            xjb.xnm,
            xjb.xqm,
            xjb.pyccdm,
            count(*) bjrs,
            sum(decode(jbb.xbm,'2',1,0)) girlrs,
            row_number() over (partition by xjb.zyh_id,xjb.xnm,xjb.xqm,xjb.pyccdm order by xjb.bh_id) rn
       from JW_XJGL_XSXJXXB  xjb,JW_XJGL_XSjbXXB jbb
      where xjb.xh_id=jbb.xh_id
        and xjb.sfzx='1'
        and xjb.njdm_id=(select zdz from zftal_xtgl_xtszb where xtsz_id = 'DQND')
        and xjb.zyh_id is not null
        and xjb.bh_id is not null
        and xjb.pyccdm is not null
        group by xjb.jg_id,xjb.zyh_id,xjb.bh_id,xjb.xnm,xjb.xqm,xjb.pyccdm) t1
  where t.zyh_id=t1.zyh_id(+) and t.rn=t1.rn(+) and t.xnm=t1.xnm(+) and t.xqm=t1.xqm(+) and t.pyccdm=t1.pyccdm(+)
        and t.zyh_id=t2.zyh_id(+) and t.rn=t2.rn(+) and t.xnm=t2.xnm(+) and t.xqm=t2.xqm(+) and t.pyccdm=t2.pyccdm(+)
        and t.zyh_id=t3.zyh_id(+) and t.rn=t3.rn(+) and t.xnm=t3.xnm(+) and t.xqm=t3.xqm(+) and t.pyccdm=t3.pyccdm(+)
        and t.zyh_id=t4.zyh_id(+) and t.rn=t4.rn(+) and t.xnm=t4.xnm(+) and t.xqm=t4.xqm(+) and t.pyccdm=t4.pyccdm(+)
       order by t.zyh_id,xnm,xqm,t.rn
/

