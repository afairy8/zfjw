create procedure proc_sp_xjydwhclwh(v_ydsxxnm    varchar2,   --异动生效学年
                                               v_ydsxxqm    varchar2,   --异动生效学期
                                               v_ydlbm      varchar2,
                                               v_xh_id      varchar2,
                                               v_sqxnm      varchar2,   --异动申请学年
                                               v_sqxqm      varchar2,   --异动申请学期
                                               v_xjyd_id    varchar2,
                                               out_clwh out varchar2,   --处理文号
                                               out_ycbj out varchar2) as
  v_xnm varchar2(20);
  v_xqm varchar2(20);
  v_dqxnm varchar2(20);
  v_dqxqm varchar2(20);
  v_ydlbmm varchar2(20);
  v_scfs varchar2(2);
begin
  select min(xnm) into v_xnm from jw_jcdm_xnb where xnm=v_ydsxxnm;
  select min(dm) into v_xqm from zftal_xtgl_jcsjb where lx='0001' and dm=v_ydsxxqm;
  select min(xnm) into v_dqxnm from jw_jcdm_xnb where xnm=v_sqxnm;
  select min(dm) into v_dqxqm from zftal_xtgl_jcsjb where lx='0001' and dm=v_sqxqm;
  select min(ydlbm) into v_ydlbmm from jw_xjgl_xjydlbdmb where ydlbm=v_ydlbm;
  select zdz into v_scfs from jw_jcdml_xtnzb where zdm='XJYDCLWHSCFS';
  out_ycbj:='0';
  if v_scfs=1 then
  ----学籍异动处理文号生成方式：1，学年+学期+流水号（流水号取3位，每学期重置为001）2018-2019-1001
    begin
      select ((select xn.xnmc from jw_jcdm_xnb xn where xn.xnm = v_dqxnm) ||'-'||
              (select jcsj.mc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and jcsj.dm = v_dqxqm) ||
              (select nvl(lpad(max(to_number(substr(yd.ydwh, -1, 3)))+1,3,'0'),'001')
                  from jw_xjgl_xjydb yd
                where regexp_like(yd.ydwh,
                       (select xn.xnmc from jw_jcdm_xnb xn where xn.xnm = v_dqxnm) ||'-'||
                       (select jcsj.mc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and jcsj.dm = v_dqxqm) || '[0-9]{3}')) )clwh
            into out_clwh
       from dual;

    exception
      When others then
      out_ycbj:='1';
   end;

  elsif v_scfs=2 then
  ----学籍异动处理文号生成方式：2，【异动开始学年学期】+【异动类别（第一个字）】+【四位随机数】，如：201720181休0001
    begin
      select ((select replace(xn.xnmc, '-', '') from jw_jcdm_xnb xn where xn.xnm = v_xnm) ||
              (select jcsj.mc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and jcsj.dm = v_xqm) ||
              (select substr(ydlb.xjydmc, 1, 1) from jw_xjgl_xjydlbdmb ydlb
                where ydlb.ydlbm = v_ydlbmm) ||
              (select decode(count(1), 0, '0000',lpad(to_number(substr(max(yd.ydwh), -4))+1,4,'0'))
                 from jw_xjgl_xjydb yd
                where regexp_like(yd.ydwh,(select replace(xn.xnmc, '-', '') from jw_jcdm_xnb xn where xn.xnm = v_xnm) ||
              (select jcsj.mc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and jcsj.dm = v_xqm) ||
              (select substr(ydlb.xjydmc, 1, 1) from jw_xjgl_xjydlbdmb ydlb  where ydlb.ydlbm = v_ydlbmm) || '[0-9]{4}')) ) clwh
            into out_clwh
        from dual;

    exception
      When others then
      out_ycbj:='1';
    end;

  else
    select '' into out_clwh from dual;
  end if;
end proc_sp_xjydwhclwh;

/

