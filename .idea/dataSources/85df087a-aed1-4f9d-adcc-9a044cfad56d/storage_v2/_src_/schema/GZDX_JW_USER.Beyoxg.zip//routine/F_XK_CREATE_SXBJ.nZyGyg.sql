create function F_XK_CREATE_SXBJ
(vXnm varchar2,
 vXqm varchar2,
 vKch_id varchar2,
 vJxb_id varchar2,
 vJg_id varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vBh_id varchar2,
 vXh_id varchar2,
 vBj varchar2) return varchar2  ---选课筛选标记状态----
as
   sBjzt varchar2(500);   ---标记状态
   v_count number;
begin
    sBjzt := '9';
    begin
       if vBj = 'yxkc' then  --值小优先-按延续性课程优先。如：课程A->课程B为延续性课程，那么上一学期选了某教师课程A的学生，这学期如果选该教师课程B，将优先选上。
         select nvl(min(0),9) into sBjzt from jw_jh_kcyxyqb t1,jw_xk_xsxkb t2 where t1.yxkch_id = t2.kch_id
                                                                         and t2.xh_id = vXh_id
                                                                         and t1.kch_id = vKch_id;
       end if;

       if vBj = 'bnjzybj' then  --值小优先-按本年级本专业本班级学生优先。
         select nvl(min(0),9) into sBjzt from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2 where t1.jxb_id = t2.jxb_id
                                                                                      and t1.jxb_id = vJxb_id
                                                                                      and t2.njdm_id = vNjdm_id
                                                                                      and t2.zyh_id = vZyh_id
                                                                                      and t2.bh_id = vBh_id
                                                                                      and t1.xnm = vXnm
                                                                                      and t1.xqm = vXqm;
       end if;

       if vBj = 'bnjzyqtbj' then  --值小优先-按本年级本专业其他班级学生优先。
         select case when nvl(min(case when vBh_id = t2.bh_id then 0 else 9 end),9)>0
                           and nvl(min(case when vBh_id != t2.bh_id then 0 else 9 end),9) <= 0
                      then 0 else 9 end into sBjzt
                      from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2 where t1.jxb_id = t2.jxb_id
                                                                   and t1.jxb_id = vJxb_id
                                                                   and t2.njdm_id = vNjdm_id
                                                                   and t2.zyh_id = vZyh_id
                                                                   and t1.xnm = vXnm
                                                                   and t1.xqm = vXqm;
       end if;

        if vBj = 'bnjxyqtzy' then  --值小优先-按本年级本学院其他专业学生优先。
         select case when nvl(min(case when vZyh_id = t2.zyh_id then 0 else 9 end),9)>0
                           and nvl(min(case when vZyh_id != t2.zyh_id then 0 else 9 end),9)<= 0
                      then 0 else 9 end into sBjzt
                      from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2,zftal_xtgl_zydmb zy
                                                                       where t1.jxb_id = t2.jxb_id
                                                                         and t1.jxb_id = vJxb_id
                                                                         and t2.njdm_id = vNjdm_id
                                                                         and t2.zyh_id = zy.zyh_id
                                                                         and zy.jg_id = vJg_id
                                                                         and t1.xnm = vXnm
                                                                         and t1.xqm = vXqm;
       end if;

       if vBj = 'bnjqtxyzy' then  --值小优先-按本年级跨学院跨专业学生优先。
         select case when nvl(min(case when vJg_id = zy.jg_id then 0 else 9 end),9)>0
                           and nvl(min(case when vJg_id != zy.jg_id then 0 else 9 end),9) <= 0
                      then 0 else 9 end into sBjzt
                      from jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2,zftal_xtgl_zydmb zy
                                                                       where t1.jxb_id = t2.jxb_id
                                                                         and t1.jxb_id = vJxb_id
                                                                         and t2.njdm_id = vNjdm_id
                                                                         and t2.zyh_id = zy.zyh_id
                                                                         and t1.xnm = vXnm
                                                                         and t1.xqm = vXqm;
       end if;

       if vBj = 'bnjzykb' then  --值小优先-按本年级本专业本课表的学生优先。
         select  nvl(min(0),9) into sBjzt  from jw_jxrw_jxbxxb t1,jw_pk_tjkbjgb t2 where t1.jxb_id = t2.jxb_id
                                                                                     and t1.jxb_id = vJxb_id
                                                                                     and t1.xnm = t2.xnm
                                                                                     and t1.xqm = t2.xqm
                                                                                     and t2.njdm_id = vNjdm_id
                                                                                     and t2.zyh_id = vZyh_id
                                                                                     and t2.bh_id = vBh_id
                                                                                     and t2.xnm = vXnm
                                                                                     and t2.xqm = vXqm
                                                                                     and t1.xnm = vXnm
                                                                                     and t1.xqm = vXqm;
       end if;

       if vBj = 'bxqxszxf' then  --值小优先-按本学期选上学分总和小的优先选上。
         select to_char(nvl(sum(t3.xf),0),'FM0000.0') into sBjzt from jw_jxrw_jxbxxb t1,jw_xk_xsxkb t2,jw_jh_kcdmb t3 where t1.fjxb_id is null
                                                                                  and t1.jxb_id = t2.jxb_id
                                                                                  and t1.kch_id = t3.kch_id
                                                                                  and t1.xnm = t2.xnm
                                                                                  and t1.xqm = t2.xqm
                                                                                  and t1.xnm = vXnm
                                                                                  and t1.xqm = vXqm
                                                                                  and t2.xnm = vXnm
                                                                                  and t2.xqm = vXqm
                                                                                  and t1.kklxdm = vBh_id ----不做参数参加利用此函数不用的参数传值
                                                                                  and t2.xh_id = vXh_id;
       end if;

       if vBj = 'lxqxszxf' then  --值小优先-按历学期选上学分总和小的优先选上。
         select to_char(nvl(sum(t3.xf),0),'FM0000.0') into sBjzt from jw_jxrw_jxbxxb t1,jw_xk_xsxkb t2,jw_jh_kcdmb t3 where t1.fjxb_id is null
                                                                                  and t1.jxb_id = t2.jxb_id
                                                                                  and t1.kch_id = t3.kch_id
                                                                                  and t1.xnm = t2.xnm
                                                                                  and t1.xqm = t2.xqm
                                                                                  and t1.kklxdm = vBh_id ----不做参数参加利用此函数不用的参数传值
                                                                                  and t2.xh_id = vXh_id;
       end if;

        if vBj = 'jxzxjh' then --值小优先-按计划优先
          select decode(count(*),1,'0','9') into sBjzt from jw_jh_jxzxjhkcxxb t1,jw_jh_jxzxjhkcyxxdxnxqb t2
                              where t1.kch_id = vKch_id
                                and t1.jxzxjhkcxx_id = t2.jxzxjhkcxx_id
                                and t2.yxkkxnm=vXnm
                                and t2.yxkkxqm=vXqm
                                and t1.njdm_id=vNjdm_id
                                and t1.zyh_id=vZyh_id
                                and rownum=1;
        end if;

        if vBj = 'cxbsf' then --值小优先-按重修不刷分优先
          select decode(count(*),0,'9','0') into sBjzt from jw_xk_xsxkb where jxb_id=vJxb_id and xh_id=vXh_id and cxbj='1';
          /*if v_count=0 then
            sBjzt:='9';
          else
            select decode(count(*),0,'0','9') into sBjzt from jw_cj_xscjb where xh_id=vXh_id and kch_id=vKch_id and bfzcj>=60;
          end if;*/
        end if;

        if vBj = 'cxsf' then --值小优先-按重修刷分优先
           select decode(count(*),0,'9','0') into sBjzt from jw_cj_xscjb where xh_id=vXh_id and kch_id=vKch_id and bfzcj>=60;
          /*select count(*) into v_count from jw_xk_xsxkb where jxb_id=vJxb_id and xh_id=vXh_id and cxbj='1';
          if v_count=0 then
            sBjzt:='9';
          else
            select decode(count(*),0,'0','9') into sBjzt from jw_cj_xscjb where xh_id=vXh_id and kch_id=vKch_id and bfzcj>=60;
          end if;*/
        end if;

       if sBjzt is null then
         sBjzt :='9';
       end if;

     exception
        When others then
          sBjzt := '9';
    end;
    return sBjzt ;
end F_XK_CREATE_SXBJ;

/

