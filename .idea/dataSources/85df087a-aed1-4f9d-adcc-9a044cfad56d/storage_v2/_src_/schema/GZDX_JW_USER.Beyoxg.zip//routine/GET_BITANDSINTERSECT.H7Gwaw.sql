create function Get_BitandsIntersect(vWeeksUnion IN varchar2)
---1,3,5,7交集组合为 1 即周次1-1，1-2，1-1.3-3，1-3 交集组合为1-1
---周交集转为二进制或运算
--11001  1+8+16    = 25
--01101  1+4+8     = 13

--01001  1+8  = 9
--例如WeeksUnionToBitand(13,25) = 9
return number
as
  type Type_weekArray is table of int;
  i integer;
  k integer;
  aWeek integer;  ---周变量
  WeeksCount integer;--周组数
  WeeksUnion integer;--第一周
  WeekArray Type_weekArray := Type_weekArray(); ---周数组
begin
   WeeksCount := fn_jsfgfs(vWeeksUnion,',');
   if WeeksCount > 0 then
   i := 1;
   k := 1;
   for aWeek in 0..WeeksCount  loop  ---log(2,vBinary)取整


      weekArray.Extend;
      weekArray(i) :=  fn_jqzd(vWeeksUnion,   ---原数据
                                ',',      ---分格符
                                aWeek+1);
      i := i + 1;
  end loop;

  WeeksUnion := weekArray(1);
  for k in 1..WeeksCount loop
   WeeksUnion := bitand(WeeksUnion,weekArray(k+1));
  end loop;
  else
   WeeksUnion := 0;
  end if;
  return WeeksUnion;
end;


/

