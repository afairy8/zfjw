create procedure p_byfzxx_sczsh
(
  in_xhs in varchar2, --如果按勾选项生成，则对该项参数按,分割
  in_bynf in varchar2,--查询条件生成，毕业年份
  in_njdm in varchar2,--年级代码
  in_jg in varchar2,--机构
  in_zyh in varchar2,--专业
  in_bh in varchar2,--班级
  in_xm in varchar2,--学生
  in_byjr in varchar2,--毕业结论
  in_zslx in varchar2,--证书类型
  in_drfs in varchar2,--导入方式
  out_flag out varchar2,
  out_msg out varchar2
)
as
v_count number;
type my_cursor is ref cursor; --定义一个Ref游标变量
type my_cursor2 is ref cursor; --定义一个Ref游标变量
v_byxx_cursor my_cursor; --毕业信息游标
TYPE v_byxx_REC IS RECORD(
    bynf varchar2(200),
    byjr varchar2(200),
    xh_id varchar2(200),
    xh varchar2(200),
    xm varchar2(200),
    xz varchar2(200)
);
TYPE v_gz_REC IS RECORD(
    qsw  varchar2(200),
    ws  varchar2(200),
    xh  varchar2(200),
    clz  varchar2(200),
    zdm  varchar2(200),
    sfyqsw  varchar2(200),
    wsbl  varchar2(200)
);
v_byxx v_byxx_REC;
v_gz_cursor my_cursor2;  --规则游标
v_gz v_gz_REC;
v_sql varchar2(8000);
sqlstr varchar2(8000);
v_bh varchar2(200);
v_tmp varchar2(200);
v_subLength varchar2(2);
begin
      if  (in_xhs is null ) and (in_bynf is null )  and(in_njdm is null)  and(in_jg is null)
         and (in_zyh is null ) and(in_bh is null )  and (in_xm is null )  and (in_byjr is null )  then
         out_flag := -3;
        out_msg := '请至少勾选一条数据或选择一个查询条件！';
        goto nextOne;
      end if;

      if (in_drfs is null  ) or (in_zslx is null  )  then
           out_flag := -4;
           out_msg := '导入方式和证书类型不能为空';
           goto nextOne;
      end if;

     --首先判断相应的证书规则有没有配置
     select count(1) into v_count from jw_bygl_zshgzxxb a, jw_bygl_zshgzjcdmb b  where a.zdm=b.zdm and a.gzlx= b.gzlx and b.sfqy = '1' and a.gzlx =  in_zslx;
     if v_count=0 then
        out_flag := -1;
        out_msg := '证书号规则未设置，请与管理员联系！';
        goto nextOne;
     end if;
     --r如果传入学号为空，则按条件查询，反之则按学号查询
     if in_xhs is null or in_xhs ='' then
        v_sql:=  'select   t1.bynf,  t1.byjr,  t2.xh_id,  t2.xh, t2.xm, t3.xz
           from
                jw_bygl_bysfzxxb t1,
                 jw_xjgl_xsjbxxb t2,
                 jw_xjgl_xsxjxxb t3
          where t1.xh_id = t2.xh_id
            and t1.xh_id = t3.xh_id
            and t3.xnm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXNM'||chr(39)||')
             and t3.xqm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXQM'||chr(39)||')';
           if in_njdm is not null  then
                 v_sql:=   v_sql||  ' and t3.njdm_id ='||chr(39)||in_njdm||chr(39);
          end if;
          if in_jg is not null   then
                 v_sql:=   v_sql||  ' and t3.jg_id ='||chr(39)||in_jg||chr(39);
          end if;
          if in_zyh is not null  then
                 v_sql:=   v_sql||  ' and t3.zyh_id ='||chr(39)||in_zyh||chr(39);
          end if;
          if in_bh is not null   then
                 v_sql:=   v_sql||  ' and t3.bh_id ='||chr(39)||in_bh||chr(39);
          end if;
          if in_bynf is not null  then
                 v_sql:=   v_sql||  ' and  t1.bynf ='||chr(39)||in_bynf||chr(39);
          end if;
          if in_xm is not null   then
                 v_sql:=   v_sql||  ' and (t2.xm like '||chr(39)||'%'||chr(39)||chr(39)||in_xm||chr(39)||chr(39)||'%'||chr(39)||' or t2.xh like '||chr(39)||'%'||chr(39)||chr(39)||in_xm||chr(39)||chr(39)||'%'||chr(39)||')';
          end if;
          if in_byjr is not null  then
                 v_sql:=   v_sql||  ' and t1.byjr like '||chr(39)||'%'||chr(39)||chr(39)||in_byjr||chr(39)||chr(39)||'%'||chr(39);
          end if;
          --导入方式是1即为追加，2是覆盖，追加的时候需要查询相应栏位为空的数据
          if in_drfs = '1' then
             if in_zslx = '1' then
                v_sql:=   v_sql||  ' and t1.xwzsh is null';
             end if;
             if in_zslx ='2' then
                 v_sql:=   v_sql||  ' and t1.byzsh is null';
             end if;
          end if;
          v_sql:=v_sql||' order by t1.xh_id';
     else

     v_sql := 'select   t1.bynf,  t1.byjr,  t2.xh_id,  t2.xh, t2.xm, t3.xz
           from
                jw_bygl_bysfzxxb t1,
                 jw_xjgl_xsjbxxb t2,
                 jw_xjgl_xsxjxxb t3
          where t1.xh_id = t2.xh_id
            and t1.xh_id = t3.xh_id
            and t3.xnm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXNM'||chr(39)||')
             and t3.xqm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXQM'||chr(39)||')
              and instr('||chr(39)||','||chr(39)||'||'||chr(39)||in_xhs||chr(39)||'||'||chr(39)||','||chr(39)||','||chr(39)||','||chr(39)||'||t1.xh_id||'||chr(39)||','||chr(39)||') > 0';
             if in_drfs = '1' then
               if in_zslx = '1' then
                  v_sql:=   v_sql||  ' and t1.xwzsh is null';
               end if;
               if in_zslx ='2' then
                   v_sql:=   v_sql||  ' and t1.byzsh is null';
               end if;
             end if;
             v_sql:=v_sql||' order by t1.xh_id';
     end if;

     ---如果覆盖 先清空查出来的所有学生
     if in_drfs = '2' then
             if in_zslx = '1' then
                sqlstr:=   'update jw_bygl_bysfzxxb t set xwzsh=null where exists(select 1 from ('||v_sql||')a where a.xh_id = t.xh_id)';
             end if;
             if in_zslx ='2' then
                sqlstr:=   'update jw_bygl_bysfzxxb t set byzsh=null where exists(select 1 from ('||v_sql||')a where a.xh_id = t.xh_id)';
             end if;
         execute immediate sqlstr;
     end if;

     open v_byxx_cursor for v_sql;
     loop
       fetch v_byxx_cursor into v_byxx;
        exit when v_byxx_cursor%notfound;
        v_bh:='';--每次循环重置
        open v_gz_cursor for  select a.qsw,a.ws,a.xh,a.clz,a.zdm ,b.sfyqsw,b.wsbl from jw_bygl_zshgzxxb a ,jw_bygl_zshgzjcdmb b where a.zdm = b.zdm and a.gzlx= b.gzlx and b.sfqy = '1'  and  a.gzlx = in_zslx order by to_number(a.xh);
         loop
           fetch v_gz_cursor into v_gz;
            --判断当前游标是否到达最后
            exit when v_gz_cursor%notfound;

            if v_gz.sfyqsw = '0'  then  --常量
                v_bh:=  v_bh||v_gz.clz;
            elsif v_gz.sfyqsw ='2' and  v_gz.wsbl  is not null then --流水号
               if in_zslx = '1' then
                  select nvl(max(to_number(substr(xwzsh,v_subLength+1,v_gz.ws))),0) into v_count from jw_bygl_bysfzxxb where  xwzsh like v_bh||'%';
               end if;
               if in_zslx ='2' then
                  select nvl(max(to_number(substr(byzsh,v_subLength+1,v_gz.ws))),0) into v_count from jw_bygl_bysfzxxb where  byzsh like v_bh||'%';
               end if;

                --v_count := 0;
/*                if v_gz.qsw is not null then
                  v_count := to_number(v_gz.qsw);
                end if;*/
                v_count:= v_count+1;
                if length(v_count) >to_number(v_gz.ws) then
                  out_flag := -2;
                  out_msg := '证书号规则流水号小于待处理数据';
                  goto nextOne;
                end if;
                if v_gz.wsbl ='1' then
                  select lpad(v_count,v_gz.ws,0) into v_tmp from dual;
                else
                   v_tmp:=to_char(v_count);
                end if;
                v_bh := v_bh|| v_tmp;
            elsif v_gz.sfyqsw ='1' and  v_gz.wsbl is null then --其他设置项
              if v_gz.zdm = 'XXDM' then --学校代码
                 if v_gz.qsw is not null and v_gz.ws is not null then
                   select substr(XXDM,v_gz.qsw,v_gz.ws) INTO v_tmp from zftal_xtgl_xxxxszb;
                 else
                 select XXDM INTO v_tmp from zftal_xtgl_xxxxszb;
                 end if ;
                 v_bh := v_bh|| v_tmp;
              end if;
              if v_gz.zdm = 'XZ' then --学制
                v_tmp:=  v_byxx.xz;
                v_bh := v_bh|| v_tmp;
              end if;
              if v_gz.zdm = 'BYNF' then --毕业年份
                v_tmp:= v_byxx.bynf;
                v_bh := v_bh|| v_tmp;
              end if;
            end if;
            select length(v_bh)into v_subLength from dual;
        end loop;
        --关闭规则游标
        close v_gz_cursor;
        v_sql:='update jw_bygl_bysfzxxb ' ;
        if in_zslx = '1' then
              v_sql:=   v_sql||'set xwzsh ='||chr(39)||v_bh||chr(39);
        end if;
        if in_zslx = '2' then
              v_sql:=   v_sql||'set byzsh ='||chr(39)||v_bh||chr(39);
        end if;
         v_sql:=   v_sql||' where xh_id = '||chr(39)|| v_byxx.xh_id||chr(39);

         execute immediate v_sql;
     end loop;
     close v_byxx_cursor; --关闭毕业规则游标
     out_flag :='0';--执行结束
     out_msg:='执行结束';
     <<nextOne>>

     if out_flag = '-1' then
         rollback;
     else
         commit;
     end if;
end;

/

