create function fun_byysh_hdxfbl(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
sJg varchar2(2000);   ---学生获得学分/本专业要求最低毕业学分
v_bl varchar2(6);
begin
sJg := '合格';
begin
	select nvl(xyjd,0) into v_bl from jw_bygl_xsxyyjyshjgb c where  c.xh_id = v_xh_id;
	 if to_number(v_bl)<to_number(v_tjsjz) then
		sJg:= '学生获得学分/本专业要求最低毕业学分比例'||v_bl||'%<'||v_tjsjz||'%,不合格！';
	 else
		sJg:= '学生获得学分/本专业要求最低毕业学分比例'||v_bl||'%>='||v_tjsjz||'%,合格！';
	 end if;

 exception
	When others then
	  sJg := '查询出错，不合格！';
end;

if sJg is null then
 return '系统无数据，不合格！' ;
else
return sJg ;
end if ;
end fun_byysh_hdxfbl;

/

