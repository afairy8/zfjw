create Function F_XK_SAME_XKGZSZ(v_xkkz_id in Varchar)
Return varchar2
as
  r_xkkz_id varchar2(2000);
  standard_status number;
  standard_count number;
  z_mxxsdx_count number;
  v_mxxsdx_count number;
  --满足选课规则基本设置内容完全相同的记录对应的xkkz_id，并剔除v_xkkz_id
  cursor cursor_xkgz is
          select a.xkkz_id
        from jw_xk_xkkzb a, jw_xk_xkkzxmb b
        where a.xkkz_id = b.xkkz_id and a.xkkz_id!=v_xkkz_id
           and exists
           (select 1 from jw_xk_xkkzb c, jw_xk_xkkzxmb d
          where c.xkkz_id = d.xkkz_id and a.xnm = c.xnm and a.xqm = c.xqm
               and a.kklxdm = c.kklxdm and a.xklc = c.xklc and a.bklx_id = c.bklx_id and a.xkkssj = c.xkkssj
               and a.xkjssj = c.xkjssj and nvl(a.bz, '-1') = nvl(c.bz, '-1')
               and nvl(b.sfqjszws, '-1') = nvl(d.sfqjszws, '-1') and nvl(b.sfyjxk, '-1') = nvl(d.sfyjxk, '-1')
               and nvl(b.rlkz, '-1') = nvl(d.rlkz, '-1') and nvl(b.rlzlkz, '-1') = nvl(d.rlzlkz, '-1')
               and nvl(b.zckz, '-1') = nvl(d.zckz, '-1') and nvl(b.pjkz, '-1') = nvl(d.pjkz, '-1')
               and nvl(b.sfkxk, '-1') = nvl(d.sfkxk, '-1') and nvl(b.bxqzdxkxf, '-1') = nvl(d.bxqzdxkxf, '-1')
               and nvl(b.bxqzgxkxf, '-1') = nvl(d.bxqzgxkxf, '-1') and nvl(b.lnzdxkxf, '-1') = nvl(d.lnzdxkxf, '-1')
               and nvl(b.lnzgxkxf, '-1') = nvl(d.lnzgxkxf, '-1') and nvl(b.bxqzdxkmc, '-1') = nvl(d.bxqzdxkmc, '-1')
               and nvl(b.bxqzgxkmc, '-1') = nvl(d.bxqzgxkmc, '-1') and nvl(b.lnzdxkmc, '-1') = nvl(d.lnzdxkmc, '-1')
               and nvl(b.lnzgxkmc, '-1') = nvl(d.lnzgxkmc, '-1') and nvl(b.sfktk, '-1') = nvl(d.sfktk, '-1')
               and nvl(b.tktjrs, '-1') = nvl(d.tktjrs, '-1') and nvl(b.sfkknj, '-1') = nvl(d.sfkknj, '-1')
               and nvl(b.sfkkzy, '-1') = nvl(d.sfkkzy, '-1') and nvl(b.sfkgbcx, '-1') = nvl(d.sfkgbcx, '-1')
               and nvl(b.sfkdkbcx, '-1') = nvl(d.sfkdkbcx, '-1') and nvl(b.sfrxtgkcxd, '-1') = nvl(d.sfrxtgkcxd, '-1')
               and nvl(b.tykczgxdcs, '-1') = nvl(d.tykczgxdcs, '-1') and nvl(b.kkbk, '-1') = nvl(d.kkbk, '-1')
               and nvl(b.kkbkdj, '-1') = nvl(d.kkbkdj, '-1') and nvl(b.sfzyxk, '-1') = nvl(d.sfzyxk, '-1')
               and nvl(b.zdzys, '-1') = nvl(d.zdzys, '-1') and nvl(b.sfqzxk, '-1') = nvl(d.sfqzxk, '-1')
               and nvl(b.sfznkx, '-1') = nvl(d.sfznkx, '-1') and nvl(b.zdkxms, '-1') = nvl(d.zdkxms, '-1')
               and nvl(b.xkly, '-1') = nvl(d.xkly, '-1') and nvl(b.jfkz, '-1') = nvl(d.jfkz, '-1')
               and nvl(b.cxkctxs, '-1') = nvl(d.cxkctxs, '-1') and c.xkkz_id = v_xkkz_id);
  --v_xkkz_id对应的面向对象的数据
  cursor cursor_mxxsdx is
        select
            xzlb,nvl(xqh_id,'-1') xqh_id,nvl(jg_id,'-1') jg_id,nvl(zyh_id,'-1') zyh_id,
            nvl(zyfx_id,'-1') zyfx_id,nvl(bh_id,'-1') bh_id,nvl(xbm,'-1') xbm,
            nvl(xslbm,'-1') xslbm,nvl(ccdm,'-1') ccdm,nvl(xh_id,'-1') xh_id,px
        from jw_xk_mxdxb where xkkz_id=v_xkkz_id;

begin
     --将v_xkkz_id编入返回数据中
     r_xkkz_id := v_xkkz_id;
     --查出指定选课规则有多少条面向对象数据，它是其他选课规则的比较标准
     select count(mxdxb_id) into standard_count from JW_XK_MXDXB where xkkz_id=v_xkkz_id;
     for p_xkgz in cursor_xkgz loop
        standard_status := 1;  --每次循环前将是否编入返回数据的标准状态置为可编入
        select count(mxdxb_id) into z_mxxsdx_count from JW_XK_MXDXB where xkkz_id=p_xkgz.xkkz_id;
        if z_mxxsdx_count = standard_count then --待编入的选课规则的面向对象总记录数与标准记录数相同是检测的第一层要求
            for p_mxxsdx in cursor_mxxsdx loop --判断标准记录中的记录内容在待编入的选课规则中是否都存在
              select
                count(mxdxb_id) into v_mxxsdx_count
              from JW_XK_MXDXB
              where xkkz_id=p_xkgz.xkkz_id and xzlb=p_mxxsdx.xzlb and nvl(xqh_id,'-1')=p_mxxsdx.xqh_id
                  and nvl(jg_id,'-1')=p_mxxsdx.jg_id and nvl(zyh_id,'-1')=p_mxxsdx.zyh_id and nvl(zyfx_id,'-1')=p_mxxsdx.zyfx_id
                  and nvl(bh_id,'-1')=p_mxxsdx.bh_id and nvl(xbm,'-1')=p_mxxsdx.xbm and nvl(xslbm,'-1')=p_mxxsdx.xslbm
                  and nvl(ccdm,'-1')=p_mxxsdx.ccdm and nvl(xh_id,'-1')=p_mxxsdx.xh_id and px=p_mxxsdx.px;
              if v_mxxsdx_count = 0 then --说明这条标准记录中的记录内容在待编入的选课规则中不存在
                standard_status := 0; --不将其编入，将标准状态置为０
                goto nextOne; --跳出该层循环
              end if;
            end loop;
            <<nextOne>>
            if standard_status = 1 then
              r_xkkz_id := r_xkkz_id ||','||p_xkgz.xkkz_id;
            end if;
        end if;
     end loop;
     return r_xkkz_id;
end;

/

