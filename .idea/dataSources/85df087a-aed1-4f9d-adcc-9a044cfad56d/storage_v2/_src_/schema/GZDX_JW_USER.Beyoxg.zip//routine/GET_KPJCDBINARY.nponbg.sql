create Function Get_KpjcdBinary(vXnm in Varchar,vXqm in Varchar,vXqhId in Varchar,vXqj in Number,vJcd in Number,vJcs in Number)
---如：Get_KpjcdBinary(2015,12,1,1,7,2) 返回3；
Return integer
as
  ikpjcd integer := 0;--可排节次段
  icount integer;--可选节次方案数
  iqsj integer;--起始节
begin
  select count(*) into icount from (
  --节次表大节
  select xnm,xqm,xqh_id,xqj,sum(jcm) jc,min(jcm) qsj from (
  select a.xnm,a.xqm,a.xqh_id,d.xqj,c.rsdm,b.jcm,b.xsdj from jw_pk_rsdszb a, jw_pk_rjcszb b, jw_pk_rsddmb c,
         (select xnm,xqm,rn xqj from jw_pk_pkkzb a,(select rownum rn from zftal_xtgl_jcsjlxb) b where a.zt=1 and rn <= kblx) d
  where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and c.qyzt = '1' and a.xnm = d.xnm and a.xqm = d.xqm
    and a.xnm = vXnm and a.xqm = vXqm and a.xqh_id = vXqhId and d.xqj=vXqj
  ) group by xnm,xqm,xqh_id,xqj,rsdm,xsdj
  union all
  --设置的特殊可排大节
  select xnm,xqm,xqh_id,xqj,jc,qsj from jw_pk_kpjcszb where xnm = vXnm and xqm = vXqm and xqh_id = vXqhId and xqj=vXqj
  ) where fn_jszs(bitand(jc,vJcd))>=vJcs and power(2,fn_jqzd(fn_bittozc(bitand(jc,vJcd)),',',1))=qsj;

  if icount > 0 then
     select fn_jqzd(fn_bittozc(qsj),',',1) into iqsj from (
        select qsj from (
        --节次表大节
        select xnm,xqm,xqh_id,xqj,sum(jcm) jc,min(jcm) qsj from (
        select a.xnm,a.xqm,a.xqh_id,d.xqj,c.rsdm,b.jcm,b.xsdj from jw_pk_rsdszb a, jw_pk_rjcszb b, jw_pk_rsddmb c,
               (select xnm,xqm,rn xqj from jw_pk_pkkzb a,(select rownum rn from zftal_xtgl_jcsjlxb) b where a.zt=1 and rn <= kblx) d
        where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and c.qyzt = '1' and a.xnm = d.xnm and a.xqm = d.xqm
          and a.xnm = vXnm and a.xqm = vXqm and a.xqh_id = vXqhId and d.xqj=vXqj
        ) group by xnm,xqm,xqh_id,xqj,rsdm,xsdj
        union all
        --设置的特殊可排大节
        select xnm,xqm,xqh_id,xqj,jc,qsj from jw_pk_kpjcszb where xnm = vXnm and xqm = vXqm and xqh_id = vXqhId and xqj=vXqj
        ) where fn_jszs(bitand(jc,vJcd))>=vJcs and power(2,fn_jqzd(fn_bittozc(bitand(jc,vJcd)),',',1))=qsj order by qsj
     ) where rownum<=1;
    --用需排节次数处理可排节次段
    ikpjcd := Get_JcToBinary((iqsj+1)||'-'||(iqsj+vJcs));
  end if;
  return ikpjcd;
end;

/

