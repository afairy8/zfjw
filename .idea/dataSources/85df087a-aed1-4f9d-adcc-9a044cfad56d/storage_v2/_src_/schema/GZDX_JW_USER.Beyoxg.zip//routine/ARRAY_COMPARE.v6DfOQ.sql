create function array_compare(piv_str1 in varchar2,
                                         piv_str2 in varchar2)
  RETURN VARCHAR2 AS
  V_COMPARE number;
  v_nbr     number;
begin

  select count(*)
    into v_nbr
    from (select column_value as a1 from table(my_split(piv_str1, ','))) a,
         (select column_value as a2 from table(my_split(piv_str2, ','))) b
   where a.a1 = b.a2;

  if v_nbr > 0 then
    V_COMPARE := 1;
  else
    V_COMPARE := 0;
  end if;

  return V_COMPARE;
end array_compare;


/

