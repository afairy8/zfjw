create view VIEW_CJ_CXKC as
  select
cxxnm||'-'||CXXQM||'-'||KCH_ID cxkc_id,
cxxnm,cxxnmc,CXXQM,cxxqmc,KCH_ID,kch,kcmc,kcywmc,xf,kkxy_id,kkxydm,kkxymc,kclbdm,kclbmc,kcgsdm,kcgsmc,
bmrs,yprws,jxrwgs,jxrwzrs,yscrs,
(case
when jxrwgs>0 and jxrwgs<=yprws then '0'
when jxrwgs>0 and jxrwgs>yprws then '1'
when jxrwgs=0 or (jxrwgs>0 and yprws=0) then '2'
else ''
end) aprwztdm,
(case
when jxrwgs>0 and jxrwgs<=yprws then '已安排'
when jxrwgs>0 and jxrwgs>yprws then '部分安排'
when jxrwgs=0 or (jxrwgs>0 and yprws=0) then '未安排'
else ''
end) aprwztmc,
(case
when bmrs=0 or (bmrs>0 and bmrs<=yscrs) then '0'
when bmrs>0 and bmrs>yscrs then '1'
when bmrs>0 and yscrs=0 then '2'
else ''
end) scmdztdm,
(case
when bmrs=0 or (bmrs>0 and bmrs<=yscrs) then '已生成'
when bmrs>0 and bmrs>yscrs then '部分生成'
when bmrs>0 and yscrs=0 then '未生成'
else ''
end) scmdztmc
from
(
select
cxxnm,
max(cxxnmc) cxxnmc,
CXXQM,
max(cxxqmc) cxxqmc,
KCH_ID,
max(kch) kch,
max(kcmc) kcmc,
max(kcywmc) kcywmc,
max(xf) xf,
max(kkxy_id) kkxy_id,
max(kkxydm) kkxydm,
max(kkxymc) kkxymc,
max(kclbdm) kclbdm,
max(kclbmc) kclbmc,
max(kcgsdm) kcgsdm,
max(kcgsmc) kcgsmc,
count(*) bmrs,
(select  count(*) from view_jxrw_jxbxxb where xnm=t1.cxxnm and xqm=t1.cxxqm and kch_id=t1.kch_id and sfyxm='1') yprws,
(select count(*) from JW_JXRW_JXBXXB t4 where kklxdm='08' and xnm=t1.cxxnm and xqm=t1.cxxqm and kch_id=t1.kch_id) jxrwgs,
(select nvl(sum(nvl(jxbrs,0)+nvl(krrl,0)),0) from JW_JXRW_JXBXXB t4 where kklxdm='08' and xnm=t1.cxxnm and xqm=t1.cxxqm and kch_id=t1.kch_id) jxrwzrs,
(select count(*) from jw_xk_xsxkb t2 where cxbj='1' and xnm=t1.cxxnm and xqm=t1.cxxqm and kch_id=t1.kch_id
and exists (select 'X' from jw_cj_cxbmb where xnm=t2.xnm and xqm=t2.xqm and kch_id=t2.kch_id and xh_id=t2.xh_id)) yscrs
 from view_cj_cxbm t1 group by cxxnm,CXXQM,KCH_ID) t3
/

comment on table VIEW_CJ_CXKC
is '视图_成绩_重修课程'
/

