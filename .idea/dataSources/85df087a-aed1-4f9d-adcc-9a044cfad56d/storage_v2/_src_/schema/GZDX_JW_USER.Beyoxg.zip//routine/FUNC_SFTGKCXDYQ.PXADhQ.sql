create function func_sftgkcxdyq(vXnm in varchar2, vXqm in varchar2, vXh_id in varchar2, vKcxdyq in varchar2, vKcxdyqtgzb in varchar2)
    ---返回值：0-不通过，1-通过
return varchar2 as
   result_flag varchar2(1);
   isum number;
   itgsum number;
begin
       result_flag := '0';

       select count(1) into isum from jw_jh_kcdmb where instr(','||vKcxdyq||',',','||kch_id||',')>0;
       select count(1) into itgsum from jw_cj_xscjb cj where cj.xnm||lpad(cj.xqm,2,'0') <= vXnm||lpad(vXqm,2,'0')
             and cj.bfzcj >= 60 and cj.xh_id = vXh_id and instr(','||vKcxdyq||',',','||cj.kch_id||',')>0;

       if isum * nvl(vKcxdyqtgzb,0) <= itgsum * 100 then
         result_flag := '1';
       end if;

       return result_flag;
end func_sftgkcxdyq;

/

