create view GZDXJCJK_BJDMBVIEW as
  select bjmc, bjdm, sszydm, nj, ssxydm, ssxqdm
  from (select a.bj     bjmc,
               a.bh     bjdm,
               c.zyh_id sszydm,
               b.njmc   nj,
               a.jg_id  ssxydm,
               a.xqh_id ssxqdm
          from zftal_xtgl_bjdmb a,
               zftal_xtgl_njdmb b,
               zftal_xtgl_zydmb c,
               zftal_xtgl_jgdmb d
         where a.njdm_id = b.njdm_id
           and a.zyh_id = c.zyh_id
           and a.jg_id = d.jg_id
        union
        select '无班级（占用）' bjmc,
               'XXXXXXXXXX' bjdm,
               'XXXX' sszydm,
               (select zdz from zftal_xtgl_xtszb where zs = '当前学年') nj,
               '40' ssxydm,
               '1' ssxqdm
          from dual)
/

