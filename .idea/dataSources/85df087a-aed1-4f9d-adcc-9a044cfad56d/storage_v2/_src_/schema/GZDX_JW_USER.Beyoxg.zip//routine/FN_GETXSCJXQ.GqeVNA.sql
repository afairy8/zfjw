create function fn_getXscjxq(vJxb_id varchar2,vXh_id varchar2) return  varchar2--返回学生成绩详情
as
  sCjxq varchar2(200);--成绩详情
begin
  if vJxb_id is null then
     return '';
  end if;
  select wm_concat(b.xmblmc||':'||a.xmcj) into sCjxq from jw_cj_xmcjb a, jw_cj_xmblszb b
  	where a.xmbl_id = b.xmbl_id and a.jxb_id = b.jxb_id and nvl(a.xmbl,b.xmbl) > 0
  	  and a.xh_id = vXh_id  and a.jxb_id = vJxb_id
    order by b.xmblxh;
  if sCjxq is null then
     return '';
  else
     return sCjxq;
  end if;
end fn_getXscjxq;

/

