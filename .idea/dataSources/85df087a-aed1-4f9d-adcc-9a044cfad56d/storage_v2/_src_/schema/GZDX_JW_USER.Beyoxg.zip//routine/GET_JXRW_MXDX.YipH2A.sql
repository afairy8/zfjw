create function get_jxrw_mxdx(vjxb_id varchar2,vxzlb varchar2)--获取面向对象信息
--vjxb_id（教学班id），vxzlb：限制类别（mx,xz）
return varchar2
as
sMianXdX varchar2(1000);
begin
   begin
   --获取面向对象中组合对象信息和学生对象信息
   select wm_concat(xx) into sMianXdX
   from (select wm_concat(njdm||xqmc||jgmc||zymc||zyfxmc||bj||xb||ccmc||xh||xslbmc||xsxzmc) xx
           from (select (select xqmc from zftal_xtgl_xqdmb where xqh_id = t1.xqh_id ) xqmc,
                        (select jgmc from zftal_xtgl_jgdmb where jg_id = t1.jg_id ) jgmc,
                        (select zymc from zftal_xtgl_zydmb where zyh_id = t1.zyh_id ) zymc,
                        (select zyfxmc from zftal_xtgl_zyfxdmb where zyfx_id = t1.zyfx_id ) zyfxmc,
                        t1.njdm_id,
                        (select njdm from zftal_xtgl_njdmb where njdm_id=t1.njdm_id) njdm,
                        (select bj from zftal_xtgl_bjdmb where bh_id = t1.bh_id ) bj,
                        (select mc from zftal_xtgl_jcsjb where lx = '0006' and dm = t1.xbm) xb,
                        (select mc from zftal_xtgl_jcsjb where lx='0016' and dm= t1.xslbm) xslbmc ,--学生类别：普通专科生，成人专科生等
                        (select mc from zftal_xtgl_jcsjb where lx = '0014'  and dm = t1.ccdm ) ccmc,--层次：博士，本科等
                        (select wm_concat(xsxzmc) from jw_xjgl_xsxzdmb a where bitand(a.xsxzm,t1.xsbj)>0 ) xsxzmc,--学生性质：民族生，交换生等
                        (select xh from jw_xjgl_xsjbxxb where xh_id=t1.xh_id) xh,
                        t1.xh_id
                   from jw_jxrw_mxdxb t1, jw_jxrw_jxbxxb t2
                  where t1.jxb_id = t2.jxb_id
                    and t1.xzlb = vxzlb
                    and t1.jxb_id = vjxb_id)
          where xh_id is null
         union all
         select wm_concat(xs.xh || xs.xm ) xx
           from (select (select xqmc from zftal_xtgl_xqdmb where xqh_id = t1.xqh_id ) xqmc,
                        (select jgmc from zftal_xtgl_jgdmb where jg_id = t1.jg_id ) jgmc,
                        (select zymc from zftal_xtgl_zydmb where zyh_id = t1.zyh_id ) zymc,
                        (select zyfxmc from zftal_xtgl_zyfxdmb where zyfx_id = t1.zyfx_id ) zyfxmc,
                        t1.njdm_id,
                        (select bj from zftal_xtgl_bjdmb where bh_id = t1.bh_id ) bj,
                        (select mc from zftal_xtgl_jcsjb where lx = '0006' and dm = t1.xbm) xb,
                        (select mc from zftal_xtgl_jcsjb where lx='0016' and dm= t1.xslbm) xslbmc ,
                        (select mc from zftal_xtgl_jcsjb where lx = '0014' and dm = t1.ccdm ) ccmc,
                        (select wm_concat(xsxzmc) from jw_xjgl_xsxzdmb a where bitand(a.xsxzm,t1.xsbj)>0 ) xsxzmc,
                        t1.xh_id
                   from jw_jxrw_mxdxb t1, jw_jxrw_jxbxxb t2
                  where t1.jxb_id = t2.jxb_id
                    and t1.xzlb = vxzlb
                    and t1.jxb_id = vjxb_id) a,
                jw_xjgl_xsjbxxb xs
          where xs.xh_id = a.xh_id
            and a.xh_id is not null
           );
    exception
        When others then
          sMianXdX := null;
    end;
return sMianXdX;
end;

/

