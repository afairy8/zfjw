create function get_Kch_test(v_kcxx varchar2)  --课程号生成规则重写一个，如果之前的get_Kch函数不满足时可以用这个
 Return varchar2 as
  cursor c_gzxxs is
    select zdm, zdsylx, sfbl, ws, zdz,qsw,
    case when zdsylx = '0' then
         (case when qsw is null then  (case when sfbl = '0' then 'SUBSTR('||ZDM||',1,'||WS||')' else 'LPAD(SUBSTR('||ZDM||',1,'||WS||'),'||WS||',''0'')' end )
               else (case when sfbl = '0' then 'SUBSTR('||ZDM||','||qsw||','||WS||')' else 'LPAD(SUBSTR('||ZDM||','||qsw||','||WS||'),'||WS||',''0'')' end ) end)
     when zdsylx = '2'  then zdz end AS ZDGZXX  from jw_jh_kchgzszb where xh is not null order by xh asc;
  c_gzxx     c_gzxxs%rowtype;

  lshqhbj varchar2(2); ---流水号前后标记0表示在流水号前,1表示在流水号后

  lshqws number;       ---流水号前位数
  lshhws number;       --流水号后位数
  lshws  number;       --流水号位数
  i      number;       --生成规则个数
  k      number;       --页面参数个数
  j      number;       --FOR循环变量参数

  lshqzdxx varchar2(500);  ---流水号前字段信息
  lshhzdxx varchar2(500);  ---流水号后字段信息
  lshzdxx  varchar2(50);   ---流水号字段信息

  gzmsxx varchar(500);     --生成规则信息参数
  ymcsxx varchar2(500);    --页面参数信息

  out_kch  varchar2(200);  --返回课程号信息
  xxdm     varchar2(10);   --学校代码
  kcxx_array mytype; --存放传入课程信息分割后的数组
  zdxx_array mytype; --存放kcxx_array中分割后的字段名和字段值
  v_sql      varchar2(4000);

begin
  i := 0;           --生成规则个数初始
  k := 0;           --页面参数个数初始

  lshqhbj := '0'; ---流水号前后标记
  lshqws := 0;  ---流水号前位数
  lshhws := 0;  ---流水号后位数
  lshws  := 0;  ---流水号位数

  lshqzdxx := ''; ---流水号前字段信息
  lshhzdxx := ''; ---流水号后字段信息
  lshzdxx  := ''; ---流水号字段信息

  gzmsxx := '';   --生成规则信息参数初始
  ymcsxx := '';   --页面参数信息初始

  for c_gzxx in c_gzxxs loop   ---生成规则表内信息循环
   if c_gzxx.zdsylx ='1' then  ---字段使用类型1表示流水号;0表示默认信息;2表示常量
    lshws    :=  c_gzxx.ws;    ---流水号位数
    lshzdxx  := '';            ---流水号字段初始
    lshqhbj  := '1';           ---流水号前后标记改为1为后
    else
     if lshqhbj = '0' then
        if lshqzdxx is null then
          lshqzdxx := c_gzxx.ZDGZXX;  ---流水号前字段规则信息
          else
          lshqzdxx := lshqzdxx ||'||'||c_gzxx.ZDGZXX;
        end if;
        lshqws := lshqws+c_gzxx.ws;   ---流水号前总位数
       else
        lshhzdxx := lshhzdxx ||'||'||c_gzxx.ZDGZXX;  ---流水号后字段规则信息
        lshhws := lshhws+c_gzxx.ws;   ---流水号后总位数
     end if;
     k := k+1;
   end if;
   gzmsxx := gzmsxx||'|'||c_gzxx.zdm;    --生成规则信息参数
  end loop;

  kcxx_array := my_split(v_kcxx, ';');
  FOR j IN 1 .. kcxx_array.count LOOP
   zdxx_array := my_split(kcxx_array(j), ':');
   if zdxx_array(1) = 'kkbm_id' then
    select jg.jgdm into zdxx_array(2) from zftal_xtgl_jgdmb jg where jg.jg_id =  zdxx_array(2);
   end if;
   ----北京化工大学提出的学分对应编码要求，现先放开统用
   if zdxx_array(1) = 'xf' then
      select (case when ceil((case when to_number(zdxx_array(2)) < 1 then 1 else to_number(zdxx_array(2)) end-1)*2)>9 then 'A' else to_char(ceil((case when to_number(zdxx_array(2)) < 1 then 1 else to_number(zdxx_array(2)) end-1)*2)) end) into zdxx_array(2) from dual;
   end if;

   if instr(lshqzdxx,zdxx_array(1))>0 or instr(lshhzdxx,zdxx_array(1))>0 then
     i := i +1;
     ymcsxx := ymcsxx||'|'||zdxx_array(1);
   end if;

   lshqzdxx := replace(lshqzdxx,zdxx_array(1),''''||zdxx_array(2)||'''');  ---流水号前替换页面参数对应规则内容
   lshhzdxx := replace(lshhzdxx,zdxx_array(1),''''||zdxx_array(2)||'''');  ---流水号后替换页面参数对应规则内容

  end LOOP;

  if i != k then
    out_kch := '生成规则'||gzmsxx||'与页面参数'||ymcsxx||'不一致';
    goto Exend;
  end if;
  ----有一种情况没有考虑流水号超出位数时存在问题(此函数不用考虑,本身功能还会判断课程号唯一性的存储)
  v_sql := 'select '||lshqzdxx||'||lpad(nvl(max(substr(kch,'||lshqws||'+1,'||lshws||'))+1,lpad(''1'','||lshws||',''0'')),'||lshws||',''0'')'||lshhzdxx||' from jw_jh_kcdmb
            where substr(kch,1,'||lshqws||')||substr(kch,-'||lshhws||') = '||lshqzdxx||lshhzdxx||' and length(kch) = '||lshqws||'+'||lshws||'+'||lshhws;

  dbms_output.put_line(v_sql);
  Execute Immediate v_sql into out_kch;
  <<Exend>>
  return out_kch;
end get_Kch_test;

/

