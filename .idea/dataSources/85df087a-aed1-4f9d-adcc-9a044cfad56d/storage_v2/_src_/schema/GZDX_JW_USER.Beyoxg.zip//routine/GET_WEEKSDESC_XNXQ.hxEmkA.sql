create Function Get_WeeksDesc_xnxq(vXnm in varchar2,vXqm in varchar2,vWeeksBinary in integer) ---周二进制流对应十进制数
Return varchar2
as
 i integer;
 zcdesc varchar2(10000);
begin
 i := -1;
 select count(*) into i from zftal_xtgl_jcsjb where lx = '0001' and dm in ('1','2','4','8') ;
  if i = 0 then
      return Get_BinaryDesc(nvl(vWeeksBinary,0), '周'); ---生成周信息
    else
      select nvl(wm_concat(zcdesc),'无') into zcdesc from
        (select (select '('||mc||')' from zftal_xtgl_jcsjb where lx = '0001' and dm =  xqm)||Get_WeeksDesc(sum(power(2,zc-1))) zcdesc from
           (select distinct t1.xnm,t1.xqm,t2.zc,t2.dxqm,t2.dxqzc from jw_pk_xlb t1,jw_pk_rcmxb t2
            where t1.xl_id = t2.xl_id
              and t2.zc <> 0
              and t1.xnm = vXnm
              and bitand(t2.dxqm ,vXqm) > 0
              and bitand(power(2,t2.dxqzc-1) ,vWeeksBinary) > 0
           ) group by xnm,xqm,dxqm order by xnm,to_number(xqm)
        );
      return trim(zcdesc);
  end if;
end;

/

