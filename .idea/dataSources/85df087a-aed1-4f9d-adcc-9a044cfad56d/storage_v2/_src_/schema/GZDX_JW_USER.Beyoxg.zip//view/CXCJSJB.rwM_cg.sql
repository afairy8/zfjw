create view CXCJSJB as
  select "XNM","XQM","KCH_ID","JXB_ID","XH_ID","CJ","BFZCJ","CJBZ","JD","CJXZM","KCBJ","JMCJ","JMBFZCJ","JMJD","SFSCEWM" from jw_cj_xscjb where cjxzm='16' and jxb_id like '%c'
/

