create view VIEW_ZSLYQK as
  select
pyccdm,
njdm_id,
lysdm,
count(1) zszrs,
count(case when a.lym in ('102','104') then a.xh_id else null end) zsncrs,
count(case when a.xslbdm='452' then a.xh_id else null end) yksrs,
count(case when a.xslbdm='452' and a.lym in ('102','104') then a.xh_id else null end) yksncrs,
count(case when a.kslbm='1' and a.lym in ('101','102') then a.xh_id else null end)  ptgzyjbyszrs,
count(case when a.kslbm='1' and a.lym='102' then a.xh_id else null end) ptgzyjbysncrs,
count(case when a.kslbm='1' and a.lym in ('103','104') then a.xh_id else null end)  ptgzwjbyszrs,
count(case when a.kslbm='1' and a.lym='104' then a.xh_id else null end)  ptgzwjbysncrs,
count(case when a.kslbm='2' and a.lym in ('101','102') then a.xh_id else null end)  zzxxyjbyszrs,
count(case when a.kslbm='2' and a.lym='102' then a.xh_id else null end)  zzxxyjbysncrs,
count(case when a.kslbm='2' and a.lym in ('103','104') then a.xh_id else null end)  zzxxwjbyszrs,
count(case when a.kslbm='2' and a.lym='104' then a.xh_id else null end)  zzxxwjbysncrs,
count(case when a.kslbm not in('1','2') then a.xh_id else null end )  qtxlzrs,
count(case when a.kslbm not in('1','2') and a.lym in ('102','104') then a.xh_id else null end )  qtxlncrs
from jw_xjgl_xsjbxxb a
 group by a.pyccdm,a.njdm_id,a.lysdm order by a.pyccdm,a.njdm_id,a.lysdm asc
/

