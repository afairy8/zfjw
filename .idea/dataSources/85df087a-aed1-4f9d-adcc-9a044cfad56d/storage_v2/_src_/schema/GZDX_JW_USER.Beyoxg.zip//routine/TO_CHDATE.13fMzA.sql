create function to_chdate(v_date date,vbj varchar2) return varchar2
is
  v_return varchar2(60);
  v_year varchar(30);
  v_month varchar(15);
  v_day varchar(15);
  v_numarry1 T_CHAR_ARR;
  v_numarry2 T_CHAR_ARR;
  begin
    v_numarry1 := T_CHAR_ARR('O','一','二','三','四','五','六','七','八','九');
    v_numarry2 := T_CHAR_ARR('一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五','十六','十七','十八','十九','二十','二十一','二十二','二十三','二十四','二十五','二十六','二十七','二十八','二十九','三十','三十一');
    v_year := to_char(v_date, 'yyyy');
    v_month := to_char(v_date, 'mm');
    v_day := to_char(v_date, 'dd');
    v_month := v_numarry2(to_number(v_month));
    v_day := v_numarry2(to_number(v_day));
    for ind in 1..length(v_year) loop
      v_return := v_return || v_numarry1(to_number(substr(v_year, ind, 1))+1);
    end loop;
    if vbj = 'nyr' then
      v_return := v_return || '年' || v_month || '月' || v_day || '日';
    end if;
    if vbj = 'n' then
      v_return := v_return;
    end if;

    if vbj = 'y' then
      v_return := v_month;
    end if;

    if vbj = 'r' then
      v_return := v_day;
    end if;
    return v_return;
end;

/

