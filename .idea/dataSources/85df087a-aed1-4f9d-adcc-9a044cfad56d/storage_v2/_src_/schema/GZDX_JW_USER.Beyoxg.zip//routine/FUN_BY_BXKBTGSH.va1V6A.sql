create function fun_by_bxkbtgsh(v_xh_id varchar2,v_tjsjz varchar2) return varchar2
as
   sJg varchar2(2000);   ---必修课程不通过门次
   v_flag int;
begin
    sJg := '合格';
    begin
        select count(1)sl into v_flag from (
            select a.kch_id from jw_jh_xsjxzxjhkcxxb a
            where nvl(a.bfzcj,0)<60 and exists(select 1 from jw_jh_kcxzdmb b where a.kcxzdm  = b.kcxzdm and b.xbx='bx'
            ) and a.xh_id=v_xh_id)
             ;

         if v_flag>v_tjsjz then
            sJg:= '必修课程不通过门次'||v_flag||'>'||v_tjsjz||'，不合格！';
         else
            sJg:= '合格！';
         end if;

     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_bxkbtgsh;

/

