create view VIEW_GJBB_ZSZXLYQK as
  with temp_a as(
  select b.lysdm lys,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)) zshj,--招生合计,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)
             *decode(b.xslbdm, '411', 1, 0)) zsptzks,--招生普通专科生,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)
             *decode(b.xslbdm, '421', 1, 0)) zsptbks,--招生普通本科生,
         count(1) zxhj,--合计,
         sum(decode(b.xslbdm, '411', 1, 0)) zxptzks,--普通专科生,
         sum(decode(b.xslbdm, '421', 1, 0)) zxptbks,--普通本科生,
         sum(decode(b.xslbdm, '412', 1, 0)) zxcrzks,--成人专科生,
         sum(decode(b.xslbdm, '422', 1, 0)) zxcrbks,--成人本科生,
         sum(decode(b.xslbdm, '413', 1, 0)) zxwlzks,--网络专科生,
         sum(decode(b.xslbdm, '423', 1, 0)) zxwlbks,--网络本科生,
         sum(decode(b.xslbdm, '431', 1, 0)) zxssyjs,--硕士研究生,
         sum(decode(b.xslbdm, '432', 1, 0)) zxbsyjs--博士研究生
    from jw_xjgl_xsjbxxb b
   where b.sfzx = '1'
   group by b.lysdm)
   (select  '总计' mc,--省份,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)) zshj,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)
             *decode(b.xslbdm, '411', 1, 0)) zsptzks,
         sum(decode((select nj.njdm from zftal_xtgl_njdmb nj where nj.njdm_id=b.njdm_id),(select zdz from zftal_xtgl_xtszb where zdm='DQXNM'),1,0)
             *decode(b.xslbdm, '421', 1, 0)) zsptbks,
         count(1) zxhj,
         sum(decode(b.xslbdm, '411', 1, 0)) zxptzks,
         sum(decode(b.xslbdm, '421', 1, 0)) zxptbks,
         sum(decode(b.xslbdm, '412', 1, 0)) zxcrzks,
         sum(decode(b.xslbdm, '422', 1, 0)) zxcrbks,
         sum(decode(b.xslbdm, '413', 1, 0)) zxwlzks,
         sum(decode(b.xslbdm, '423', 1, 0)) zxwlbks,
         sum(decode(b.xslbdm, '431', 1, 0)) zxssyjs,
         sum(decode(b.xslbdm, '432', 1, 0)) zxbsyjs
    from jw_xjgl_xsjbxxb b
   where b.sfzx = '1')
     union all
   (select "省份","ZSHJ","ZSPTZKS","ZSPTBKS","ZXHJ","ZXPTZKS","ZXPTBKS","ZXCRZKS","ZXCRBKS","ZXWLZKS","ZXWLBKS","ZXSSYJS","ZXBSYJS" from(
  (select lys.mc 省份,
         nvl(temp_a.zshj, 0) zshj,--招生合计,
         nvl(temp_a.zsptzks, 0) zsptzks,--招生普通专科生,
         nvl(temp_a.zsptbks, 0) zsptbks,--招生普通本科生,
         nvl(temp_a.zxhj, 0) zxhj,--合计,
         nvl(temp_a.zxptzks, 0) zxptzks,--普通专科生,
         nvl(temp_a.zxptbks, 0) zxptbks,--普通本科生,
         nvl(temp_a.zxcrzks, 0) zxcrzks,--成人专科生,
         nvl(temp_a.zxcrbks, 0) zxcrbks,--成人本科生,
         nvl(temp_a.zxwlzks, 0) zxwlzks,--网络专科生,
         nvl(temp_a.zxwlbks, 0) zxwlbks,--网络本科生,
         nvl(temp_a.zxssyjs, 0) zxssyjs,--硕士研究生,
         nvl(temp_a.zxbsyjs, 0) zxbsyjs--博士研究生
    from (select a.dm, a.mc from zftal_xtgl_jcsjb a where a.lx = '1030') lys,
         temp_a
   where lys.dm = temp_a.lys(+)
   order by lys.dm)))
/

