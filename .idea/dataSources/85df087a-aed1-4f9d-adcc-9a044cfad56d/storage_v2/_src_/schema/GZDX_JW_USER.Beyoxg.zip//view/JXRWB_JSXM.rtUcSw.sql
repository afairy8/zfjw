create view JXRWB_JSXM as
  select "XKKH","JSXM" from(
select xkkh, wm_concat(jszgh2||'/'||jsxm||'/无') jsxm from dgjsskxxb_yyh  group by xkkh
) where  xkkh in(select xkkh from jxrwb)
/

