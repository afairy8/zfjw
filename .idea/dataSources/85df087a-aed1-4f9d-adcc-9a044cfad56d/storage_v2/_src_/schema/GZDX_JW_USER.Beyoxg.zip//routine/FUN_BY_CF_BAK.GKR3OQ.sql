create function fun_by_cf_bak(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
begin
    sJg := '合格';
    begin
       select decode(wm_concat(a.cfdm),
              '',
              '合格',
              '存在[' || wm_concat((select jcsjb.mc
                                   from zftal_xtgl_jcsjb jcsjb
                                      where jcsjb.dm = a.cfdm
                                        and jcsjb.lx = '0018')) || ']处分，不合格！') into sJg
          from jw_xjgl_xscfb a
         where a.xh_id = v_xh_id  and a.cfdm not in('1','2','9')
      and a.WJLBM in ('14');
         --and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')<=nvl(a.cfjsrq,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;


    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_cf;
/

