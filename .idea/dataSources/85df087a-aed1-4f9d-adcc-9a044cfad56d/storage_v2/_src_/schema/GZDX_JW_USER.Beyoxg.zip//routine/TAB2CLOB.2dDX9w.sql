create FUNCTION tab2clob(my_type MYTYPE, p_delim IN VARCHAR2 DEFAULT ',')
  RETURN CLOB IS----wmconcat字符不够长的时候用此方法代替 ，如：tab2clob(CAST(COLLECT(tj.tjmc) AS MYTYPE))
  l_result CLOB;
BEGIN
  FOR cc IN (SELECT column_value
               FROM TABLE(my_type)
              ORDER BY column_value) LOOP
    l_result := l_result || p_delim || cc.column_value;
  END LOOP;
  RETURN ltrim(l_result, p_delim);
END;

/

