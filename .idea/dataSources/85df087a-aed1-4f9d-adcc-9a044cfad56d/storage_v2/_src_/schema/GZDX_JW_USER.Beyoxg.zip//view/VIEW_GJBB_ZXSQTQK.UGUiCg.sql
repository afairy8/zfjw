create view VIEW_GJBB_ZXSQTQK as
  with mytempTable as(
          select
          lb.dm,--类别代码
          lb.mc,--类别名称
          a.njdm_id,--年级id
           sum(case when a.zzmmm='01' then 1 else 0 end) gcdrs,--共产党人数
           sum(case when a.zzmmm='03' then 1 else 0  end) gqtrs,--共青团人数
           sum(case when a.zzmmm in('04','05','06','07','08','09','10','11') then 1 else 0 end) mzdprs,--民主党派人数
           sum(case when (a.mzm>'01' or a.mzm<'01') then 1 else 0 end ) ssmzrs,--少数民族人数 除去汉族
           sum(case when (a.gatqwm>'10' ) then 1 else 0 end ) hqrs,-- 华侨人数
           sum(case when (a.gatqwm>'00' and a.gatqwm<'11') then 1 else 0 end ) gatrs,--港澳台人数
           sum(case when (a.JKZK ='6') then 1 else 0 end ) cjrs--残疾人数
          from
          (select c.dm,c.mc from zftal_xtgl_jcsjb c where c.lx = '0016') lb
          left join
          (select t.zzmmm,t.xslbdm,t.mzm,t.gatqwm,t.JKZK,t.njdm_id from jw_xjgl_xsjbxxb t where t.sfzx='1') a --在校的学生
          on lb.dm=a.xslbdm
          group by lb.dm,lb.mc,a.njdm_id
       )
       select dm ,mc,njdm_id,row_type,gcdrs,gqtrs,mzdprs,ssmzrs,hqrs,gatrs,cjrs,rownum rownum_ from (--类别代码、名称、年级、共产党人数...
            select '421411' dm ,'普通本科、专科生' mc,njdm_id ,'0' row_type,sum(gcdrs) gcdrs,--普通本科和专科生求和 row_type区分合集还是子集 0是子集 1是合集
               sum(gqtrs) gqtrs,
               sum(mzdprs) mzdprs,
               sum(ssmzrs) ssmzrs,
               sum(hqrs) hqrs,
               sum(gatrs) gatrs,
               sum(cjrs) cjrs from mytempTable tt1 where tt1.dm='421' or tt1.dm='411' group by njdm_id
            union all
            select dm ,mc,njdm_id,'1' row_type,gcdrs,gqtrs,mzdprs,ssmzrs,hqrs,gatrs,cjrs from mytempTable where dm ='421' or dm ='411'--普通本科和专科生
            union all
            select '412422' dm ,'成人本科、专科生' mc, njdm_id,'0' row_type,sum(gcdrs) gcdrs,
               sum(gqtrs) gqtrs,
               sum(mzdprs) mzdprs,
               sum(ssmzrs) ssmzrs,
               sum(hqrs) hqrs,
               sum(gatrs) gatrs,
               sum(cjrs) cjrs from mytempTable tt1 where tt1.dm='412' or tt1.dm='422' group by njdm_id
            union all
            select dm ,mc,njdm_id,'1' row_type,gcdrs,gqtrs,mzdprs,ssmzrs,hqrs,gatrs,cjrs from mytempTable where dm ='412' or dm ='422'
            union all
             select '413423' dm ,'网络本科、专科生' mc,njdm_id,'0' row_type, sum(gcdrs) gcdrs,
               sum(gqtrs) gqtrs,
               sum(mzdprs) mzdprs,
               sum(ssmzrs) ssmzrs,
               sum(hqrs) hqrs,
               sum(gatrs) gatrs,
               sum(cjrs) cjrs from mytempTable tt1 where tt1.dm='413' or tt1.dm='423' group by njdm_id
            union all
            select dm ,mc,njdm_id,'1' row_type,gcdrs,gqtrs,mzdprs,ssmzrs,hqrs,gatrs,cjrs from mytempTable where dm ='413' or dm ='423'
            union all
            select '431432' dm ,'研究生' mc,njdm_id,'0' row_type, sum(gcdrs) gcdrs,
               sum(gqtrs) gqtrs,
               sum(mzdprs) mzdprs,
               sum(ssmzrs) ssmzrs,
               sum(hqrs) hqrs,
               sum(gatrs) gatrs,
               sum(cjrs) cjrs from mytempTable tt1 where tt1.dm='431' or tt1.dm='432' group by njdm_id
            union all
            select dm ,mc,njdm_id,'1' row_type,gcdrs,gqtrs,mzdprs,ssmzrs,hqrs,gatrs,cjrs from mytempTable where dm ='431' or dm ='432'
       ) t1

/

