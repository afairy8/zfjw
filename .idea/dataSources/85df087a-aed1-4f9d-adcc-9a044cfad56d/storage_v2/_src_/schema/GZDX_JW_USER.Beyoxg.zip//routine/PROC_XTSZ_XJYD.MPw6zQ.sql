create procedure proc_xtsz_xjyd(vDqxnm in varchar2,vDqxqm in varchar2,vbj out varchar2) is
begin
  --系统设置当前学年学期时更新当前学年学期生效的学籍异动数据
  begin
  update jw_xjgl_xsjbxxb jb
  set (jb.njdm_id, jb.jg_id, jb.zyh_id, jb.zyfx_id, jb.bh_id, jb.xz, jb.sfzx, jb.xjztdm, jb.bdzcbj)=
  (select
       ydhnjdm_id,
       ydhjg_id,
       ydhzyh_id,
       ydhzyfx,
       ydhbh_id,
       ydhxz,
       sfzx,
       dyxjzt,
       sfzc
       from
       (select   row_number() over (partition by a.xh_id order by a.zzshsj desc) rn, a.ydhnjdm_id,
         a.xh_id,
         a.ydhjg_id,
         a.ydhzyh_id,
         a.ydhzyfx,
         a.ydhbh_id,
         a.ydhxz,
         b.sfzx,
         b.dyxjzt,
         decode(b.sfzc,'1','2','0','1','0') sfzc
  from jw_xjgl_xjydb a, jw_xjgl_xjydlbdmb b
  where a.ydlbm = b.ydlbm
        and a.ydsxxnm = vDqxnm
        and a.ydsxxqm = vDqxqm
        and a.shzt = '3') t where t.rn = '1' and t.xh_id = jb.xh_id)
  where exists (select 'X' from jw_xjgl_xjydb c, jw_xjgl_xjydlbdmb d
        where c.ydlbm = d.ydlbm
              and jb.xh_id = c.xh_id
              and c.ydsxxnm = vDqxnm
              and c.ydsxxqm = vDqxqm);
   vbj := '1';

    exception
       When others then
        vbj := '0';
        rollback;
     end;
end proc_xtsz_xjyd;

/

