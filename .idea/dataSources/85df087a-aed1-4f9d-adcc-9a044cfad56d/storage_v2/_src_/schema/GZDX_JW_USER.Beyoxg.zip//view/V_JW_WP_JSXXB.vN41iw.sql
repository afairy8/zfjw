create view V_JW_WP_JSXXB as
  select jgh UserID ,xm UserName ,xbm,(select t1.jgdm from zftal_xtgl_jgdmb  t1 where t.jg_id=t1.jg_id)DepartmentID,t.dzyx UserEmail  from jw_jg_jzgxxb t where substr(jgh,1,1) in('4','5')
/

