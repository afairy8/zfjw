create procedure proc_by_kcxzxfth_xs(v_xh_id  varchar2) -- 学生端课程性质替代的相关处理
as
    resultInfo        varchar2(32);  --返回结果信息
    iKcxzxfthb_id     varchar2(32);  --存放课程性质替代表   主键ID
    ikcxzNum          varchar2(32);  --存放课程性质替代表   数量
    iThkcxzdm         varchar2(32);  --存放课程性质替代表     替代的课程性质
    iBthkcxzdm        varchar2(32);  --存放课程性质替代表   被替代的课程性质
    iTdkcxzdm_num     varchar2(32);  --存放学生计划节点中 跟  替代课程性质相匹配的 数量
    iBtdkcxzdm_num    varchar2(32);  --存放学生计划节点中 跟被替代课程性质相匹配的 数量
    iCcjdxf_subentry   varchar2(32); --超出学分 分项
    iCcjdxf_total      varchar2(32); --超出学分 总计
    IQsjdxf_subentry   varchar2(32); --缺失学分 分项
    IQsjdxf_total      varchar2(32); --缺失学分 总计
    IdataBottle        varchar2(32); --数据交换 瓶子
    ITempXsxdqktjb_id  varchar2(32); --学生教学执行计划学分要求信息表ID
    ipm                varchar2(32); --序列
begin
  begin
        /*查看 课程性质 替代 关系表中是否有数据*/
        select count(1) into ikcxzNum from jw_jh_kcxzxfthb;
         /*1.如果存在课程性质替代数据*/
         if to_number(ikcxzNum) > 0 and v_xh_id is not null then
             /*2.开始循环*/
            for x in 1 .. ikcxzNum loop
                /*查询当前 替代课程性质  被替代课程性质  还有课程性质主键ID*/
                select kcxzxfthb_id,kcxzdm,thkcxzdm,pm  into iKcxzxfthb_id,iThkcxzdm,iBthkcxzdm,ipm
                from (select  kcxzxfthb_id,kcxzdm,thkcxzdm,row_number() OVER(ORDER BY to_number(nvl(yxj, 0)) asc) as pm
                    from jw_jh_kcxzxfthb)   where pm = x;

                /*查询当前学分要求信息表中 符合要求的课程性质代码节点 有几个 */
                select count(1) into iTdkcxzdm_num    from jw_cj_xsxdqktjb where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm ;
                select count(1) into iBtdkcxzdm_num   from jw_cj_xsxdqktjb where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;

                   /*3.判断替代和被替代的课程性质节点  均必满足 各自至少有一个 */
                   if  to_number(iTdkcxzdm_num) > 0  and to_number(iBtdkcxzdm_num) > 0 then

                       /*替代节点课程性质 总共可用的学分*/
                       select hdxf - yqzdxf  into iCcjdxf_total
                       from (select sum(yqzdxf)yqzdxf,sum(hdxf)hdxf
                             from jw_cj_xsxdqktjb
                             where fxfyqjd_id is not null and  xh_id = v_xh_id and kcxzdm = iThkcxzdm and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0));

                      /*被替代节点课程性质 总共缺失的学分*/
                      select yqzdxf - hdxf into IQsjdxf_total
                      from (select sum(yqzdxf) yqzdxf,sum(hdxf)hdxf
                            from jw_cj_xsxdqktjb
                            where fxfyqjd_id is not null and  xh_id = v_xh_id and kcxzdm = iBthkcxzdm and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0));

                       /*4.使用三段分支的方式来处理数据*/
                          /*第一段 如所有节点 替代多出的学分 等于= 被替代缺失的学分  将 替代的相应节点的获得学分的值 更新为跟要求最低学分 的值相等*/
                          /*第二段 如所有节点 替代多出的学分 大于> 被替代缺失的学分  将 替代的相应节点的获得学分的值 减少到被替代学分缺失学分的和 并将所有被替代学分节点 获得学分 等值于要求最低学分*/
                          /*第三段 如所有节点 替代多出的学分 小于< 被替代缺失的学分  将 替代的相应节点的获得学分的值 更新为跟要求最低学分 的值相等  并将 被替代节点学分 增加 替代学分的和个学分*/
                      if  to_number(iCcjdxf_total)= to_number(IQsjdxf_total) then
                        /*a、处理替代课程性质 节点的获得学分*/
                        update (select * from jw_cj_xsxdqktjb order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = (hdxf - yqzdxf)*-1 where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm ;
                        /*b、处理被替代课程性质 节点的获得学分*/
                        update (select * from jw_cj_xsxdqktjb order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = yqzdxf - hdxf where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;
                      elsif  to_number(iCcjdxf_total) > to_number(IQsjdxf_total) then
                         /*a、处理替代课程性质 节点的获得学分*/
                           /*初始化瓶子*/
                           IdataBottle := IQsjdxf_total;
                           /*开始循环 要求处理的节点个数 次*/
                           for p in 1 .. iTdkcxzdm_num loop
                              /*始终保持瓶子里面有值*/
                              if to_number(IdataBottle) > 0  then
                                 /*获取 临时需要减掉的值（替代节点多出的 已经给出去的学分） 和主键ID*/
                                  select hdxf-yqzdxf,xsxdqktjb_id into iCcjdxf_subentry,ITempXsxdqktjb_id
                                  from (select xxb.xsxdqktjb_id,xxb.yqzdxf,xxb.hdxf,row_number() OVER(PARTITION BY  kcxzdm ORDER BY kcxzdm, yqzdxf, xfyqjdmc, px desc) as line
                                        from jw_cj_xsxdqktjb xxb
                                        where xh_id = v_xh_id
                                          and fxfyqjd_id is not null
                                          and nvl(to_number(yqzdxf),0) < nvl(hdxf+kcxzthxf*-1,0)
                                          and kcxzdm = iThkcxzdm
                                          )
                                  where line = p;
                                 /*使用三段分支的方式来处理数据*/
                                 if to_number(iCcjdxf_subentry) = to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf-IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle*-1 where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(iCcjdxf_subentry) > to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf-IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle*-1 where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(iCcjdxf_subentry) < to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf-iCcjdxf_subentry,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = iCcjdxf_subentry*-1  where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*更新瓶子值*/
                                    IdataBottle := IdataBottle-iCcjdxf_subentry;
                                 end if;
                              end if;
                           end loop;

                        /*b、处理被替代课程性质 节点的获得学分*/
                        update (select * from jw_cj_xsxdqktjb order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = yqzdxf - hdxf where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) > nvl(to_number(hdxf),0) and kcxzdm = iBthkcxzdm;

                      elsif  to_number(iCcjdxf_total) < to_number(IQsjdxf_total) then
                        /*a、处理替代课程性质 节点的获得学分*/
                        update (select * from jw_cj_xsxdqktjb order by kcxzdm, yqzdxf, xfyqjdmc, px) set hdxf=yqzdxf,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = (hdxf - yqzdxf)*-1 where xh_id = v_xh_id and fxfyqjd_id is not null and nvl(to_number(yqzdxf),0) < nvl(to_number(hdxf),0) and kcxzdm = iThkcxzdm ;

                        /*b、处理被替代课程性质 节点的获得学分*/
                           /*初始化瓶子*/
                           IdataBottle := iCcjdxf_total;
                           /*开始循环 要求处理的节点个数 次*/
                           for p in 1 .. iBtdkcxzdm_num loop
                              /*始终保持瓶子里面有值*/
                              if to_number(IdataBottle) > 0  then
                                 /*获取 临时需要缺失的值（被替代节点缺少 需要替代补上的） 和主键ID*/
                                  select yqzdxf - hdxf,xsxdqktjb_id into IQsjdxf_subentry,ITempXsxdqktjb_id
                                  from (select xxb.xsxdqktjb_id,xxb.yqzdxf,xxb.hdxf,row_number() OVER(PARTITION BY  kcxzdm ORDER BY kcxzdm, yqzdxf, xfyqjdmc, px desc) as line
                                        from jw_cj_xsxdqktjb xxb
                                        where xh_id = v_xh_id
                                           and fxfyqjd_id is not null
                                           and nvl(to_number(yqzdxf),0) > nvl(hdxf-kcxzthxf,0)
                                           and kcxzdm = iBthkcxzdm
                                           )
                                  where line = p;
                                 /*使用三段分支的方式来处理数据*/
                                 if to_number(IQsjdxf_subentry) = to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf+IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(IQsjdxf_subentry) > to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf+IdataBottle,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IdataBottle where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*清空瓶子*/
                                    IdataBottle := '0';
                                 elsif to_number(IQsjdxf_subentry) < to_number(IdataBottle) then
                                    update jw_cj_xsxdqktjb set hdxf = hdxf+IQsjdxf_subentry,kcxzxfthb_id=iKcxzxfthb_id,kcxzthxf = IQsjdxf_subentry  where xsxdqktjb_id = ITempXsxdqktjb_id;
                                    /*更新瓶子值*/
                                    IdataBottle := IdataBottle-IQsjdxf_subentry;
                                 end if;
                              end if;
                           end loop;
                      end if;
                   else
                     goto next;
                   end if;
                   <<next>>
                    null;
            end loop;
         end if;

exception
  When others then
    resultInfo := '出现了错误!';
end;
end;

/

