create function Get_Kcxzdm
(vXnm varchar2,
 vXqm varchar2,
 vXh_id varchar2,
 vNjdm_id varchar2,
 vZyh_id varchar2,
 vKch_id varchar2,
 vJxb_id varchar2,
 vFxbj varchar2,
 vCxbj varchar2,
 vBj  varchar2) return varchar2
as
 sKcxzdm varchar2(8);
 sKcxzqzfs  varchar2(4);
 sKcxzqz varchar2(4);
 sNjdm_id varchar2(32);
 sZyh_id varchar2(32);
begin
     select zdz into sKcxzqzfs  from jw_jcdml_xtnzb where ZDM='KCXZQZFS';

     if vBj = '0' then
     if sKcxzqzfs='1' then ---取计划后取任务
          select max(kcxzdm) into sKcxzdm from jw_jh_jxzxjhkcxxb a where a.njdm_id = vNjdm_id and a.zyh_id = vZyh_id and a.kch_id = vKch_id ;

         if nvl(sKcxzdm ,'-1') ='-1' then
            --关联课组
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kzkcdmb c
           where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
             and b.kz_id = c.kz_id and c.kch_id= vKch_id
             and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if  nvl(sKcxzdm ,'-1') ='-1' then
            --关联课程类别
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhxfyqxxfb b,jw_jh_kcdmb c
            where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
              and b.kclbdm = c.kclbdm  and c.kch_id=vKch_id
              and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if nvl(sKcxzdm ,'-1') ='-1' then
            --关联课程归属
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kcdmb c
           where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
             and b.kcgsdm = c.kcgsdm and c.kch_id=vKch_id
             and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if nvl(sKcxzdm ,'-1') ='-1' then
           select max(kcxzdm) into sKcxzdm from jw_jxrw_jxbhbxxb where jxb_id=vJxb_id and  njdm_id=vNjdm_id and zyh_id=vZyh_id ;
         end if;
         if nvl(sKcxzdm ,'-1') ='-1' then
           select max(kcxzdm) into sKcxzdm from jw_jxrw_jxbhbxxb where jxb_id=vJxb_id;
         end if;
     else
         select zdz into sKcxzqz  from zftal_xtgl_xtszb where SSMK='JHMK' and ZDM='KCXZQZ';

         select max(kcxzdm) into sKcxzdm from jw_jh_jxzxjhkcxxb a where a.njdm_id = vNjdm_id and a.zyh_id = vZyh_id and a.kch_id = vKch_id ;

         if nvl(sKcxzdm ,'-1') ='-1' then
            --关联课组
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kzkcdmb c
           where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
             and b.kz_id = c.kz_id and c.kch_id= vKch_id
             and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if  nvl(sKcxzdm ,'-1') ='-1' then
            --关联课程类别
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhxfyqxxfb b,jw_jh_kcdmb c
            where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
              and b.kclbdm = c.kclbdm  and c.kch_id=vKch_id
              and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if nvl(sKcxzdm ,'-1') ='-1' then
            --关联课程归属
           select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kcdmb c
           where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
             and b.kcgsdm = c.kcgsdm and c.kch_id=vKch_id
             and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
         end if;

         if nvl(sKcxzdm ,'-1') ='-1' then
           sKcxzdm := sKcxzqz;
         end if;
     end if;
     end if;

     --成绩录入时课程性质取值
     if vBj = '1' then
        if sKcxzqzfs='1' then ---取计划后取任务

          if nvl(vFxbj,'0') = '0' then
              select max(kcxzdm) into sKcxzdm from jw_jh_jxzxjhkcxxb a where a.njdm_id = vNjdm_id and a.zyh_id = vZyh_id and a.kch_id = vKch_id ;

             if nvl(sKcxzdm ,'-1') ='-1' then
                --关联课组
               select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kzkcdmb c
               where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
                 and b.kz_id = c.kz_id and c.kch_id= vKch_id
                 and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
             end if;

             if  nvl(sKcxzdm ,'-1') ='-1' then
                --关联课程类别
               select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhxfyqxxfb b,jw_jh_kcdmb c
                where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
                  and b.kclbdm = c.kclbdm  and c.kch_id=vKch_id
                  and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
             end if;

             if nvl(sKcxzdm ,'-1') ='-1' then
                --关联课程归属
               select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kcdmb c
               where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
                 and b.kcgsdm = c.kcgsdm and c.kch_id=vKch_id
                 and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
             end if;

             if nvl(sKcxzdm ,'-1') ='-1' then
               select max(kcxzdm) into sKcxzdm from jw_jxrw_jxbhbxxb where jxb_id=vJxb_id and  njdm_id=vNjdm_id and zyh_id=vZyh_id ;
             end if;
             if nvl(sKcxzdm ,'-1') ='-1' then
               select max(kcxzdm) into sKcxzdm from jw_jxrw_jxbhbxxb where jxb_id=vJxb_id;
             end if;
          else
            select max(njdm_id) ,max(zyh_id) into sNjdm_id,sZyh_id from (
            select t2.njdm_id,t2.zyh_id  from jw_fx_fxezybmkzb t1,jw_fx_fxezybmb t2
            where t1.fxezybmkz_id = t2.fxezybmkz_id
            and case when t1.bmlbdm = '01' then '1' when t1.bmlbdm = '02' then '2' when t1.bmlbdm = '03' then '3' end = vFxbj
            and nvl(t2.zzshjg,'0')='3'
            and t2.xh_id = vXh_id
            and rownum = 1) ;

            if vFxbj = '1' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.fxbj = '1';
            end if;

            if vFxbj = '2' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.ezybj = '1';
            end if;

            if vFxbj = '3' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.exwbj = '1';
            end if;

             if nvl(sKcxzdm ,'-1') ='-1' then
               select max(kcxzdm) into sKcxzdm from jw_jxrw_jxbhbxxb where jxb_id=vJxb_id;
             end if;
         end if;

     else
        select zdz into sKcxzqz  from zftal_xtgl_xtszb where SSMK='JHMK' and ZDM='KCXZQZ';
         if nvl(vFxbj,'0') = '0' then
           select max(kcxzdm) into sKcxzdm from jw_jh_jxzxjhkcxxb a where a.njdm_id = vNjdm_id and a.zyh_id = vZyh_id and a.kch_id = vKch_id ;

           if nvl(sKcxzdm ,'-1') ='-1' then
              --关联课组
             select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kzkcdmb c
             where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
               and b.kz_id = c.kz_id and c.kch_id= vKch_id
               and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
           end if;

           if  nvl(sKcxzdm ,'-1') ='-1' then
              --关联课程类别
             select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,jw_jh_jxzxjhxfyqxxfb b,jw_jh_kcdmb c
              where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
                and b.kclbdm = c.kclbdm  and c.kch_id=vKch_id
                and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
           end if;

           if nvl(sKcxzdm ,'-1') ='-1' then
              --关联课程归属
             select max(a.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxxb t ,jw_jh_jxzxjhxfyqxxb a,  jw_jh_jxzxjhxfyqxxfb b ,jw_jh_kcdmb c
             where t.jxzxjhxx_id = a.jxzxjhxx_id and a.xfyqjd_id=b.xfyqjd_id
               and b.kcgsdm = c.kcgsdm and c.kch_id=vKch_id
               and t.njdm_id = vNjdm_id and t.zyh_id = vZyh_id;
           end if;

           if nvl(sKcxzdm ,'-1') ='-1' then
             sKcxzdm := sKcxzqz;
           end if;
          else
            select max(njdm_id) ,max(zyh_id) into sNjdm_id,sZyh_id from (
            select t2.njdm_id,t2.zyh_id  from jw_fx_fxezybmkzb t1,jw_fx_fxezybmb t2
            where t1.fxezybmkz_id = t2.fxezybmkz_id
            and case when t1.bmlbdm = '01' then '1' when t1.bmlbdm = '02' then '2' when t1.bmlbdm = '03' then '3' end = vFxbj
            and nvl(t2.zzshjg,'0')='3'
            and t2.xh_id = vXh_id
            and rownum = 1) ;

            if vFxbj = '1' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.fxbj = '1';
            end if;

            if vFxbj = '2' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.ezybj = '1';
            end if;

            if vFxbj = '3' then
            select max(kcxx.kcxzdm) into sKcxzdm from jw_jh_jxzxjhxfyqxxb xfyq,jw_jh_jxzxjhkcxxb kcxx
            where xfyq.xfyqjd_id=kcxx.xfyqjd_id and kcxx.kch_id=vKch_id
              and kcxx.njdm_id=sNjdm_id
              and kcxx.zyh_id=sZyh_id
              and kcxx.exwbj = '1';
            end if;

            if nvl(sKcxzdm ,'-1') ='-1' then
             sKcxzdm := sKcxzqz;
            end if;
          end if;
     end if;

   end if;
  return sKcxzdm;
end Get_Kcxzdm;

/

