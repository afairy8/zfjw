create function fn_getKskcxz(v_ksmcdmb_id in varchar2,v_sjbh_id in varchar2,v_xnm in varchar2,v_xqm in varchar2,v_apfs in varchar2,v_cd_id in varchar2)-----获取考试课程性质
return varchar2 is
    v_bksfayjxbpk number; --补考是否按原教学班排考(0：正考或补考不按原教学班;1:补考且按原教学班;)
    v_axzbpksfqfjxb number; --按行政班排考是否区分教学班(0：否;1:是;)
    v_kcxzmc varchar2(2000):= ''; --课程性质名称
begin
     if v_apfs='0' then --按试卷
       select nvl(wm_concat(kcxzmc),'无') into v_kcxzmc from (
         select distinct kcxz.kcxzmc,kcxz.kcxzdm from jw_kw_ksmcjxbdzb dzb,jw_jxrw_jxbhbxxb hb,jw_jh_kcxzdmb kcxz
         where dzb.xnm=v_xnm and dzb.xqm=v_xqm and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
           and dzb.jxb_id=hb.jxb_id and hb.kcxzdm=kcxz.kcxzdm order by kcxz.kcxzdm
       );
     end if;
     if v_apfs='1' then --按行政班
        select count(1) into v_axzbpksfqfjxb from zftal_xtgl_xtszb where (zdm='AXZBPKSFQFJXB' and zdz='1') or (zdm='AXZBPKFSSZ' and zdz='1');
        if v_axzbpksfqfjxb > 0 then --区分教学班
           select nvl(wm_concat(kcxzmc),'无') into v_kcxzmc from (
             select distinct kcxz.kcxzmc,kcxz.kcxzdm from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb,jw_jh_kcxzdmb kcxz
             where t3.kshkbj_id=t4.kshkbj_id and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
               and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
               and t3.jxb_id=hb.jxb_id and t3.bh_id=hb.bh_id and hb.kcxzdm=kcxz.kcxzdm order by kcxz.kcxzdm
           );
        else --不区分教学班
           select nvl(wm_concat(kcxzmc),'无') into v_kcxzmc from (
             select distinct kcxz.kcxzmc,kcxz.kcxzdm from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb,
             jw_jh_kcxzdmb kcxz,jw_kw_ksmcjxbdzb dzb,jw_kw_ksmcjxbdzb t5
             where t3.kshkbj_id=t4.kshkbj_id and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                   and t5.jxb_id = hb.jxb_id
                   and t5.sjbh_id = v_sjbh_id
                   and t5.xnm=v_xnm
                   and t5.xqm=v_xqm
                   and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                   and dzb.xnm=v_xnm and dzb.xqm=v_xqm and dzb.ksmcdmb_id=v_ksmcdmb_id and dzb.sjbh_id=v_sjbh_id
                   and dzb.jxb_id=hb.jxb_id and t3.bh_id=hb.bh_id and hb.kcxzdm=kcxz.kcxzdm order by kcxz.kcxzdm
           );
         end if;
     end if;
     if v_apfs='2' then --按教学班
        select count(1) into v_bksfayjxbpk from jw_kw_ksmcdmb ksmc,zftal_xtgl_xtszb szb where ksmc.ksmcdmb_id=v_ksmcdmb_id and ksmc.ksxz in ('11','12') and szb.zdm='BKSFAYJXBPK' and szb.zdz='1';
        if v_bksfayjxbpk > 0 then --补考按原教学班
            select nvl(wm_concat(kcxzmc),'无') into v_kcxzmc from (
               select distinct kcxz.kcxzmc,kcxz.kcxzdm from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb,jw_jh_kcxzdmb kcxz
               where t3.kshkbj_id=t4.kshkbj_id and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                 and t3.yjxb_id=hb.jxb_id and hb.kcxzdm=kcxz.kcxzdm order by kcxz.kcxzdm
            );
        else --正考和补考按补考教学班
            select nvl(wm_concat(kcxzmc),'无') into v_kcxzmc from (
              select distinct kcxz.kcxzmc,kcxz.kcxzdm from jw_kw_ksddbjdzb t3,jw_kw_ksddb t4,jw_jxrw_jxbhbxxb hb,jw_jh_kcxzdmb kcxz
               where t3.kshkbj_id=t4.kshkbj_id and t3.sjbh_id=v_sjbh_id and t3.xnm=v_xnm and t3.xqm=v_xqm
                 and t4.cd_id=v_cd_id and t3.xnm=t4.xnm and t3.xqm=t4.xqm
                 and t3.jxb_id=hb.jxb_id and hb.kcxzdm=kcxz.kcxzdm order by kcxz.kcxzdm
            );
         end if;
     end if;
     if v_apfs='3' then --按学院
        v_kcxzmc := '';
     end if;
     return v_kcxzmc;
end fn_getKskcxz;

/

