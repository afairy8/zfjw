create view GZDXJCJK_JXRWBVIEW as
  select
  decode(jxb.xqh_id, '1', '大学城', '2', '桂花岗') xqmc,
  jxb.jxbmc                                  xkkh,
  ''                                         zymc,
  ''                                         zydm,
  jxb.jxbmc                                  bjmc,
  jxb.JXBRS                                  rs,
  (select WM_CONCAT(njdm_id)
   from JW_JXRW_JXBHBXXB hbb
   where hbb.JXB_ID = jxb.jxb_id)            nj,
  (select kch
   from JW_JH_KCDMB
   where kch_id = jxb.KCH_ID)                kcdm,
  (select kcmc
   from JW_JH_KCDMB
   where kch_id = jxb.KCH_ID)                kcmc,
   (select jgh from jw_jg_jzgxxb where jgh_id=rkb.jgh_id) jszgh,
   (select xm from jw_jg_jzgxxb where jgh_id=rkb.jgh_id) jsxm,
  ''zc,jxb.xf xf,''zxs,''jkxs,Get_JxbKcxzxx(jxb.jxb_id,'0') kcxz,
  (select jgmc from ZFTAL_XTGL_JGDMB where jg_id=jxb.KKBM_ID) kkxy,
  (select xnmc from jw_jcdm_xnb t where jxb.xnm = t.xnm) xn,
  (select mc  from zftal_xtgl_jcsjb t  where t.lx = '0001'  and t.dm = jxb.xqm) xq
from JW_JXRW_JXBXXB jxb,jw_jxrw_jxbjsrkb rkb
where rkb.jxb_id=jxb.jxb_id
/*select
  decode(jxb.xqh_id, '1', '大学城', '2', '桂花岗') xqmc,
  jxb.jxbmc                                  xkkh,
  ''                                         zymc,
  ''                                         zydm,
  jxb.jxbmc                                  bjmc,
  jxb.JXBRS                                  rs,
  (select WM_CONCAT(njdm_id)
   from JW_JXRW_JXBHBXXB hbb
   where hbb.JXB_ID = jxb.jxb_id)            nj,
  (select kch
   from JW_JH_KCDMB
   where kch_id = jxb.KCH_ID)                kcdm,
  (select kcmc
   from JW_JH_KCDMB
   where kch_id = jxb.KCH_ID)                kcmc,
  (select t.jgh
   from (select
           rkb.jxb_id,
           zgb.JGH
         from JW_JXRW_JXBJSRKB rkb, JW_JG_JZGXXB zgb
         where rkb.JGH_ID = zgb.JGH_ID) t
   where t.jxb_id = jxb.jxb_id) jszgh,
  (select t.xm
   from (select
           rkb.jxb_id,
           zgb.xm
         from JW_JXRW_JXBJSRKB rkb, JW_JG_JZGXXB zgb
         where rkb.JGH_ID = zgb.JGH_ID) t
   where t.jxb_id = jxb.jxb_id) jsxm,
  ''zc,jxb.xf xf,''zxs,''jkxs,Get_JxbKcxzxx(jxb.jxb_id,'0') kcxz,
  (select jgmc from ZFTAL_XTGL_JGDMB where jg_id=jxb.KKBM_ID) kkxy,
  (select xnmc from jw_jcdm_xnb t where jxb.xnm = t.xnm) xn,
  (select mc  from zftal_xtgl_jcsjb t  where t.lx = '0001'  and t.dm = jxb.xqm) xq
from JW_JXRW_JXBXXB jxb*/
/*select
 xn,
 xq,
 xkkh,
 xqyq,
 zydm,
 zymc,
 zc,
 bjmc,
 rs,
 yxrs,
 kcdm,
 kcmc,
 jszgh,
 jsxm,
 kcxz,
 xf,
 kkxy,
 kkx,
 jkxs,
 zhxs,
 kclb,
 kcxzjc
  from (select t1.xnm || '-' || to_char(to_number(t1.xnm) + 1) xn, --学年,
               case
                 when t1.xqm = '3' then
                  '1'
                 else
                  '2'
               end xq, --学期,
               t1.xqh_id xqyq, --校区,
               t1.jxbmc xkkh, --选课课号,
               t2.bh_id,
               '' zc,
               t3.kch kcdm, --课程代码,
               t3.kcmc kcmc, --课程名称,
               t1.rwzxs zhxs, --总学时,
               t1.rwzxs jkxs,
               t6.bj bjmc, --班级
               t2.rs rs, --班级人数
               t1.yxzrs yxrs,
               t7.zyh zydm, --专业代码
               t7.zymc zymc, --专业名称
               t4.jgmc kkxy, --开课学院,
               '' kkx,
               t1.xf xf, --任务学分,
               t5.kcxzmc kcxz, --任务课程性质,
               t5.kcxzjc,
               '' kclb,
               --jsxx,
               substr(jsxx, 1, instr(jsxx, '/') - 1) jszgh, --教师职工号,
               substr(jsxx,
                      instr(jsxx, '/') + 1,
                      instr(jsxx, '/', instr(jsxx, '/') + 1) -
                      instr(jsxx, '/') - 1) jsxm --教师姓名
          from jw_jxrw_jxbxxb   t1, --教学班信息表
               jw_jxrw_jxbhbxxb t2, --教学班合班信息表
               jw_jh_kcdmb      t3, --课程代码表
               zftal_xtgl_jgdmb t4, --机构代码表
               jw_jh_kcxzdmb    t5, --课程性质代码表
               zftal_xtgl_bjdmb t6,
               zftal_xtgl_zydmb t7
         where t1.kklxdm = '01'
           and to_number(t1.xnm) >= '2018'
           and t1.kch_id = t3.kch_id
           and t1.jxb_id = t2.jxb_id
           and t1.kkbm_id = t4.jg_id
           and t2.kcxzdm = t5.kcxzdm
           and t2.bh_id = t6.bh_id
           and t6.zyh_id = t7.zyh_id
           and t1.kkzt = '1'
        union
        --开课类型非主修的课程，特点无班级，无专业
        select t1.xnm || '-' || to_char(to_number(t1.xnm) + 1) xn, --学年,
               case
                 when t1.xqm = '3' then
                  '1'
                 else
                  '2'
               end xq, --学期,
               t1.xqh_id xqyq, --校区,
               t1.jxbmc xkkh, --选课课号,
               t2.bh_id,
               '' zc,
               t3.kch kcdm, --课程代码,
               t3.kcmc kcmc, --课程名称,
               t1.rwzxs zhxs, --总学时,
               t1.rwzxs jkxs,
               '无班级（占用）' bjmc, --班级
               t2.rs rs,
               t1.yxzrs yxrs,
               'XXXX' zydm, --专业代码
               '无专业' zymc, --专业名称
               t4.jgmc kkxy, --开课学院,
               '' kkx,
               t1.xf xf, --任务学分,
               t5.kcxzmc kcxz, --任务课程性质,
               t5.kcxzjc,
               '' kclb,
               --jsxx,
               substr(jsxx, 1, instr(jsxx, '/') - 1) jszgh, --教师职工号,
               substr(jsxx,
                      instr(jsxx, '/') + 1,
                      instr(jsxx, '/', instr(jsxx, '/') + 1) -
                      instr(jsxx, '/') - 1) jsxm --教师姓名
          from jw_jxrw_jxbxxb   t1, --教学班信息表
               jw_jxrw_jxbhbxxb t2, --教学班合班信息表
               jw_jh_kcdmb      t3, --课程代码表
               zftal_xtgl_jgdmb t4, --机构代码表
               jw_jh_kcxzdmb    t5 --课程性质代码表
        --zftal_xtgl_bjdmb t6,
        --zftal_xtgl_zydmb t7
         where t1.kklxdm <> '01'
           and to_number(t1.xnm) >= '2018'
           and t1.kch_id = t3.kch_id
           and t1.jxb_id = t2.jxb_id
           and t1.kkbm_id = t4.jg_id
           and t2.kcxzdm = t5.kcxzdm
           and t4.jgmc <> '音乐舞蹈学院（团委课）'
           and t1.kkzt = '1');*/

