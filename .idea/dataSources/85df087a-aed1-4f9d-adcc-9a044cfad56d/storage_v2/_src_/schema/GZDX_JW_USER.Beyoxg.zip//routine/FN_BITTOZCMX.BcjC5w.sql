create function FN_BITTOZCMX(int_ZC in int) return varchar2 is
  i       int;
  LoopCount int;
  returnstr varchar2(1000);
begin
   /**通过周次二进制计算出，周次明细**/
  if int_ZC = 0 then
    return '';
  end if;
  i := 0;
  returnstr:='';
  LoopCount:=21;
  while i <= LoopCount Loop
    if bitand (power(2,i),int_ZC)<>0 then
      if (returnstr = '') or (returnstr is null) then
       returnstr := '1';
       else
       returnstr := returnstr||'1';
       end if;
     ELSE
       if (returnstr = '') or (returnstr is null) then
       returnstr := '0';
       else
       returnstr := returnstr||'0';
       end if;
    End if;
    i := i + 1;
  End Loop;
  return(returnstr);
end FN_BITTOZCMX;

/

