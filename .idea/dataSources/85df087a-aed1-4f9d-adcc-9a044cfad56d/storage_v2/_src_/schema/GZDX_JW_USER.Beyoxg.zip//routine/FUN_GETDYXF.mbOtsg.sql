create function fun_getDyxf(v_Xh_id varchar2,v_Kcxzdm varchar2)return varchar2
/****根据学号 和课程性质 获取节点所有多余学分 kwy 2019年10月10日 11:21:51 ****/
as
 sResult varchar2(20);
begin

  select sum(nvl(s.dyxf,0)) into sResult from (

    --1.并且关系 父子节点要求学分相等 取末节点多余学分
      select sum(xxb.hdxf)-sum(xxb.yqzdxf) dyxf --末节点多余学分
        from JW_JH_xsJXZXJHXFYQXXB xxb
       where xxb.fxfyqjd_id is not null
         and xxb.sfmjd = '1'
         and xxb.xh_id = v_Xh_id
         and xxb.kcxzdm = v_Kcxzdm
         and nvl(to_number(xxb.yqzdxf), 0) < nvl(to_number(xxb.hdxf), 0)
          --父节点 的学分要求子节点关系 = 1
         and exists (select '1' from JW_JH_xsJXZXJHXFYQXXB fxxb where  fxxb.xfyqjd_id = xxb.fxfyqjd_id and fxxb.xh_id = v_Xh_id and fxxb.xfyqzjdgx = '1' )
          --父节点要求学分 = 子节点 要求学分
         and (select nvl(yqzdxf,0)yqzdxf from JW_JH_xsJXZXJHXFYQXXB b where b.xfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id)
             =
             (select sum(yqzdxf)yqzdxf from JW_JH_xsJXZXJHXFYQXXB b where b.fxfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id)

    union all
    --2.并且关系 父子节点要求学分不相等 取父节点多余学分

    select (select f.hdxf - f.yqzdxf from JW_JH_xsJXZXJHXFYQXXB f where f.xfyqjd_id = t.fxfyqjd_id and f.xh_id = v_Xh_id) dyxf --父节点多余学分
      from (select xxb.fxfyqjd_id
              from JW_JH_xsJXZXJHXFYQXXB xxb
             where xxb.fxfyqjd_id is not null
               and xxb.sfmjd = '1'
               and xxb.xh_id = v_Xh_id
               and xxb.kcxzdm = v_Kcxzdm
               and nvl(to_number(xxb.yqzdxf), 0) < nvl(to_number(xxb.hdxf), 0)
                  --父节点 的学分要求子节点关系 = 1
               and exists (select '1' from JW_JH_xsJXZXJHXFYQXXB fxxb where fxxb.xfyqjd_id = xxb.fxfyqjd_id and fxxb.xh_id = v_Xh_id and fxxb.xfyqzjdgx = '1')
                  --父节点要求学分 <> 子节点 要求学分
               and (select nvl(yqzdxf, 0) yqzdxf from JW_JH_xsJXZXJHXFYQXXB b where b.xfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id)
                   <>
                   (select sum(yqzdxf) yqzdxf from JW_JH_xsJXZXJHXFYQXXB b where b.fxfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id)
               group by xxb.fxfyqjd_id) t

    union all
    --3.或关系 子节点满足或N通过的条件，取其他节点多余学分 否则不取（暂时这样处理）

     select (select f.hdxf - f.yqzdxf from JW_JH_xsJXZXJHXFYQXXB f where f.xfyqjd_id = t.fxfyqjd_id and f.xh_id = v_Xh_id) dyxf --父节点多余学分
           from  (select xxb.fxfyqjd_id
                from JW_JH_xsJXZXJHXFYQXXB xxb
               where xxb.fxfyqjd_id is not null
                 and xxb.sfmjd = '1'
                 and xxb.xh_id = v_Xh_id
                 and xxb.kcxzdm = v_Kcxzdm
                 and nvl(to_number(xxb.yqzdxf), 0) < nvl(to_number(xxb.hdxf), 0)
                  --父节点 的学分要求子节点关系 = 0
                 and exists (select '1' from JW_JH_xsJXZXJHXFYQXXB fxxb where  fxxb.xfyqjd_id = xxb.fxfyqjd_id and fxxb.xh_id = v_Xh_id and fxxb.xfyqzjdgx <> '1' )
                  --父节点或N 数量 <= 子节点 通过节点数量
                 and (select to_number(xfyqzjdgx) from JW_JH_xsJXZXJHXFYQXXB b where b.xfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id)
                     <=
                     (select count(1) from JW_JH_xsJXZXJHXFYQXXB b where b.fxfyqjd_id = xxb.fxfyqjd_id and b.xh_id = v_Xh_id and b.yqzdxf <=b.hdxf)
                 group by xxb.fxfyqjd_id) t
  )s;

  if sResult is null then
     sResult := 0;
  end if;
  return sResult;
end fun_getDyxf;

/

