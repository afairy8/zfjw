create view V_JK_KCDMB as
  select kch kcdm,kcmc,kcywmc,xf,zxs,(select jgmc from zftal_xtgl_jgdmb where jg_id=kkbm_id)kkxy,zwkcjj,zwjxdg
 from jw_jh_kcdmb r where r.tkbj='0'
/

