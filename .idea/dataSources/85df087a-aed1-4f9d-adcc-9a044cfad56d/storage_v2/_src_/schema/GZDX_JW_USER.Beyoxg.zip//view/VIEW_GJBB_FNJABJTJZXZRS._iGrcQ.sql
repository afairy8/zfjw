create view VIEW_GJBB_FNJABJTJZXZRS as
  select
	bh_id,
	xnm,
	xqm,
	pyccdm,
	njdm_id,
	xjztdm,
	(select sfyxj from jw_xjgl_xjztdmb  where xjztdm=xjb.xjztdm) sfyxj,
	(select xqh_id from zftal_xtgl_bjdmb where bh_id=xjb.bh_id) xqh_id,
	(select bj from zftal_xtgl_bjdmb where bh_id=xjb.bh_id) bj,
	count(*) rs,
	row_number() over (partition by xjb.xnm,xjb.xqm,xjb.njdm_id,xjb.pyccdm order by xjb.bh_id) rn
from
jw_xjgl_xsxjxxb xjb
where xjb.sfzx='1'
  and exists (select 1 from zftal_xtgl_bjdmb where bh_id=xjb.bh_id)
  and xjb.bh_id is not null
group by bh_id,njdm_id,xnm,xqm,pyccdm,xjztdm
/

