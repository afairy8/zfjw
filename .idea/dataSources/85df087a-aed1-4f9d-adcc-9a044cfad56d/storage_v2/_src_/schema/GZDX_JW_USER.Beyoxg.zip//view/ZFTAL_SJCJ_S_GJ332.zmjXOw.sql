create view ZFTAL_SJCJ_S_GJ332 as
  (select
  al,
  rownum bh,
  hb,
  txsj,
  pk,
  xxcjbh,
  cg,
  qt
from
(select t.mc al,
         sum(case when b.ydyy in ('10','11','12','19') then 1 else 0 end) hb,
         sum(case when b.ydyy='25' then 1 else 0 end) txsj,
         sum(case when b.ydyy='27' then 1 else 0 end) pk,
         sum(case when b.ydyy='22' then 1 else 0 end) xxcjbh,
         sum(case when b.ydyy in ('28','29','30') then 1 else 0 end) cg,
         sum(case when b.ydyy='39' then 1 else 0 end) qt
    from zftal_xtgl_jcsjb t,
         (select t.xh_id,xj.xslbdm,t.ydyy
          from JW_XJGL_XJYDB t, jw_xjgl_xsxjxxb xj
          where t.ydlbm = '31'
          and t.xh_id = xj.xh_id
          and t.xnm = xj.xnm
          and t.xqm = xj.xqm
         ) b
   where t.lx = '0016'
     and t.dm = b.xslbdm
   group by t.mc
   ))
/

