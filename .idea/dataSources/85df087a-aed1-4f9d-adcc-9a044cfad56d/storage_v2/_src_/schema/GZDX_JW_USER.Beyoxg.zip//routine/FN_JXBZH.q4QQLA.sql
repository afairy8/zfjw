create function fn_jxbzh(vJxb_id varchar2,vBj varchar2) return varchar2  ---教学班组合----
as
   sJxbzh varchar2(2000);   ---教学班组合
   sXxdmbj varchar2(20); --学校代码标记
begin
    sJxbzh := '无';
    begin
       select nvl(max(xxdm),'-1') into sXxdmbj from zftal_xtgl_xxxxszb;
       if vBj = '0' then
         --dbms_output.put_line('sXxdmbj:'||sXxdmbj);
         if sXxdmbj = '13684' then  --吉林大学珠海学院个性化
            select wm_concat(Jxbzh) into sJxbzh from (
            select njdm_id,zyh_id,bj1||Get_XhDesc(min(bj2),max(bj2),wm_concat(bj2)) Jxbzh from (
               select njdm_id,zyh_id,substr(bj,1,length(bj)-2) bj1,to_number(substr(bj,length(bj)-1,2)) bj2 from (
               select a.njdm_id,a.zyh_id,a.bh_id,(select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) bj
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id and nvl(a.bh_id,'wbj') != 'wbj'
               )
             )group by njdm_id,zyh_id,bj1
            );

         elsif sXxdmbj = '10191' then --吉林建筑个性化

           select wm_concat(Jxbzh) into sJxbzh from (
            select njdm_id,zyh_id,bj1||Get_XhDesc(min(bj2),max(bj2),wm_concat(bj2)) Jxbzh from (
               select njdm_id,zyh_id,substr(bj,1,length(bj)-1) bj1,to_number(substr(bj,length(bj),1)) bj2 from (
               select a.njdm_id,a.zyh_id,a.bh_id,(select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) bj
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id and nvl(a.bh_id,'wbj') != 'wbj'
               )
             )group by njdm_id,zyh_id,bj1
            );

         else
          select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
           (select Jxbzh from
            (select  distinct (case when bh_id = 'wbj' then
                                     (select njmc from zftal_xtgl_njdmb where njdm_id=a.njdm_id)||
                                     (select zymc from zftal_xtgl_zydmb where zyh_id=a.zyh_id)
                                  when zyh_id = 'wzy' then '无'
                                  else (select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) end) Jxbzh
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id
              ) order by Jxbzh
            );
          end if;
       end if ;
       if vBj = 'bh' then
       select replace(wm_concat(jxbzh_bh),',',';') into sJxbzh from
           (select jxbzh_bh ,Jxbzh from
            (select  distinct (case when bh_id = 'wbj' then
                                     (select njdm from zftal_xtgl_njdmb where njdm_id=a.njdm_id)||
                                     (select zyh from zftal_xtgl_zydmb where zyh_id=a.zyh_id)
                                  when zyh_id = 'wzy' then '无'
                                  else (select bj from zftal_xtgl_bjdmb where bh_id=a.bh_id) end) Jxbzh,
                               (select bh from zftal_xtgl_bjdmb where bh_id=a.bh_id) jxbzh_bh
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id
              ) order by Jxbzh
            );
       end if;
       ---专业组合
       if vBj = '1' then
       select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
           (select Jxbzh from
            (select  distinct (case
                                 when zyh_id = 'wzy' then '无'
                                else
                                  (select zymc from zftal_xtgl_zydmb where zyh_id = a.zyh_id)
                                end) Jxbzh
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id
              ) order by Jxbzh
            );
        end if;

       if vBj = '2' then
       select replace(wm_concat(Jxbzh),',',';') into sJxbzh from
           (select Jxbzh from
            (select case when a.bh_id = 'wbj' then null else  (select jg.jgmc||zy.zymc from zftal_xtgl_jgdmb jg,zftal_xtgl_zydmb zy where jg.jg_id = zy.jg_id and zy.zyh_id = a.zyh_id)||
                     (select njmc from zftal_xtgl_njdmb where njdm_id = a.njdm_id)||
                     (select bj from zftal_xtgl_bjdmb where bh_id = a.bh_id) end as  Jxbzh
                from jw_jxrw_jxbhbxxb a where jxb_id= vJxb_id
              ) order by Jxbzh
            );
        end if;
     exception
        When others then
          sJxbzh := '无0';
    end;
    if sJxbzh is null then
     return '无' ;
    else
    return sJxbzh ;
    end if ;
end fn_jxbzh;

/

