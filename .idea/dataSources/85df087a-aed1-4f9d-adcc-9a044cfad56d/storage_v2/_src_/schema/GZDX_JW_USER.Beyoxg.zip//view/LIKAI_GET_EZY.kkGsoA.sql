create view LIKAI_GET_EZY as
  select distinct
      xsj1.xh_id                   pk,
      xsj1.xh,
      xsj1.xjztdm,
      xsj1.njdm_id,
      (select xjztmc
       from jw_xjgl_xjztdmb
       where xjztdm = xsj1.xjztdm) ezyxjztmc,
      xsj1.jg_id,
      (select jgmc
       from zftal_xtgl_jgdmb
       where jg_id = xsj1.jg_id)   ezyjgmc,
      xsj1.zyh_id,
      (select zyh
       from zftal_xtgl_zydmb
       where zyh_id = xsj1.zyh_id) ezyzyh,
      (select zymc
       from zftal_xtgl_zydmb
       where zyh_id = xsj1.zyh_id) ezyzymc,
             decode((select jsbyf
              from jw_bygl_byshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行机审')           ejsbyf,
      decode((select xyzs
              from jw_bygl_byshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学院审')          exyzs,
      decode((select xxsh
              from jw_bygl_byshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学校审核')         exxsh,
      nvl((select byjr
           from JW_BYGL_BYSFZXXB
           where xh_id = xsj1.xh_id),
          '该生暂无毕业结论')              ebyjr,
      decode((select jssyf
              from jw_bygl_xwshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行机审')           exwjssyf,
      decode((select xyzs
              from jw_bygl_xwshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学院审')          exwxyzs,
      decode((select xxsh
              from jw_bygl_xwshb
              where xh_id = xsj1.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学校审核')         exwxxsh,
      decode((select ywxw
              from JW_BYGL_BYSFZXXB
              where xh_id = xsj1.xh_id),
             '0',
             '无',
             '1',
             '有',
             '该生暂无学位结论')           eywxw,
      xsj2.xh                      zxh,
      xsj2.xm,
      xsj2.njdm_id                 znjdm_id,
      xsj2.xjztdm                  zxjzt,
      (select xjztmc
       from jw_xjgl_xjztdmb
       where xjztdm = xsj2.xjztdm) zxjztmc,
      xsj2.jg_id                   zjg_id,
      (select jgmc
       from zftal_xtgl_jgdmb
       where jg_id = xsj2.jg_id)   zjgmc,
      xsj2.zyh_id                  zzyh_id,
      (select zyh
       from zftal_xtgl_zydmb
       where zyh_id = xsj2.zyh_id) zzyh,
      (select zymc
       from zftal_xtgl_zydmb
       where zyh_id = xsj2.zyh_id) zzymc,
      decode((select jsbyf
              from jw_bygl_byshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行机审')           jsbyf,
      decode((select xyzs
              from jw_bygl_byshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学院审')          xyzs,
      decode((select xxsh
              from jw_bygl_byshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学校审核')         xxsh,
      nvl((select byjr
           from JW_BYGL_BYSFZXXB
           where xh_id = xsj2.xh_id),
          '该生暂无毕业结论')              byjr,
      decode((select jssyf
              from jw_bygl_xwshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行机审')           xwjssyf,
      decode((select xyzs
              from jw_bygl_xwshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学院审')          xwxyzs,
      decode((select xxsh
              from jw_bygl_xwshb
              where xh_id = xsj2.xh_id),
             '0',
             '不通过',
             '1',
             '通过',
             '该生还未进行学校审核')         xwxxsh,
      decode((select ywxw
              from JW_BYGL_BYSFZXXB
              where xh_id = xsj2.xh_id),
             '0',
             '无',
             '1',
             '有',
             '该生暂无学位结论')           ywxw
    from JW_XJGL_XSJBXXB xsj1, JW_XJGL_XSJBXXB xsj2
    where xsj1.xh like 's%'
          and (xsj1.ZJHM = xsj2.ZJHM or replace(xsj1.xh, 's', '1') = xsj2.xh)
/

