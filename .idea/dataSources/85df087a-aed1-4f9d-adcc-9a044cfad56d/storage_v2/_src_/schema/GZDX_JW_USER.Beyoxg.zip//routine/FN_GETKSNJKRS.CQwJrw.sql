create function fn_getKsnjkrs(v_ksmcdmb_id in varchar2,v_rs in number)-----获取考试拟监考人数
return varchar2 is
    v_njkrs varchar2(10); --拟监考人数
begin
    select nvl(to_char(max(jkjsrs)),'未设置') into v_njkrs from jw_kw_kcjkjssgzszb where ksmcdmb_id=v_ksmcdmb_id and kss1<=v_rs and kss2>=v_rs;
    return v_njkrs;
end fn_getKsnjkrs;

/

