create procedure PJ_JSPJZHTJB-----教师评价综合统计表---
(
 vXnm in varchar2,
 vXqm in varchar2,
 vBj out varchar2)
 as
 sJgh_id varchar2(32);
 sXspjf  varchar2(10);---------学生评价成绩
 sThpjf  varchar2(10);---------同行评价成绩
 sDdpjf  varchar2(10);---------督导评价成绩
 sLdpjf  varchar2(10);---------领导评价成绩
 sXypjf  varchar2(10);---------学院评价成绩
 sZppjf  varchar2(10);---------自评评价成绩
 sXscpdx  varchar2(4);---------学生参评对象
 sThcpdx  varchar2(4);---------同行参评对象
 sDdcpdx  varchar2(4);---------督导参评对象
 sLdcpdx  varchar2(4);---------领导参评对象
 sXycpdx  varchar2(4);---------学院参评对象
 sZpcpdx  varchar2(4);---------自评参评对象
 sPjzf   varchar2(10);----------评价总分
 iGs      number;
 iZgs     number;
 cursor Get_Jghid is
      select distinct jgh_id from JW_PJ_XSPJTJB
                      where xnm = vXnm
                      and xqm=vXqm
                      and cpdxdm='01';
 Cur_Jghid Get_Jghid%rowtype;


begin
  vBj := '0';
  open Get_Jghid;
    loop
      fetch Get_Jghid into Cur_Jghid;
      exit when Get_Jghid%notfound;
      sjgh_id   := Cur_Jghid.jgh_id;

      sXspjf:='0';
      sThpjf:='0';
      sDdpjf:='0';
      sXypjf:='0';
      sLdpjf:='0';
      sZppjf:='0';
      -------------------------------------------------------学生评教
      select nvl((select round(avg(bfzpf),3) from JW_PJ_XSPJTJB where xnm=vXnm and xqm=vXqm and jgh_id=sjgh_id
      group by xnm,xqm,jgh_id),0) into sXspjf from dual ;
      sXscpdx:='01';

      -------------------------------------------------------同行评价
      select nvl((select round(avg(bfzpf),3)  from JW_PJ_JXBPJTJB where xnm=vXnm and xqm=vXqm and bpjgh_id=sjgh_id and cpdxdm='02'
      group by xnm,xqm,bpjgh_id),0) into sThpjf from dual;
      sThcpdx:='02';
      --------------------------------------------------------督导评价
      select nvl((select round(avg(bfzpf),3) from JW_PJ_JXBPJTJB where xnm=vXnm and xqm=vXqm and bpjgh_id=sjgh_id and cpdxdm='03'
      group by xnm,xqm,bpjgh_id),0) into sDdpjf from dual;
      sDdcpdx:='03';

      -------------------------------------------------------学院评价
      select nvl((select round(avg(bfzpf),3)  from jw_pj_jspjtjb where xnm=vXnm and xqm=vXqm and bpjgh_id=sjgh_id and cpdxdm='04'
      group by xnm,xqm,bpjgh_id),0) into sXypjf from dual;
      sXycpdx:='04';

      ------------------------------------------------------领导评价
      select nvl((select round(avg(bfzpf),3)  from JW_PJ_JXBPJTJB where xnm=vXnm and xqm=vXqm and bpjgh_id=sjgh_id and cpdxdm='05'
      group by xnm,xqm,bpjgh_id),0) into sLdpjf from dual;
      sLdcpdx:='05';

      ------------------------------------------------------教师自评
      select nvl((select round(avg(bfzpf),3)  from jw_pj_jspjtjb where xnm=vXnm and xqm=vXqm and bpjgh_id=sjgh_id and cpdxdm='06'
      group by xnm,xqm,bpjgh_id),0) into sZppjf from dual;
      sZpcpdx:='06';

      select nvl((select count(*)  from
      (
      select sThpjf x from dual
      union all select sDdpjf x from dual
      union all select sXypjf x from dual
      union all select sLdpjf x from dual
      union all select sZppjf x from dual
      ) a where a.x='0'),0) into iZgs from dual;

      select  round((sXspjf*0.5+sThpjf*0.1+sDdpjf*0.1+sXypjf*0.1+sLdpjf*0.1+sZppjf*0.1)/(100-iZgs*10)*100,3) into sPjzf from dual;

      select count(*) into iGs from JW_PJ_JSPJZHTJB where xnm=vXnm and xqm=vXqm and Jgh_id=sJgh_id;

        if sXspjf='0' then
      sXspjf:='无此项';
      end if;

      if sThpjf='0' then
      sThpjf:='无此项';
      end if;

      if sDdpjf='0' then
      sDdpjf:='无此项';
      end if;

      if sXypjf='0' then
      sXypjf:='无此项';
      end if;

      if sLdpjf='0' then
      sLdpjf:='无此项';
      end if;

      if sZppjf='0' then
      sZppjf:='无此项';
      end if;
      if iGs = 0 then
      begin-----没有存在，直接插入
       insert into JW_PJ_JSPJZHTJB(xnm,xqm,Cpdxdm,JGH_ID,bfzpf,pjzhf)
         select vXnm,vXqm,sXscpdx,sJgh_id,sXspjf,sPjzf from dual
         union all select vXnm,vXqm,sThcpdx,sJgh_id,sThpjf,sPjzf from dual
         union all select vXnm,vXqm,sDdcpdx,sJgh_id,sDdpjf,sPjzf from dual
         union all select vXnm,vXqm,sXycpdx,sJgh_id,sXypjf,sPjzf from dual
         union all select vXnm,vXqm,sLdcpdx,sJgh_id,sLdpjf,sPjzf from dual
         union all select vXnm,vXqm,sZpcpdx,sJgh_id,sZppjf,sPjzf from dual;
         commit;
      end;
      else
      begin ------已经存在，先删除再插入
        delete from JW_PJ_JSPJZHTJB where xnm=vXnm and xqm=vXqm  and jgh_id=sJgh_id;
        insert into JW_PJ_JSPJZHTJB(xnm,xqm,Cpdxdm,JGH_ID,bfzpf,pjzhf)
         select vXnm,vXqm,sXscpdx,sJgh_id,sXspjf,sPjzf from dual
         union all select vXnm,vXqm,sThcpdx,sJgh_id,sThpjf,sPjzf from dual
         union all select vXnm,vXqm,sDdcpdx,sJgh_id,sDdpjf,sPjzf from dual
         union all select vXnm,vXqm,sXycpdx,sJgh_id,sXypjf,sPjzf from dual
         union all select vXnm,vXqm,sLdcpdx,sJgh_id,sLdpjf,sPjzf from dual
         union all select vXnm,vXqm,sZpcpdx,sJgh_id,sZppjf,sPjzf from dual;
         commit;
      end;
      end if;
  end loop;
  close Get_Jghid;

  <<Exend>>
 null;
end PJ_JSPJZHTJB;

/

