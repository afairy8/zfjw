create function fun_by_getpjxfjd(v_xh_id varchar2,v_lx varchar2,v_tjkcxz varchar2,v_btjkc varchar2,v_xdlx varchar2)
Return varchar2 ------------------平均学分绩点
as
pjxfjd varchar2(100);
sqlstr varchar2(8000);
v_xxdm varchar2(10);
vsb varchar2(5000);
v_n   number;
v_sql varchar(32767);---总的sql
begin
     begin
      proc_sc_bycjjgb(v_xh_id);--生成成绩结果记录
      select xxdm into v_xxdm  from zftal_xtgl_xxxxszb;

      sqlstr:='select to_char((case when cjjd_zxf = 0 then 0 else nvl(round(zxfjd / cjjd_zxf, 2), 0) end), ''fm9999999990.09'')'||
      ' from (select nvl(sum(to_number(nvl(xf, 0)) * to_number(nvl(cjjd, 0))), 0) zxfjd, nvl(sum(to_number(nvl((case '||
      ' when cjjd is null then 0 ';
      if v_xxdm ='10364' then
         sqlstr:=sqlstr|| ' when kcxzdm = ''06'' then  0  ';
      end if;
      sqlstr:=sqlstr|| ' else  to_number(nvl(xf, 0)) end),  0))),0) cjjd_zxf '||
      ' from (select xh_id, xnm, xqm,kch_id,kcmc, kcxzdm, sftjjd, xf,maxcj cj,maxbfzcj bfzcj,'||
      ' (case  when sftjjd = ''0'' then  null ';
      if v_xxdm='10364' then
        sqlstr:=sqlstr||  ' when kcxzdm = ''06'' then 0 ';
      end if;
      sqlstr:=sqlstr||  ' else to_number(maxjd) end) cjjd'||
      ' from (select t99.*,  t99.ly as lx,(select sftjjd from jw_jh_kcxzdmb where kcxzdm = t99.kcxzdm) sftjjd'||
      ' from jw_bygl_xscjjgb t99  where 1 = 1  and t99.xh_id='''||v_xh_id||'''';
      if v_lx='2' then
            sqlstr:= sqlstr||' and exists (select 1 from jw_xjgl_xsjbxxb b, jw_jh_jxzxjhkcxxb c where c.kch_id = t99.kch_id and c.zyh_id = nvl(b.byzyh_id,b.zyh_id) and c.njdm_id = nvl(b.bynjdm_id,b.njdm_id) and b.xh_id = '''||v_xh_id||''' and  c.zyzgkcbj = ''1'') ';
      end if;
      if v_tjkcxz is not null and v_tjkcxz!='qb' then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_tjkcxz||'''||'','' , '',''||t99.kcxzdm||'','' )>0 ';
      end if;

      if v_xdlx is not null and v_xdlx!='qb' then
            vsb :='AND EXISTS (select 1 from (SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxb xfyq,JW_JH_xsJXZXJHKCXXB kcxx'||
                  ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id union all '||
                  ' SELECT xfyq.xh_id, xfyq.xdlx, nvl(kcxx.sskch_id,kcxx.kch_id) kch_id  FROM jw_jh_xsjxzxjhxfyqxxfxezyb xfyq,Jw_Jh_Xsjxzxjhkcxxfxezyb kcxx '||
                  ' where xfyq.xh_id = kcxx.xh_id AND xfyq.xfyqjd_id = kcxx.xfyqjd_id) a '||
                  ' WHERE a.XH_ID=t99.XH_ID  AND a.KCH_ID=nvl(t99.sskch_id,t99.KCH_ID) AND ('||

                  ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                  ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                  ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 or'||
                  ' instr('',''||'''||v_xdlx||'''||'','' , '',''|| a.xdlx ||'','' ) >0 ))';
            sqlstr:= sqlstr||''||vsb;
       end if;

       if v_btjkc is not null then
            sqlstr:= sqlstr||' and  instr('',''||'''||v_btjkc||'''||'','' , '',''||t99.kch_id||'','' )<1 ';
       end if;

      sqlstr:= sqlstr||' ) t4 where xh_id is not null and lx = ''cjb'') t5) t6';

       v_n := 1;
    loop
        v_sql := substr(sqlstr, v_n, 1000);
        dbms_output.put_line(v_sql);

        v_n := v_n + 1000;
        exit when v_n > length(sqlstr);
    end loop;
      execute immediate sqlstr into pjxfjd;
    exception
          When others then
            pjxfjd := '查询出错，不合格！';
    end;
  return pjxfjd;
end;

/

