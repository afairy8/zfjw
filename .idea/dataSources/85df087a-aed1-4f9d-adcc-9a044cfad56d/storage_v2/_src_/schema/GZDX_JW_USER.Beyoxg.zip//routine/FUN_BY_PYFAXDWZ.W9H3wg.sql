create function fun_by_pyfaxdwz(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_flag int;
   v_id varchar2(32);
begin
    sJg := '合格';
    begin
          select  count(1),max(xh_id) into v_flag,v_id  from  (select nvl(bfzcj,0)bfzcj,xh_id  from JW_JH_xsJXZXJHKCXXB where xh_id=v_xh_id)a where a.bfzcj<60;
            -- dbms_output.put_line('v_flag:'||v_flag);
           if v_id is null then
              sJg:= '系统无数据，不合格！';
           elsif v_flag>0    then
              sJg:= '个人培养方案修读不完整，不合格！';

           elsif v_flag=0 and v_id is not null  then
              sJg:= '合格！';
           end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_pyfaxdwz;

/

