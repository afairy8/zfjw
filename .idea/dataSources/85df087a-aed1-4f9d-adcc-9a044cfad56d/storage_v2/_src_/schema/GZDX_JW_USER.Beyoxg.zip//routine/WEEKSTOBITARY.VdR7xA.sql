create function WeeksToBitary(vQsz IN NUMBER,vJsz IN NUMBER)---起始周与结束周转换为二进制数,如：1-8 转为255
return number is
begin
  if  vQsz = vJsz then
     return power(2,vQsz-1);
    else
     return power(2,vJsz-1)+bitlmv(bitrmv(power(2,vJsz-1)-1-power(2,vQsz-1),vQsz-1),vQsz-1) + power(2,vQsz-1);
  end if ;
end;


/

