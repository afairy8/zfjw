create function fn_jxbypcdzc(fn_jxbId varchar2,fn_xqj varchar2,fn_jc number,fn_jgh varchar2)return number
as
   --根据条件查询教学班已经安排的周次场地
   zcdBit number;
begin
     dbms_output.put_line('fn_jxbId:'||fn_jxbId);
     dbms_output.put_line('fn_xqj:'||fn_xqj);
     dbms_output.put_line('fn_jc:'||fn_jc);
     select  zcd into zcdBit from (
               select  get_bitorsunion(wm_concat(a.zcd)) zcd from jw_pk_kbcdb a where exists(select 'x' from jw_pk_kbsjb where kb_id=a.kb_id
               and jxb_id=fn_jxbId and xqj=fn_xqj and instr(''''||fn_jgh||'''',''''||jgh_id||'''')>0)
               and bitand(a.jc,power(2,fn_jc-1))>0
     );
    return zcdBit;
end fn_jxbypcdzc;

/

