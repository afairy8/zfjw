create procedure p_byfzxx_sczsh_tx(in_pyccdm in varchar2, --培养层次
                                                   in_bynf   in varchar2, --查询条件生成，毕业年份
                                                   in_njdm   in varchar2, --年级代码
                                                   in_jg     in varchar2, --机构
                                                   in_zyh    in varchar2, --专业
                                                   in_bh     in varchar2, --班级
                                                   in_xjztdm in varchar2, --学籍状态
                                                   in_zslx   in varchar2, --证书类型
                                                   in_bynjdm_id in varchar2,--毕业年级
                                                    in_byjg_id   in varchar2,--毕业机构
                                                    in_byzyh_id  in varchar2,--毕业专业
                                                    in_xm        in varchar2,--姓名
                                                    in_byjr      in varchar2,--毕业结论
                                                    in_sfzx      in varchar2,--是否在校
                                                    in_sfyxj     in varchar2,--是否有学籍
                                                    in_sfyzp     in varchar2,--是否有照片
                                                    in_ywxw      in varchar2,--有无学位
                                                    in_xsbj      in varchar2,--学生标记
                                                    in_pc        in varchar2,--批次
                                                    in_xslbdm    in varchar2,--学生类别代码
                                                    in_xdlx      in varchar2,--修读类型
                                                    in_xqh_id    in varchar2,--校区号
                                                    in_sfbynf    in varchar2,--是否毕业年份
                                                   out_flag  out varchar2,
                                                   out_msg   out varchar2) as
  v_count number;
  type my_cursor is ref cursor; --定义一个Ref游标变量
  type my_cursor2 is ref cursor; --定义一个Ref游标变量
  v_byxx_cursor my_cursor; --毕业信息游标
  TYPE v_byxx_REC IS RECORD(
    bynf  varchar2(200),
    byjr  varchar2(200),
    xh_id varchar2(200),
    xh    varchar2(200),
    xm    varchar2(200),
    xz    varchar2(200),
    xwwyhkhrq varchar2(200));
  TYPE v_gz_REC IS RECORD(
    qsw    varchar2(200),
    ws     varchar2(200),
    xh     varchar2(200),
    clz    varchar2(200),
    zdm    varchar2(200),
    sfyqsw varchar2(200),
    wsbl   varchar2(200));
  v_byxx      v_byxx_REC;
  v_gz_cursor my_cursor2; --规则游标
  v_gz        v_gz_REC;
  v_sql       varchar2(4000);--存储查询数据的SQL
  v_cntsql    varchar2(4000);--存储查询个数的SQL
  v_maxlshsql varchar2(4000);--存储查询最大流水号的sql
  v_bh        varchar2(200);--用于存储结果编号
  v_tmp       varchar2(200);--临时变量
  v_tmp1      varchar2(200);--临时变量1
begin
  --判断是否传入了指定的参数
  if (in_pyccdm is null) and (in_bynf is null) and (in_njdm is null) and (in_jg is null) and (in_zyh is null) and (in_bh is null) and (in_xjztdm is null)  then
    out_flag := -1;
    out_msg  := '请至少选择一个查询条件！';
    goto nextOne;
  end if;
  --判断是否传入了证书类型
  if (in_zslx is null) then
    out_flag := -2;
    out_msg  := '证书类型不能为空';
    goto nextOne;
  end if;
  --根据证书类型判断相应的证书规则有没有配置
  select count(1) into v_count from jw_bygl_zshgzxxb a, jw_bygl_zshgzjcdmb b where a.zdm = b.zdm and a.gzlx = b.gzlx and b.sfqy = '1' and a.gzlx = in_zslx;
  if v_count = 0 then
    out_flag := -3;
    out_msg  := '证书号规则未设置，请与管理员联系！';
    goto nextOne;
  end if;
  --按条件查询要处理的数据
  v_sql := 'select t1.bynf,t1.byjr,t2.xh_id,t2.xh,t2.xm,t3.xz,replace(t1.xwwyhkhrq,'||chr(39)||'-'||chr(39)||','||chr(39)||''||chr(39)||')xwwyhkhrq from jw_bygl_bysfzxxb t1, jw_xjgl_xsjbxxb t2, jw_xjgl_xsxjxxb t3 where t1.xh_id = t2.xh_id and t1.xh_id = t3.xh_id and t3.xnm = (select zdz from zftal_xtgl_xtszb where zdm = ' ||
           chr(39)||'DQXNM'||chr(39)||') and t3.xqm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXQM'||chr(39)||')';
  --查询符合条件的数据个数
  v_cntsql:='select count(distinct t1.xh_id) from jw_bygl_bysfzxxb t1, jw_xjgl_xsjbxxb t2, jw_xjgl_xsxjxxb t3 where t1.xh_id = t2.xh_id and t1.xh_id = t3.xh_id and t3.xnm = (select zdz from zftal_xtgl_xtszb where zdm = ' ||
           chr(39)||'DQXNM'||chr(39)||') and t3.xqm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXQM'||chr(39)||')';
  --查询符合条件的已生成数据的最大编号
  v_maxlshsql:='select ';
  if in_zslx = '1' then
    v_maxlshsql := v_maxlshsql||' nvl(max(nvl(t1.xwlsh,0)),0)';
  end if;
  if in_zslx = '2' then
    v_maxlshsql := v_maxlshsql||' nvl(max(nvl(t1.bylsh,0)),0)';
  end if;
  if in_zslx = '3' then
    v_maxlshsql := v_maxlshsql||' nvl(max(nvl(t1.fxlsh,0)),0)';
  end if;
  if in_zslx = '4' then
    v_maxlshsql := v_maxlshsql||' nvl(max(nvl(t1.exwlsh,0)),0)';
  end if;
  v_maxlshsql:=v_maxlshsql||' from jw_bygl_bysfzxxb t1, jw_xjgl_xsjbxxb t2, jw_xjgl_xsxjxxb t3 where t1.xh_id = t2.xh_id and t1.xh_id = t3.xh_id and t3.xnm = (select zdz from zftal_xtgl_xtszb where zdm = ' ||
           chr(39)||'DQXNM'||chr(39)||') and t3.xqm = (select zdz from zftal_xtgl_xtszb where zdm = '||chr(39)||'DQXQM'||chr(39)||')';
 --年级
 if in_njdm is not null then
    v_sql := v_sql||' and t3.njdm_id = '||chr(39)||in_njdm||chr(39);
    v_cntsql := v_cntsql||' and t3.njdm_id = '||chr(39)||in_njdm||chr(39);
    v_maxlshsql := v_maxlshsql||' and t3.njdm_id = '||chr(39)||in_njdm||chr(39);
  end if;
  --学院
  if in_jg is not null then
    v_sql := v_sql||' and t3.jg_id = '||chr(39)||in_jg||chr(39);
    v_cntsql := v_cntsql||' and t3.jg_id = '||chr(39)||in_jg||chr(39);
    v_maxlshsql := v_maxlshsql||' and t3.jg_id = '||chr(39)||in_jg||chr(39);
  end if;
  --专业
  if in_zyh is not null then
    v_sql := v_sql||' and t3.zyh_id = '||chr(39)||in_zyh||chr(39);
    v_cntsql := v_cntsql||' and t3.zyh_id = '||chr(39)||in_zyh||chr(39);
    v_maxlshsql := v_maxlshsql||' and t3.zyh_id = '||chr(39)||in_zyh||chr(39);
  end if;
  --班级
  if in_bh is not null then
    v_sql := v_sql||' and t3.bh_id = '||chr(39)||in_bh||chr(39);
    v_cntsql := v_cntsql||' and t3.bh_id = '||chr(39)||in_bh||chr(39);
    v_maxlshsql := v_maxlshsql||' and t3.bh_id = '||chr(39)||in_bh||chr(39);
  end if;
  --毕业年份
  if in_bynf is not null then
    v_sql := v_sql||' and  t1.bynf = '||chr(39)||in_bynf||chr(39);
    v_cntsql := v_cntsql||' and  t1.bynf = '||chr(39)||in_bynf||chr(39);
    v_maxlshsql := v_maxlshsql||' and  t1.bynf = '||chr(39)||in_bynf||chr(39);
  end if;
  --学籍状态
  if in_xjztdm is not null then
    v_sql := v_sql||' and t2.xjztdm = '||chr(39)||in_xjztdm||chr(39);
    v_cntsql := v_cntsql||' and t2.xjztdm = '||chr(39)||in_xjztdm||chr(39);
    v_maxlshsql := v_maxlshsql||' and t2.xjztdm = '||chr(39)||in_xjztdm||chr(39);
  end if;
  --证书类型-学位证
  if in_zslx = '1' then
    v_sql := v_sql||' and t1.xwzsh is null';
    v_cntsql := v_cntsql||' and t1.xwzsh is null';
    --最大流水号统计是统计有号码的 和上面不一样
    v_maxlshsql := v_maxlshsql||' and t1.xwzsh is not null';
  end if;
  --证书类型-毕业证
  if in_zslx = '2' then
    v_sql := v_sql||' and t1.byzsh is null';
    v_cntsql := v_cntsql||' and t1.byzsh is null';
    --最大流水号统计是统计有号码的 和上面不一样
    v_maxlshsql := v_maxlshsql||' and t1.byzsh is not null';
  end if;
  --培养层次
  if in_pyccdm is not null then
    v_sql := v_sql||' and nvl(t3.pyccdm,t2.pyccdm) = '||chr(39)||in_pyccdm||chr(39);
    v_cntsql := v_cntsql||' and nvl(t3.pyccdm,t2.pyccdm) = '||chr(39)||in_pyccdm||chr(39);
    v_maxlshsql := v_maxlshsql||' and nvl(t3.pyccdm,t2.pyccdm) = '||chr(39)||in_pyccdm||chr(39);
  end if;
  --毕业年级jw_bygl_bysfzxxb t1, jw_xjgl_xsjbxxb t2, jw_xjgl_xsxjxxb t3
  if in_bynjdm_id is not null then
    v_sql := v_sql||' and nvl(t3.bynjdm_id,t3.njdm_id) = '||chr(39)||in_bynjdm_id||chr(39);
    v_cntsql := v_cntsql||' and nvl(t3.bynjdm_id,t3.njdm_id) = '||chr(39)||in_bynjdm_id||chr(39);
    v_maxlshsql := v_maxlshsql||' and nvl(t3.bynjdm_id,t3.njdm_id) = '||chr(39)||in_bynjdm_id||chr(39);
  end if;
  --毕业机构
  if in_byjg_id is not null then
    v_sql := v_sql||' and nvl(t3.byjg_id,t3.jg_id) = '||chr(39)||in_byjg_id||chr(39);
    v_cntsql := v_cntsql||' and nvl(t3.byjg_id,t3.jg_id) = '||chr(39)||in_byjg_id||chr(39);
    v_maxlshsql := v_maxlshsql||' and nvl(t3.byjg_id,t3.jg_id) = '||chr(39)||in_byjg_id||chr(39);
  end if;
  --毕业专业
  if in_byzyh_id is not null then
    v_sql := v_sql||' and nvl(t3.byzyh_id,t3.zyh_id) = '||chr(39)||in_byzyh_id||chr(39);
    v_cntsql := v_cntsql||' and nvl(t3.byzyh_id,t3.zyh_id) = '||chr(39)||in_byzyh_id||chr(39);
    v_maxlshsql := v_maxlshsql||' and nvl(t3.byzyh_id,t3.zyh_id) = '||chr(39)||in_byzyh_id||chr(39);
  end if;
  --姓名
  if in_xm is not null then
    v_sql := v_sql||' and t2.xh||t2.xm like ''%'||in_xm||'%''';
    v_cntsql := v_cntsql||' and t2.xh||t2.xm like ''%'||in_xm||'%''';
    v_maxlshsql := v_maxlshsql||' and t2.xh||t2.xm like ''%'||in_xm||'%''';
  end if;
  --毕业结论
  if in_byjr is not null then
    v_sql := v_sql||' and t1.byjr like ''%'||in_byjr||'%''';
    v_cntsql := v_cntsql||' and t1.byjr like ''%'||in_byjr||'%''';
    v_maxlshsql := v_maxlshsql||' and t1.byjr like ''%'||in_byjr||'%''';
  end if;
  --是否在校
  if in_sfzx is not null then
    v_sql := v_sql||' and t2.sfzx = '||chr(39)||in_sfzx||chr(39);
    v_cntsql := v_cntsql||' and  t2.sfzx = '||chr(39)||in_sfzx||chr(39);
    v_maxlshsql := v_maxlshsql||' and  t2.sfzx = '||chr(39)||in_sfzx||chr(39);
  end if;
  --是否有学籍
  if in_sfyxj is not null then
    v_sql := v_sql||' and exists(select * from jw_xjgl_xjztdmb t4 where t2.xjztdm  = t4.xjztdm and t4.sfyxj = '''||in_sfyxj||''' )';
    v_cntsql := v_cntsql||'  and exists(select * from jw_xjgl_xjztdmb t4 where t2.xjztdm  = t4.xjztdm and t4.sfyxj = '''||in_sfyxj||''' )';
    v_maxlshsql := v_maxlshsql||'  and exists(select * from jw_xjgl_xjztdmb t4 where t2.xjztdm  = t4.xjztdm and t4.sfyxj = '''||in_sfyxj||''' )';
  end if;
  --是否有照片
  if in_sfyzp is not null then
     if in_sfyzp = '0' then
        v_sql := v_sql||' and (exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is null ) or not exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id))';
        v_cntsql := v_cntsql||'  and (exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is null ) or not exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id))';
        v_maxlshsql := v_maxlshsql||' and (exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is null ) or not exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id))';
     elsif in_sfyzp = '1' then
        v_sql := v_sql||' and exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is not null )';
        v_cntsql := v_cntsql||'  and exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is not null )';
        v_maxlshsql := v_maxlshsql||'  and exists (select 1 from jw_xjgl_xszpb t1 where t2.xh_id = t1.xh_id and t1.byzp is not null )';
     end if;
  end if;
  --有无学位
  if in_ywxw is not null then
    v_sql := v_sql||' and t1.ywxw = '||chr(39)||in_ywxw||chr(39);
    v_cntsql := v_cntsql||' and  t1.ywxw = '||chr(39)||in_ywxw||chr(39);
    v_maxlshsql := v_maxlshsql||' and  t1.ywxw = '||chr(39)||in_ywxw||chr(39);
  end if;
  --学生标记
  if in_xsbj is not null then
    v_sql := v_sql||' and bitand(t2.xsbj,'||chr(39)||in_xsbj||chr(39)||') > 0';
    v_cntsql := v_cntsql||' and bitand(t2.xsbj,'||chr(39)||in_xsbj||chr(39)||') > 0';
    v_maxlshsql := v_maxlshsql||' and bitand(t2.xsbj,'||chr(39)||in_xsbj||chr(39)||') > 0';
  end if;
  --批次
  if in_pc is not null then
    v_sql := v_sql||' and exists(select 1 from jw_bygl_byshb  a where a.xh_id = t1.xh_id and a.bynd = t1.bynf and a.pc='''||in_pc||''')';
    v_cntsql := v_cntsql||' and exists(select 1 from jw_bygl_byshb  a where a.xh_id = t1.xh_id and a.bynd = t1.bynf and a.pc='''||in_pc||''')';
    v_maxlshsql := v_maxlshsql||' and exists(select 1 from jw_bygl_byshb  a where a.xh_id = t1.xh_id and a.bynd = t1.bynf and a.pc='''||in_pc||''')';
  end if;
  --学生类别代码
  if in_xslbdm is not null then
     v_sql := v_sql||' and t2.xslbdm = '||chr(39)||in_xslbdm||chr(39);
    v_cntsql := v_cntsql||' and  t2.xslbdm = '||chr(39)||in_xslbdm||chr(39);
    v_maxlshsql := v_maxlshsql||' and  t2.xslbdm = '||chr(39)||in_xslbdm||chr(39);
  end if;

  if in_xdlx is not null then
     if in_xdlx='zx' then
        v_sql := v_sql||' and 1=1 ';
        v_cntsql := v_cntsql||' and 1=1 ';
        v_maxlshsql := v_maxlshsql||' and 1=1 ';
     elsif in_xdlx='fx' then
        v_sql := v_sql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''01'')';
        v_cntsql := v_cntsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''01'')';
        v_maxlshsql := v_maxlshsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''01'')';
     elsif in_xdlx='ezy' then
        v_sql := v_sql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''02'')';
        v_cntsql := v_cntsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''02'')';
        v_maxlshsql := v_maxlshsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''02'')';
     elsif in_xdlx='exw' then
         v_sql := v_sql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''03'')';
        v_cntsql := v_cntsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''03'')';
        v_maxlshsql := v_maxlshsql||' and exists(select 1 from jw_fx_fxezybmb bmb ,jw_fx_fxezybmkzb kzb where bmb.fxezybmkz_id = kzb.fxezybmkz_id and bmb.xh_id = t1.xh_id and kzb.bmlbdm=''03'')';
     end if;
  end if;

  --校区号
  if in_xqh_id is not null then
    v_sql := v_sql||' and exists(select 1 from zftal_xtgl_bjdmb bj where t2.bh_id = bj.bh_id and bj.xqh_id = '''||in_xqh_id||''')';
    v_cntsql := v_cntsql||' and exists(select 1 from zftal_xtgl_bjdmb bj where t2.bh_id = bj.bh_id and bj.xqh_id = '''||in_xqh_id||''')';
    v_maxlshsql := v_maxlshsql||' and exists(select 1 from zftal_xtgl_bjdmb bj where t2.bh_id = bj.bh_id and bj.xqh_id = '''||in_xqh_id||''')';
  end if;
  --是否毕业年份
  if in_sfbynf is not null then
     if in_sfbynf = '1' then
         v_sql := v_sql||' and substr(t2.yjbyrq, 0, 4) = t1.bynf';
         v_cntsql := v_cntsql||' and substr(t2.yjbyrq, 0, 4) = t1.bynf';
         v_maxlshsql := v_maxlshsql||' and substr(t2.yjbyrq, 0, 4) = t1.bynf';
     elsif in_sfbynf = '0' then
         v_sql := v_sql||' and substr(t2.yjbyrq, 0, 4) != t1.bynf';
         v_cntsql := v_cntsql||' and substr(t2.yjbyrq, 0, 4) != t1.bynf';
         v_maxlshsql := v_maxlshsql||' and substr(t2.yjbyrq, 0, 4) != t1.bynf';
     end if;
  end if;


  --未编号的按学号排序
  v_sql:=v_sql||' order by t1.xh_id';
  --查询是否存在数据
  execute immediate v_cntsql into v_count;
  if v_count = 0 then
    out_flag := -5;
    out_msg  := '未查询到符合条件的信息！';
    goto nextOne;
  end if;
  execute immediate v_maxlshsql into v_count;

  open v_byxx_cursor for v_sql;
  loop
    fetch v_byxx_cursor
      into v_byxx;
    exit when v_byxx_cursor%notfound;
    v_bh := ''; --每次循环重置
    open v_gz_cursor for
      select a.qsw, a.ws, a.xh, a.clz, a.zdm, b.sfyqsw, b.wsbl
        from jw_bygl_zshgzxxb a, jw_bygl_zshgzjcdmb b
       where a.zdm = b.zdm
         and a.gzlx = b.gzlx
         and b.sfqy = '1'
         and a.gzlx = in_zslx
       order by to_number(a.xh);
    loop
      fetch v_gz_cursor
        into v_gz;
      --判断当前游标是否到达最后
      exit when v_gz_cursor%notfound;

      if v_gz.sfyqsw = '0' then
        --常量
        v_bh := v_bh || v_gz.clz;
      elsif v_gz.sfyqsw = '1' and v_gz.wsbl is not null then
        --流水号 由于上面已经将最大流水号写入，此处不需要再赋值
       -- v_count := 0;
       --如果有起始位且之前没有流水号，则从起始位开始，否则从最大流水号开始
        if v_gz.qsw is not null and v_count = 0 then
          v_count := to_number(v_gz.qsw);
        end if;
        --count+1
        v_count := v_count + 1;
        --此处由于起始位变成了起始数的概念，代码注释掉不用
        --if length(v_count) > to_number(v_gz.ws) then
          --out_flag := -5;
          --out_msg  := '证书号规则流水号位数设置小于待处理数据';
          --goto nextOne;
       -- end if;
        if v_gz.wsbl = '1' then
          select lpad(v_count, v_gz.ws, 0) into v_tmp from dual;
        else
          v_tmp := to_char(v_count);
        end if;
        v_bh := v_bh || v_tmp;
      elsif v_gz.sfyqsw = '1' and v_gz.wsbl is null then
        --其他设置项
        if v_gz.zdm = 'XXDM' then
          --学校代码
          if v_gz.qsw is not null and v_gz.ws is not null then
            select substr(XXDM, v_gz.qsw, v_gz.ws)
              INTO v_tmp
              from zftal_xtgl_xxxxszb;
          else
            select XXDM INTO v_tmp from zftal_xtgl_xxxxszb;
          end if;
          v_bh := v_bh || v_tmp;
        end if;
        if v_gz.zdm = 'XZ' then
          --学制
          select substr(v_byxx.xz,v_gz.qsw,v_gz.ws) into v_tmp1 from dual;
          v_tmp := v_tmp1;
          v_bh  := v_bh || v_tmp;
        end if;
        if v_gz.zdm = 'BYNF' then
        --毕业年份
        select substr(v_byxx.bynf,v_gz.qsw,v_gz.ws) into v_tmp1 from dual;

          v_tmp := v_tmp1;
          v_bh  := v_bh || v_tmp;
        end if;
        if v_gz.zdm = 'XWWYHKHRQ' then
         --学位委员会开会日期
          select substr(v_byxx.xwwyhkhrq,v_gz.qsw,v_gz.ws) into v_tmp1 from dual;
          v_tmp := v_tmp1;
          v_bh  := v_bh || v_tmp;
        end if;

      end if;
    end loop;
    --关闭规则游标
    close v_gz_cursor;
    --判断生成好的序号是否有重复
    v_sql :='select count(1) from jw_bygl_bysfzxxb' ;
    if in_zslx = '1' then
      v_sql := v_sql ||' where xwzsh = ' || chr(39) || v_bh || chr(39);
    end if;
    if in_zslx = '2' then
      v_sql := v_sql ||' where byzsh = ' || chr(39) || v_bh || chr(39);
    end if;
    if in_zslx = '3' then
      v_sql := v_sql ||' where fxbyzsh = ' || chr(39) || v_bh || chr(39);
    end if;
    if in_zslx = '4' then
      v_sql := v_sql ||' where exwbyzsh = ' || chr(39) || v_bh || chr(39);
    end if;

    execute immediate v_sql into v_tmp;
    if v_tmp != 0 then
       out_flag := -4;
       out_msg  := '该规则下生成编号发生重复数据，生成失败';
       goto nextOne;
    end if;

    --更新流水号和证书号
    v_sql := 'update jw_bygl_bysfzxxb ';
    if in_zslx = '1' then
      v_sql := v_sql ||' set xwzsh = ' || chr(39) || v_bh || chr(39);
      v_sql := v_sql ||' , xwlsh = ' || chr(39) || v_count || chr(39);
    end if;
    if in_zslx = '2' then
      v_sql := v_sql ||' set byzsh = ' || chr(39) || v_bh || chr(39);
      v_sql := v_sql ||' , bylsh = ' || chr(39) || v_count || chr(39);
    end if;
    if in_zslx = '3' then
      v_sql := v_sql ||' set fxbyzsh = ' || chr(39) || v_bh || chr(39);
      v_sql := v_sql ||' , fxlsh = ' || chr(39) || v_count || chr(39);
    end if;
    if in_zslx = '4' then
      v_sql := v_sql ||' set exwbyzsh = ' || chr(39) || v_bh || chr(39);
      v_sql := v_sql ||' , exwlsh = ' || chr(39) || v_count || chr(39);
    end if;
    v_sql := v_sql ||' where xh_id = ' || chr(39) || v_byxx.xh_id || chr(39);
    v_sql := v_sql ||' and bynf = ' || chr(39) || v_byxx.bynf || chr(39);

    execute immediate v_sql;
  end loop;
  close v_byxx_cursor; --关闭毕业规则游标
  out_flag := '0'; --执行结束
  out_msg  := '执行结束';
  <<nextOne>>

  if out_flag = '-4' then
    rollback;
  else
    commit;
  end if;
end;

/

