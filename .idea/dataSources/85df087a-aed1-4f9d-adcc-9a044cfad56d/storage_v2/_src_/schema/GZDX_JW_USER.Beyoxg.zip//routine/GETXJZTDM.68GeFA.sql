create function getXjztdm(in_xh_id in varchar2) return varchar2
as
    v_xxdm varchar2(10);
    v_xndm varchar2(400);
    v_xqdm varchar2(400);
    v_xjztdm varchar2(2);
    v_sfby varchar(2);
    v_result varchar2(2);
   begin
      v_result:='';
       select zdz into v_xndm from zftal_xtgl_xtszb where zdm ='DQXNM';
       select zdz into v_xqdm from zftal_xtgl_xtszb where zdm ='DQXQM';
       select xxdm into v_xxdm from zftal_xtgl_xxxxszb;
       select xjztdm into v_xjztdm from jw_xjgl_xsjbxxb where xh_id=in_xh_id;
       select xxsh into v_sfby from jw_bygl_byshb t where xh_id=in_xh_id;

      if v_sfby='1' then
        if v_xxdm = '10248' then
          if v_xjztdm='12' then
            v_result:='13';
          elsif v_xjztdm='25' then
            v_result:='14';
          else
             v_result:='11';
          end if;
         end if;
       end if;
       if v_sfby='2' then
          if v_xxdm = '10248' then
          if v_xjztdm='25' then
            v_result:='56';
          else
             v_result:='12';
          end if;
         end if;
        end if;
       if v_sfby is null or v_sfby='' then
        v_result:=v_xjztdm;
        end if;
    return v_result;
 end getXjztdm;
/

