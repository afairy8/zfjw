create function fn_decrypt_des(p_text varchar2) return varchar2 is
v_text varchar2(2000);
v_key varchar2(128);
v_sfjm varchar2(10);
begin
 begin
  if p_text is null then
    return '';
  end if;
	select zdz into v_key from jw_jcdml_xtnzb where zdm='ZJHMMY';
	select zdz into v_sfjm from jw_jcdml_xtnzb where zdm='ZJHMSFJJM';
	if v_sfjm='1' then
	dbms_obfuscation_toolkit.DESDECRYPT(input_string => UTL_RAW.CAST_TO_varchar2(p_text),key_string =>v_key, decrypted_string=> v_text);
	v_text := rtrim(v_text,chr(0));
	else
	v_text :=p_text;
	end if;
	dbms_output.put_line(v_text);
  return v_text;
exception
 When others then
 return p_text;
end;
end;

/

