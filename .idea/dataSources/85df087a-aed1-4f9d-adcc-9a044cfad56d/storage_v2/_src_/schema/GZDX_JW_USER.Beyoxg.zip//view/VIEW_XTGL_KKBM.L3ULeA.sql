create view VIEW_XTGL_KKBM as
  select t.jg_id as kkbm_id,
       t.lssjjgid,
       t.jgdm as kkbmdm,
       t.jgmc as kkbmmc,
       t.jgywmc as kkbmywmc,
       t.jgjc   as kkbmjc,
       t.jgjp   as kkbmjp,
       t.jgdz   as kkbmjz,
       t.lsxqid,
       t.sfjxbm,
       t.sfst,
       t.kkxy
  from zftal_xtgl_jgdmb t
 where t.jgyxbs = '1'
   and t.sfjxbm = '1'
   and bitand(t.kkxy,1) > 0
   and t.lssjjgid is not null
union
select t.jg_id as kkbm_id,
       t.jg_id as lssjjgid,
       t.jgdm as kkbmdm,
       t.jgmc as kkbmmc,
       t.jgywmc as kkbmywmc,
       t.jgjc   as kkbmjc,
       t.jgjp   as kkbmjp,
       t.jgdz   as kkbmjz,
       t.lsxqid,
       t.sfjxbm,
       t.sfst,
       t.kkxy
  from zftal_xtgl_jgdmb t
 where t.jgyxbs = '1'
   and t.lssjjgid is null
   and t.sfjxbm = '1'
   and bitand(t.kkxy,1) > 0
/

