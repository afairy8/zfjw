create procedure p_xk_choose_zykc_zjgsdx
(
  in_ids in varchar2,
  in_xh_id in varchar2,
  in_njdm_id in varchar2,
  in_cxbj in varchar2,
  in_xxkbj in varchar2,
  in_kch_id in varchar2,
  in_xkkz_id in varchar2,
  in_qz in varchar2,
  in_sxbj in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
    sqlStr varchar2(2000);
    v_xkxnm varchar2(5);
    v_xkxqm varchar2(2);
    v_count number;
    v_rwlx varchar2(1);
    v_zdzys number;
    v_sfzyxk varchar2(1);
    v_fxbj varchar2(1);
    v_bklx_id varchar2(32);
    v_xzjxbCount number;
    v_sfkzyxk varchar2(1);
    v_kklxdm varchar2(5);
    v_kch_id varchar2(32);
    t_kch_id varchar2(32);
    v_rlzlkz varchar2(1);
    v_jdlx varchar2(1);
    v_xklc number;
    v_xf number;
    v_jfdj number;
    v_kcmc varchar2(60);
    v_zyh_id varchar2(32);
    v_xnm varchar2(5);
    v_xqm varchar2(2);
    v_sfkxk varchar2(1);
    v_pjkz varchar2(1);
    v_jfkz varchar2(1);
    v_gz_sfzx varchar2(1);
    v_xs_sfzx varchar2(1);
    v_bdzcbj varchar2(2);
    v_zckz varchar2(1);
    v_ztbj varchar2(1);
    v_temp varchar2(32);
    v_cxbj varchar2(1) default '0';
    jxb_id_array mytype;
begin
    out_flag := '1';
    v_fxbj := '0';
    v_bklx_id := '0';
    jxb_id_array := my_split(in_ids,',');
    --v_kch_id := in_kch_id;

    --判断当前是否在选课时间内
    select count(*) into v_count from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if v_count='0' then
        out_flag := '0';--不在选课时间内
        out_msg := '选课时间已过，不可再选！';
        goto nextOne; --跳出循环
    end if;

    select count(*) into v_count from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and fjxb_id=jxb_id_array(1);
    if v_count>0 and jxb_id_array.count=1 then
        out_flag := '0';--只有父教学班，没有子教学班的参数
        out_msg := '请刷新页面重新选择！';
        goto nextOne; --跳出循环
    end if;

  --查找可能要用到的选课规则设置项
    select
        a.xnm,a.xqm,a.kklxdm,a.xklc,b.sfzyxk,nvl(b.zdzys,1),b.rlzlkz,
        nvl(b.sfkxk,'0'),nvl(pjkz,'0'),nvl(jfkz,'0'),nvl(sfzx,'0'),nvl(zckz,'0')
        into
        v_xkxnm,v_xkxqm,v_kklxdm,v_xklc,v_sfzyxk,v_zdzys,v_rlzlkz,v_sfkxk,v_pjkz,v_jfkz,v_gz_sfzx,v_zckz
    from JW_XK_XKKZB a,JW_XK_XKKZXMB b where a.xkkz_id=b.xkkz_id and a.xkkz_id=in_xkkz_id;

    --判断该课程学生是否已选过
    select count(*) into v_count from jw_xk_xsxkb a where a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xh_id=in_xh_id and a.jxb_id=jxb_id_array(1);
    if v_count='1' then
        out_flag := '1';--该教学班该学生已选过
        goto nextOne; --跳出循环
    end if;

    if v_sfkxk='0' then
        out_flag:='0';
        out_msg:='对不起，当前未开放选课！';
        goto nextOne;
    end if;

    if v_pjkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDPJXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDPJXQM';
        select max(nvl(ztbj,'0')) into v_ztbj from jw_pj_xspjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id;
        if nvl(v_ztbj,'w')='w' then --不存在状态记录
            if fn_xspjztbj(v_xnm,v_xqm,in_xh_id)='0' then
                out_flag:='0';
                out_msg := '未完成评价，不可选课！';
                goto nextOne; --跳出循环
            end if;
        else
            if v_ztbj!='1' then
                out_flag:='0';
                out_msg := '未完成评价，不可选课！';
                goto nextOne; --跳出循环
            end if;
        end if;
    end if;

    if v_jfkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDJFXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDJFXQM';
        select count(*) into v_count from jw_xjgl_xsxqjfztb where xh_id=in_xh_id and xnm=v_xnm and decode(xqm,'0',v_xqm,xqm)=v_xqm and jfzt='1';
        if v_count=0 then
            out_flag:='0';
            out_msg := '未缴费，不可选课！';
            goto nextOne; --跳出循环
        end if;
    end if;

    if v_gz_sfzx='1' or v_zckz='1' then
      select nvl(sfzx,'0'),nvl(bdzcbj,'0') into v_xs_sfzx,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
      if v_gz_sfzx='1' and v_xs_sfzx='0' then
            out_flag:='0';
            out_msg:='对不起，您当前学籍状态为不在校，不可选此类课程！';
            goto nextOne;
        end if;
        if v_zckz='1' and v_bdzcbj not in ('2','3') then
            out_flag:='0';
            out_msg:='对不起，您的学籍处于未注册状态，不可选此类课程！';
            goto nextOne;
        end if;
    end if;

    select kch_id into v_kch_id from jw_jxrw_jxbxxb where jxb_id=jxb_id_array(1);
    t_kch_id:=v_kch_id;
    if v_kklxdm not in ('05','07') then --体育分项、英语分项等课程重复修读不算重修
        select count(*) into v_cxbj from jw_xk_xsxkb where xh_id=in_xh_id and kch_id=v_kch_id and nvl(kklxdm,'00') not in ('05','07') and xnm||lpad(xqm,2,'0')<v_xkxnm||lpad(v_xkxqm,2,'0') and rownum=1;
    end if;

    select t.rwlx,t.jdlx into v_rwlx,v_jdlx from jw_jcdm_kklxdmb t where t.kklxdm=v_kklxdm;
    if v_jdlx='1' then
        v_kch_id := v_kklxdm;
    end if;

    if v_kklxdm='04' then
        v_fxbj := '1';
    elsif v_kklxdm='02' then
        v_fxbj := '2';
    elsif v_kklxdm='03' then
        v_fxbj := '3';
    end if;

    --最大志愿数判断
    if v_sfzyxk='1' then
        select count(*) into v_count from jw_jxrw_jxbxxb a,jw_xk_xsxkb b,jw_jh_kcdmb c
                                        where a.jxb_id=b.jxb_id
                                        and a.kch_id=c.kch_id
                                        and a.fjxb_id is null
                                        and a.xnm=v_xkxnm
                                        and a.xqm=v_xkxqm
                                        and b.xnm=v_xkxnm
                                        and b.xqm=v_xkxqm
                                        and (case when v_jdlx='1' then a.kklxdm else a.kch_id end)=v_kch_id
                                        and b.xh_id=in_xh_id;
        if v_count >= v_zdzys then
            out_flag := '0';
            out_msg := '超过最大志愿数限制，不可再选！';
            goto nextOne; --跳出循环
        end if;
    end if;
  --判断是否允许通过课程修读(不允许时，除了修读课程合格的不允许之外，在修还未出成绩的也不允许)
    --select count(*) into v_count from jw_cj_xscjb where xh_id=in_xh_id and kch_id=in_kch_id and bfzcj>=60;
    --if v_sfrxtgkcxd='0' then
    --if v_count>0 then
      --out_flag := '0';
      --out_msg := '该课程已修读合格，不可再选！';
      --goto nextOne; --跳出循环
    --else
      --select count(*) into v_count from jw_xk_xsxkb t1 where t1.xh_id=in_xh_id and t1.kch_id=in_kch_id and xnm||xqm!=v_xkxnm||v_xkxqm and not exists(select 1 from jw_cj_xscjb t2 where t2.jxb_id=t1.jxb_id and t2.xh_id=t1.xh_id);
      --if v_count>0 then
        --out_flag := '0';
        --out_msg := '该课程已在修读，不可再选！';
        --goto nextOne; --跳出循环
      --end if;
    --end if;
    --elsif v_count>=v_tykczgxdcs then
        --out_flag := '0';
    --out_msg := '该课程修读次数已不少于'||v_tykczgxdcs||'次，不可再选！';
    --goto nextOne; --跳出循环
    --end if;

    if in_xxkbj='1' then
        select nvl((select sfkzyxk from jw_xk_qtxkgzb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id='tongyi'),'0') into v_sfkzyxk from dual;
        if v_sfkzyxk='1' then --判断先行课（预修课）控制是否设置为控制
            select count(b.jxb_id) into v_count from jw_jh_kcyxyqb a,jw_xk_xsxkb b where a.yxkch_id=b.kch_id and b.xnm||b.xqm!=v_xkxnm||v_xkxqm and b.xh_id=in_xh_id and a.kch_id=t_kch_id;
            if v_count=0 then
                out_flag := '0';
                out_msg :='该课程的先行课未修，不可选！';
                goto nextOne; --跳出检验
            end if;
        end if;
    end if;

    --判断学生是否已选体育课
    /*if v_kklxdm='05' then
        select count(*) into v_count from jw_xk_xsxkb a,view_xk_tykdzb b where a.kch_id=b.kch_id and a.kch_id != v_kch_id and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xh_id=in_xh_id;
        if v_count > 0 then
            out_flag := '0';
            out_msg :='您已选过体育课，不可再选！';
            goto nextOne; --跳出循环
        end if;
    end if;*/

    --板块课同一个课组只能选一门课程
    if v_kklxdm='06' then
        --该课程是否为某课组内课程
        --select nvl((select bklx_id from view_xk_bkkkzb a where xnm=v_xkxnm and xqm=v_xkxqm and kch_id=v_kch_id and njdm_id=in_njdm_id and exists (select 1 from jw_xjgl_xsbklxcjb b where a.bklx_id=b.bklx_id and b.xh_id=in_xh_id)),'0') into v_bklx_id from dual;
        select nvl(bklx_id,'0') into v_bklx_id from JW_XK_XKKZB where xkkz_id=in_xkkz_id;
        if v_bklx_id != '0' then
            select count(*) into v_count from jw_xk_xsxkb a,view_xk_bkkkzb b where a.kch_id=b.kch_id and a.kch_id != v_kch_id and a.xnm=b.xnm and a.xqm=b.xqm and b.njdm_id=in_njdm_id and a.xnm=v_xkxnm and a.xqm=v_xkxqm and a.xh_id=in_xh_id and b.bklx_id=v_bklx_id;
            if v_count > 0 then
                out_flag := '0';
                out_msg :='您已选过该课程所在课组的其他课程，不可再选！';
                goto nextOne; --跳出循环
            end if;
        end if;
    end if;

    --sqlStr := 'select count(*) from (select c.kch_id, c.jxbmc, b.* from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jxrw_jxbxxb c,jw_jh_kcdmb d where a.jxb_id=b.jxb_id and a.jxb_id=c.jxb_id and c.kch_id=d.kch_id and (case when c.kklxdm in (''10'',''15'') then c.kklxdm else nvl(d.sskch_id,c.kch_id) end) != '''||v_kch_id||''' and a.xh_id='''||in_xh_id||''' and b.xnm='''||v_xkxnm||''' and b.xqm='''||v_xkxqm||''' and a.xnm='''||v_xkxnm||''' and a.xqm='''||v_xkxqm||''' ) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where xnm='''||v_xkxnm||''' and xqm='''||v_xkxqm||''' and jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
    if v_jdlx='1' and v_rlzlkz != '1' then  --这里为什么这样写？？？？？？？？？？？？？？？？？？？？？？？
        --当前选的教学班与其他开课类型的课程之间的上课时间冲突
        sqlStr := 'select count(*) from (select c.kch_id, c.jxbmc, b.* from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jxrw_jxbxxb c where a.jxb_id=b.jxb_id and a.jxb_id=c.jxb_id and c.kklxdm != '''||v_kklxdm||''' and a.xh_id='''||in_xh_id||''' and b.xnm='''||v_xkxnm||''' and b.xqm='''||v_xkxqm||'''  and a.xnm='''||v_xkxnm||''' and a.xqm='''||v_xkxqm||''' ) t1, (select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where xnm='''||v_xkxnm||''' and xqm='''||v_xkxqm||''' and jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
    else
        --当前选的教学班与其他课程的上课时间冲突
        sqlStr := 'select count(*) from (select c.kch_id, c.jxbmc, b.* from jw_xk_xsxkb a, jw_pk_kbsjb b, jw_jxrw_jxbxxb c,jw_jh_kcdmb d where a.jxb_id=b.jxb_id and a.jxb_id=c.jxb_id and c.kch_id=d.kch_id and nvl(d.sskch_id,c.kch_id) != '''||v_kch_id||''' and a.xh_id='''||in_xh_id||''' and b.xnm='''||v_xkxnm||''' and b.xqm='''||v_xkxqm||''' and a.xnm='''||v_xkxnm||''' and a.xqm='''||v_xkxqm||''' ) t1,(select jxb_id, xqj, zcd, jc from jw_pk_kbsjb where xnm='''||v_xkxnm||''' and xqm='''||v_xkxqm||''' and jxb_id in ('''||replace(in_ids,',',''',''')||''')) t2 where t1.xqj=t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0';
    end if;

    Execute Immediate sqlStr into v_count;--满足约束条件的记录个数
    if v_count > 0 then
        out_flag := '0';
        out_msg := '所选教学班的上课时间与其他教学班有冲突！';
        goto nextOne; --跳出循环
    end if;

    select count(*) into v_count from zftal_xtgl_xtszb where zdm='PKFS' and zdz='1';
    if v_count > 0 then--先排考后选课，需判断考试冲突
        sqlStr := 'select count(*) from (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_xk_xsxkb xk, jw_pk_kbsjb kb where kb.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||v_xkxnm||''' and xk.xqm='''||v_xkxqm||''') yxsk,
        (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
        from jw_pk_xlb t4,jw_pk_rcmxb t5,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
        where t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq and t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
        where yxsk.xqj=dxks.xqj and bitand(yxsk.zcd, dxks.zcd) > 0 and bitand(yxsk.jc, dxks.jc) > 0';
        Execute Immediate sqlStr into v_count;--考试与上课冲突个数
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的考试时间与其他教学班上课时间有冲突！';
            goto nextOne; --跳出循环
        end if;

        sqlStr := 'select count(*) from(select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
        where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||v_xkxnm||''' and xk.xqm='''||v_xkxqm||''') yxks,
        (select t1.jxb_id,t3.ksrq,t3.kskssj,t3.ksjssj from jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3
        where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t1.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxks
        where yxks.ksrq=dxks.ksrq and yxks.ksjssj >= dxks.kskssj and yxks.kskssj <= dxks.ksjssj';
        Execute Immediate sqlStr into v_count;--考试与考试冲突个数
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的考试时间与其他教学班考试时间有冲突！';
            goto nextOne; --跳出循环
        end if;

        sqlStr := 'select count(*) from (select power(2,t5.dxqzc-1) zcd,t5.xqj xqj,(select sum(rjc.jcm) from jw_pk_rsdszb rsd,jw_pk_rjcszb rjc where rsd.rsdsz_id=rjc.rsdsz_id and rsd.xnm=t1.xnm and rsd.xqm=t1.xqm and substr(rjc.jssj,1,5) >= t3.kskssj and substr(rjc.qssj,1,5) <= t3.ksjssj and rsd.xqh_id=(select jxb.xqh_id from jw_jxrw_jxbxxb jxb where jxb.jxb_id=t1.jxb_id)) jc
        from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb t1,jw_kw_kssjb t2,jw_kw_ksccb t3,jw_pk_xlb t4,jw_pk_rcmxb t5 where t1.ksmcdmb_id=t2.ksmcdmb_id and t1.sjbh_id=t2.sjbh_id and t2.ksccb_id=t3.ksccb_id and t4.xl_id=t5.xl_id and t4.xnm=t1.xnm and t5.dxqm=t1.xqm and t5.rq=t3.ksrq and t1.jxb_id=xk.jxb_id and xk.kch_id != '''||in_kch_id||''' and xk.xh_id='''||in_xh_id||''' and xk.xnm='''||v_xkxnm||''' and xk.xqm='''||v_xkxqm||''') yxks,
        (select kb.jxb_id,kb.xqj,kb.zcd,kb.jc from jw_pk_kbsjb kb where kb.jxb_id in ('''||replace(in_ids,', ',''', ''')||''')) dxsk where yxks.xqj=dxsk.xqj and bitand(yxks.zcd, dxsk.zcd) > 0 and bitand(yxks.jc, dxsk.jc) > 0';
        Execute Immediate sqlStr into v_count;--上课与考试冲突个数
        if v_count > 0 then
            out_flag := '0';
            out_msg := '所选教学班的上课时间与其他教学班考试时间有冲突！';
            goto nextOne; --跳出循环
        end if;
    end if;


    if in_qz='0' then
        select count(*)+1 into v_xzjxbCount from JW_XK_XSXKB t where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and zy>0
             and exists (select 1 from jw_jxrw_jxbxxb t1,jw_jh_kcdmb t2 where t.jxb_id=t1.jxb_id and t1.kch_id=t2.kch_id
                              and (case when v_jdlx='1' then t1.kklxdm else t2.kch_id end)=v_kch_id
                              and t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.fjxb_id is null);
    else
        v_xzjxbCount := 0;
    end if;

    if nvl(v_rlzlkz,'0')='1' then
        select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=jxb_id_array(1) and xh_id=in_xh_id;
        if v_count=0 then
            --xkbj=10(学生自选)，20(配课生成)，30(管理员调课生成)
            insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id)
            select
                jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,v_cxbj,v_xkxnm,v_xkxqm,kch_id,v_bklx_id
            from jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=in_kch_id and ','||in_ids||',' like '%,'||t1.jxb_id||',%'
                and (
                    select
                        count(*)
                    from
                        jw_jxrw_jxbxxb t2
                    where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.kch_id=in_kch_id and ','||in_ids||',' like '%,'||t2.jxb_id||',%'
                        and (t2.jxbrs+nvl(t2.krrl,0))<=(select count(*) from jw_xk_xsxkb t3 where t2.jxb_id=t3.jxb_id and t3.xnm=v_xkxnm and t3.xqm=v_xkxqm and nvl(zxbj,'0')!='1')
                )=0;
        end if;
    else
        select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=jxb_id_array(1) and xh_id=in_xh_id;
        if v_count=0 then
            --xkbj=10(学生自选)，20(配课生成)，30(管理员调课生成)
            insert into JW_XK_XSXKB(jxb_id,xh_id,xklc,xksj,jgh_id,zy,qz,sxbj,xkbj,fxbj,cxbj,xnm,xqm,kch_id,bklx_id)
            select
                jxb_id,in_xh_id,v_xklc,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),in_xh_id,v_xzjxbCount,in_qz,in_sxbj,'10',v_fxbj,v_cxbj,v_xkxnm,v_xkxqm,kch_id,v_bklx_id
            from jw_jxrw_jxbxxb t1
            where
                t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=in_kch_id and ','||in_ids||',' like '%,'||t1.jxb_id||',%';
        end if;
    end if;

    select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and jxb_id=jxb_id_array(1);
    --选课成功
    if v_count>0 then
        update jw_jxrw_jxbxxb set yxzrs=yxzrs+1 where xnm=v_xkxnm and xqm=v_xkxqm and kch_id=in_kch_id and ','||in_ids||',' like '%,'||jxb_id||',%';
        select count(*) into v_count from jw_jcdml_xtnzb where zdm='FXEZYXKBM' and zdz='1';
        if v_count>0 then
            select count(*) into v_count from zftal_xtgl_zfywsjb where ywsjb_id=v_xkxnm||lpad(v_xkxqm,2,'0')||in_kch_id||in_xh_id;
            if v_count=0 then
                if v_kklxdm in ('02','03','04') then
                  select zyh_id into v_zyh_id from (select c.njdm_id,c.zyh_id from jw_fx_fxezybmb a,jw_fx_fxezybmkzb b,jw_jh_jxzxjhxxb c where a.fxezybmkz_id=b.fxezybmkz_id and b.jxzxjhxx_id=c.jxzxjhxx_id and b.bmlbdm=decode(v_kklxdm,'02','02','03','03','04','01','00') and a.xh_id=in_xh_id and a.zzshjg= '3' order by a.zzshsj desc) where rownum=1;
                else
                    select zyh_id into v_zyh_id from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
                end if;
                select nvl(t1.xf,0),kcmc into v_xf,v_kcmc from jw_jh_kcdmb t1 where t1.kch_id=in_kch_id;
                if v_cxbj='1' then
                  v_jfdj := fn_cx_jfdj(in_njdm_id,v_zyh_id,in_kch_id,jxb_id_array(1),in_xh_id,'2');
                    insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name,order_id)
                    values('05','jw_xk_xsxkb',v_xkxnm||lpad(v_xkxqm,2,'0')||in_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc,'ZZJF'||to_char(sysdate,'yyyyMMddHHmmss')||trunc(dbms_random.value(1000,9999)));
                else
                  if v_kklxdm in ('02','03','04') then
                  v_jfdj := fn_cx_jfdj(in_njdm_id,v_zyh_id,in_kch_id,jxb_id_array(1),in_xh_id,'1');
                    insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name,order_id)
                    values('09','jw_xk_xsxkb',v_xkxnm||lpad(v_xkxqm,2,'0')||in_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc,'ZZJF'||to_char(sysdate,'yyyyMMddHHmmss')||trunc(dbms_random.value(1000,9999)));
                  end if;
                end if;
            end if;
        end if;
    else
        out_flag := '-1';
    end if;

    <<nextOne>>

    if out_flag='-1' then
        rollback;
        update jw_jxrw_jxbxxb t1 set yxzrs=(
            select count(xh_id) from jw_xk_xsxkb t2 where t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.jxb_id=t1.jxb_id and nvl(zxbj,'0')!='1'
        )
        where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=in_kch_id and ','||in_ids||',' like '%,'||t1.jxb_id||',%';
        commit;

        select (case when fjxb_id is null then '0' else '1' end)||','||jxb_id||','||yxzrs into out_msg
        from jw_jxrw_jxbxxb t1
        where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.kch_id=in_kch_id and ','||in_ids||',' like '%,'||t1.jxb_id||',%'
            and (t1.jxbrs+nvl(t1.krrl,0))<=t1.yxzrs and rownum=1;
    else
        commit;
    end if;
end;

/

