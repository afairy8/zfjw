create function fn_mxdx_zrzc(
    in_xkxnm varchar2,
    in_xkxqm varchar2,
    in_xh_id varchar2,
    in_xkkz_id varchar2
) return varchar2 as
    out_mxxz varchar2(1) default '1';--面向
    v_count number;
    v_jg_id varchar2(32);
    v_njdm_id varchar2(32);
    v_zyh_id varchar2(32);
    v_bh_id varchar2(32);
    v_zyfx_id varchar2(32);
    v_xbm varchar2(32);
    v_xslbdm varchar2(32);
    v_pyccdm varchar2(32);
    v_xsbj varchar2(32);
    v_xqh_id varchar2(32);
begin
    select count(*) into v_count from jw_xk_zrzcmxb where zrzcbmszb_id=in_xkkz_id;
    if v_count=0 then
        out_mxxz:='1'; --没有面向对象时，即面向所有学生
    else
        select nvl(xbm,'w'),nvl(xsbj,'4294967296') into v_xbm,v_xsbj from jw_xjgl_xsjbxxb where xh_id=in_xh_id;
        select nvl(jg_id,'w'),nvl(njdm_id,'w'),nvl(zyh_id,'w'),nvl(bh_id,'w'),nvl(zyfx_id,'w'),nvl(xslbdm,'w'),nvl(pyccdm,'w') into v_jg_id,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,v_xslbdm,v_pyccdm from jw_xjgl_xsxjxxb where xnm=in_xkxnm and xqm=in_xkxqm and xh_id=in_xh_id;
        select nvl(xqh_id,'w') into v_xqh_id from zftal_xtgl_bjdmb where bh_id=v_bh_id;
        select count(*) into v_count from jw_xk_zrzcmxb
        where nvl(xqh_id,v_xqh_id)=v_xqh_id
          and nvl(jg_id,v_jg_id)=v_jg_id
          and nvl(zyh_id,v_zyh_id)=v_zyh_id
          and nvl(bh_id,v_bh_id)=v_bh_id
          and nvl(xh_id,in_xh_id)=in_xh_id
          and nvl(xbm,v_xbm)=v_xbm
          and nvl(xslbm,v_xslbdm)=v_xslbdm
          and nvl(ccdm,v_pyccdm)=v_pyccdm
          and bitand(nvl(xsbj,v_xsbj),v_xsbj)>0
          and zrzcbmszb_id=in_xkkz_id and xzlb='xz';
        if v_count>0 then
            out_mxxz:='0'; --当前学生在被限制范围内=限制
        else
            select count(*) into v_count from jw_xk_zrzcmxb
            where nvl(xqh_id,v_xqh_id)=v_xqh_id
              and nvl(jg_id,v_jg_id)=v_jg_id
              and nvl(zyh_id,v_zyh_id)=v_zyh_id
              and nvl(bh_id,v_bh_id)=v_bh_id
              and nvl(xh_id,in_xh_id)=in_xh_id
              and nvl(xbm,v_xbm)=v_xbm
              and nvl(xslbm,v_xslbdm)=v_xslbdm
              and nvl(ccdm,v_pyccdm)=v_pyccdm
              and bitand(nvl(xsbj,v_xsbj),v_xsbj)>0
              and zrzcbmszb_id=in_xkkz_id and xzlb='mx';
            if v_count>0 then
                out_mxxz:='1'; --当前学生在被面向范围内=面向
            else
                select count(*) into v_count from jw_xk_zrzcmxb where zrzcbmszb_id=in_xkkz_id and xzlb='mx';
            if v_count=0 then
                    out_mxxz:='1'; --学生不在被限制范围内，且不存在面向范围时=面向
                else
                    out_mxxz:='0'; --学生不在被限制范围内，有面向范围且不在面向范围内=限制
                end if;
            end if;
        end if;
    end if;

    return out_mxxz;
end fn_mxdx_zrzc;
/

