create trigger TRI_UPDATE_JXBPFB_BZ
  before insert
  on JW_PJ_JXBPFB
  for each row
  begin
    if :new.jgh_id in (select jgh_id
                       from jw_pj_tkjsb t
                       where t.xnm = (select zdz
                                      from zftal_xtgl_xtszb
                                      where zs = '评价学年') and t.xqm = (select zdz
                                                                      from zftal_xtgl_xtszb
                                                                      where zs = '评价学期') and t.likai_ddsf like '%校督导%')
    then
      select '校督导#' || replace(replace(replace(:new.bz, '校督导', ''), '校级督导', ''),'校级督导听课','')
      into :new.bz
      from dual;
    end if;
  end;
/

