create FUNCTION likai_get_iszf(v_xh_id  IN varchar2,
                                          v_jxb_id in varchar2,
                                          v_cj     IN varchar2) RETURN INT IS
  v_count2 int;
BEGIN
  v_count2 := 0;
  select count(1)
    into v_count2
    from jw_cj_cjjglxsqb zfb
   where zfb.XH_ID = v_xh_id
     and zfb.JXB_ID = v_jxb_id and zfb.shzt='3';
     --and zfb.cj = v_cj;
  return v_count2;
end likai_get_iszf;
/

