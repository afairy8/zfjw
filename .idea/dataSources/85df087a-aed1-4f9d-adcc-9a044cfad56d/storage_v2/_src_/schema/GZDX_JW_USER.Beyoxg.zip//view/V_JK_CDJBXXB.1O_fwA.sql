create view V_JK_CDJBXXB as
  select CDBH,CDMC,CDJC,(SELECT V.XQMC FROM ZFTAL_XTGL_XQDMB V WHERE  V.XQH_ID=G.XQH_ID)XQMC ,
(SELECT C.CDLBMC FROM JW_JCDM_CDLBDMB C  WHERE C.CDLB_ID=G.CDLB_ID )LBMC,
(SELECT T.JXLMC FROM JW_JCDM_JXLDMB T WHERE T.JXLDM=G.LH )LH,G.LCH||'层'lch,G.ZWS,G.KSZWS1 ,
 case when bitand(cdkyzt,1) = 1 then '可用' else '不可用' end cdkyzt
 from jw_jcdm_cdxqxxb G where xnm in(select ZDZ from zftal_xtgl_xtszb where zdm='DQXNM' )
AND XQM In(select ZDZ from zftal_xtgl_xtszb where zdm='DQXQM' )
/

