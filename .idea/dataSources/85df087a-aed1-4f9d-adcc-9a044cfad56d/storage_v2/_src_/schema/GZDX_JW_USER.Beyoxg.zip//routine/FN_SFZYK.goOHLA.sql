create function fn_sfzyk(kcxzmc in varchar2,kclbmc in varchar2)
    ----华中师范-----专业课的取值范围为课程性质名称:专业必修课,专业选修课
    ----返回值:0-不是专业课,1-是专业课
     return varchar2 as
     result_flag varchar2(1);
    begin
       result_flag := '0';
       if trim(kcxzmc)='专业必修课' or trim(kcxzmc)='专业选修课' then
          result_flag := '1';
       end if;
       return result_flag ;
    end fn_sfzyk;


/

