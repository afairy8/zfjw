create view V_XSCJXX_JHKC as
  select
   xs.xh,
   xs.xm,
   xs.xh_id,
  (select xnmc from jw_jcdm_xnb where xnm = t.xnm) as xn,
  t.xnm,
  (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = t.xqm) as xq,
  t.xqm,
  t.cj,
  t.kch_id,
  t.kch,
  t.kcmc,
  t.kcywmc,
  to_char(t.xf) as xf,
  t.jxb_id,
  t.cjxzm,
  t.bfzcj,
  t.mbkcj,
  t.mbkbfzcj ,
  t.mcxcj,
  t.mcxbfzcj,
  t.maxcj,
  t.maxbfzcj,
  (SELECT kcxzmc from JW_JH_KCXZDMB WHERE kcxzdm=t.KCXZDM) kcxz,
  t.kcxzdm,
  (SELECT kclbmc from JW_JH_KClbDMB WHERE kclbdm=t.KClbDM) kclb,
  t.kclbdm,
  (SELECT kcgsmc from JW_JH_KCgsDMB WHERE kcgsdm=t.KCgsDM) kcgs,
  t.kcgsdm,
  t.maxjd,
  t.jd,
  t.mbkjd,
  t.mcxjd,
  decode(nvl(t.kcbj,'0'),'0','1') as fxbj,
  t.maxcjbj
from
(select 'cjb' as ly,t.xnm,t.xqm,t.jg_id,t.njdm_id,t.zyh_id,t.zyfx_id,t.bh_id,t.xh_id,t.xh,t.xm,t.xbm,
         t.kcxzdm,t.kclbdm,t.kcgsdm,t.sskch_id,t.kch_id,t.kch,t.kcmc,t.kcywmc,t.xf,t.jxb_id,t.kcbj,
         t.cj,t.bfzcj,t.cjbz,t.hkcj,
       fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,t.cjbz,t.jd,t.bfzcj,
               case when t.tdkcbj = '1' then 'cjb-dtkc' when t.btdkcbj = '1' then 'cjb-bdtkc' else 'cjb' end, 'tj','0') as jd,
       t.cjxzm,
       decode(GREATEST(nvl(t.mbkbfzcj,0),nvl(t.mbybfzcj,0)),nvl(t.mbkbfzcj,0),t.mbkcj,nvl(t.mbybfzcj,0),t.mbycj) as mbkcj,
       decode(GREATEST(nvl(t.mbkbfzcj,0),nvl(t.mbybfzcj,0)),nvl(t.mbkbfzcj,0),t.mbkbfzcj,nvl(t.mbybfzcj,0),t.mbybfzcj) as mbkbfzcj,
       decode(GREATEST(nvl(t.mbkbfzcj,0),nvl(t.mbybfzcj,0)),nvl(t.mbkbfzcj,0),t.mbkjd,nvl(t.mbybfzcj,0),t.mbyjd) as mbkjd,
       decode(GREATEST(nvl(t.mbkbfzcj,0),nvl(t.mbybfzcj,0)),nvl(t.mbkbfzcj,0),t.mbkcjbz,nvl(t.mbybfzcj,0),t.mbycjbz) as mbkcjbz,
       t.mbkcj as mbkcj1,mbkbfzcj as mbkbfzcj1, t.mbkjd as mbkjd1,t.mbkcjbz as mbkcjbz1,
       t.mbycj,t.mbybfzcj,t.mbyjd,t.mbycjbz,
       t.mcxcj,t.mcxbfzcj,t.mcxjd,t.mcxcjbz,
         t.bkcs,t.cxcs,t.cxcj1,t.cxbfzcj1,t.cxjd1,t.cxcj2,t.cxbfzcj2,t.cxjd2,
       decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj
                          ) as mzbcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)) as mzbbfzcj,
          fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ),
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
               case when t.tdkcbj = '1' then 'cjb-dtkc' when t.btdkcbj = '1' then 'cjb-bdtkc' else 'cjb' end, 'tj','0') as mzbjd,
      decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ) as mzbcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx'
                                             when cjxzm in ('21','22') then 'bybk'
                                             when cjbz = '缓考' or hkcj is not null then 'hk'
                                             else 'zk' end),
                          nvl(mbkbfzcj,0),'bk'
                          ) as mzbcjbj,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj,
                          nvl(mcxbfzcj,0),mcxcj,
                          nvl(mbybfzcj,0),mbycj
                          ) as maxcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)) as maxbfzcj,
        fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd,
                          nvl(mcxbfzcj,0),mcxjd,
                          nvl(mbybfzcj,0),mbyjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
               case when t.tdkcbj = '1' then 'cjb-dtkc' when t.btdkcbj = '1' then 'cjb-bdtkc' else 'cjb' end, 'tj','0') as maxjd,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ) as maxcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in ('16') then 'cx'
                                             when cjxzm in ('21','22')  then 'bybk'
                                             when cjbz = '缓考' or hkcj is not null then 'hk'
                                             else 'zk' end),
                          nvl(mbkbfzcj,0),'bk',
                          nvl(mcxbfzcj,0),'cx',
                          nvl(mbybfzcj,0),'bybk'
                          ) as maxcjbj,
    --替代课程标记begin
    t.tdkcbj,
    t.btdkcbj,
    --替代课程标记end--
   (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc from
   (select t1.xnm,t1.xqm, t1.kcxzdm,t1.xf,
   t1.jg_id,t1.njdm_id,t1.zyh_id,t1.zyfx_id,t1.bh_id,t1.xh_id,t1.xh,t1.xm,t1.xbm,
   t1.kclbdm,t1.kcgsdm,t1.sskch_id,t1.kch_id,t1.kch,t1.kcmc,t1.kcywmc, t1.jxb_id,t1.kcbj,t1.hkcj,
    --替代课程标记begin--
   (select count(1) from jw_cj_xsgrcjdtb cjdtb
                   where cjdtb.zszt = '3'
                     and t1.xh_id = cjdtb.xh_id
                     and t1.kch_id = cjdtb.kch_id
                     and cjdtb.kcthzbm = 'xnkc'
                     and rownum = 1) as tdkcbj,
     --替代课程标记end--
     --被被替代课程标记begin--
   (select count(1) from jw_cj_xsgrdtzb m,jw_cj_xsgrjhdtb n
           where m.kcthzh_id = n.kcthzh_id
             and m.kcthzbm = 'xnkc'
             and m.zszt = '3'
             and n.kch_id = t1.kch_id
             and n.xh_id = t1.xh_id
                     and rownum = 1) as btdkcbj,
    --被替代课程标记end--
    case when t1.cjxzm in ('16','21','22') then null
           else (case when t1.hkcj is null then nvl(t1.cj,t1.cjbz) else t1.hkcj end) end as cj,
    case when t1.cjxzm in ('16','21','22') then null
           else (case when t1.hkcj is null then t1.bfzcj else t1.hkbfzcj end) end as bfzcj,
    case when t1.cjxzm in ('16','21','22') then null
           else (case when t1.hkcj is null then t1.cjbz  else t1.hkbz end) end as cjbz,
    case when t1.cjxzm in ('16','21','22') then null
           else (case when t1.hkcj is null then t1.jd else t1.hkjd end) end as jd,
    t1.cjxzm,
    t1.bkcj as mbkcj,
    t1.bkbfzcj as mbkbfzcj,
    t1.bkbz as mbkcjbz,
    t1.bkjd as mbkjd,
    t2.mbycj as mbycj,
    t2.mbybfzcj as mbybfzcj,
    t2.mbyjd as mbyjd,
    t2.mbycjbz as mbycjbz,
    t3.mcxcj as mcxcj,
    t3.mcxbfzcj as mcxbfzcj,
    t3.mcxjd as mcxjd,
    t3.mcxcjbz as mcxcjbz,
    t1.bkcs,t3.cxcs,t3.cxcj1,t3.cxbfzcj1,t3.cxjd1,t3.cxcj2,t3.cxbfzcj2,t3.cxjd2 from
    (select XNM,XQM,njdm_id,jg_id,zyh_id,zyfx_id,bh_id,XH_ID,xh,xm,xbm,sskch_id,KCH_ID,KCH,KCMC,KCYWMC,XF,KCXZDM,KCLBDM,KCGSDM,JXB_ID,
           CJ,BFZCJ,CJBZ,JD,CJXZM,KCBJ,BZXX,bkcj,bkbfzcj,bkbz,bkjd,hkcj,hkbfzcj,hkbz,hkjd,bkcs from
     (select a.XNM,a.XQM,b.jg_id,b.njdm_id,b.zyh_id,nvl(b.zyfx_id,'wfx') zyfx_id,b.bh_id,a.XH_ID,b.xh,b.xm,b.xbm,
          a.sskch_id,a.KCH_ID,
          nvl(kc.kch,a.KCH) as kch,
          nvl(kc.kcmc,a.KCMC) as kcmc,
          nvl(kc.kcywmc,a.KCYWMC) as kcywmc,
          a.XF,a.KCXZDM,a.KCLBDM,a.KCGSDM,a.JXB_ID,
          a.CJ,a.BFZCJ,a.CJBZ,a.JD,a.CJXZM,a.KCBJ,a.BZXX,
          a.bkcj,a.bkbfzcj,a.bkbz,
          fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,'11',a.kcbj,null,a.bkbz,a.bkjd,a.bkbfzcj,'cjb', 'tj','0') as bkjd,
          a.hkcj,a.hkbfzcj,a.hkbz,a.hkjd,a.bkcs,
          row_number() over (partition by a.xh_id,case when length(a.sskch_id) =1 then a.sskch_id||'-'||a.kch_id else nvl(a.sskch_id,a.kch_id) end order by to_number(a.cjxzm),to_number(nvl(a.hkbfzcj,a.bfzcj)) desc,a.xnm,to_number(a.xqm)) rn
  from JW_CJ_XSCJB a,jw_xjgl_xsjbxxb b,jw_jh_kcdmb kc
    where a.xh_id = b.xh_id
      and a.cjxzm in ('01','16','21','22')
        and not exists(select 'X' from jw_cj_cjjglxsqb zfb
          where zfb.cjjglx='01' and zfb.shzt='3' and zfb.xh_id=a.xh_id
           -- and zfb.jxb_id = a.jxb_id
            and zfb.kch_id = a.kch_id )
        and (case when length(a.sskch_id)=1 or a.sskch_id is null then a.kch_id else a.sskch_id end)  = kc.kch_id(+)
       --不显示替代课程及被替代课程（参数需要控制）begin-->
        and not exists(select 'X' from jw_cj_xsgrjhdtb jhdtb
                                 where jhdtb.zszt = '3'
                                   and a.xh_id = jhdtb.xh_id
                                   and a.kch_id = jhdtb.kch_id
                       union all
                       select 'X' from jw_cj_xsgrcjdtb cjdtb
                                 where cjdtb.zszt = '3'
                                   and a.xh_id = cjdtb.xh_id
                                   and a.kch_id = cjdtb.kch_id
                                   and cjdtb.kcthzbm = 'xnkc'
                      )
        --不显示替代课程（参数需要控制）end-->
        --不显示成绩表内被认定课程begin--
        and not exists(select 'X' from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb
                                where rdb.xrdz_id = rdmxb.rdz_id
                    and a.kch_id = rdmxb.kch_id
                    and a.xh_id = rdb.xh_id
                    and rdb.rdlybj = '0'
                    and rdb.shjg = '3')
        --不显示成绩表内被认定课程end--
      ) where rn = '1') t1
      left join
      (select XH_ID,sskch_id,KCH_ID,
              CJ as MBYCJ,BFZCJ as MBYBFZCJ,JD as MBYJD,
              CJBZ as MBYCJBZ from
         ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
                fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
                'cjb', 'tj','0') as JD,
          t1.CJBZ,row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end order by t1.bfzcj desc) rn
      from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
         where t1.xh_id = t2.xh_id
           and t1.cjxzm in ('21','22')
          ) where rn = '1'
       ) t2
       on t1.xh_id = t2.xh_id
       and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
          = case when length(t2.sskch_id) =1 then t2.sskch_id||'-'||t2.kch_id else nvl(t2.sskch_id,t2.kch_id) end
      left join
      (select XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||'-'||kch_id else nvl(sskch_id,kch_id) end as KCH_ID,
              MAX(decode(rn,'1' ,CJ)) as MCXCJ,MAX(decode(rn,'1' ,BFZCJ)) as MCXBFZCJ, MAX(decode(rn,'1' ,JD)) as MCXJD,
         MAX(decode(rn,'1' ,CJBZ)) as MCXCJBZ,cxcs,
         MAX(decode(minrn,'1' ,CJ)) as CXCJ1,MAX(decode(minrn,'1' ,BFZCJ)) as CXBFZCJ1,MAX(decode(minrn,'1' ,JD)) as CXJD1,
         MAX(decode(minrn,'2' ,CJ)) as CXCJ2,MAX(decode(minrn,'2' ,BFZCJ)) as CXBFZCJ2,MAX(decode(minrn,'2' ,JD)) as CXJD2
         from
         (select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
            fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
                'cjb', 'tj','0') as JD,
           t1.CJBZ,
          row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end order by to_number(nvl(t1.hkbfzcj,t1.bfzcj)) desc) rn,
          row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end order by t1.xnm,to_number(t1.xqm)) minrn,
          count(distinct case when instr(','||nvl('y','y')||',' , ','||nvl(t1.cjbz,'xx')||',') = 0
          and t1.cjxzm='16' then t1.jxb_id else null end) over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id)) cxcs
         from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
         where t1.xh_id = t2.xh_id
           and t1.cjxzm in ('16','17')
         ) where (rn = '1' or minrn in ('1','2')) group by XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||'-'||kch_id else nvl(sskch_id,kch_id) end,cxcs
      ) t3
      on t1.xh_id = t3.xh_id
      and case when length(t1.sskch_id) =1 then t1.sskch_id||'-'||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
          = case when length(t3.sskch_id) =1 then t3.sskch_id||'-'||t3.kch_id else nvl(t3.sskch_id,t3.kch_id) end
  ) t
  union all
  select 'bdtkc' as ly,rdmxb.xnm,rdmxb.xqm,b.jg_id,b.njdm_id,b.zyh_id,b.zyfx_id,b.bh_id,b.xh_id,b.xh,b.xm,b.xbm,
         rdmxb.kcxzdm,rdmxb.kclbdm,null as kcgsdm,null as sskch_id,rdmxb.kch_id,kc.kch,kc.kcmc,kc.kcywmc,to_char(rdmxb.xf) as xf,null as jxb_id,'0' as kcbj,
         rdmxb.cj,rdmxb.bfzcj,null as cjbz,null as hkcj,
       fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,kc.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bdtkc', 'tj','0') as jd,
       '01' as cjxzm,
         null as mbkcj,null as mbkbfzcj,null as mbkjd,null as mbkcjbz,null as mbycj,null as mbybfzcj,null as mbyjd,null as mbycjbz,
         null as mbkcj1,null as mbkbfzcj1,null as mbkjd1,null as mbkcjbz1,
         null as mcxcj,null as mcxbfzcj,null as mcxjd,null as mcxcjbz,null as bkcs,null as cxcs,
         null as cxcj1,null as cxbfzcj1,null as cxjd1,null as cxcj2,null as cxbfzcj2,null as cxjd2,
         rdmxb.cj as mzbcj,rdmxb.bfzcj as mzbbfzcj,
       fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,kc.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bdtkc', 'tj','0') as mzbjd,
       null as mzbcjbz,'zk' as mzbcjbj,
         rdmxb.cj as maxcj,rdmxb.bfzcj as maxbfzcj,
       fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,kc.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bdtkc', 'tj','0') as maxjd,
       null as maxcjbz,'zk' as maxcjbj,
         0 as tdkcbj,
       1 as btdkcbj,
       1 as sfjhkc
         from Jw_Cj_Xsgrjhdtb rdmxb,jw_jh_kcdmb kc,jw_xjgl_xsjbxxb b
        where rdmxb.zszt = '3'
          and rdmxb.xh_id = b.xh_id
          and rdmxb.kch_id = kc.kch_id
  union all
    select 'bxwxfrdkc' as ly,rdmxb.xnm,rdmxb.xqm,b.jg_id,b.njdm_id,b.zyh_id,b.zyfx_id,b.bh_id,b.xh_id,b.xh,b.xm,b.xbm,
           rdmxb.kcxzdm,rdmxb.kclbdm,null as kcgsdm,null as sskch_id,rdmxb.kch_id,null as kch,rdmxb.kcmc,rdmxb.kcywmc,to_char(rdmxb.xf) as xf,null as jxb_id,'0' as kcbj,
           rdmxb.cj,rdmxb.bfzcj,null as cjbz,null as hkcj,
         fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,rdmxb.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bxwxfrdkc', 'tj','0') as jd,'01' as cjxzm,
           null as mbkcj,null as mbkbfzcj,null as mbkjd,null as mbkcjbz,
           null as mbkcj1,null as mbkbfzcj1,null as mbkjd1,null as mbkcjbz1,
           null as mbycj,null as mbybfzcj,null as mbyjd,null as mbycjbz,
           null as mcxcj,null as mcxbfzcj,null as mcxjd,null as mcxcjbz,null as bkcs,null as cxcs,
           null as cxcj1,null as cxbfzcj1,null as cxjd1,null as cxcj2,null as cxbfzcj2,null as cxjd2,
           rdmxb.cj as mzbcj, rdmxb.bfzcj as mzbbfzcj,
         fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,rdmxb.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bxwxfrdkc', 'tj','0') as mzbjd,
         null as mzbcjbz,'zk' as mzbcjbj,
           rdmxb.cj as maxcj,rdmxb.bfzcj as maxbfzcj,
         fn_jdjs(rdmxb.xnm,rdmxb.xqm,null,rdmxb.kch_id,rdmxb.kcmc,null,b.xh_id,rdmxb.kcxzdm,rdmxb.kclbdm,'01','0',null,null,rdmxb.jd,rdmxb.bfzcj,
               'bxwxfrdkc', 'tj','0') as maxjd,null as maxcjbz,'zk' as maxcjbj,
           0 as tdkcbj,
         1 as tdkcbj,
           0 as sfjhkc
           from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb,jw_xjgl_xsjbxxb b
          where rdb.xrdz_id = rdmxb.rdz_id
           and rdb.xh_id = b.xh_id
           and rdb.rdlybj = '0'
           and rdb.shjg = '3'
) t,jw_xjgl_xsjbxxb xs where t.xh_id = xs.xh_id
/

