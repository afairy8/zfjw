create view ZZDYCJB as
  select a.xnm,a.xqm,a.kch_id,a.jxb_id,a.xh_id,a.cj,a.cjbz,a.bfzcj,a.jd,b.cj bkcj,b.cjbz bkcj_bz,c.cj cxcj ,a.kcxz,case when a.cjxzm='16' then '1' else ''end cxbj from zkcjsjb a
left join bkcjsjb b on a.xh_id=b.xh_id and a.jxb_id=substr(b.jxb_id,1,instr(b.jxb_id,'b')-1) left join cxcjsjb c on a.xh_id=c.xh_id and a.jxb_id=substr(c.jxb_id,1,instr(c.jxb_id,'c')-1)
/

