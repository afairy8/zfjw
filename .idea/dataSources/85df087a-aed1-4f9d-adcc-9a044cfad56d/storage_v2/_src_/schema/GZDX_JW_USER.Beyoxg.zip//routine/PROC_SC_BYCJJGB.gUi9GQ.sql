create procedure proc_sc_bycjjgb(v_xh_id in varchar2)
as------------生成学生成绩结果表，毕业审核用
pragma  AUTONOMOUS_TRANSACTION;
v_count  number;
v_CJTJFXFS varchar(1);--成绩统计分析方式1：按实际修读统计分析；2：按校内课程统计分析;
v_CJTJFXSFKLXNTD varchar(1);--成绩统计分析是否考虑校内替代1：考虑校内替代；0：不考虑校内替代;
v_CJTJFXSFKLXWRD varchar(1);--成绩统计分析是否考虑校外认定1：考虑校外认定；0：不考虑校外认定;
v_CJTJFXSJKCXS varchar(1);--成绩统计分析实际课程显示1：显示实际修读课程，如篮球；0:计划课程显示，如篮球对应体育1，显示体育1;
v_CJTJFXBKALSFJ varchar(1);--成绩统计分析补考按六十分记1：是；0：否;
v_CJTJFXCXALSFJ varchar(1);--成绩统计分析重修按六十分记1：是；0：否;
v_CJTJFXSFTJZFCJ varchar(1);--成绩统计分析是否统计作废成绩1：是；0：否;
v_CJZDZJSFS varchar(1);--成绩最大值计算方式 1：按百分制成绩，2：按成绩绩点
v_CJZFKG varchar(1);--成绩作废开关
v_sql1 varchar(32767);
v_sql_CJZDZJSFS varchar(32767);
v_n   number;

v_sql2 varchar(32767);
v_sql varchar(32767);---总的sql
begin
   ---删除学生结果表
   delete from JW_BYGL_XSCJJGB where xh_id = v_xh_id;
   select zdz  into v_CJTJFXFS from jw_jcdml_xtnzb where zdm ='CJTJFXFS';
   select zdz  into v_CJTJFXSFKLXNTD from jw_jcdml_xtnzb where zdm ='CJTJFXSFKLXNTD';
   select zdz  into v_CJTJFXSFKLXWRD from jw_jcdml_xtnzb where zdm ='CJTJFXSFKLXWRD';
   select zdz  into v_CJTJFXSJKCXS from jw_jcdml_xtnzb where zdm ='CJTJFXSJKCXS';
   select zdz  into v_CJTJFXBKALSFJ from jw_jcdml_xtnzb where zdm ='CJTJFXBKALSFJ';
   select zdz  into v_CJTJFXCXALSFJ from jw_jcdml_xtnzb where zdm ='CJTJFXCXALSFJ';
   select zdz  into v_CJTJFXSFTJZFCJ from jw_jcdml_xtnzb where zdm ='CJTJFXSFTJZFCJ';
   select zdz  into v_CJZDZJSFS from jw_jcdml_xtnzb where zdm ='CJZDZJSFS';
   select zdz  into v_CJZFKG from jw_jcdml_xtnzb where zdm='CJZFKG';

  if v_CJTJFXFS='1' then ----按实际最高成绩统计
     v_sql1:='select ''cjb'' as ly,t.xnm,t.xqm,t.jg_id,t.njdm_id,t.zyh_id,t.zyfx_id,t.bh_id,t.xh_id,t.xh,t.xm,t.xbm,
         t.kcxzdm,t.kclbdm,t.kcgsdm,t.sskch_id,t.kch_id,t.kch,t.kcmc,t.kcywmc,t.xf,t.jxb_id,t.kcbj,
         t.cj,t.bfzcj,t.cjbz,
       fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,t.cjbz,t.jd,t.bfzcj,
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as jd,
       t.cjxzm,t.mbkcj,t.mbkbfzcj,t.mbkjd,t.mbkcjbz,t.mbycj,t.mbybfzcj,t.mbyjd,t.mbycjbz,t.mcxcj,t.mcxbfzcj,t.mcxjd,t.mcxcjbz,
         t.bkcs,t.cxcs,t.cxcj1,t.cxbfzcj1,t.cxjd1,t.cxcj2,t.cxbfzcj2,t.cxjd2,';

     if v_CJZDZJSFS='1' then
        v_sql_CJZDZJSFS:=' decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj
                          ) as mzbcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)) as mzbbfzcj,
          fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ),
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as mzbjd,
      decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ) as mzbcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk''
                          ) as mzbcjbj,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj,
                          nvl(mcxbfzcj,0),mcxcj,
                          nvl(mbybfzcj,0),mbycj
                          ) as maxcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)) as maxbfzcj,
        fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd,
                          nvl(mcxbfzcj,0),mcxjd,
                          nvl(mbybfzcj,0),mbyjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as maxjd,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ) as maxcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'')  then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk'',
                          nvl(mcxbfzcj,0),''cx'',
                          nvl(mbybfzcj,0),''bybk''
                          ) as maxcjbj,';

     else
         v_sql_CJZDZJSFS:=' case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
       decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
              nvl(jd,0),cj,
              nvl(mbkjd,0),mbkcj
              )
           else
       decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
            nvl(bfzcj,0),cj,
            nvl(mbkbfzcj,0),mbkcj
            )
      end  as mzbcj,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj
                          )
            else
            GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0))
      end as mzbbfzcj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz
                          ),
          GREATEST(nvl(jd,0),nvl(mbkjd,0)),
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj
                          ),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
            else
            fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      end  as mzbjd,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          )
      end as mzbcjbz,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),(case when cjxzm in (''16'') then ''cx''
                                          when cjxzm in (''21'',''22'') then ''bybk''
                                          when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                          else ''zk'' end),
                          nvl(mbkjd,0),''bk''
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk''
                          )
      end as mzbcjbj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cj,
                          nvl(mbkjd,0),mbkcj,
                          nvl(mcxjd,0),mcxcj,
                          nvl(mbyjd,0),mbycj
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj,
                          nvl(mcxbfzcj,0),mcxcj,
                          nvl(mbybfzcj,0),mbycj
                          )
      end  as maxcj,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
            decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj,
                          nvl(mcxjd,0),mcxbfzcj,
                          nvl(mbyjd,0),mbybfzcj
                          )
      else
            GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0))
      end as maxbfzcj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
        fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz,
                          nvl(mcxjd,0),mcxcjbz,
                          nvl(mbyjd,0),mbycjbz
                          ),
          GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj,
                          nvl(mcxjd,0),mcxbfzcj,
                          nvl(mbyjd,0),mbybfzcj
                          ),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      else
            fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd,
                          nvl(mcxbfzcj,0),mcxjd,
                          nvl(mbybfzcj,0),mbyjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      end   as maxjd,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
      decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz,
                          nvl(mcxjd,0),mcxcjbz,
                          nvl(mbyjd,0),mbycjbz
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          )
      end as maxcjbz,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),(case when cjxzm in (''16'') then ''cx''
                                          when cjxzm in (''21'',''22'') then ''bybk''
                                          when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                          else ''zk'' end),
                          nvl(mbkjd,0),''bk'',
                          nvl(mcxjd,0),''cx'',
                          nvl(mbyjd,0),''bybk''
                          )
      else
             decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk'',
                          nvl(mcxbfzcj,0),''cx'',
                          nvl(mbybfzcj,0),''bybk''
                          )
      end  as maxcjbj,';
     end if;

     v_sql1:=v_sql1 || v_sql_CJZDZJSFS;
     v_sql1:=v_sql1 ||' t.tdkcbj,t.btdkcbj,
   (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc from
   (select t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.zyfx_id,t1.bh_id,t1.xh_id,t1.xh,t1.xm,t1.xbm,
    t1.kcxzdm,t1.kclbdm,t1.kcgsdm,t1.sskch_id,t1.kch_id,t1.kch,t1.kcmc,t1.kcywmc,t1.xf, t1.jxb_id,t1.kcbj,t1.hkcj,
   (select count(1) from jw_cj_xsgrcjdtb cjdtb
                   where cjdtb.zszt = ''3''
                     and t1.xh_id = cjdtb.xh_id
                     and t1.kch_id = cjdtb.kch_id
                     and cjdtb.kcthzbm = ''xnkc''
                     and rownum = 1) as tdkcbj,
   (select count(1) from jw_cj_xsgrdtzb m,jw_cj_xsgrjhdtb n
           where m.kcthzh_id = n.kcthzh_id
             and m.kcthzbm = ''xnkc''
             and m.zszt = ''3''
             and n.kch_id = t1.kch_id
             and n.xh_id = t1.xh_id
                     and rownum = 1) as btdkcbj,
    case when t1.hkcj is null then nvl(t1.cj,t1.cjbz) else t1.hkcj end as cj,
    case when t1.hkcj is null then t1.bfzcj else t1.hkbfzcj end as bfzcj,
    case when t1.hkcj is null then t1.cjbz  else t1.hkbz end as cjbz,
    case when t1.hkcj is null then t1.jd else t1.hkjd end as jd,
    t1.cjxzm,
    t1.bkcj as mbkcj,
    t1.bkbfzcj as mbkbfzcj,
    t1.bkbz as mbkcjbz,
    t1.bkjd as mbkjd,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycj end as mbycj,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbybfzcj end as mbybfzcj,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbyjd end as mbyjd,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycjbz end as mbycjbz,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcj end as mcxcj,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxbfzcj end as mcxbfzcj,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxjd end as mcxjd,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcjbz end as mcxcjbz,
    t1.bkcs,t3.cxcs,t3.cxcj1,t3.cxbfzcj1,t3.cxjd1,t3.cxcj2,t3.cxbfzcj2,t3.cxjd2 from
    (select XNM,XQM,njdm_id,jg_id,zyh_id,zyfx_id,bh_id,XH_ID,xh,xm,xbm,sskch_id,KCH_ID,KCH,KCMC,KCYWMC,XF,KCXZDM,KCLBDM,KCGSDM,JXB_ID,
           CJ,BFZCJ,CJBZ,JD,CJXZM,KCBJ,BZXX,bkcj,bkbfzcj,bkbz,bkjd,hkcj,hkbfzcj,hkbz,hkjd,bkcs from
     (select a.XNM,a.XQM,b.jg_id,b.njdm_id,b.zyh_id,nvl(b.zyfx_id,''wfx'') zyfx_id,b.bh_id,a.XH_ID,b.xh,b.xm,b.xbm,
          a.sskch_id,a.KCH_ID,
          nvl(kc.kch,a.KCH) as kch,
          nvl(kc.kcmc,a.KCMC) as kcmc,
          nvl(kc.kcywmc,a.KCYWMC) as kcywmc,
          a.XF,a.KCXZDM,a.KCLBDM,a.KCGSDM,a.JXB_ID,
          a.CJ,a.BFZCJ,a.CJBZ,a.JD,a.CJXZM,a.KCBJ,a.BZXX,   ';

       ----是否补考按60分计
       if v_CJTJFXBKALSFJ ='1' then
          v_sql1:=v_sql1 || ' case when a.bkbfzcj >= 60 then ''60'' else a.bkcj end as bkcj, case when a.bkbfzcj >= 60 then 60
          else a.bkbfzcj end as bkbfzcj, a.bkbz, case when a.bkbfzcj >= 60 then 1 else a.bkjd end as bkjd,';
       else
          v_sql1:=v_sql1 || ' a.bkcj,a.bkbfzcj,a.bkbz,fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,''11'',
          a.kcbj,null,a.bkbz,a.bkjd,a.bkbfzcj,''cjb'', ''tj'',''0'') as bkjd,';
       end if;


       v_sql1:=v_sql1 || ' a.hkcj,a.hkbfzcj,a.hkbz,a.hkjd,a.bkcs,';

       if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' row_number() over (partition by a.xh_id,case when length(a.sskch_id) =1 then a.sskch_id||''-''||a.kch_id else
          nvl(a.sskch_id,a.kch_id) end order by to_number(a.cjxzm),a.bfzcj desc,a.xnm,to_number(a.xqm)) rn';
       else
          v_sql1:=v_sql1 || ' row_number() over (partition by a.xh_id,case when length(a.sskch_id) =1 then a.sskch_id||''-''||a.kch_id else
          nvl(a.sskch_id,a.kch_id) end order by to_number(a.cjxzm),to_number(nvl(a.jd,0)) desc,a.xnm,to_number(a.xqm)) rn';
       end if;

       v_sql1:=v_sql1 ||' from JW_CJ_XSCJB a,jw_xjgl_xsjbxxb b,jw_jh_kcdmb kc  where a.xh_id = b.xh_id  and a.cjxzm in (''01'',''16'',''21'',''22'')';
       v_sql1:=v_sql1 ||' and b.xh_id='''||v_xh_id||'''';
       --成绩作废
       if v_CJTJFXSFTJZFCJ='0' then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_cjjglxsqb zfb where zfb.cjjglx=''01'' and zfb.shzt=''3'' and zfb.xh_id=a.xh_id';

          if v_CJZFKG='2' then
              v_sql1:=v_sql1||' and zfb.jxb_id = a.jxb_id';
          else
              v_sql1:=v_sql1||' and zfb.kch_id = a.kch_id';
          end if;
           v_sql1:=v_sql1||')';
       else
           v_sql1:=v_sql1||'';
       end if;

       --按实际课程显示
       if v_CJTJFXSJKCXS='1' then
          v_sql1:=v_sql1||' and (case when length(a.sskch_id)=1 or a.sskch_id is null then a.kch_id else a.sskch_id end)  = kc.kch_id(+)';
       else
          v_sql1:=v_sql1||' and a.kch_id  = kc.kch_id(+)';
       end if;

       v_sql1:=v_sql1||' and not exists(select 1 from jw_cj_bzdmb c where a.cjbz =c.cjbzmc and c.cjtjfx=''0'' )';

       --成绩统计分析是否考虑校内替代
       if v_CJTJFXSFKLXNTD='1'  then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_xsgrjhdtb jhdtb where jhdtb.zszt = ''3'' and a.xh_id = jhdtb.xh_id and a.kch_id = jhdtb.kch_id)';
       else
          v_sql1:=v_sql1||'';
       end if;

       --成绩统计分析是否考虑校外认定
       if v_CJTJFXSFKLXWRD='1' then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb  where rdb.xrdz_id = rdmxb.rdz_id  and a.kch_id = rdmxb.kch_id
                            and a.xh_id = rdb.xh_id  and rdb.rdlybj = ''0'' and rdb.shjg = ''3'')';
       else
          v_sql1:=v_sql1||'';
       end if;

       v_sql1:=v_sql1||' ) where rn = ''1'') t1   left join   (select XH_ID,sskch_id,KCH_ID,';

       if v_CJTJFXBKALSFJ='1' then
          v_sql1:=v_sql1||' case when BFZCJ >= 60 then ''60'' else CJ end as MBYCJ,case when BFZCJ >= 60 then 60 else BFZCJ end
                            as MBYBFZCJ,case when BFZCJ >= 60 then 1 else JD end as MBYJD,';
       else
          v_sql1:=v_sql1||' CJ as MBYCJ,BFZCJ as MBYBFZCJ,JD as MBYJD,';
       end if;

       v_sql1:=v_sql1||' CJBZ as MBYCJBZ from ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
                         fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
                         ''cjb'', ''tj'',''0'') as JD,';

      if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' t1.CJBZ,row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id
                         else nvl(t1.sskch_id,t1.kch_id) end order by t1.bfzcj desc) rn ';
       else
          v_sql1:=v_sql1 || ' t1.CJBZ,row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id
                         else nvl(t1.sskch_id,t1.kch_id) end order by to_number(nvl(t1.jd,0)) desc) rn ';
       end if;

       v_sql1:=v_sql1 ||' from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2 where t1.xh_id = t2.xh_id  and  t2.xh_id  = '''||v_xh_id||'''
       and t1.cjxzm in (''21'',''22'') ) where rn = ''1'' ) t2 on t1.xh_id = t2.xh_id
       and case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
          = case when length(t2.sskch_id) =1 then t2.sskch_id||''-''||t2.kch_id else nvl(t2.sskch_id,t2.kch_id) end
      left join (select XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||''-''||kch_id else nvl(sskch_id,kch_id) end as KCH_ID,';

      --按六十分统计
      if v_CJTJFXCXALSFJ='1' then
         v_sql1:=v_sql1 ||'case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then ''60'' else MAX(decode(rn,''1'' ,CJ)) end as MCXCJ,
                 case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then 60 else MAX(decode(rn,''1'' ,BFZCJ)) end as MCXBFZCJ,
                 case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then 1 else MAX(decode(rn,''1'' ,JD)) end as MCXJD,';
      else
         v_sql1:=v_sql1 ||' MAX(decode(rn,''1'' ,CJ)) as MCXCJ,MAX(decode(rn,''1'' ,BFZCJ)) as MCXBFZCJ, MAX(decode(rn,''1'' ,JD)) as MCXJD,';
      end if;

      v_sql1:=v_sql1 || 'MAX(decode(rn,''1'' ,CJBZ)) as MCXCJBZ,cxcs,
         MAX(decode(minrn,''1'' ,CJ)) as CXCJ1,MAX(decode(minrn,''1'' ,BFZCJ)) as CXBFZCJ1,MAX(decode(minrn,''1'' ,JD)) as CXJD1,
         MAX(decode(minrn,''2'' ,CJ)) as CXCJ2,MAX(decode(minrn,''2'' ,BFZCJ)) as CXBFZCJ2,MAX(decode(minrn,''2'' ,JD)) as CXJD2
         from (select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
         fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
         ''cjb'', ''tj'',''0'') as JD,  t1.CJBZ,';

      if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else
          nvl(t1.sskch_id,t1.kch_id) end order by t1.bfzcj desc) rn,';
       else
          v_sql1:=v_sql1 || ' row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else
          nvl(t1.sskch_id,t1.kch_id) end order by to_number(nvl(t1.jd,0)) desc) rn, ';
       end if;

       v_sql1:=v_sql1||'row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end order by t1.xnm,to_number(t1.xqm)) minrn,
          count(distinct case when instr('',''||nvl('''',''y'')||'','' , '',''||nvl(t1.cjbz,''xx'')||'','') = 0
          and t1.cjxzm=''16'' then t1.jxb_id else null end) over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id)) cxcs
         from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
         where t1.xh_id = t2.xh_id
           and t1.cjxzm in (''16'',''17'')
           and t2.xh_id='''||v_xh_id||'''
         ) where (rn = ''1'' or minrn in (''1'',''2'')) group by XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||''-''||kch_id else nvl(sskch_id,kch_id) end,cxcs
        ) t3
        on t1.xh_id = t3.xh_id
        and case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
            = case when length(t3.sskch_id) =1 then t3.sskch_id||''-''||t3.kch_id else nvl(t3.sskch_id,t3.kch_id) end
        ) t';


       if v_CJTJFXSFKLXWRD='1' then
          v_sql1:=v_sql1||' union all
           select ''bxwxfrdkc'' as ly,rdmxb.xnm,rdmxb.xqm,b.jg_id,b.njdm_id,b.zyh_id,b.zyfx_id,b.bh_id,b.xh_id,b.xh,b.xm,b.xbm,
           rdmxb.kcxzdm,rdmxb.kclbdm,null as kcgsdm,null as sskch_id,rdmxb.kch_id,null as kch,rdmxb.kcmc,rdmxb.kcywmc,to_char(rdmxb.xf) as xf,null as jxb_id,''0'' as kcbj,
           rdmxb.cj,rdmxb.bfzcj,null as cjbz,null as jd,''01'' as cjxzm,
           null as mbkcj,null as mbkbfzcj,null as mbkjd,null as mbkcjbz,null as mbycj,null as mbybfzcj,null as mbyjd,null as mbycjbz,
           null as mcxcj,null as mcxbfzcj,null as mcxjd,null as mcxcjbz,null as bkcs,null as cxcs,
           null as cxcj1,null as cxbfzcj1,null as cxjd1,null as cxcj2,null as cxbfzcj2,null as cxjd2,
           rdmxb.cj as mzbcj, rdmxb.bfzcj as mzbbfzcj,null as mzbjd,null as mzbcjbz,''zk'' as mzbcjbj,
           rdmxb.cj as maxcj,rdmxb.bfzcj as maxbfzcj,null as maxjd,null as maxcjbz,''zk'' as maxcjbj,
           0 as tdkcbj, 1 as tdkcbj,0 as sfjhkc
           from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb,jw_xjgl_xsjbxxb b
          where rdb.xrdz_id = rdmxb.rdz_id
           and rdb.xh_id = b.xh_id
           and rdb.rdlybj = ''0''
           and b.xh_id='''||v_xh_id||'''
           and rdb.shjg = ''3''';
       else
           v_sql1:=v_sql1||'';
       end if;

  else
       v_sql1:=v_sql1||'';
  ---第2种按校内课程统计暂时先不加
 v_sql1:='select ''cjb'' as ly,t.xnm,t.xqm,t.jg_id,t.njdm_id,t.zyh_id,t.zyfx_id,t.bh_id,t.xh_id,t.xh,t.xm,t.xbm,
         t.kcxzdm,t.kclbdm,t.kcgsdm,t.sskch_id,t.kch_id,t.kch,t.kcmc,t.kcywmc,t.xf,t.jxb_id,t.kcbj,
         t.cj,t.bfzcj,t.cjbz,
       fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,t.cjbz,t.jd,t.bfzcj,
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as jd,
       t.cjxzm,t.mbkcj,t.mbkbfzcj,t.mbkjd,t.mbkcjbz,t.mbycj,t.mbybfzcj,t.mbyjd,t.mbycjbz,t.mcxcj,t.mcxbfzcj,t.mcxjd,t.mcxcjbz,
         t.bkcs,t.cxcs,t.cxcj1,t.cxbfzcj1,t.cxjd1,t.cxcj2,t.cxbfzcj2,t.cxjd2,';

     if v_CJZDZJSFS='1' then
        v_sql_CJZDZJSFS:=' decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj
                          ) as mzbcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)) as mzbbfzcj,
          fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ),
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as mzbjd,
      decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ) as mzbcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk''
                          ) as mzbcjbj,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj,
                          nvl(mcxbfzcj,0),mcxcj,
                          nvl(mbybfzcj,0),mbycj
                          ) as maxcj,
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)) as maxbfzcj,
        fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd,
                          nvl(mcxbfzcj,0),mcxjd,
                          nvl(mbybfzcj,0),mbyjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'') as maxjd,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ) as maxcjbz,
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'')  then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk'',
                          nvl(mcxbfzcj,0),''cx'',
                          nvl(mbybfzcj,0),''bybk''
                          ) as maxcjbj,';

     else
         v_sql_CJZDZJSFS:=' case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
       decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
              nvl(jd,0),cj,
              nvl(mbkjd,0),mbkcj
              )
           else
       decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
            nvl(bfzcj,0),cj,
            nvl(mbkbfzcj,0),mbkcj
            )
      end  as mzbcj,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj
                          )
            else
            GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0))
      end as mzbbfzcj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz
                          ),
          GREATEST(nvl(jd,0),nvl(mbkjd,0)),
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj
                          ),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
            else
            fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      end  as mzbjd,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz
                          )
      end as mzbcjbz,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0)),
                          nvl(jd,0),(case when cjxzm in (''16'') then ''cx''
                                          when cjxzm in (''21'',''22'') then ''bybk''
                                          when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                          else ''zk'' end),
                          nvl(mbkjd,0),''bk''
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk''
                          )
      end as mzbcjbj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cj,
                          nvl(mbkjd,0),mbkcj,
                          nvl(mcxjd,0),mcxcj,
                          nvl(mbyjd,0),mbycj
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cj,
                          nvl(mbkbfzcj,0),mbkcj,
                          nvl(mcxbfzcj,0),mcxcj,
                          nvl(mbybfzcj,0),mbycj
                          )
      end  as maxcj,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
            decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj,
                          nvl(mcxjd,0),mcxbfzcj,
                          nvl(mbyjd,0),mbybfzcj
                          )
      else
            GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0))
      end as maxbfzcj,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
        fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz,
                          nvl(mcxjd,0),mcxcjbz,
                          nvl(mbyjd,0),mbycjbz
                          ),
          GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),bfzcj,
                          nvl(mbkjd,0),mbkbfzcj,
                          nvl(mcxjd,0),mcxbfzcj,
                          nvl(mbyjd,0),mbybfzcj
                          ),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      else
            fn_jdjs(t.xnm,t.xqm,t.sskch_id,t.kch_id,t.kcmc,t.jxb_id,t.xh_id,t.kcxzdm,t.kclbdm,t.cjxzm,t.kcbj,null,
              decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          ),
          decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),jd,
                          nvl(mbkbfzcj,0),mbkjd,
                          nvl(mcxbfzcj,0),mcxjd,
                          nvl(mbybfzcj,0),mbyjd
                          ),
          GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
               case when t.tdkcbj = ''1'' then ''cjb-dtkc'' when t.btdkcbj = ''1'' then ''cjb-bdtkc'' else ''cjb'' end, ''tj'',''0'')
      end   as maxjd,
      case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
      decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),cjbz,
                          nvl(mbkjd,0),mbkcjbz,
                          nvl(mcxjd,0),mcxcjbz,
                          nvl(mbyjd,0),mbycjbz
                          )
      else
            decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),cjbz,
                          nvl(mbkbfzcj,0),mbkcjbz,
                          nvl(mcxbfzcj,0),mcxcjbz,
                          nvl(mbybfzcj,0),mbycjbz
                          )
      end as maxcjbz,
            case when GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)) != 0 then
          decode(GREATEST(nvl(jd,0),nvl(mbkjd,0), nvl(mcxjd,0), nvl(mbyjd,0)),
                          nvl(jd,0),(case when cjxzm in (''16'') then ''cx''
                                          when cjxzm in (''21'',''22'') then ''bybk''
                                          when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                          else ''zk'' end),
                          nvl(mbkjd,0),''bk'',
                          nvl(mcxjd,0),''cx'',
                          nvl(mbyjd,0),''bybk''
                          )
      else
             decode(GREATEST(nvl(bfzcj,0),nvl(mbkbfzcj,0), nvl(mcxbfzcj,0), nvl(mbybfzcj,0)),
                          nvl(bfzcj,0),(case when cjxzm in (''16'') then ''cx''
                                             when cjxzm in (''21'',''22'') then ''bybk''
                                             when cjbz = ''缓考'' or hkcj is not null then ''hk''
                                             else ''zk'' end),
                          nvl(mbkbfzcj,0),''bk'',
                          nvl(mcxbfzcj,0),''cx'',
                          nvl(mbybfzcj,0),''bybk''
                          )
      end  as maxcjbj,';
     end if;

     v_sql1:=v_sql1 || v_sql_CJZDZJSFS;
     v_sql1:=v_sql1 ||' t.tdkcbj,t.btdkcbj,
   (select count(1) from jw_jh_jxzxjhkcxxb where njdm_id = t.njdm_id and zyh_id = t.zyh_id and kch_id = t.kch_id and rownum = 1) sfjhkc from
   (select t1.xnm,t1.xqm,t1.jg_id,t1.njdm_id,t1.zyh_id,t1.zyfx_id,t1.bh_id,t1.xh_id,t1.xh,t1.xm,t1.xbm,
    t1.kcxzdm,t1.kclbdm,t1.kcgsdm,t1.sskch_id,t1.kch_id,t1.kch,t1.kcmc,t1.kcywmc,t1.xf, t1.jxb_id,t1.kcbj,t1.hkcj,
   (select count(1) from jw_cj_xsgrcjdtb cjdtb
                   where cjdtb.zszt = ''3''
                     and t1.xh_id = cjdtb.xh_id
                     and t1.kch_id = cjdtb.kch_id
                     and cjdtb.kcthzbm = ''xnkc''
                     and rownum = 1) as tdkcbj,
   (select count(1) from jw_cj_xsgrdtzb m,jw_cj_xsgrjhdtb n
           where m.kcthzh_id = n.kcthzh_id
             and m.kcthzbm = ''xnkc''
             and m.zszt = ''3''
             and n.kch_id = t1.kch_id
             and n.xh_id = t1.xh_id
                     and rownum = 1) as btdkcbj,
    case when t1.hkcj is null then nvl(t1.cj,t1.cjbz) else t1.hkcj end as cj,
    case when t1.hkcj is null then t1.bfzcj else t1.hkbfzcj end as bfzcj,
    case when t1.hkcj is null then t1.cjbz  else t1.hkbz end as cjbz,
    case when t1.hkcj is null then t1.jd else t1.hkjd end as jd,
    t1.cjxzm,
    t1.bkcj as mbkcj,
    t1.bkbfzcj as mbkbfzcj,
    t1.bkbz as mbkcjbz,
    t1.bkjd as mbkjd,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycj end as mbycj,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbybfzcj end as mbybfzcj,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbyjd end as mbyjd,
    case when t1.cjxzm in (''21'',''22'') and nvl(t1.bfzcj,0) = nvl(t2.mbybfzcj,0) then null else  t2.mbycjbz end as mbycjbz,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcj end as mcxcj,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxbfzcj end as mcxbfzcj,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxjd end as mcxjd,
    case when t1.cjxzm in (''16'') and nvl(t1.bfzcj,0) = nvl(t3.mcxbfzcj,0) then null else  t3.mcxcjbz end as mcxcjbz,
    t1.bkcs,t3.cxcs,t3.cxcj1,t3.cxbfzcj1,t3.cxjd1,t3.cxcj2,t3.cxbfzcj2,t3.cxjd2 from
    (select XNM,XQM,njdm_id,jg_id,zyh_id,zyfx_id,bh_id,XH_ID,xh,xm,xbm,sskch_id,KCH_ID,KCH,KCMC,KCYWMC,XF,KCXZDM,KCLBDM,KCGSDM,JXB_ID,
           CJ,BFZCJ,CJBZ,JD,CJXZM,KCBJ,BZXX,bkcj,bkbfzcj,bkbz,bkjd,hkcj,hkbfzcj,hkbz,hkjd,bkcs from
     (select a.XNM,a.XQM,b.jg_id,b.njdm_id,b.zyh_id,nvl(b.zyfx_id,''wfx'') zyfx_id,b.bh_id,a.XH_ID,b.xh,b.xm,b.xbm,
          a.sskch_id,a.KCH_ID,
          nvl(kc.kch,a.KCH) as kch,
          nvl(kc.kcmc,a.KCMC) as kcmc,
          nvl(kc.kcywmc,a.KCYWMC) as kcywmc,
          a.XF,a.KCXZDM,a.KCLBDM,a.KCGSDM,a.JXB_ID,
          a.CJ,a.BFZCJ,a.CJBZ,a.JD,a.CJXZM,a.KCBJ,a.BZXX,   ';

       ----是否补考按60分计
       if v_CJTJFXBKALSFJ ='1' then
          v_sql1:=v_sql1 || ' case when a.bkbfzcj >= 60 then ''60'' else a.bkcj end as bkcj, case when a.bkbfzcj >= 60 then 60
          else a.bkbfzcj end as bkbfzcj, a.bkbz, case when a.bkbfzcj >= 60 then 1 else a.bkjd end as bkjd,';
       else
          v_sql1:=v_sql1 || ' a.bkcj,a.bkbfzcj,a.bkbz,fn_jdjs(a.xnm,a.xqm,a.sskch_id,a.kch_id,a.kcmc,a.jxb_id,a.xh_id,a.kcxzdm,a.kclbdm,''11'',
          a.kcbj,null,a.bkbz,a.bkjd,a.bkbfzcj,''cjb'', ''tj'',''0'') as bkjd,';
       end if;


       v_sql1:=v_sql1 || ' a.hkcj,a.hkbfzcj,a.hkbz,a.hkjd,a.bkcs,';

       if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' row_number() over (partition by a.xh_id,case when length(a.sskch_id) =1 then a.sskch_id||''-''||a.kch_id else
          nvl(a.sskch_id,a.kch_id) end order by to_number(a.cjxzm),a.bfzcj desc,a.xnm,to_number(a.xqm)) rn';
       else
          v_sql1:=v_sql1 || ' row_number() over (partition by a.xh_id,case when length(a.sskch_id) =1 then a.sskch_id||''-''||a.kch_id else
          nvl(a.sskch_id,a.kch_id) end order by to_number(a.cjxzm),to_number(nvl(a.jd,0)) desc,a.xnm,to_number(a.xqm)) rn';
       end if;

       v_sql1:=v_sql1 ||' from JW_CJ_XSCJB a,jw_xjgl_xsjbxxb b,jw_jh_kcdmb kc  where a.xh_id = b.xh_id  and a.cjxzm in (''01'',''16'',''21'',''22'')';
       v_sql1:=v_sql1 ||' and b.xh_id='''||v_xh_id||'''';
       --成绩作废
       if v_CJTJFXSFTJZFCJ='0' then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_cjjglxsqb zfb where zfb.cjjglx=''01'' and zfb.shzt=''3'' and zfb.xh_id=a.xh_id';

          if v_CJZFKG='2' then
              v_sql1:=v_sql1||' and zfb.jxb_id = a.jxb_id';
          else
              v_sql1:=v_sql1||' and zfb.kch_id = a.kch_id';
          end if;
           v_sql1:=v_sql1||')';
       else
           v_sql1:=v_sql1||'';
       end if;

       --按实际课程显示
       if v_CJTJFXSJKCXS='1' then
          v_sql1:=v_sql1||' and (case when length(a.sskch_id)=1 or a.sskch_id is null then a.kch_id else a.sskch_id end)  = kc.kch_id(+)';
       else
          v_sql1:=v_sql1||' and a.kch_id  = kc.kch_id(+)';
       end if;

       v_sql1:=v_sql1||' and not exists(select 1 from jw_cj_bzdmb c where a.cjbz =c.cjbzmc and c.cjtjfx=''0'' )';

       --成绩统计分析是否考虑校内替代
       if v_CJTJFXSFKLXNTD='1'  then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_xsgrjhdtb jhdtb where jhdtb.zszt = ''3'' and a.xh_id = jhdtb.xh_id and a.kch_id = jhdtb.kch_id
          union all select ''X'' from jw_cj_xsgrcjdtb cjdtb where cjdtb.zszt = ''3'' and a.xh_id = cjdtb.xh_id and a.kch_id = cjdtb.kch_id)';
       else
          v_sql1:=v_sql1||'';
       end if;

       --成绩统计分析是否考虑校外认定
       if v_CJTJFXSFKLXWRD='1' then
          v_sql1:=v_sql1||' and not exists(select ''X'' from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb  where rdb.xrdz_id = rdmxb.rdz_id  and a.kch_id = rdmxb.kch_id
                            and a.xh_id = rdb.xh_id  and rdb.rdlybj = ''0'' and rdb.shjg = ''3'')';
       else
          v_sql1:=v_sql1||'';
       end if;

       v_sql1:=v_sql1||' ) where rn = ''1'') t1   left join   (select XH_ID,sskch_id,KCH_ID,';

       if v_CJTJFXBKALSFJ='1' then
          v_sql1:=v_sql1||' case when BFZCJ >= 60 then ''60'' else CJ end as MBYCJ,case when BFZCJ >= 60 then 60 else BFZCJ end
                            as MBYBFZCJ,case when BFZCJ >= 60 then 1 else JD end as MBYJD,';
       else
          v_sql1:=v_sql1||' CJ as MBYCJ,BFZCJ as MBYBFZCJ,JD as MBYJD,';
       end if;

       v_sql1:=v_sql1||' CJBZ as MBYCJBZ from ( select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
                         fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
                         ''cjb'', ''tj'',''0'') as JD,';

      if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' t1.CJBZ,row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id
                         else nvl(t1.sskch_id,t1.kch_id) end order by t1.bfzcj desc) rn ';
       else
          v_sql1:=v_sql1 || ' t1.CJBZ,row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id
                         else nvl(t1.sskch_id,t1.kch_id) end order by to_number(nvl(t1.jd,0)) desc) rn ';
       end if;

       v_sql1:=v_sql1 ||' from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2 where t1.xh_id = t2.xh_id  and  t2.xh_id  = '''||v_xh_id||'''
       and t1.cjxzm in (''21'',''22'') ) where rn = ''1'' ) t2 on t1.xh_id = t2.xh_id
       and case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
          = case when length(t2.sskch_id) =1 then t2.sskch_id||''-''||t2.kch_id else nvl(t2.sskch_id,t2.kch_id) end
      left join (select XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||''-''||kch_id else nvl(sskch_id,kch_id) end as KCH_ID,';

      --按六十分统计
      if v_CJTJFXCXALSFJ='1' then
         v_sql1:=v_sql1 ||'case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then ''60'' else MAX(decode(rn,''1'' ,CJ)) end as MCXCJ,
                 case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then 60 else MAX(decode(rn,''1'' ,BFZCJ)) end as MCXBFZCJ,
                 case when MAX(decode(rn,''1'' ,BFZCJ)) >= 60 then 1 else MAX(decode(rn,''1'' ,JD)) end as MCXJD,';
      else
         v_sql1:=v_sql1 ||' MAX(decode(rn,''1'' ,CJ)) as MCXCJ,MAX(decode(rn,''1'' ,BFZCJ)) as MCXBFZCJ, MAX(decode(rn,''1'' ,JD)) as MCXJD,';
      end if;

      v_sql1:=v_sql1 || 'MAX(decode(rn,''1'' ,CJBZ)) as MCXCJBZ,cxcs,
         MAX(decode(minrn,''1'' ,CJ)) as CXCJ1,MAX(decode(minrn,''1'' ,BFZCJ)) as CXBFZCJ1,MAX(decode(minrn,''1'' ,JD)) as CXJD1,
         MAX(decode(minrn,''2'' ,CJ)) as CXCJ2,MAX(decode(minrn,''2'' ,BFZCJ)) as CXBFZCJ2,MAX(decode(minrn,''2'' ,JD)) as CXJD2
         from (select t1.XH_ID,t1.sskch_id,t1.KCH_ID,t1.CJ,t1.BFZCJ,
         fn_jdjs(t1.xnm,t1.xqm,t1.sskch_id,t1.kch_id,t1.kcmc,t1.jxb_id,t1.xh_id,t1.kcxzdm,t1.kclbdm,t1.cjxzm,t1.kcbj,null,t1.cjbz,t1.jd,t1.bfzcj,
         ''cjb'', ''tj'',''0'') as JD,  t1.CJBZ,';

      if v_CJZDZJSFS='1' then
          v_sql1:=v_sql1 || ' row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else
          nvl(t1.sskch_id,t1.kch_id) end order by t1.bfzcj desc) rn,';
       else
          v_sql1:=v_sql1 || ' row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else
          nvl(t1.sskch_id,t1.kch_id) end order by to_number(nvl(t1.jd,0)) desc) rn, ';
       end if;

       v_sql1:=v_sql1||'row_number() over (partition by t1.xh_id,case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end order by t1.xnm,to_number(t1.xqm)) minrn,
          count(distinct case when instr('',''||nvl('''',''y'')||'','' , '',''||nvl(t1.cjbz,''xx'')||'','') = 0
          and t1.cjxzm=''16'' then t1.jxb_id else null end) over (partition by t1.xh_id,nvl(t1.sskch_id,t1.kch_id)) cxcs
         from JW_CJ_XSCJB t1 ,jw_xjgl_xsjbxxb t2
         where t1.xh_id = t2.xh_id
           and t1.cjxzm in (''16'',''17'')
           and t2.xh_id='''||v_xh_id||'''
         ) where (rn = ''1'' or minrn in (''1'',''2'')) group by XH_ID,sskch_id,case when length(sskch_id) =1 then sskch_id||''-''||kch_id else nvl(sskch_id,kch_id) end,cxcs
        ) t3
        on t1.xh_id = t3.xh_id
        and case when length(t1.sskch_id) =1 then t1.sskch_id||''-''||t1.kch_id else nvl(t1.sskch_id,t1.kch_id) end
            = case when length(t3.sskch_id) =1 then t3.sskch_id||''-''||t3.kch_id else nvl(t3.sskch_id,t3.kch_id) end
        ) t';


         v_sql1:=v_sql1||' union all
          select ''bdtkc'' as ly,jhdt.xnm,jhdt.xqm,b.jg_id,b.njdm_id,b.zyh_id,b.zyfx_id,b.bh_id,b.xh_id,b.xh,b.xm,b.xbm,
          jhdt.kcxzdm,jhdt.kclbdm,null as kcgsdm,null as sskch_id,jhdt.kch_id,kc.kch,kc.kcmc,kc.kcywmc,to_char(jhdt.xf) as xf,null as jxb_id,''0'' as kcbj,
          jhdt.cj,jhdt.bfzcj,null as cjbz,jhdt.jd,''01'' as cjxzm,
          null as mbkcj,null as mbkbfzcj,null as mbkjd,null as mbkcjbz,null as mbycj,null as mbybfzcj,null as mbyjd,null as mbycjbz,
          null as mcxcj,null as mcxbfzcj,null as mcxjd,null as mcxcjbz,null as bkcs,null as cxcs,
          null as cxcj1,null as cxbfzcj1,null as cxjd1,null as cxcj2,null as cxbfzcj2,null as cxjd2,
          jhdt.cj as mzbcj,jhdt.bfzcj as mzbbfzcj,jhdt.jd as mzbjd,null as mzbcjbz,''zk'' as mzbcjbj,
          jhdt.cj as maxcj,jhdt.bfzcj as maxbfzcj,jhdt.jd as maxjd,null as maxcjbz,''zk'' as maxcjbj,
          0 as tdkcbj, 1 as tdkcbj,0 as sfjhkc
          from Jw_Cj_Xsgrjhdtb jhdt,jw_jh_kcdmb kc,jw_xjgl_xsjbxxb b
          where jhdt.zszt = ''3''
          and jhdt.xh_id = b.xh_id
          and b.xh_id='''||v_xh_id||'''
          and jhdt.kch_id = kc.kch_id';

       if v_CJTJFXSFKLXWRD='1' then v_sql1:=v_sql1||'';
         v_sql1:=v_sql1||' union all
           select ''bxwxfrdkc'' as ly,rdmxb.xnm,rdmxb.xqm,b.jg_id,b.njdm_id,b.zyh_id,b.zyfx_id,b.bh_id,b.xh_id,b.xh,b.xm,b.xbm,
           rdmxb.kcxzdm,rdmxb.kclbdm,null as kcgsdm,null as sskch_id,rdmxb.kch_id,null as kch,rdmxb.kcmc,rdmxb.kcywmc,to_char(rdmxb.xf) as xf,null as jxb_id,''0'' as kcbj,
           rdmxb.cj,rdmxb.bfzcj,null as cjbz,null as jd,''01'' as cjxzm,
           null as mbkcj,null as mbkbfzcj,null as mbkjd,null as mbkcjbz,null as mbycj,null as mbybfzcj,null as mbyjd,null as mbycjbz,
           null as mcxcj,null as mcxbfzcj,null as mcxjd,null as mcxcjbz,null as bkcs,null as cxcs,
           null as cxcj1,null as cxbfzcj1,null as cxjd1,null as cxcj2,null as cxbfzcj2,null as cxjd2,
           rdmxb.cj as mzbcj, rdmxb.bfzcj as mzbbfzcj,null as mzbjd,null as mzbcjbz,''zk'' as mzbcjbj,
           rdmxb.cj as maxcj,rdmxb.bfzcj as maxbfzcj,null as maxjd,null as maxcjbz,''zk'' as maxcjbj,
           0 as tdkcbj, 1 as tdkcbj,0 as sfjhkc
           from jw_cj_xfrdb rdb,jw_cj_xfrdmxb rdmxb,jw_xjgl_xsjbxxb b
          where rdb.xrdz_id = rdmxb.rdz_id
           and rdb.xh_id = b.xh_id
           and rdb.rdlybj = ''0''
           and b.xh_id='''||v_xh_id||'''
           and rdb.shjg = ''3''';
       else
           v_sql1:=v_sql1||'';
       end if;
  end if;
v_sql:='insert into jw_bygl_xscjjgb select * from ('||v_sql1||')';
--dbms_output.put_line (v_sql1);

/* v_n := 1;
loop
    v_sql := substr(v_sql1, v_n, 1000);
    dbms_output.put_line(v_sql);

    v_n := v_n + 1000;
    exit when v_n > length(v_sql1);
end loop;*/

execute immediate v_sql;
commit;
end proc_sc_bycjjgb;

/

