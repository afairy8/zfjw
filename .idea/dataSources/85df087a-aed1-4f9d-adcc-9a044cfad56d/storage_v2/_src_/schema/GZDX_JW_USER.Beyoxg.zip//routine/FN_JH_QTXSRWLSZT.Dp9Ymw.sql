create function fn_jh_qtxsrwlszt(
    vXnm varchar2,
    vXqm varchar2,
    vKch_id varchar2,
    vFjxb_id varchar2,
    vNjdm_id varchar2,
    vZyh_id varchar2
) return varchar2
as
    v_f_rs number;
    v_z_rs number;
    v_tmp varchar2(10);
    v_result varchar2(1) default '2';
    cursor c_xsdm(i_xnm varchar2,i_xqm varchar2,i_kch_id varchar2,i_njdm_id varchar2,i_zyh_id varchar2) is
         select distinct xsdm from jw_jh_jxzxjhkcxsdzb t1,jw_jh_jxzxjhkcyxxdxnxqb t2,jw_jh_jxzxjhkcxxb t3
            where t1.jxzxjhkcxx_id=t2.jxzxjhkcxx_id
                  and t2.jxzxjhkcxx_id=t3.jxzxjhkcxx_id
                  and t1.jxzxjhkcxx_id = t3.jxzxjhkcxx_id
                  and t2.yxkkxnm=i_xnm
                  and t2.yxkkxqm=i_xqm
                  and t1.kch_id=i_kch_id
                  and t2.njdm_id=i_njdm_id
                  and t2.zyh_id=i_zyh_id
                  and t1.kch_id = t3.kch_id
                  and t2.njdm_id = t3.njdm_id
                  and t2.zyh_id = t3.zyh_id
                  and t1.xsdm!='01';
begin
    for p_xsdm in c_xsdm(vXnm,vXqm,vKch_id,vNjdm_id,vZyh_id) loop
        select jxbrs into v_f_rs from jw_jxrw_jxbxxb where jxb_id=vFjxb_id;
        select sum(rs) into v_z_rs from jw_jxrw_jxbhbxxb t1
            where exists(select 1 from jw_jxrw_jxbxxb t2 where t1.jxb_id=t2.jxb_id and t2.xnm=vXnm and t2.xqm=vXqm and t2.fjxb_id=vFjxb_id and t2.xsdm=p_xsdm.xsdm);
        if nvl(v_z_rs,0)=0 and nvl(v_f_rs,0)>nvl(v_z_rs,0) then
            v_tmp:=v_tmp||'0';--未安排
        elsif nvl(v_z_rs,0)>0 and nvl(v_f_rs,0)>nvl(v_z_rs,0) then
            v_tmp:=v_tmp||'1';--部分安排
        else
            v_tmp:=v_tmp||'2';--完全安排
        end if;
    end loop;
    if instr(nvl(v_tmp,'2'),'0')>0 and instr(nvl(v_tmp,'2'),'1')=0 and instr(nvl(v_tmp,'2'),'2')=0 then
        v_result := '0';--未安排
    elsif instr(nvl(v_tmp,'2'),'2')>0 and instr(nvl(v_tmp,'2'),'0')=0 and instr(nvl(v_tmp,'2'),'1')=0 then
        v_result := '2';--完全安排
    else
        v_result := '1';--部分安排
    end if;
    return v_result ;
end fn_jh_qtxsrwlszt;

/

