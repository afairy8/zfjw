create function get_Tjzmc(vTjz varchar2) return varchar2  ---返回条件值名称----
as
   sTjzmc varchar2(2000);   ---条件值名称
   in_tjzs mytype;
   in_kch_ids mytype;
   v_kcmc varchar2(100);
begin
    sTjzmc := '';
    begin
       in_tjzs := my_split(vTjz,',');
       for i in 1..in_tjzs.count loop
           in_kch_ids := my_split(in_tjzs(i),'@');
           select kcmc into v_kcmc from jw_jh_kcdmb where kch_id = in_kch_ids(1);
           if i = 1 then
             sTjzmc := sTjzmc||v_kcmc||'|'||in_kch_ids(2);
           else
             sTjzmc := sTjzmc||','||v_kcmc||'|'||in_kch_ids(2);
           end if;
       end loop;
     exception
        When others then
          sTjzmc := '';
    end;
    return sTjzmc;
end get_Tjzmc;

/

