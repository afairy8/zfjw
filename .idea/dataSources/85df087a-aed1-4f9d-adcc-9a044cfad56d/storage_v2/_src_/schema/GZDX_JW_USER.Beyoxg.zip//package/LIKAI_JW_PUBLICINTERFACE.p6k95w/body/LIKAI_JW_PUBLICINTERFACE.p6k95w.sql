create package body likai_jw_publicInterface is
  procedure insertBackUpXyyj(sign varchar2) is
    begin
      insert into likai_yesterdat_xyyjclb
        select *
        from JW_CJ_XYYJCLJGB clb
        where not exists(select 'x'
                         from likai_yesterdat_xyyjclb
                         where xnm = clb.xnm and xqm = clb.xqm and xh_id = clb.xh_id);
      commit;
    end;
  procedure updateSfkp(sign varchar2) is
    begin
      update JW_XK_XSXKB xkb
      set xkb.SFKP = '0'
      where xkb.XNM = (select zdz
                       from ZFTAL_XTGL_XTSZB
                       where zs = '当前学年')
            and xkb.XQM = (select zdz
                           from ZFTAL_XTGL_XTSZB
                           where zs = '当前学期')
            and xkb.SFKP = '1'
            and exists(
                select 'x'
                from
                  (select *
                   from jw_xjgl_xjydb t
                   where t.YDSXXNM = (select zdz
                                      from ZFTAL_XTGL_XTSZB
                                      where zs = '当前学年')
                         and t.YDSXXQM = (select zdz
                                          from ZFTAL_XTGL_XTSZB
                                          where zs = '当前学期') and t.YDLBM in (
                     select t.YDLBM
                     from jw_xjgl_xjydlbdmb t
                     where
                       t.DYXJZT in (select XJZTDM
                                    from JW_XJGL_XJZTDMB
                                    where SFYXJ = '0') or SFZX = '0')) t
                where t.XH_ID = xkb.xh_id);
    end;
  procedure update_zsjhrsAndbjzxrs(v_njdm_id varchar2) is
    --1\update JW_XJGL_NJZYZSJHB bjs,zsjhrs
    begin
      update JW_XJGL_NJZYZSJHB zsjh
      set zsjh.BJS                                 = (
        select bjs
        from (
               select
                 bj.ZYH_ID,
                 count(bj.BH_ID) bjs
               from zftal_xtgl_bjdmb bj
               where bj.njdm_id = v_njdm_id
               group by bj.ZYH_ID) t
        where t.ZYH_ID = zsjh.ZYH_ID), zsjh.ZSJHRS =
      (
        select rs
        from (
               select
                 lsb.ZYH_ID,
                 count(lsb.ZKZH) rs
               from JW_XJGL_XSXXLSB lsb
               where lsb.NJDM_ID = v_njdm_id
               group by lsb.ZYH_ID) t
        where t.ZYH_ID = zsjh.ZYH_ID)
      where zsjh.NJDM_ID = v_njdm_id;
      --update zftal_xtgl_bjdmb zxrs
      update zftal_xtgl_bjdmb bj
      set bj.ZXRS =
      (select bjrs
       from (
              select
                zsjh.ZYH_ID,
                round(to_number(zsjh.ZSJHRS) / to_number(zsjh.BJS), 0) + 1 bjrs
              from JW_XJGL_NJZYZSJHB zsjh
              where zsjh.NJDM_ID = v_njdm_id)
            t
       where t.ZYH_ID = bj.zyh_id)
      where bj.NJDM_ID = v_njdm_id;
      commit;
      exception
      when others
      then
        rollback;
    end update_zsjhrsAndbjzxrs;
  function return_cdjkxyAnKsrs(v_cd_id in varchar2, v_xnm in varchar2, v_xqm in varchar2, v_kshkbj_id in varchar2)
    return varchar2
  is
    v_jkjgid varchar2(255);
    begin
      select t.jg_id
      into v_jkjgid
      from (
             select
               t.JG_ID,
               row_number()
               over (
                 partition by t.cd_id
                 order by crs desc ) rn
             from (
                    select
                      xsj.JG_ID,
                      xkb.cd_id,
                      count(xsj.XH_ID) crs
                    from JW_KW_XSKSXXB xkb, JW_XJGL_XSJBXXB xsj
                    where xkb.XH_ID = xsj.XH_ID
                          and xkb.XNM = v_xnm
                          and xkb.xqm = v_xqm
                          and xkb.SJBH_ID in (select dzb.SJBH_ID
                                              from JW_KW_KSDDBJDZB dzb
                                              where
                                                dzb.XNM = v_xnm and dzb.XQM = v_xqm and dzb.KSHKBJ_ID = v_kshkbj_id)
                          and xkb.CD_ID = v_cd_id
                    group by xkb.CD_ID, xsj.JG_ID
                    order by xsj.JG_ID) t) t
      where t.rn = 1;
      return v_jkjgid;
    end return_cdjkxyAnKsrs;
  function return_xnOrXqmc(v_xnorxqm varchar2)
    return varchar2 is
    v_mc varchar2(255);
    begin
      if v_xnorxqm = '3' or v_xnorxqm = '12'
      then
        select mc
        into v_mc
        from zftal_xtgl_jcsjb
        where lx = '0001' and dm = v_xnorxqm;
      else
        select XNMC
        into v_mc
        from JW_JCDM_XNB
        where xnm = v_xnorxqm;
      end if;
      return v_mc;
    end return_xnOrXqmc;
  function return_cdyyxq(v_yub_id varchar2, v_sign varchar2)
    return varchar2 is
    v_xq varchar2(255);
    begin
      --select '（'||WM_CONCAT(t.JYSJ)||'）' into v_xq from
      --(select t.YYXX_ID,substr('第'||FN_BITTOZC(2*ZCD)||'周星期'||replace(t.XQJ,'7','日')||'第'||FN_BITTOZC(t.jc*2)||'节',1,100) jysj
      --from JW_PK_JXCDYUYSJB t where t.zcd is not null and t.xqj is not null and t.jc is not null) t
      --where t.YYXX_ID=v_yub_id;
      --select
      --(select '第'||WM_CONCAT(FN_BITTOZC(2*zcd))||'周,星期' from (
      --select distinct  t.YYXX_ID,t.ZCD from JW_PK_JXCDYUYSJB t where t.YYXX_ID=
      --v_yub_id order by t.ZCD))||(select WM_CONCAT(xqj) from (
      --select distinct  t.YYXX_ID,t.xqj from JW_PK_JXCDYUYSJB t where t.YYXX_ID=
      --v_yub_id order by t.xqj))||(select '第'||WM_CONCAT(FN_BITTOZC(2*jc))||'节' from (
      --select distinct  t.YYXX_ID,t.jc from JW_PK_JXCDYUYSJB t where t.YYXX_ID=
      --v_yub_id order by t.jc)) into v_xq from dual;
      if v_sign = 'zc'
      then
        select WM_CONCAT(FN_BITTOZC(2 * zcd))
        into v_xq
        from
          (select distinct
             t.YYXX_ID,
             t.ZCD
           from JW_PK_JXCDYUYSJB t
           where t.YYXX_ID =
                 v_yub_id
           order by t.ZCD);
      end if;
      if v_sign = 'xq'
      then
        select WM_CONCAT(xqj)
        into v_xq
        from
          (select decode(t.xqj, '1', '一', '2', '二', '3', '三', '4', '四', '5', '五', '6', '六', '7', '日') xqj
           from (select distinct
                   t.yyxx_id,
                   t.xqj
                 from JW_PK_JXCDYUYSJB t
                 where t.YYXX_ID =
                       v_yub_id
                 order by t.XQJ) t);
      end if;
      if v_sign = 'jc'
      then
        select WM_CONCAT(FN_BITTOZC(2 * jc))
        into v_xq
        from
          (select distinct
             t.YYXX_ID,
             t.jc
           from JW_PK_JXCDYUYSJB t
           where t.YYXX_ID =
                 v_yub_id
           order by t.jc);
      end if;
      return v_xq;
    end;
  procedure update_xsCjJd(v_grade varchar2) is
    begin
      update JW_CJ_XSCJB cjb
      set cjb.jd = round((cjb.bfzcj - 50) / 10,
                         1)
      where cjb.xh_id in
            (select xh_id
             from JW_XJGL_XSJBXXB xsj
             where to_number(xsj.NJDM_ID) < 2018
                   and xsj.XJZTDM in
                       (select XJZTDM
                        from JW_XJGL_XJZTDMB
                        where sfyxj = '1'))
            and round((round(cjb.BFZCJ, 0) - 50) / 10, 1) <> round(to_number(cjb.JD), 1)
            and to_number(cjb.xnm) >= 2018
            and cjb.bfzcj > 59
            and cjb.CJXZM in ('01', '02', '16', '17');
      commit;
      --更新18级之后的学生绩点
      update JW_CJ_XSCJB cjb
      set cjb.jd = '4.0'
      where cjb.xh_id in
            (select xh_id
             from JW_XJGL_XSJBXXB xsj
             where to_number(xsj.NJDM_ID) >= 2018
                   and xsj.XJZTDM in
                       (select XJZTDM
                        from JW_XJGL_XJZTDMB
                        where sfyxj = '1'))
            and round((round(cjb.BFZCJ, 0) - 50) / 10, 1) <> round(to_number(cjb.JD), 1)
            and cjb.bfzcj >= 90
            and to_number(cjb.xnm) >= 2018
            and cjb.CJXZM in ('01', '02', '16', '17');
      commit;
    end;
  function jwKcdmIsUsed(v_kch varchar2)
    return int
    --返回0，则表示没有被落实过；否则被落实过
  is
    v_is_used int := 0;

    begin
      select nvl(count(distinct 1), 0)
      into v_is_used
      from JW_JXRW_JXBXXB jxb, jw_jh_kcdmb kc
      where jxb.kch_id = kc.kch_id and kc.kch = v_kch;
      --dbms_output.put_line(v_is_used);
      if v_is_used <= 0
      then
        select nvl(count(distinct 1), 0)
        into v_is_used
        from JW_CJ_XSCJB cjb
        where
          cjb.XNM >= (select to_char(to_number(zdz) - 5)
                      from zftal_xtgl_xtszb
                      where zs = '当前学年')
          and exists(select 'x'
                     from JW_JH_KCDMB kc
                     where cjb.KCH_ID = kc.KCH_ID and (kc.KCH = v_kch or kc.KCH_ID = v_kch));
      end if;
      return v_is_used;
    end;
  --计算学时分项周学时、非集中性实践教学环节的，集中性实践教学环节zhxs为1
  function jwKcXsfxZhxs(v_xs varchar2)
    return varchar2 is
    v_zhxs int;
    begin
      select case when to_number(v_xs) <= 32
        then '2'
             when to_number(v_xs) <= 48
               then '3'
             when to_number(v_xs) <= 64
               then '4'
             when to_number(v_xs) > 64
               then '6'
             else '0'
             end
      into v_zhxs
      from dual;
      return v_zhxs;
    end;
  procedure updateAndinsertJzg(sign varchar2) is
    begin
    --处理jzgxxb
----更新现有教师机构，当前状态，姓名，机构，职称信息
update jw_jg_jzgxxb jzg
set
jzg.xm=(select xm from view_likai_jzg where jgh=jzg.jgh),--姓名
jzg.dqzt=(select dqzt from view_likai_jzg where jgh=jzg.jgh),--当前状态
jzg.zcm=(select zcm from view_likai_jzg where jgh=jzg.jgh),--职称码
jzg.zcmc=(select zcmc from view_likai_jzg where jgh=jzg.jgh),--职称名称
jzg.jg_id=(select jg_id from view_likai_jzg where jgh=jzg.jgh),--机构
jzg.csrq=(select csrq from view_likai_jzg where jgh=jzg.jgh)--出生日期
where exists (select 'x' from view_likai_jzg where jgh=jzg.jgh);
commit;
----插入新增教师
insert into JW_JG_JZGXXB(jgh_id, jgh, xm, csrq, xbm, dqzt, zcmc, ZCM, JG_ID, skZg, JKZG)
select jgh_id, jgh, xm, csrq, xb xbm, dqzt, zcmc, ZCM, JG_ID, '1' skZg, '1' JKZG
from view_likai_jzg t
where not exists  (select jgh from JW_JG_JZGXXB where jgh=t.jgh);
commit;
--处理jzgshxxb
--更新jzgshxxb
update JW_JG_JZGSHXXB shb
set shb.zcm=(select zcm from likai_shzgDQXNXQ where jgh_id=shb.jgh_id),
shb.dqzt=(select dqzt from likai_shzgDQXNXQ where jgh_id=shb.jgh_id),
shb.jg_id=(select jg_id from likai_shzgDQXNXQ where jgh_id=shb.jgh_id)
where shb.jgh_id in  (select jgh_id from likai_shzgDQXNXQ )
and shb.xnm=(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学年')
and shb.xqm=(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学期');
commit;
------
update JW_JG_JZGSHXXB shb
set shb.zcm=(select zcm from likai_shzgRWXNXQ where jgh_id=shb.jgh_id),
shb.dqzt=(select dqzt from likai_shzgRWXNXQ where jgh_id=shb.jgh_id),
shb.jg_id=(select jg_id from likai_shzgRWXNXQ where jgh_id=shb.jgh_id)
where exists (select 'x' from likai_shzgRWXNXQ where jgh_id=shb.jgh_id)
and shb.xnm=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学年')
and shb.xqm=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学期');
commit;
--插入jzgshxxb
insert into jw_jg_jzgshxxb(xnm,xqm,jgh_id,jg_id,dqzt,jkzg,skzg,zcm)
select
(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学年') xnm,
(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学期') xqm,
jzg.JGH_ID,
jzg.JG_ID,
jzg.DQZT,
jzg.JKZG,
jzg.SKZG,
jzg.ZCM
from JW_JG_JZGXXB jzg
where not exists (select 'x' from JW_JG_JZGSHXXB shb
                  where
                  shb.XNM=(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学年')
                  and
                  shb.xqm=(select zdz from ZFTAL_XTGL_XTSZB where zs='当前学期')
                  and shb.JGH_ID=jzg.JGH_ID
                  )
union
select
(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学年') xnm,
(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学期') xqm,
jzg.JGH_ID,
jzg.JG_ID,
jzg.DQZT,
jzg.JKZG,
jzg.SKZG,
jzg.ZCM
from JW_JG_JZGXXB jzg
where not exists (select 'x' from JW_JG_JZGSHXXB shb
                  where
                  shb.XNM=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学年')
                  and
                  shb.xqm=(select zdz from ZFTAL_XTGL_XTSZB where zs='任务落实学期')
                  and shb.JGH_ID=jzg.JGH_ID
                  );
commit;
--更新用户表机构信息
update ZFTAL_XTGL_YHB yhb
      set yhb.JGDM = (select jg_id from view_likai_jzg where jgh = yhb.YHM)
where yhb.YHLX = 'teacher'
and exists(select 'x' from view_likai_jzg where jgh = yhb.yhm and jg_id<>yhb.jgdm );
commit;
---插入用户表
insert into ZFTAL_XTGL_YHB(xm, sfqy, sjly, jgdm, yhlx, yhm, kl, yhmmdj, PAGECOUNT)
select jzg.xm,
          '1'                     sfqy,
          'JW_JG_JZGXXB'          sjly,
          jzg.jg_id jgdm,
          'teacher'               yhlx,
          jzg.jgh,
          GETMD5('1234abc')       kl,
          '1'                     yhmmdj,
          '15'                    pagecount
        from JW_JG_JZGXXB jzg
        where jzg.JGH not in (select yhm from zftal_xtgl_yhb);
--插入到用户角色表，默认教师
insert into ZFTAL_XTGL_YHJSB(jsdm, yhm, SFMRJS)
  select 'js' jsdm,jzg.jgh,'1'  sfmrjs
  from JW_JG_JZGXXB jzg
  where jzg.JGH not in (select yhm from ZFTAL_XTGL_YHJSB) and jzg.jgh not like 's%';
commit;
--插入考试安排学年
      insert into jw_kw_jkjsxxb (jkjsxx_id, xnm, xqm, jgh_id, jgh, xm, xbm, jg_id, lyb, pqmks)
        select
          sys_guid()           jkjsxx_id,
          (select zdz
           from zftal_xtgl_xtszb
           where zs = '排考试学年') xnm,
          (select zdz
           from zftal_xtgl_xtszb
           where zs = '排考试学期') xqm,
          jzg.jgh_id,
          jzg.jgh,
          jzg.xm,
          jzg.xbm,
          jzg.jg_id,
          'jw_jg_jzgxxb'       lyb,
          '1'                  pqmks
        from jw_jg_jzgxxb jzg
        where jzg.jgh_id not in
              (select jgh_id
               from jw_kw_jkjsxxb
               where xnm =
                     (select zdz
                      from zftal_xtgl_xtszb
                      where zs = '排考试学年')
                     and xqm =
                         (select zdz
                          from zftal_xtgl_xtszb
                          where zs = '排考试学期'));
commit;
--      ---更新教师职称
--      update jw_jg_jzgxxb jzg
--      set jzg.zcmc =
--      (select zcmc
--       from likai_sjtb_jzgxxb
--       where jgh = jzg.jgh),
--        jzg.csrq   =
--        (select csrq
--         from likai_sjtb_jzgxxb
--         where jgh = jzg.jgh)
--      where jzg.jgh in (select jgh from likai_sjtb_jzgxxb);
--      update jw_jg_jzgxxb jzg
--      set jzg.zcm =
--      (select zcm
--       from JW_JG_ZYJSZCB t
--       where t.zcmc = jzg.ZCMC);
--      update jw_jg_jzgshxxb jzg
--      set jzg.zcm =
--      (select zcm
--       from jw_jg_jzgxxb
--       where jgh_id = jzg.jgh_id)
--      where jzg.xnm = (select zdz
--                       from zftal_xtgl_xtszb
--                       where zs = '当前学年')
--            and jzg.xqm = (select zdz
--                           from zftal_xtgl_xtszb
--                           where zs = '当前学期');
--      update jw_jg_jzgshxxb jzg
--      set jzg.zcm =
--      (select zcm
--       from jw_jg_jzgxxb
--       where jgh_id = jzg.jgh_id)
--      where jzg.xnm =
--            (select zdz
--             from zftal_xtgl_xtszb
--             where zs = '任务落实学年')
--            and jzg.xqm =
--                (select zdz
--                 from zftal_xtgl_xtszb
--                 where zs = '任务落实学期');
--      --插入到jzgxxb
--      insert into JW_JG_JZGXXB
--      (jgh_id, jgh, xm, csrq, xbm, dqzt, zcmc, ZCM, JG_ID, skZg, JKZG)
--        select
--          jzg.JGH_ID,
--          jzg.jgh,
--          jzg.xm,
--          jzg.CSRQ,
--          jzg.XB,
--          case
--          when jzg.DQZT = '101'
--            then
--              '1'
--          else
--            '0'
--          end                     dqzt,
--          jzg.ZCMC,
--          (select zcm
--           from JW_JG_ZYJSZCB
--           where zcmc = jzg.ZCMC) zcm,
--          (select jg_id
--           from ZFTAL_XTGL_JGDMB
--           where jgdm = jzg.JGDM) jg_id,
--          '1'                     skzg,
--          '1'                     jkzg
--        from LIKAI_SJTB_JZGXXB jzg
--        where jzg.JGH not in (select jgh
--                              from JW_JG_JZGXXB);
--      --插入到jzgshxxb，任务落实学年学期
--      insert into JW_JG_JZGSHXXB
--      (xnm, xqm, jgh_id, jg_id, dqzt, zcm, skzg, jkzg)
--        select
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '任务落实学年')   xnm,
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '任务落实学期')   xqm,
--          jzg.JGH_ID,
--          (select jg_id
--           from ZFTAL_XTGL_JGDMB
--           where jgdm = jzg.JGDM) jg_id,
--          case
--          when jzg.DQZT = '101'
--            then
--              '1'
--          else
--            '0'
--          end                     dqzt,
--          (select zcm
--           from JW_JG_ZYJSZCB
--           where zcmc = jzg.ZCMC) zcm,
--          '1'                     skzg,
--          '1'                     jkzg
--        from LIKAI_SJTB_JZGXXB jzg
--        where jzg.JGH not in
--              (select t2.jgh
--               from JW_JG_JZGSHXXB t1,JW_JG_JZGXXB t2
--               where t1.JGH_ID=t2.JGH_ID and xnm = (select zdz
--                            from zftal_xtgl_xtszb
--                            where zs = '任务落实学年')
--                     and xqm = (select zdz
--                                from zftal_xtgl_xtszb
--                                where zs = '任务落实学期'));
--      --插入到jzgshxxb，当前学年
--      insert into JW_JG_JZGSHXXB
--      (xnm, xqm, jgh_id, jg_id, dqzt, zcm, skzg, jkzg)
--        select
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '当前学年')     xnm,
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '当前学期')     xqm,
--          jzg.JGH_ID,
--          (select jg_id
--           from ZFTAL_XTGL_JGDMB
--           where jgdm = jzg.JGDM) jg_id,
--          case
--          when jzg.DQZT = '101'
--            then
--              '1'
--          else
--            '0'
--          end                     dqzt,
--          (select zcm
--           from JW_JG_ZYJSZCB
--           where zcmc = jzg.ZCMC) zcm,
--          '1'                     skzg,
--          '1'                     jkzg
--        from LIKAI_SJTB_JZGXXB jzg
--        where jzg.JGH not in
--              (select t2.jgh
--               from JW_JG_JZGSHXXB t1,JW_JG_JZGXXB t2
--               where t1.JGH_ID=t2.jgh_id and xnm =
--                     (select zdz
--                      from zftal_xtgl_xtszb
--                      where zs = '当前学年')
--                     and xqm =
--                         (select zdz
--                          from zftal_xtgl_xtszb
--                          where zs = '当前学期'));
--      --插入到用户表
--      insert into ZFTAL_XTGL_YHB
--      (xm, sfqy, sjly, jgdm, yhlx, yhm, kl, yhmmdj, PAGECOUNT)
--        select
--          jzg.xm,
--          '1'                     sfqy,
--          'JW_JG_JZGXXB'          sjly,
--          (select jg_id
--           from ZFTAL_XTGL_JGDMB
--           where jgdm = jzg.JGDM) jgdm,
--          'teacher'               yhlx,
--          jzg.jgh,
--          GETMD5('1234abc')       kl,
--          '1'                     yhmmdj,
--          '15'                    pagecount
--        from LIKAI_SJTB_JZGXXB jzg
--        where jzg.JGH not in (select yhm
--                              from zftal_xtgl_yhb);
--      --插入到用户角色表，默认教师
--      insert into ZFTAL_XTGL_YHJSB
--      (jsdm, yhm, SFMRJS)
--        select
--          'js' jsdm,
--          jzg.jgh,
--          '1'  sfmrjs
--        from LIKAI_SJTB_JZGXXB jzg
--        where jzg.JGH not in (select yhm
--                              from ZFTAL_XTGL_YHJSB);
--      --插入到监考教师信息表
--      insert into jw_kw_jkjsxxb (jkjsxx_id, xnm, xqm, jgh_id, jgh, xm, xbm, jg_id, lyb, pqmks)
--        select
--          sys_guid()           jkjsxx_id,
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '排考试学年') xnm,
--          (select zdz
--           from zftal_xtgl_xtszb
--           where zs = '排考试学期') xqm,
--          jzg.jgh_id,
--          jzg.jgh,
--          jzg.xm,
--          jzg.xbm,
--          jzg.jg_id,
--          'jw_jg_jzgxxb'       lyb,
--          '1'                  pqmks
--        from jw_jg_jzgxxb jzg
--        where jzg.jgh_id not in
--              (select jgh_id
--               from jw_kw_jkjsxxb
--               where xnm =
--                     (select zdz
--                      from zftal_xtgl_xtszb
--                      where zs = '排考试学年')
--                     and xqm =
--                         (select zdz
--                          from zftal_xtgl_xtszb
--                          where zs = '排考试学期'));
--      --更新教师机构信息,jg_likai_sjtb为自行创建的视图
--      update JW_JG_JZGXXB jzg
--      set JG_ID                        =
--      (select jg_id
--       from jg_likai_sjtb t
--       where t.jgh = jzg.jgh), jzg.DWH = jzg.jg_id
--      where exists(select 'x'
--                   from jg_likai_sjtb t
--                   where t.jgh = jzg.jgh);
--      --更新时盒中教师机构信息
--      update JW_JG_JZGSHXXB shb
--      set JG_ID =
--      (select jg_id
--       from JW_JG_JZGXXB jzg
--       where jzg.JGH_ID = shb.JGH_ID)
--      where (shb.XNM = (select zdz
--                        from ZFTAL_XTGL_XTSZB
--                        where zs in ('当前学年'))
--             and shb.XQM = (select zdz
--                            from ZFTAL_XTGL_XTSZB
--                            where zs in ('当前学期')))
--            or
--            (shb.XNM = (select zdz
--                        from ZFTAL_XTGL_XTSZB
--                        where zs in ('任务落实学年'))
--             and shb.XQM = (select zdz
--                            from ZFTAL_XTGL_XTSZB
--                            where zs in ('任务落实学期')));
--      --更新用户表中的机构信息
--      update ZFTAL_XTGL_YHB yhb
--      set yhb.JGDM = (select jg_id
--                      from JW_JG_JZGXXB
--                      where jgh = yhb.YHM)
--      where yhb.YHLX = 'teacher' and exists(select 'x'
--                                            from JG_LIKAI_SJTB
--                                            where jgh = yhb.yhm);
--      commit;
    end;
  procedure updateJxbCjBl(sign varchar2) is
    begin
      /*
更新成绩比例
0、先在系统中用界面设置为：CJFXBZ05，再执行后续的操作
1、18级的更新为 4：6（要使用代码）
思路：先找到18级的课程，改为：CJFXBL02中对应的
2、非18级的更新为：3：7（系统操作即可实现）
3、大学体育更新为3：2：5（系统操作即可实现）

--大学体育有保健课，是否按2：3：5
*/

      update jw_cj_xmblszb
      set xmblzbh = 'CJFXBZ02', xmbl_id = '7903D493B7053CDEE053206411ACFFE2', xmbl = '40', xmblbz = '平时成绩:40，期末成绩:60'
      where jxb_id in
            (select jxb_id
             from jw_jxrw_jxbxxb
             where xnm = (select zdz
                          from ZFTAL_XTGL_XTSZB
                          where zdm = 'DQXNM')
                   and xqm = (select zdz
                              from ZFTAL_XTGL_XTSZB
                              where zdm = 'DQXQM')
                   and kch_id in (select kch_id
                                  from jw_jh_kcdmb
                                  where qynj = '2018' and (kch like '18%' or kch like '19%'))
            )
            and xmbl_id = '7903D493B7013CDEE053206411ACFFE2';


      update jw_cj_xmblszb
      set xmblzbh = 'CJFXBZ02', xmbl_id = '7903D493B7063CDEE053206411ACFFE2', xmbl = '60', xmblbz = '平时成绩:40，期末成绩:60'
      where jxb_id in
            (select jxb_id
             from jw_jxrw_jxbxxb
             where xnm = (select zdz
                          from ZFTAL_XTGL_XTSZB
                          where zdm = 'DQXNM')
                   and xqm = (select zdz
                              from ZFTAL_XTGL_XTSZB
                              where zdm = 'DQXQM')
                   and kch_id in (select kch_id
                                  from jw_jh_kcdmb
                                  where qynj = '2018' and (kch like '18%' or kch like '19%'))
            )
            and xmbl_id = '7903D493B7023CDEE053206411ACFFE2';
      commit;
    end;
  function getKsaprs(v_xnm varchar2, v_xqm varchar2, v_sjbh_id varchar2, v_cd_id varchar2)
    return int
  is
    v_ksrs int;
    begin
      select sum(to_number(dzb.rs))
      into v_ksrs
      from JW_KW_KSDDB ddb, JW_KW_KSDDBJDZB dzb
      where ddb.XNM = v_xnm and ddb.xqm = v_xqm and ddb.XNM = dzb.XNM and ddb.xqm = dzb.XQM and ddb.CD_ID = v_cd_id and
            dzb.SJBH_ID = v_sjbh_id and ddb.kshkbj_id = dzb.kshkbj_id;
      --group by dzb.sjbh_id,ddb.cd_id;
      return v_ksrs;
    end;
  function getPjXyPjf(v_xnm varchar2, v_xqm varchar2, v_jg_id varchar2)
    return varchar2
  is
    v_fz varchar2(255);
    begin
      select t1.xyjqpjf || '#zpf' || t1.xyzppjf || '#bfz' || (select BFZPFpjf
                                                              from (
                                                                     select
                                                                       v.XNM,
                                                                       v.XQM,
                                                                       v.xn,
                                                                       v.xq,
                                                                       'xy'                              xy,
                                                                       v.JG_ID,
                                                                       v.jgmc,
                                                                       round(avg(to_number(v.BFZPF)), 4) bfzpfpjf
                                                                     from LIKAI_JXPJBASIC_VIEW v
                                                                     group by v.xnm, v.xqm, v.xn, v.xq, v.jg_id,
                                                                       v.jgmc) t2
                                                              where
                                                                t2.xnm = t1.xnm and t2.xqm = t1.xqm and
                                                                t2.jg_id = t1.jg_id)
      into v_fz
      from
        (select
           v.xnm,
           v.xqm,
           v.xn,
           v.xq,
           'xy'                              xy,
           v.jg_id,
           v.jgmc,
           round(avg(to_number(v.JQPF)), 4)  xyjqpjf,
           round(avg(to_number(v.JSZPF)), 4) xyzppjf
         from
           (select distinct
              v.XNm,
              v.xqm,
              v.xn,
              v.xq,
              v.JG_ID,
              v.jgmc,
              v.jgh,
              JQPF,
              JSZPF
            from LIKAI_JXPJBASIC_VIEW v) v
         group by v.xnm, v.xqm, v.xn, v.xq, v.jg_id, v.jgmc
         order by v.XNM, v.xqm, v.JG_ID) t1
      where t1.xnm = v_xnm and t1.xqm = v_xqm and t1.jg_id = v_jg_id;
      return v_fz;
    end;
  function getTklxByMbmc(v_mbid varchar2)
    return varchar2
  is
    v_tklx varchar2(255);
    begin
      select tklx
      into v_tklx
      from (
        select distinct case when mbb.PJMBMC like '%理论%'
          then 'lr'
                        when mbb.PJMBMC like '%实验%'
                          then 'sy'
                        else 'qt' end tklx
        from JW_PJ_JXBPFMXB mxb, JW_PJ_PJMBMCB mbb
        where mxb.PJMBMCB_ID = mbb.PJMBMCB_ID and mxb.JXBPFB_ID = v_mbid);
      return v_tklx;
    end;
  function getXnXqTklxZcs(v_xnm varchar2, v_xqm varchar2, v_jgh_id varchar2)
    return int
  is
    v_count int;
    begin

      select nvl(count(1), 0)
      into v_count
      from jw_pj_jxbpfb pfb
      where pfb.xnm = v_xnm and pfb.xqm = v_xqm and pfb.jgh_id = v_jgh_id
            and pfb.cpdxdm in ('03', '05') and exists(select 'x'
                                                      from jw_pj_tkjsb
                                                      where likai_ddsf not like '%校督导%');
      return v_count;
    end;
  procedure updateXbJxbMxdx(sign varchar2) is
    begin
      insert into JW_JXRW_MXDXB (mxdxb_id, xnm, xqm, jxb_id, xzlb, xqh_id, jg_id, njdm_id)
        select
          sys_guid()               mxdxb_id,
          jxb.XNM,
          jxb.XQM,
          jxb.jxb_id,
          'mx'                     xzlb,
          nvl(jxb.XQH_ID, '1')     xqh_id,
          jxb.KKBM_ID              jg_id,
          (to_number(jxb.XNM) - 1) njdm_id
        from jw_jxrw_jxbxxb jxb
        where (jxb.FJXB_ID is null or jxb.FJXB_ID = '1')
              and jxb.XNM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学年')
              and jxb.XQM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学期')
              and jxb.KCH_ID in (select kch_id
                                 from JW_JH_KCDMB
                                 where kch like '%XB%') and not exists(select 'x'
                                                                       from JW_JXRW_MXDXB mxb
                                                                       where mxb.JXB_ID = jxb.JXB_ID)
        union
        select
          sys_guid()               mxdxb_id,
          jxb.XNM,
          jxb.XQM,
          jxb.jxb_id,
          'mx'                     xzlb,
          nvl(jxb.XQH_ID, '1')     xqh_id,
          jxb.KKBM_ID              jg_id,
          (to_number(jxb.XNM) - 2) njdm_id
        from jw_jxrw_jxbxxb jxb
        where (jxb.FJXB_ID is null or jxb.FJXB_ID = '1')
              and jxb.XNM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学年')
              and jxb.XQM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学期')
              and jxb.KCH_ID in (select kch_id
                                 from JW_JH_KCDMB
                                 where kch like '%XB%') and not exists(select 'x'
                                                                       from JW_JXRW_MXDXB mxb
                                                                       where mxb.JXB_ID = jxb.JXB_ID)
        union
        select
          sys_guid()               mxdxb_id,
          jxb.XNM,
          jxb.XQM,
          jxb.jxb_id,
          'mx'                     xzlb,
          nvl(jxb.XQH_ID, '1')     xqh_id,
          jxb.KKBM_ID              jg_id,
          (to_number(jxb.XNM) - 3) njdm_id
        from jw_jxrw_jxbxxb jxb
        where (jxb.FJXB_ID is null or jxb.FJXB_ID = '1')
              and jxb.XNM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学年')
              and jxb.XQM = (select zdz
                             from ZFTAL_XTGL_XTSZB
                             where zs = '选课学期')
              and jxb.KCH_ID in (select kch_id
                                 from JW_JH_KCDMB
                                 where kch like '%XB%') and not exists(select 'x'
                                                                       from JW_JXRW_MXDXB mxb
                                                                       where mxb.JXB_ID = jxb.JXB_ID);
      commit;
    end;
  procedure deleteXwandBySh(sign varchar2) is
    begin
      delete from JW_BYGL_BYSHB shb
      where shb.BYND =
            (select max(bynf) nf
             from JW_BYGL_BYSFZXXB)
            and not exists(select 'x'
                           from JW_BYGL_BYSFZXXB t
                           where t.XH_ID = shb.XH_ID and t.BYNF = shb.BYND);
      delete from JW_BYGL_XWSHB shb
      where shb.BYND =
            (select max(bynf) nf
             from JW_BYGL_BYSFZXXB)
            and not exists(select 'x'
                           from JW_BYGL_BYSFZXXB t
                           where t.XH_ID = shb.XH_ID and t.BYNF = shb.BYND);
      commit;
    end;
function kctdsqxsxxbz(v_xh_id varchar2) return varchar2
is 
v_bz varchar2(2000);
begin
select dmb.XJYDMC||';生效学年学期:'||LIKAI_JW_PUBLICINTERFACE.RETURN_XNORXQMC(ydb.YDSXXNM)||'-'
||LIKAI_JW_PUBLICINTERFACE.RETURN_XNORXQMC(ydb.YDSXXQM)||',现学院专业年级:'||jg.jgmc||','||zy.zyh||','||zy.zymc||','||xjb.NJDM_ID
into v_bz
from JW_XJGL_XJYDB ydb ,JW_XJGL_XJYDLBDMB dmb,JW_XJGL_XSXJXXB xjb,ZFTAL_XTGL_ZYDMB zy,
     ZFTAL_XTGL_JGDMB jg
where ydb.XH_ID=v_xh_id
and ydb.YDLBm=dmb.YDLBM
and xjb.XNM=(select zdz from ZFTAL_XTGL_XTSZB where zs='选课学年')
and xjb.XQM=(select zdz from ZFTAL_XTGL_XTSZB where zs='选课学期')
and xjb.ZYH_ID=zy.ZYH_ID
and zy.JG_ID=jg.JG_ID
and ydb.XH_ID=xjb.XH_ID;
return v_bz;
end;
procedure likai_xywcqk(t_xh_id varchar2)
is
  v_xh_id        varchar(32);
  v_jxzxjhxx_id  varchar(32);
  v_njdm_id      varchar(32);
  v_zyh_id       varchar(32);
  sl             number;
  v_JDKCRDBJ     number;
  v_JDKCRDBJ_num number;
  v_xyjd         varchar(10);
  v_wc           varchar(10);
  v_yj           varchar(2);
  v_zyfx_id          varchar(32);
  v_xfyqjd_id        varchar(32);
  v_level            number;
  x                  number;
  iMaxjb             number;
  sJhwkcgs_sfmjd     varchar(8);
  sJhwkcgs_xfyqjd_id varchar(50);
  -- begin v_xh_id := '1620300078';
begin v_xh_id := t_xh_id;
  select nvl(bynjdm_id, njdm_id), nvl(byzyh_id, zyh_id) into v_njdm_id, v_zyh_id
  from jw_xjgl_xsxjxxb
  where xh_id = v_xh_id
    and xnm = (select zdz from zftal_xtgl_xtszb where zdm = 'DQXNM')
    and xqm = (select zdz from zftal_xtgl_xtszb where zdm = 'DQXQM');
  delete from JW_JH_xsJXZXJHXFYQXXB where xh_id = v_xh_id;
  delete from JW_JH_xsJXZXJHKCXXB where xh_id = v_xh_id;
  commit;
  select max(jxzxjhxx_id) into v_jxzxjhxx_id
  from jw_jh_jxzxjhxxb
  where njdm_id = v_njdm_id
    and zyh_id = v_zyh_id;
  select nvl(max(zyfx_id), 'wfx') into v_zyfx_id from jw_xjgl_xsjbxxb where xh_id = v_xh_id;
  select max(decode(sfmjd, sfmjd, sfmjd)),
         max(decode(xfyqjd_id, xfyqjd_id, xfyqjd_id)) into sJhwkcgs_sfmjd, sJhwkcgs_xfyqjd_id
  from jw_jh_jxzxjhxfyqxxb
  where jxzxjhxx_id = v_jxzxjhxx_id
    and xfyqjdmc = (select zdz from zftal_xtgl_xtszb where zdm = 'JHWKCGSJDMC')
    and rownum = 1;
  insert into JW_JH_xsJXZXJHXFYQXXB (xh_ID,
                                     XFYQJD_ID,
                                     XFYQJDMC,
                                     JDKCSX,
                                     ZYFX_ID,
                                     YQZDXF,
                                     YQZGXF,
                                     KCZDMS,
                                     KCZGMS,
                                     BYSHYQ,
                                     XFYQZJDGX,
                                     FXFYQJD_ID,
                                     PX,
                                     BZ,
                                     SFMJD,
                                     KCXZDM,
                                     XDLX,
                                     XFYQJDYWMC)
  select v_xh_id,
         XFYQJD_ID,
         XFYQJDMC,
         '1'                  JDKCSX,
         ZYFX_ID,
         case
           when fxfyqjd_id is null and xdlx = 'zx' then (select zdxf
                                                         from jw_jh_jxzxjhxxb
                                                         where jxzxjhxx_id = v_jxzxjhxx_id)
           else YQZDXF end as YQZDXF,
         YQZGXF,
         KCZDMS,
         KCZGMS,
         BYSHYQ,
         XFYQZJDGX,
         FXFYQJD_ID,
         PX,
         BZ,
         SFMJD,
         KCXZDM,
         XDLX,
         XFYQJDYWMC
  from JW_JH_JXZXJHXFYQXXB
  where jxzxjhxx_id = v_jxzxjhxx_id
    and xdlx = 'zx'
    and decode(zyfx_id, 'wfx', 1, v_zyfx_id, 2, 0) > 0;
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.YQZDXF = case
                   when nvl(a.YQZDXF, '0') = '0' then (select sum(b.YQZDXF)
                                                       from JW_JH_xsJXZXJHXFYQXXB b
                                                       where a.xfyqjd_id = b.fxfyqjd_id
                                                         and b.xdlx = 'zx'
                                                         and b.xh_id = v_xh_id)
                   else to_number(a.YQZDXF) end
  where a.fxfyqjd_id is null
    and a.xdlx = 'zx'
    and a.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHXFYQXXB
  set jb = 1
  where FXFYQJD_ID is null
    and XDLX = 'zx'
    and xh_id = v_xh_id;
  for x in 2 .. 10 loop update JW_JH_xsJXZXJHXFYQXXB a
                        set a.jb = x
                        where a.jb is null
                          and a.XDLX = 'zx'
                          and a.xh_id = v_xh_id
                          and exists(select 'X'
                                     from JW_JH_xsJXZXJHXFYQXXB b
                                     where a.fxfyqjd_id = b.xfyqjd_id
                                       and b.XDLX = 'zx'
                                       and b.xh_id = v_xh_id
                                       and b.jb = x - 1);
  end loop;
  select max(jb) - 1 into iMaxjb
  from JW_JH_xsJXZXJHXFYQXXB
  where XDLX = 'zx'
    and xh_id = v_xh_id;
  insert into JW_JH_xsJXZXJHKCXXB (xnm,
                                   xqm,
                                   Njdm_id,
                                   zyh_id,
                                   zyfx_id,
                                   xh_id,
                                   kclbdm,
                                   kcxzdm,
                                   sskch_id,
                                   kch_id,
                                   kch,
                                   kcmc,
                                   kcywmc,
                                   cj,
                                   bfzcj,
                                   jd,
                                   cjbz,
                                   CJLYBJ,
                                   HDXF,
                                   XF,
                                   kcgsdm)
  select xnm,
         xqm,
         v_njdm_id,
         v_zyh_id,
         'wfx' as                           zyfx_id,
         xh_id,
         kclbdm,
         kcxzdm,
         sskch_id,
         (case
            when length(sskch_id) = 1 then kch_id
            else nvl(sskch_id, kch_id) end) kch_id,
         kch,
         kcmc,
         kcywmc,
         maxcj,
         maxbfzcj,
         maxjd,
         maxcjbz,
         ly,
         case
           when maxbfzcj >= 60 then xf
           else null end                    hdxf,
         xf,
         kcgsdm
  from (select 'cjb'                                                                                               as ly,
               t.xnm,
               t.xqm,
               t.njdm_id,
               t.jg_id,
               t.zyh_id,
               t.zyfx_id,
               t.bh_id,
               t.xh_id,
               t.xh,
               t.xm,
               t.xbm,
               t.kcxzdm,
               t.kclbdm,
               t.kcgsdm,
               t.sskch_id,
               t.kch_id,
               t.kch,
               t.kcmc,
               t.kcywmc,
               t.xf,
               t.jxb_id,
               t.kcbj,
               t.cj,
               t.bfzcj,
               t.cjbz,
               t.hkcj,
               fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm, t.cjxzm,
                       t.kcbj, null, t.cjbz, t.jd, t.bfzcj, case
                                                              when t.tdkcbj = '1' then 'cjb-dtkc'
                                                              when t.btdkcbj = '1' then 'cjb-bdtkc'
                                                              else 'cjb' end, 'tj',
                       '0')                                                                                        as jd,
               t.cjxzm,
               decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkcj, nvl(t.mbybfzcj, 0),
                      t.mbycj)                                                                                     as mbkcj,
               decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkbfzcj,
                      nvl(t.mbybfzcj, 0),
                      t.mbybfzcj)                                                                                  as mbkbfzcj,
               decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkjd, nvl(t.mbybfzcj, 0),
                      t.mbyjd)                                                                                     as mbkjd,
               decode(GREATEST(nvl(t.mbkbfzcj, 0), nvl(t.mbybfzcj, 0)), nvl(t.mbkbfzcj, 0), t.mbkcjbz,
                      nvl(t.mbybfzcj, 0),
                      t.mbycjbz)                                                                                   as mbkcjbz,
               t.mbkcj                                                                                             as mbkcj1,
               mbkbfzcj                                                                                            as mbkbfzcj1,
               t.mbkjd                                                                                             as mbkjd1,
               t.mbkcjbz                                                                                           as mbkcjbz1,
               t.mbycj,
               t.mbybfzcj,
               t.mbyjd,
               t.mbycjbz,
               t.mcxcj,
               t.mcxbfzcj,
               t.mcxjd,
               t.mcxcjbz,
               nvl(t.bkcs, 0)                                                                                         bkcs,
               t.ksrq,
               nvl(t.cxcs, 0)                                                                                         cxcs,
               t.cxcj1,
               t.cxbfzcj1,
               t.cxjd1,
               t.cxcj2,
               t.cxbfzcj2,
               t.cxjd2,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cj, nvl(mbkbfzcj, 0),
                      mbkcj)                                                                                       as mzbcj,
               GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0))                                                           as mzbbfzcj,
               fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm, t.cjxzm,
                       t.kcbj, null,
                       decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0),
                              mbkcjbz),
                       decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), jd, nvl(mbkbfzcj, 0), mbkjd),
                       GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), case
                                                                    when t.tdkcbj = '1' then 'cjb-dtkc'
                                                                    when t.btdkcbj = '1' then 'cjb-bdtkc'
                                                                    else 'cjb' end, 'tj',
                       '0')                                                                                        as mzbjd,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0),
                      mbkcjbz)                                                                                     as mzbcjbz,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0)), nvl(bfzcj, 0), (case
                                                                                   when cjxzm in ('16') then 'cx'
                                                                                   when cjxzm in ('21', '22')
                                                                                           then 'bybk'
                                                                                   when cjbz = '缓考' or hkcj is not null
                                                                                           then 'hk'
                                                                                   else 'zk' end), nvl(mbkbfzcj, 0),
                      'bk')                                                                                        as mzbcjbj,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)), nvl(bfzcj, 0), cj,
                      nvl(mbkbfzcj, 0), mbkcj, nvl(mcxbfzcj, 0), mcxcj, nvl(mbybfzcj, 0),
                      mbycj)                                                                                       as maxcj,
               GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0),
                        nvl(mbybfzcj, 0))                                                                          as maxbfzcj,
               fn_jdjs(t.xnm, t.xqm, t.sskch_id, t.kch_id, t.kcmc, t.jxb_id, t.xh_id, t.kcxzdm, t.kclbdm, t.cjxzm,
                       t.kcbj, null,
                       decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                              nvl(bfzcj, 0), cjbz, nvl(mbkbfzcj, 0), mbkcjbz, nvl(mcxbfzcj, 0), mcxcjbz,
                              nvl(mbybfzcj, 0), mbycjbz),
                       decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                              nvl(bfzcj, 0), jd, nvl(mbkbfzcj, 0), mbkjd, nvl(mcxbfzcj, 0), mcxjd, nvl(mbybfzcj, 0),
                              mbyjd), GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)),
                       case
                         when t.tdkcbj = '1' then 'cjb-dtkc'
                         when t.btdkcbj = '1' then 'cjb-bdtkc'
                         else 'cjb' end, 'tj',
                       '0')                                                                                        as maxjd,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)), nvl(bfzcj, 0),
                      cjbz, nvl(mbkbfzcj, 0), mbkcjbz, nvl(mcxbfzcj, 0), mcxcjbz, nvl(mbybfzcj, 0),
                      mbycjbz)                                                                                     as maxcjbz,
               decode(GREATEST(nvl(bfzcj, 0), nvl(mbkbfzcj, 0), nvl(mcxbfzcj, 0), nvl(mbybfzcj, 0)), nvl(bfzcj, 0),
                      (case
                         when cjxzm in ('16') then 'cx'
                         when cjxzm in ('21', '22') then 'bybk'
                         when cjbz = '缓考' or hkcj is not null then 'hk'
                         else 'zk' end), nvl(mbkbfzcj, 0), 'bk', nvl(mcxbfzcj, 0), 'cx', nvl(mbybfzcj, 0),
                      'bybk')                                                                                      as maxcjbj,
               t.tdkcbj,
               t.btdkcbj,
               (select count(1)
                from jw_jh_jxzxjhkcxxb
                where njdm_id = t.njdm_id
                  and zyh_id = t.zyh_id
                  and kch_id = t.kch_id
                  and rownum = 1)                                                                                     sfjhkc
        from (select t1.xnm,
                     t1.xqm,
                     t1.kcxzdm,
                     t1.xf,
                     t1.jg_id,
                     t1.njdm_id,
                     t1.zyh_id,
                     t1.zyfx_id,
                     t1.bh_id,
                     t1.xh_id,
                     t1.xh,
                     t1.xm,
                     t1.xbm,
                     t1.kclbdm,
                     t1.kcgsdm,
                     t1.sskch_id,
                     t1.kch_id,
                     t1.kch,
                     t1.kcmc,
                     t1.kcywmc,
                     t1.jxb_id,
                     t1.kcbj,
                     t1.hkcj,
                     (select count(1)
                      from jw_cj_xsgrcjdtb cjdtb
                      where cjdtb.zszt = '3'
                        and t1.xh_id = cjdtb.xh_id
                        and (case
                               when length(t1.sskch_id) = 1 or t1.sskch_id is null then t1.kch_id
                               else t1.sskch_id end) = cjdtb.kch_id
                        and cjdtb.kcthzbm = 'xnkc'
                        and rownum = 1)                 as tdkcbj,
                     (select count(1)
                      from jw_cj_xsgrdtzb m,
                           jw_cj_xsgrjhdtb n
                      where m.kcthzh_id = n.kcthzh_id
                        and m.kcthzbm = 'xnkc'
                        and m.zszt = '3'
                        and n.kch_id = (case
                                          when length(t1.sskch_id) = 1 or t1.sskch_id is null then t1.kch_id
                                          else t1.sskch_id end)
                        and n.xh_id = t1.xh_id
                        and rownum = 1)                 as btdkcbj,
                     case
                       when t1.cjxzm in ('16', '21', '22') then null
                       else (case
                               when t1.hkcj is null then nvl(t1.cj, t1.cjbz)
                               else t1.hkcj end) end    as cj,
                     case
                       when t1.cjxzm in ('16', '21', '22') then null
                       else (case
                               when t1.hkcj is null then t1.bfzcj
                               else t1.hkbfzcj end) end as bfzcj,
                     case
                       when t1.cjxzm in ('16', '21', '22') then null
                       else (case
                               when t1.hkcj is null then t1.cjbz
                               else t1.hkbz end) end    as cjbz,
                     case
                       when t1.cjxzm in ('16', '21', '22') then null
                       else (case
                               when t1.hkcj is null then t1.jd
                               else t1.hkjd end) end    as jd,
                     t1.cjxzm,
                     t1.bkcj                            as mbkcj,
                     t1.bkbfzcj                         as mbkbfzcj,
                     t1.bkbz                            as mbkcjbz,
                     t1.bkjd                            as mbkjd,
                     t2.mbycj                           as mbycj,
                     t2.mbybfzcj                        as mbybfzcj,
                     t2.mbyjd                           as mbyjd,
                     t2.mbycjbz                         as mbycjbz,
                     t3.mcxcj                           as mcxcj,
                     t3.mcxbfzcj                        as mcxbfzcj,
                     t3.mcxjd                           as mcxjd,
                     t3.mcxcjbz                         as mcxcjbz,
                     t1.bkcs,
                     t1.ksrq,
                     t3.cxcs,
                     t3.cxcj1,
                     t3.cxbfzcj1,
                     t3.cxjd1,
                     t3.cxcj2,
                     t3.cxbfzcj2,
                     t3.cxjd2
              from (select XNM,
                           XQM,
                           njdm_id,
                           jg_id,
                           zyh_id,
                           zyfx_id,
                           bh_id,
                           XH_ID,
                           xh,
                           xm,
                           xbm,
                           sskch_id,
                           KCH_ID,
                           KCH,
                           KCMC,
                           KCYWMC,
                           XF,
                           KCXZDM,
                           KCLBDM,
                           KCGSDM,
                           JXB_ID,
                           CJ,
                           BFZCJ,
                           CJBZ,
                           JD,
                           CJXZM,
                           KCBJ,
                           BZXX,
                           bkcj,
                           bkbfzcj,
                           bkbz,
                           bkjd,
                           hkcj,
                           hkbfzcj,
                           hkbz,
                           hkjd,
                           bkcs,
                           ksrq
                    from (select a.XNM,
                                 a.XQM,
                                 b.jg_id,
                                 b.njdm_id,
                                 b.zyh_id,
                                 nvl(b.zyfx_id, 'wfx')                                                                 zyfx_id,
                                 b.bh_id,
                                 a.XH_ID,
                                 b.xh,
                                 b.xm,
                                 b.xbm,
                                 a.sskch_id,
                                 a.KCH_ID,
                                 nvl(kc.kch, a.KCH)                                                                 as kch,
                                 nvl(kc.kcmc, a.KCMC)                                                               as kcmc,
                                 nvl(kc.kcywmc, a.KCYWMC)                                                           as kcywmc,
                                 a.XF,
                                 a.KCXZDM,
                                 a.KCLBDM,
                                 a.KCGSDM,
                                 a.JXB_ID,
                                 a.CJ,
                                 a.BFZCJ,
                                 a.CJBZ,
                                 a.JD,
                                 a.CJXZM,
                                 a.KCBJ,
                                 a.BZXX,
                                 a.ksrq,
                                 a.bkcj,
                                 a.bkbfzcj,
                                 a.bkbz,
                                 fn_jdjs(a.xnm, a.xqm, a.sskch_id, a.kch_id, a.kcmc, a.jxb_id, a.xh_id, a.kcxzdm,
                                         a.kclbdm, '11', a.kcbj, null, a.bkbz, a.bkjd, a.bkbfzcj, 'cjb', 'tj',
                                         '0')                                                                       as bkjd,
                                 a.hkcj,
                                 a.hkbfzcj,
                                 a.hkbz,
                                 a.hkjd,
                                 a.bkcs,
                                 row_number() over (partition by a.xh_id, case when length(a.sskch_id) = 1
                                   then a.sskch_id || '-' || a.kch_id
                                                                          else nvl(a.sskch_id, a.kch_id) end
                                   order by to_number(a.cjxzm), to_number(
                                       nvl(a.hkbfzcj, a.bfzcj)) desc, a.xnm, to_number(a.xqm))                         rn
                          from JW_CJ_XSCJB a,
                               jw_xjgl_xsjbxxb b,
                               jw_jh_kcdmb kc
                          where a.xh_id = b.xh_id
                            and a.cjxzm in ('01', '16', '21', '22')
                            and not exists(select 'X'
                                           from jw_cj_cjjglxsqb zfb
                                           where zfb.cjjglx = '01'
                                             and zfb.shzt = '3'
                                             and zfb.xh_id = a.xh_id
                                             and zfb.jxb_id = a.jxb_id)
                            and a.kch_id = kc.kch_id (+)
                            and not exists(select 1
                                           from jw_cj_bzdmb c
                                           where (case
                                                    when a.hkcj is null then a.cjbz
                                                    else a.hkbz end) = c.cjbzmc
                                             and c.cjtjfx = '0')
                            and b.xh_id = v_xh_id
                            and a.cjzt = '3'
                            and a.kcbj = '0'
                            and not exists(select 'X'
                                           from jw_cj_xfrdb rdb,
                                                jw_cj_xfrdmxb rdmxb
                                           where rdb.xrdz_id = rdmxb.rdz_id
                                             and (case
                                                    when length(a.sskch_id) = 1 or a.sskch_id is null then a.kch_id
                                                    else a.sskch_id end) = rdmxb.kch_id
                                             and a.xh_id = rdb.xh_id
                                             and rdb.rdlybj = '0'
                                             and rdb.shjg = '3'))
                    where rn = '1') t1
                     left join (select XH_ID,
                                       sskch_id,
                                       KCH_ID,
                                       CJ    as MBYCJ,
                                       BFZCJ as MBYBFZCJ,
                                       JD    as MBYJD,
                                       CJBZ  as MBYCJBZ
                                from (select t1.XH_ID,
                                             t1.sskch_id,
                                             t1.KCH_ID,
                                             t1.CJ,
                                             t1.BFZCJ,
                                             fn_jdjs(t1.xnm, t1.xqm, t1.sskch_id, t1.kch_id, t1.kcmc, t1.jxb_id,
                                                     t1.xh_id, t1.kcxzdm, t1.kclbdm, t1.cjxzm, t1.kcbj, null, t1.cjbz,
                                                     t1.jd, t1.bfzcj, 'cjb', 'tj', '0') as JD,
                                             t1.CJBZ,
                                             row_number() over (partition by t1.xh_id, case when length(t1.sskch_id) = 1
                                               then t1.sskch_id || '-' || t1.kch_id
                                                                                       else nvl(t1.sskch_id,
                                                                                                t1.kch_id) end
                                               order by t1.bfzcj desc)                     rn
                                      from JW_CJ_XSCJB t1,
                                           jw_xjgl_xsjbxxb t2
                                      where t1.xh_id = t2.xh_id
                                        and t1.cjxzm in ('21', '22')
                                        and not exists(select 'X'
                                                       from jw_cj_cjjglxsqb zfb
                                                       where zfb.cjjglx = '01'
                                                         and zfb.shzt = '3'
                                                         and zfb.xh_id = t1.xh_id
                                                         and zfb.kch_id = t1.kch_id)
                                        and t2.xh_id = v_xh_id)
                                where rn = '1') t2 on t1.xh_id = t2.xh_id and case
                                                                                when length(t1.sskch_id) = 1
                                                                                        then t1.sskch_id || '-' || t1.kch_id
                                                                                else nvl(t1.sskch_id, t1.kch_id) end =
                                                                              case
                                                                                when length(t2.sskch_id) = 1
                                                                                        then t2.sskch_id || '-' || t2.kch_id
                                                                                else nvl(t2.sskch_id, t2.kch_id) end
                     left join (select XH_ID,
                                       sskch_id,
                                       case
                                         when length(sskch_id) = 1 then sskch_id || '-' || kch_id
                                         else nvl(sskch_id, kch_id) end as KCH_ID,
                                       MAX(decode(rn, '1', CJ))         as MCXCJ,
                                       MAX(decode(rn, '1', BFZCJ))      as MCXBFZCJ,
                                       MAX(decode(rn, '1', JD))         as MCXJD,
                                       MAX(decode(rn, '1', CJBZ))       as MCXCJBZ,
                                       cxcs,
                                       MAX(decode(minrn, '1', CJ))      as CXCJ1,
                                       MAX(decode(minrn, '1', BFZCJ))   as CXBFZCJ1,
                                       MAX(decode(minrn, '1', JD))      as CXJD1,
                                       MAX(decode(minrn, '2', CJ))      as CXCJ2,
                                       MAX(decode(minrn, '2', BFZCJ))   as CXBFZCJ2,
                                       MAX(decode(minrn, '2', JD))      as CXJD2
                                from (select t1.XH_ID,
                                             t1.sskch_id,
                                             t1.KCH_ID,
                                             nvl(t1.hkcj, t1.cj)                                                      as CJ,
                                             (case
                                                when t1.hkcj is null then t1.bfzcj
                                                else t1.hkbfzcj end)                                                  as BFZCJ,
                                             fn_jdjs(t1.xnm, t1.xqm, t1.sskch_id, t1.kch_id, t1.kcmc, t1.jxb_id,
                                                     t1.xh_id, t1.kcxzdm, t1.kclbdm, t1.cjxzm, t1.kcbj, null, (case
                                                                                                                 when t1.hkcj is null
                                                                                                                         then t1.cjbz
                                                                                                                 else t1.hkbz end),
                                                     (case
                                                        when t1.hkcj is null then t1.jd
                                                        else t1.hkjd end), (case
                                                                              when t1.hkcj is null then t1.bfzcj
                                                                              else t1.hkbfzcj end), 'cjb', 'tj',
                                                     '0')                                                             as JD,
                                             (case
                                                when t1.hkcj is null then t1.cjbz
                                                else t1.hkbz end)                                                     as CJBZ,
                                             row_number() over (partition by t1.xh_id, case when length(t1.sskch_id) = 1
                                               then t1.sskch_id || '-' || t1.kch_id
                                                                                       else nvl(t1.sskch_id,
                                                                                                t1.kch_id) end
                                               order by to_number(nvl(t1.hkbfzcj,
                                                                      t1.bfzcj)) desc)                                   rn,
                                             row_number() over (partition by t1.xh_id, case when length(t1.sskch_id) = 1
                                               then t1.sskch_id || '-' || t1.kch_id
                                                                                       else nvl(t1.sskch_id,
                                                                                                t1.kch_id) end
                                               order by t1.xnm, to_number(
                                                   t1.xqm))                                                              minrn,
                                             count(distinct case
                                                              when instr(',' || nvl('null', 'y') || ',',
                                                                         ',' || nvl(t1.cjbz, 'xx') || ',') = 0 and
                                                                   t1.cjxzm = '16' then t1.jxb_id
                                                              else null end) over (partition by t1.xh_id, nvl(
                                                 t1.sskch_id, t1.kch_id))                                                cxcs
                                      from JW_CJ_XSCJB t1,
                                           jw_xjgl_xsjbxxb t2
                                      where t1.xh_id = t2.xh_id
                                        and t1.cjxzm in ('16', '17')
                                        and not exists(select 'X'
                                                       from jw_cj_cjjglxsqb zfb
                                                       where zfb.cjjglx = '01'
                                                         and zfb.shzt = '3'
                                                         and zfb.xh_id = t1.xh_id
                                                         and zfb.kch_id = t1.kch_id)
                                        and t2.xh_id = v_xh_id)
                                where (rn = '1' or minrn in ('1', '2'))
                                group by XH_ID, sskch_id, case
                                                            when length(sskch_id) = 1 then sskch_id || '-' || kch_id
                                                            else nvl(sskch_id, kch_id) end, cxcs) t3
                       on t1.xh_id = t3.xh_id and case
                                                    when length(t1.sskch_id) = 1 then t1.sskch_id || '-' || t1.kch_id
                                                    else nvl(t1.sskch_id, t1.kch_id) end = t3.kch_id) t
        union all select 'bxwxfrdkc'                                                                                 as ly,
                         rdmxb.xnm,
                         rdmxb.xqm,
                         b.njdm_id,
                         b.jg_id,
                         b.zyh_id,
                         nvl(b.zyfx_id, 'wfx')                                                                          zyfx_id,
                         b.bh_id,
                         b.xh_id,
                         b.xh,
                         b.xm,
                         b.xbm,
                         rdmxb.kcxzdm,
                         rdmxb.kclbdm,
                         null                                                                                        as kcgsdm,
                         null                                                                                        as sskch_id,
                         rdmxb.kch_id,
                         null                                                                                        as kch,
                         rdmxb.kcmc,
                         rdmxb.kcywmc,
                         to_char(rdmxb.xf)                                                                           as xf,
                         null                                                                                        as jxb_id,
                         '0'                                                                                         as kcbj,
                         rdmxb.cj,
                         rdmxb.bfzcj,
                         null                                                                                        as cjbz,
                         null                                                                                        as hkcj,
                         fn_jdjs(rdmxb.xnm, rdmxb.xqm, null, rdmxb.kch_id, rdmxb.kcmc, null, b.xh_id, rdmxb.kcxzdm,
                                 rdmxb.kclbdm, '01', '0', null, null, rdmxb.jd, rdmxb.bfzcj, 'bxwxfrdkc', 'tj',
                                 '0')                                                                                as jd,
                         '01'                                                                                        as cjxzm,
                         null                                                                                        as mbkcj,
                         null                                                                                        as mbkbfzcj,
                         null                                                                                        as mbkjd,
                         null                                                                                        as mbkcjbz,
                         null                                                                                        as mbkcj1,
                         null                                                                                        as mbkbfzcj1,
                         null                                                                                        as mbkjd1,
                         null                                                                                        as mbkcjbz1,
                         null                                                                                        as mbycj,
                         null                                                                                        as mbybfzcj,
                         null                                                                                        as mbyjd,
                         null                                                                                        as mbycjbz,
                         null                                                                                        as mcxcj,
                         null                                                                                        as mcxbfzcj,
                         null                                                                                        as mcxjd,
                         null                                                                                        as mcxcjbz,
                         null                                                                                        as bkcs,
                         null                                                                                        as ksrq,
                         null                                                                                        as cxcs,
                         null                                                                                        as cxcj1,
                         null                                                                                        as cxbfzcj1,
                         null                                                                                        as cxjd1,
                         null                                                                                        as cxcj2,
                         null                                                                                        as cxbfzcj2,
                         null                                                                                        as cxjd2,
                         rdmxb.cj                                                                                    as mzbcj,
                         rdmxb.bfzcj                                                                                 as mzbbfzcj,
                         fn_jdjs(rdmxb.xnm, rdmxb.xqm, null, rdmxb.kch_id, rdmxb.kcmc, null, b.xh_id, rdmxb.kcxzdm,
                                 rdmxb.kclbdm, '01', '0', null, null, rdmxb.jd, rdmxb.bfzcj, 'bxwxfrdkc', 'tj',
                                 '0')                                                                                as mzbjd,
                         null                                                                                        as mzbcjbz,
                         'zk'                                                                                        as mzbcjbj,
                         rdmxb.cj                                                                                    as maxcj,
                         rdmxb.bfzcj                                                                                 as maxbfzcj,
                         fn_jdjs(rdmxb.xnm, rdmxb.xqm, null, rdmxb.kch_id, rdmxb.kcmc, null, b.xh_id, rdmxb.kcxzdm,
                                 rdmxb.kclbdm, '01', '0', null, null, rdmxb.jd, rdmxb.bfzcj, 'bxwxfrdkc', 'tj',
                                 '0')                                                                                as maxjd,
                         null                                                                                        as maxcjbz,
                         'zk'                                                                                        as maxcjbj,
                         0                                                                                           as tdkcbj,
                         1                                                                                           as tdkcbj,
                         0                                                                                           as sfjhkc
                  from jw_cj_xfrdb rdb,
                       jw_cj_xfrdmxb rdmxb,
                       jw_xjgl_xsjbxxb b
                  where rdb.xrdz_id = rdmxb.rdz_id
                    and rdb.xh_id = b.xh_id
                    and rdb.rdlybj = '0'
                    and rdb.shjg = '3'
                    and b.xh_id = v_xh_id) t1;
  select count(1) into v_JDKCRDBJ_num from jw_jcdml_xtnzb where zdm = 'JDKCRDBJ';
  if v_JDKCRDBJ_num > 0
  then select zdz into v_JDKCRDBJ from jw_jcdml_xtnzb where zdm = 'JDKCRDBJ';
  else v_JDKCRDBJ := 0; end if;
  insert into JW_JH_xsJXZXJHKCXXB (xh_ID,
                                   KCH_ID,
                                   KCH,
                                   KCMC,
                                   KCYWMC,
                                   XFYQJD_ID,
                                   XBX,
                                   JYXDXNM,
                                   JYXDXQM,
                                   ZXBJ,
                                   FXBJ,
                                   EZYBJ,
                                   EXWBJ,
                                   ZYHXKCBJ,
                                   ZYFX_ID,
                                   BZ,
                                   SQR,
                                   SQSJ,
                                   SHZT,
                                   ZZSHR,
                                   ZZSHSJ,
                                   XQH_ID,
                                   ZYZGKCBJ,
                                   KCXZDM,
                                   KSFSDM,
                                   NJDM_ID,
                                   ZYH_ID,
                                   KCLBDM,
                                   XF,
                                   HDXF,
                                   KKBM_ID,
                                   KSXSDM,
                                   KHFSDM,
                                   QSJSZ)
  select v_xh_id,
         t1.KCH_ID,
         (select kch from jw_jh_kcdmb where kch_id = t1.kch_id)    as kch,
         (select kcmc from jw_jh_kcdmb where kch_id = t1.kch_id)   as kcmc,
         (select kcywmc from jw_jh_kcdmb where kch_id = t1.kch_id) as kcywmc,
         t1.XFYQJD_ID,
         t1.XBX,
         t1.JYXDXNM,
         t1.JYXDXQM,
         t1.ZXBJ,
         t1.FXBJ,
         t1.EZYBJ,
         t1.EXWBJ,
         t1.ZYHXKCBJ,
         t2.ZYFX_ID,
         t1.BZ,
         t1.SQR,
         t1.SQSJ,
         t1.SHZT,
         t1.ZZSHR,
         t1.ZZSHSJ,
         t1.XQH_ID,
         t1.ZYZGKCBJ,
         t1.KCXZDM,
         t1.KSFSDM,
         t1.NJDM_ID,
         t1.ZYH_ID,
         t1.KCLBDM,
         t1.XF,
         '0'                                                       as hdxf,
         t1.KKBM_ID,
         t1.KSXSDM,
         t1.KHFSDM,
         t1.QSJSZ
  from JW_JH_JXZXJHKCXXB t1,
       JW_JH_JXZXJHXFYQXXB t2
  where t1.xfyqjd_id = t2.xfyqjd_id
    and t2.jxzxjhxx_id = v_jxzxjhxx_id
    and t1.njdm_id = v_njdm_id
    and t1.zyh_id = v_zyh_id
    and t2.xdlx = 'zx'
    and decode(t2.zyfx_id, 'wfx', 1, v_zyfx_id, 2, 0) > 0
    and not exists(select 'X'
                   from JW_JH_xsJXZXJHKCXXB ykcxxb
                   where ykcxxb.xh_id = v_xh_id
                     and (case
                            when v_JDKCRDBJ = '1' then nvl(t1.kcxzdm, '-1')
                            else nvl(ykcxxb.kcxzdm, '-1') end) = nvl(ykcxxb.kcxzdm, '-1')
                     and (case
                            when length(ykcxxb.sskch_id) = 1 then ykcxxb.kch_id
                            else nvl(ykcxxb.sskch_id, ykcxxb.kch_id) end) = t1.kch_id);
  insert into JW_JH_xsJXZXJHKCXXB (xnm,
                                   xqm,
                                   Njdm_id,
                                   zyh_id,
                                   zyfx_id,
                                   xh_id,
                                   xfyqjd_id,
                                   kclbdm,
                                   kcxzdm,
                                   sskch_id,
                                   kch_id,
                                   kch,
                                   kcmc,
                                   kcywmc,
                                   cj,
                                   bfzcj,
                                   jd,
                                   CJLYBJ,
                                   HDXF,
                                   XF)
  select t2.xnm,
         t2.xqm,
         v_njdm_id,
         v_zyh_id,
         'wfx',
         v_xh_id,
         'qtkcxfyq',
         t2.kclbdm,
         t2.kcxzdm,
         null,
         t2.kcmc,
         null           as kch,
         t2.kcmc,
         t2.kcywmc,
         t2.cj,
         t2.bfzcj,
         null           as jd,
         t1.rdlybj,
         to_char(t2.xf) as xf,
         to_char(t2.xf) as xf
  from jw_cj_xfrdb t1,
       jw_cj_xfrdmxb t2
  where t1.yrdz_id = t2.rdz_id
    and t1.rdlybj in ('0', '2')
    and t1.shjg = '3'
    and t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.xfyqjd_id = (select max(jhkc.xfyqjd_id)
                      from jw_cj_xsgrcjdtb b,
                           jw_cj_xsgrjhdtb c,
                           jw_jh_jxzxjhkcxxb jhkc,
                           jw_xjgl_xsjbxxb xs
                      where b.kcthzh_id = c.kcthzh_id
                        and b.kcthzbm = 'xnkc'
                        and b.zszt = '3'
                        and b.xh_id = c.xh_id
                        and c.kch_id = jhkc.kch_id
                        and c.xh_id = xs.xh_id
                        and jhkc.njdm_id = xs.njdm_id
                        and jhkc.zyh_id = xs.zyh_id
                        and b.kch_id = t1.kch_id
                        and jhkc.zxbj = '1'
                        and b.xh_id = v_xh_id
                        and c.xh_id = v_xh_id
                        and xs.xh_id = v_xh_id)
  where t1.xh_id = v_xh_id
    and t1.xfyqjd_id is null;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.xfyqjd_id = (select max(c.xfyqjd_id)
                      from jw_cj_xsgrcjdtb b,
                           jw_cj_xsgrjhjddtb c
                      where b.kcthzh_id = c.kcthzh_id
                        and b.kcthzbm = 'xnkcxfjd'
                        and b.zszt = '3'
                        and b.xh_id = c.xh_id
                        and b.xh_id = v_xh_id
                        and c.xh_id = v_xh_id
                        and b.kch_id = t1.kch_id)
  where t1.xh_id = v_xh_id
    and t1.xfyqjd_id is null;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.ngl_xfyqjd_id = (select '@' || wm_concat(t.xfyqjd_id)
                          from JW_JH_JXZXJHXFYQXXB t,
                               jw_jh_jxzxjhkcxxb t2
                          where t1.njdm_id = t2.njdm_id
                            and t1.zyh_id = t2.zyh_id
                            and t.xfyqjd_id = t2.xfyqjd_id
                            and decode(nvl(t.zyfx_id, 'wfx'), 'wfx', 1, v_zyfx_id, 2, 0) > 0
                            and t2.zxbj = '1'
                            and (case
                                   when length(t1.sskch_id) = 1 then t1.kch_id
                                   else nvl(t1.sskch_id, t1.kch_id) end) = t2.kch_id)
  where t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.ngl_xfyqjd_id = (case
                            when t1.ngl_xfyqjd_id is null or substr(t1.ngl_xfyqjd_id, -1) = ',' then t1.ngl_xfyqjd_id
                            else t1.ngl_xfyqjd_id || ',' end) || (select '#' || wm_concat(c.xfyqjd_id)
                                                                  from jw_jh_jxzxjhxxb a,
                                                                       jw_jh_jxzxjhxfyqxxb b,
                                                                       jw_jh_jxzxjhxfyqxxfb c,
                                                                       jw_jh_kcdmb d
                                                                  where t1.njdm_id = a.njdm_id
                                                                    and t1.zyh_id = a.zyh_id
                                                                    and a.jxzxjhxx_id = b.jxzxjhxx_id
                                                                    and b.xfyqjd_id = c.xfyqjd_id
                                                                    and decode(nvl(b.zyfx_id, 'wfx'), 'wfx', 1, v_zyfx_id, 2, 0) > 0
                                                                    and b.xdlx = 'zx'
                                                                    and (case
                                                                           when length(t1.sskch_id) = 1 then t1.kch_id
                                                                           else nvl(t1.sskch_id, t1.kch_id) end) =
                                                                        d.kch_id
                                                                    and c.kclbdm = d.kclbdm)
  where t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.ngl_xfyqjd_id = (case
                            when t1.ngl_xfyqjd_id is null or substr(t1.ngl_xfyqjd_id, -1) = ',' then t1.ngl_xfyqjd_id
                            else t1.ngl_xfyqjd_id || ',' end) || (select '$' || wm_concat(c.xfyqjd_id)
                                                                  from jw_jh_jxzxjhxxb a,
                                                                       jw_jh_jxzxjhxfyqxxb b,
                                                                       jw_jh_jxzxjhxfyqxxfb c
                                                                  where t1.njdm_id = a.njdm_id
                                                                    and t1.zyh_id = a.zyh_id
                                                                    and a.jxzxjhxx_id = b.jxzxjhxx_id
                                                                    and b.xfyqjd_id = c.xfyqjd_id
                                                                    and decode(nvl(b.zyfx_id, 'wfx'), 'wfx', 1, v_zyfx_id, 2, 0) > 0
                                                                    and b.xdlx = 'zx'
                                                                    and c.kcgsdm = t1.kcgsdm)
  where t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set t1.ngl_xfyqjd_id = (case
                            when t1.ngl_xfyqjd_id is null or substr(t1.ngl_xfyqjd_id, -1) = ',' then t1.ngl_xfyqjd_id
                            else t1.ngl_xfyqjd_id || ',' end) || (select '%' || wm_concat(c.xfyqjd_id)
                                                                  from jw_jh_jxzxjhxxb a,
                                                                       jw_jh_jxzxjhxfyqxxb b,
                                                                       jw_jh_jxzxjhxfyqxxfb c,
                                                                       jw_jh_kzkcdmb d
                                                                  where t1.njdm_id = a.njdm_id
                                                                    and t1.zyh_id = a.zyh_id
                                                                    and a.jxzxjhxx_id = b.jxzxjhxx_id
                                                                    and b.xfyqjd_id = c.xfyqjd_id
                                                                    and decode(nvl(b.zyfx_id, 'wfx'), 'wfx', 1, v_zyfx_id, 2, 0) > 0
                                                                    and b.xdlx = 'zx'
                                                                    and (case
                                                                           when length(t1.sskch_id) = 1 then t1.kch_id
                                                                           else nvl(t1.sskch_id, t1.kch_id) end) =
                                                                        d.kch_id
                                                                    and c.kz_id = d.kz_id)
  where t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set xfyqjd_id = case
                    when instr(ngl_xfyqjd_id || ',', '@', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '@,', 1, 1) = 0 and
                         (select count(*)
                          from jw_jh_jxzxjhkcxxb
                          where njdm_id = v_njdm_id
                            and zyh_id = v_zyh_id
                            and kch_id = t1.kch_id
                            and kcxzdm = t1.kcxzdm
                            and instr(ngl_xfyqjd_id || ',', xfyqjd_id || ',') > 0
                            and rownum = 1) > 0 then (select xfyqjd_id
                                                      from jw_jh_jxzxjhkcxxb
                                                      where njdm_id = v_njdm_id
                                                        and zyh_id = v_zyh_id
                                                        and kch_id = t1.kch_id
                                                        and kcxzdm = t1.kcxzdm
                                                        and instr(ngl_xfyqjd_id || ',', xfyqjd_id || ',') > 0
                                                        and rownum = 1)
                    when instr(ngl_xfyqjd_id || ',', '$', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '$,', 1, 1) = 0 and
                         (select count(*)
                          from jw_jh_jxzxjhxxb m,
                               jw_jh_jxzxjhxfyqxxb n,
                               jw_jh_jxzxjhxfyqxxfb l
                          where m.jxzxjhxx_id = n.jxzxjhxx_id
                            and n.sfmjd = '1'
                            and m.njdm_id = v_njdm_id
                            and m.zyh_id = v_zyh_id
                            and n.kcxzdm = t1.kcxzdm
                            and n.xfyqjd_id = l.xfyqjd_id
                            and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                            and rownum = 1) > 0 then (select n.xfyqjd_id
                                                      from jw_jh_jxzxjhxxb m,
                                                           jw_jh_jxzxjhxfyqxxb n,
                                                           jw_jh_jxzxjhxfyqxxfb l
                                                      where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                        and n.sfmjd = '1'
                                                        and m.njdm_id = v_njdm_id
                                                        and m.zyh_id = v_zyh_id
                                                        and n.kcxzdm = t1.kcxzdm
                                                        and n.xfyqjd_id = l.xfyqjd_id
                                                        and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                        and rownum = 1
                                                        and n.jdkcsx = '3')
                    when instr(ngl_xfyqjd_id || ',', '#', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '#,', 1, 1) = 0 and
                         (select count(*)
                          from jw_jh_jxzxjhxxb m,
                               jw_jh_jxzxjhxfyqxxb n,
                               jw_jh_jxzxjhxfyqxxfb l
                          where m.jxzxjhxx_id = n.jxzxjhxx_id
                            and n.sfmjd = '1'
                            and m.njdm_id = v_njdm_id
                            and m.zyh_id = v_zyh_id
                            and n.kcxzdm = t1.kcxzdm
                            and n.xfyqjd_id = l.xfyqjd_id
                            and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                            and rownum = 1) > 0 then (select n.xfyqjd_id
                                                      from jw_jh_jxzxjhxxb m,
                                                           jw_jh_jxzxjhxfyqxxb n,
                                                           jw_jh_jxzxjhxfyqxxfb l
                                                      where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                        and n.sfmjd = '1'
                                                        and m.njdm_id = v_njdm_id
                                                        and m.zyh_id = v_zyh_id
                                                        and n.kcxzdm = t1.kcxzdm
                                                        and n.xfyqjd_id = l.xfyqjd_id
                                                        and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                        and rownum = 1
                                                        and n.jdkcsx = '2')
                    when instr(ngl_xfyqjd_id || ',', '%', 1, 1) > 0 and
                         instr(ngl_xfyqjd_id || ',' || ',', '%,', 1, 1) = 0 and (select count(*)
                                                                                 from jw_jh_jxzxjhxxb m,
                                                                                      jw_jh_jxzxjhxfyqxxb n,
                                                                                      jw_jh_jxzxjhxfyqxxfb l
                                                                                 where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                                                   and n.sfmjd = '1'
                                                                                   and m.njdm_id = v_njdm_id
                                                                                   and m.zyh_id = v_zyh_id
                                                                                   and n.kcxzdm = t1.kcxzdm
                                                                                   and n.xfyqjd_id = l.xfyqjd_id
                                                                                   and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                                                   and rownum = 1) > 0
                            then (select n.xfyqjd_id
                                  from jw_jh_jxzxjhxxb m,
                                       jw_jh_jxzxjhxfyqxxb n,
                                       jw_jh_jxzxjhxfyqxxfb l
                                  where m.jxzxjhxx_id = n.jxzxjhxx_id
                                    and n.sfmjd = '1'
                                    and m.njdm_id = v_njdm_id
                                    and m.zyh_id = v_zyh_id
                                    and n.kcxzdm = t1.kcxzdm
                                    and n.xfyqjd_id = l.xfyqjd_id
                                    and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                    and rownum = 1
                                    and n.jdkcsx = '4') end
  where t1.xh_id = v_xh_id
    and t1.xfyqjd_id is null;
  update JW_JH_xsJXZXJHKCXXB t1
  set xfyqjd_id = case
                    when instr(ngl_xfyqjd_id || ',', '@', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '@,', 1, 1) = 0
                            then (case
                                    when (select count(*)
                                          from jw_jh_jxzxjhkcxxb
                                          where njdm_id = v_njdm_id
                                            and zyh_id = v_zyh_id
                                            and kch_id = t1.kch_id
                                            and kcxzdm = t1.kcxzdm
                                            and instr(ngl_xfyqjd_id || ',', xfyqjd_id || ',') > 0
                                            and rownum = 1) > 0 then (select xfyqjd_id
                                                                      from jw_jh_jxzxjhkcxxb
                                                                      where njdm_id = v_njdm_id
                                                                        and zyh_id = v_zyh_id
                                                                        and kch_id = t1.kch_id
                                                                        and kcxzdm = t1.kcxzdm
                                                                        and instr(ngl_xfyqjd_id || ',', xfyqjd_id || ',') > 0
                                                                        and rownum = 1)
                                    else (case
                                            when (select count(1)
                                                  from jw_jcdml_xtnzb
                                                  where zdm = 'JDKCRDBJ'
                                                    and zdz = '1') > 0 then null
                                            else substr(trim(substr(ngl_xfyqjd_id || ',',
                                                                    instr(ngl_xfyqjd_id || ',', '@', 1, 1) + 1,
                                                                    length(ngl_xfyqjd_id || ','))), 1, instr(trim(
                                                                                                               substr(
                                                                                                                 ngl_xfyqjd_id || ',',
                                                                                                                 instr(ngl_xfyqjd_id || ',', '@', 1, 1) + 1,
                                                                                                                 length(ngl_xfyqjd_id || ','))) ||
                                                                                                             ',', ',',
                                                                                                             1, 1) -
                                                                                                       1) end) end)
                    when instr(ngl_xfyqjd_id || ',', '$', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '$,', 1, 1) = 0
                            then (case
                                    when (select count(*)
                                          from jw_jh_jxzxjhxxb m,
                                               jw_jh_jxzxjhxfyqxxb n,
                                               jw_jh_jxzxjhxfyqxxfb l
                                          where m.jxzxjhxx_id = n.jxzxjhxx_id
                                            and n.sfmjd = '1'
                                            and m.njdm_id = v_njdm_id
                                            and m.zyh_id = v_zyh_id
                                            and n.kcxzdm = t1.kcxzdm
                                            and n.xfyqjd_id = l.xfyqjd_id
                                            and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                            and rownum = 1) > 0 then (select n.xfyqjd_id
                                                                      from jw_jh_jxzxjhxxb m,
                                                                           jw_jh_jxzxjhxfyqxxb n,
                                                                           jw_jh_jxzxjhxfyqxxfb l
                                                                      where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                                        and n.sfmjd = '1'
                                                                        and m.njdm_id = v_njdm_id
                                                                        and m.zyh_id = v_zyh_id
                                                                        and n.kcxzdm = t1.kcxzdm
                                                                        and n.xfyqjd_id = l.xfyqjd_id
                                                                        and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                                        and rownum = 1)
                                    else (case
                                            when (select count(1)
                                                  from jw_jcdml_xtnzb
                                                  where zdm = 'JDKCRDBJ'
                                                    and zdz = '1') > 0 then null
                                            else substr(trim(substr(ngl_xfyqjd_id || ',',
                                                                    instr(ngl_xfyqjd_id || ',', '$', 1, 1) + 1,
                                                                    length(ngl_xfyqjd_id || ','))), 1, instr(trim(
                                                                                                               substr(
                                                                                                                 ngl_xfyqjd_id || ',',
                                                                                                                 instr(ngl_xfyqjd_id || ',', '$', 1, 1) + 1,
                                                                                                                 length(ngl_xfyqjd_id || ','))) ||
                                                                                                             ',', ',',
                                                                                                             1, 1) -
                                                                                                       1) end) end)
                    when instr(ngl_xfyqjd_id || ',', '#', 1, 1) > 0 and instr(ngl_xfyqjd_id || ',', '#,', 1, 1) = 0
                            then (case
                                    when (select count(*)
                                          from jw_jh_jxzxjhxxb m,
                                               jw_jh_jxzxjhxfyqxxb n,
                                               jw_jh_jxzxjhxfyqxxfb l
                                          where m.jxzxjhxx_id = n.jxzxjhxx_id
                                            and n.sfmjd = '1'
                                            and m.njdm_id = v_njdm_id
                                            and m.zyh_id = v_zyh_id
                                            and n.kcxzdm = t1.kcxzdm
                                            and n.xfyqjd_id = l.xfyqjd_id
                                            and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                            and rownum = 1) > 0 then (select n.xfyqjd_id
                                                                      from jw_jh_jxzxjhxxb m,
                                                                           jw_jh_jxzxjhxfyqxxb n,
                                                                           jw_jh_jxzxjhxfyqxxfb l
                                                                      where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                                        and n.sfmjd = '1'
                                                                        and m.njdm_id = v_njdm_id
                                                                        and m.zyh_id = v_zyh_id
                                                                        and n.kcxzdm = t1.kcxzdm
                                                                        and n.xfyqjd_id = l.xfyqjd_id
                                                                        and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                                        and rownum = 1)
                                    else (case
                                            when (select count(1)
                                                  from jw_jcdml_xtnzb
                                                  where zdm = 'JDKCRDBJ'
                                                    and zdz = '1') > 0 then null
                                            else substr(trim(substr(ngl_xfyqjd_id || ',',
                                                                    instr(ngl_xfyqjd_id || ',', '#', 1, 1) + 1,
                                                                    length(ngl_xfyqjd_id || ','))), 1, instr(trim(
                                                                                                               substr(
                                                                                                                 ngl_xfyqjd_id || ',',
                                                                                                                 instr(ngl_xfyqjd_id || ',', '#', 1, 1) + 1,
                                                                                                                 length(ngl_xfyqjd_id || ','))) ||
                                                                                                             ',', ',',
                                                                                                             1, 1) -
                                                                                                       1) end) end)
                    when instr(ngl_xfyqjd_id || ',', '%', 1, 1) > 0 and
                         instr(ngl_xfyqjd_id || ',' || ',', '%,', 1, 1) = 0 then (case
                                                                                    when (select count(*)
                                                                                          from jw_jh_jxzxjhxxb m,
                                                                                               jw_jh_jxzxjhxfyqxxb n,
                                                                                               jw_jh_jxzxjhxfyqxxfb l
                                                                                          where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                                                            and n.sfmjd = '1'
                                                                                            and m.njdm_id = v_njdm_id
                                                                                            and m.zyh_id = v_zyh_id
                                                                                            and n.kcxzdm = t1.kcxzdm
                                                                                            and n.xfyqjd_id = l.xfyqjd_id
                                                                                            and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                                                            and rownum = 1) > 0
                                                                                            then (select n.xfyqjd_id
                                                                                                  from jw_jh_jxzxjhxxb m,
                                                                                                       jw_jh_jxzxjhxfyqxxb n,
                                                                                                       jw_jh_jxzxjhxfyqxxfb l
                                                                                                  where m.jxzxjhxx_id = n.jxzxjhxx_id
                                                                                                    and n.sfmjd = '1'
                                                                                                    and m.njdm_id = v_njdm_id
                                                                                                    and m.zyh_id = v_zyh_id
                                                                                                    and n.kcxzdm = t1.kcxzdm
                                                                                                    and n.xfyqjd_id = l.xfyqjd_id
                                                                                                    and instr(ngl_xfyqjd_id || ',', n.xfyqjd_id || ',') > 0
                                                                                                    and rownum = 1)
                                                                                    else (case
                                                                                            when (select count(1)
                                                                                                  from jw_jcdml_xtnzb
                                                                                                  where zdm = 'JDKCRDBJ'
                                                                                                    and zdz = '1') > 0
                                                                                                    then null
                                                                                            else substr(trim(substr(
                                                                                                               ngl_xfyqjd_id || ',',
                                                                                                               instr(ngl_xfyqjd_id || ',', '%', 1, 1) + 1,
                                                                                                               length(ngl_xfyqjd_id || ','))),
                                                                                                        1, instr(trim(
                                                                                                                   substr(
                                                                                                                     ngl_xfyqjd_id || ',',
                                                                                                                     instr(ngl_xfyqjd_id || ',', '%', 1, 1) + 1,
                                                                                                                     length(ngl_xfyqjd_id || ','))) ||
                                                                                                                 ',',
                                                                                                                 ',', 1,
                                                                                                                 1) -
                                                                                                           1) end) end)
                    when (nvl(ngl_xfyqjd_id, '-1') = '-1' or ngl_xfyqjd_id = '@,#,$,%' or length(xfyqjd_id) = 7)
                            then (case
                                    when (select count(*)
                                          from jw_cj_xsgrcjdtb b,
                                               jw_cj_xsgrjhdtb c,
                                               jw_jh_jxzxjhkcxxb jhkc,
                                               jw_xjgl_xsjbxxb xs
                                          where b.kcthzh_id = c.kcthzh_id
                                            and b.kcthzbm = 'xnkc'
                                            and b.zszt = '3'
                                            and b.xh_id = c.xh_id
                                            and c.kch_id = jhkc.kch_id
                                            and c.xh_id = xs.xh_id
                                            and jhkc.njdm_id = xs.njdm_id
                                            and jhkc.zyh_id = xs.zyh_id
                                            and b.kch_id = t1.kch_id
                                            and b.xh_id = v_xh_id
                                            and c.xh_id = v_xh_id
                                            and xs.xh_id = v_xh_id) > 0 then (select max(jhkc.xfyqjd_id)
                                                                              from jw_cj_xsgrcjdtb b,
                                                                                   jw_cj_xsgrjhdtb c,
                                                                                   jw_jh_jxzxjhkcxxb jhkc,
                                                                                   jw_xjgl_xsjbxxb xs
                                                                              where b.kcthzh_id = c.kcthzh_id
                                                                                and b.kcthzbm = 'xnkc'
                                                                                and b.zszt = '3'
                                                                                and b.xh_id = c.xh_id
                                                                                and c.kch_id = jhkc.kch_id
                                                                                and c.xh_id = xs.xh_id
                                                                                and jhkc.njdm_id = xs.njdm_id
                                                                                and jhkc.zyh_id = xs.zyh_id
                                                                                and b.kch_id = t1.kch_id
                                                                                and b.xh_id = v_xh_id
                                                                                and c.xh_id = v_xh_id
                                                                                and xs.xh_id = v_xh_id)
                                    when (select count(*)
                                          from jw_cj_xsgrcjdtb b,
                                               jw_cj_xsgrjhjddtb c
                                          where b.kcthzh_id = c.kcthzh_id
                                            and b.kcthzbm = 'xnkcxfjd'
                                            and b.zszt = '3'
                                            and b.xh_id = c.xh_id
                                            and b.xh_id = v_xh_id
                                            and c.xh_id = v_xh_id
                                            and b.kch_id = t1.kch_id) > 0 then (select max(c.xfyqjd_id)
                                                                                from jw_cj_xsgrcjdtb b,
                                                                                     jw_cj_xsgrjhjddtb c
                                                                                where b.kcthzh_id = c.kcthzh_id
                                                                                  and b.kcthzbm = 'xnkcxfjd'
                                                                                  and b.zszt = '3'
                                                                                  and b.xh_id = c.xh_id
                                                                                  and b.xh_id = v_xh_id
                                                                                  and c.xh_id = v_xh_id
                                                                                  and b.kch_id = t1.kch_id) end) end
  where t1.xh_id = v_xh_id
    and t1.xfyqjd_id is null;
  update JW_JH_xsJXZXJHKCXXB t
  set (XBX,
       JYXDXNM,
       JYXDXQM,
       ZXBJ,
       FXBJ,
       EZYBJ,
       EXWBJ,
       ZYHXKCBJ,
       ZYFX_ID,
       BZ,
       SQR,
       SQSJ,
       SHZT,
       ZZSHR,
       ZZSHSJ,
       XQH_ID,
       ZYZGKCBJ,
       KSFSDM,
       KKBM_ID,
       KSXSDM,
       KHFSDM,
       QSJSZ,
       XF) = (select t1.XBX,
                     t1.JYXDXNM,
                     t1.JYXDXQM,
                     t1.ZXBJ,
                     t1.FXBJ,
                     t1.EZYBJ,
                     t1.EXWBJ,
                     t1.ZYHXKCBJ,
                     t2.ZYFX_ID,
                     t1.BZ,
                     t1.SQR,
                     t1.SQSJ,
                     t1.SHZT,
                     t1.ZZSHR,
                     t1.ZZSHSJ,
                     t1.XQH_ID,
                     t1.ZYZGKCBJ,
                     t1.KSFSDM,
                     t1.KKBM_ID,
                     t1.KSXSDM,
                     t1.KHFSDM,
                     t1.QSJSZ,
                     t1.XF
              from JW_JH_JXZXJHKCXXB t1,
                   JW_JH_JXZXJHXFYQXXB t2
              where t1.xfyqjd_id = t2.xfyqjd_id
                and t2.jxzxjhxx_id = v_jxzxjhxx_id
                and t1.njdm_id = v_njdm_id
                and t1.zyh_id = v_zyh_id
                and t2.xdlx = 'zx'
                and decode(t2.zyfx_id, 'wfx', 1, v_zyfx_id, 2, 0) > 0
                and (case
                       when length(t.sskch_id) = 1 then t.kch_id
                       else nvl(t.sskch_id, t.kch_id) end) = t1.kch_id
                and t.xfyqjd_id = t1.xfyqjd_id
                and rownum = 1)
  where t.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set xfyqjd_id = 'qtkcxfyq',
      sfyxqtkc  = case
                    when bfzcj >= 60 then 1
                    else 0 end
  where (nvl(ngl_xfyqjd_id, '-1') = '-1' or ngl_xfyqjd_id = '@,#,$,%' or length(xfyqjd_id) = 7)
    and t1.xfyqjd_id is null
    and t1.xh_id = v_xh_id;
  update JW_JH_xsJXZXJHKCXXB t1
  set sfyxqtkc = case
                   when bfzcj >= 60 then 1
                   else 2 end
  where xfyqjd_id = 'qtkcxfyq'
    and xh_id = v_xh_id;
  if sJhwkcgs_sfmjd = '1'
  then update JW_JH_xsJXZXJHKCXXB t1
       set t1.xfyqjd_id = sJhwkcgs_xfyqjd_id
       where t1.xfyqjd_id = 'qtkcxfyq'
         and t1.xh_id = v_xh_id;
  else update JW_JH_xsJXZXJHKCXXB t1
       set t1.xfyqjd_id = nvl((select t2.xfyqjd_id
                               from jw_jh_jxzxjhxfyqxxb t2
                               where t2.sfmjd = '1'
                                 and t2.xdlx = 'zx'
                                 and exists(select 1
                                            from jw_jh_jxzxjhxxb a,
                                                 jw_xjgl_xsjbxxb xs
                                            where t2.jxzxjhxx_id = a.jxzxjhxx_id
                                              and xs.njdm_id = a.njdm_id
                                              and xs.zyh_id = a.zyh_id
                                              and xs.xh_id = v_xh_id)
                                 and rownum = 1
                                 and t2.kcxzdm = t1.kcxzdm), t1.xfyqjd_id)
       where t1.xfyqjd_id = 'qtkcxfyq'
         and t1.xh_id = v_xh_id
         and not exists(select 1
                        from jw_jh_kcxzdmb t4
                        where t1.kcxzdm = t4.kcxzdm
                          and t4.xbx = 'bx'); end if;
  update JW_JH_xsJXZXJHXFYQXXB t
  set (t.hdxf, t.sjhdxf, t.hdkcms, t.zgshzt) = (select nvl(hdxf, 0)hdxf,
                                                       nvl(hdxf, 0)hdxf,
                                                       nvl(hdkcms, 0)hdkcms,
                                                       case
                                                         when (nvl(yqzdxf, 0) >= 0 and yqzdxf <= nvl(hdxf, 0) and
                                                               kczdms is null) or
                                                              (nvl(yqzdxf, 0) = 0 and kczdms is not null and
                                                               kczdms <= nvl(hdkcms, 0)) or
                                                              ((yqzdxf is not null and yqzdxf <= nvl(hdxf, 0)) and
                                                               (kczdms is not null and kczdms <= nvl(hdkcms, 0)))
                                                                 then 'Y'
                                                         else 'N' end as zgshzt
                                                from (select t2.xh_id,
                                                             t2.xfyqjd_id,
                                                             sum(case
                                                                   when t1.hdxf is not null then t1.hdxf
                                                                   else 0 end) hdxf,
                                                             sum(case
                                                                   when t1.bfzcj >= 60 then 1
                                                                   else 0 end) hdkcms
                                                      from JW_JH_xsJXZXJHKCXXB t1,
                                                           JW_JH_xsJXZXJHXFYQXXB t2
                                                      where t2.xh_id = v_xh_id
                                                        and t2.xh_id = t1.xh_id (+)
                                                        and not exists(select 1
                                                                       from JW_CJ_XSGRCJDTB tdkc
                                                                       where tdkc.zszt = '3'
                                                                         and tdkc.kch_id = t1.kch_id
                                                                         and tdkc.xh_id = t1.xh_id
                                                                         and tdkc.kcthzbm = 'xnkc')
                                                        and t2.xfyqjd_id = t1.xfyqjd_id (+)
                                                      group by t2.xh_id, t2.xfyqjd_id) t1
                                                where t1.xfyqjd_id = t.xfyqjd_id)
  where t.xh_id = v_xh_id
    and t.sfmjd = '1'
    and t.xdlx = 'zx';
  if sJhwkcgs_sfmjd = '1'
  then update JW_JH_xsJXZXJHXFYQXXB a
       set a.hdxf   = nvl(a.hdxf, 0) + nvl((select sum(nvl(xf, 0))
                                            from JW_JH_xsJXZXJHKCXXB t1
                                            where xfyqjd_id = 'qtkcxfyq'
                                              and sfyxqtkc = '1'
                                              and xh_id = v_xh_id
                                              and bfzcj >= 60), 0),
           a.hdkcms = nvl(a.hdkcms, 0) + nvl((select count(*)
                                              from JW_JH_xsJXZXJHKCXXB t1
                                              where xfyqjd_id = 'qtkcxfyq'
                                                and sfyxqtkc = '1'
                                                and xh_id = v_xh_id
                                                and bfzcj >= 60), 0)
       where a.xh_id = v_xh_id
         and a.xfyqjd_id = sJhwkcgs_xfyqjd_id
         and a.sfmjd = '1'
         and a.xdlx = 'zx';
    update JW_JH_xsJXZXJHXFYQXXB a
    set a.zgshzt = case
                     when (a.yqzdxf is not null and a.yqzdxf <= a.hdxf) then 'Y'
                     else 'N' end,
        a.sjhdxf = a.hdxf
    where a.xh_id = v_xh_id
      and a.xfyqjd_id = sJhwkcgs_xfyqjd_id
      and a.sfmjd = '1'
      and a.xdlx = 'zx'; end if;
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.hdxf = a.hdxf + (select t2.xf
                         from jw_cj_xfrdb t1,
                              jw_cj_xfrdmxb t2
                         where t1.xrdz_id = t2.rdz_id
                           and t1.rdlybj = '2'
                           and t1.shjg = '3'
                           and t1.xh_id = v_xh_id
                           and a.xfyqjd_id = t2.kch_id)
  where exists(select 'X'
               from jw_cj_xfrdb tt1,
                    jw_cj_xfrdmxb tt2
               where tt1.xrdz_id = tt2.rdz_id
                 and tt1.rdlybj = '2'
                 and tt1.shjg = '3'
                 and tt1.xh_id = v_xh_id
                 and a.xfyqjd_id = tt2.kch_id)
    and a.xh_id = v_xh_id
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.zgshzt = case
                   when (a.yqzdxf is not null and a.yqzdxf <= a.hdxf) then 'Y'
                   else 'N' end,
      a.sjhdxf = a.hdxf
  where exists(select 'X'
               from jw_cj_xfrdb tt1,
                    jw_cj_xfrdmxb tt2
               where tt1.xrdz_id = tt2.rdz_id
                 and tt1.rdlybj = '2'
                 and tt1.shjg = '3'
                 and tt1.xh_id = v_xh_id
                 and a.xfyqjd_id = tt2.kch_id)
    and a.xh_id = v_xh_id
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.hdxf = a.hdxf + (select sum(nvl(t2.xf, 0))
                         from jw_cj_xsgrdtzb t1,
                              jw_cj_xsgrjhjddtb t2
                         where t1.kcthzh_id = t2.kcthzh_id
                           and t1.kcthzbm = 'xnxfjd'
                           and t1.zszt = '3'
                           and t2.xh_id = v_xh_id
                           and a.xfyqjd_id = t2.xfyqjd_id)
  where exists(select 'X'
               from jw_cj_xsgrdtzb tt1,
                    jw_cj_xsgrjhjddtb tt2
               where tt1.kcthzh_id = tt2.kcthzh_id
                 and tt1.kcthzbm = 'xnxfjd'
                 and tt1.zszt = '3'
                 and tt2.xh_id = v_xh_id
                 and a.xfyqjd_id = tt2.xfyqjd_id)
    and a.xh_id = v_xh_id
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.hdxf = a.hdxf - (select sum(nvl(t2.xf, 0))
                         from jw_cj_xsgrdtzb t1,
                              jw_cj_xsgrjhjddtb t2
                         where t1.kcthzh_id = t2.kcthzh_id
                           and t1.kcthzbm = 'xnxfjd'
                           and t1.zszt = '3'
                           and t2.xh_id = v_xh_id
                           and a.xfyqjd_id = t2.xfyqzjd_id)
  where exists(select 'X'
               from jw_cj_xsgrdtzb tt1,
                    jw_cj_xsgrjhjddtb tt2
               where tt1.kcthzh_id = tt2.kcthzh_id
                 and tt1.kcthzbm = 'xnxfjd'
                 and tt1.zszt = '3'
                 and tt2.xh_id = v_xh_id
                 and a.xfyqjd_id = tt2.xfyqzjd_id)
    and a.xh_id = v_xh_id
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.hdxf = a.hdxf + (select sum(nvl(xf, 0)) xf
                         from (select distinct tdkc.xh_id, btdkc.KCH_ID btdkcxx, btdkc.xf, jhkc.xfyqjd_id, xfb.XFYQJDMC
                               from JW_CJ_XSGRCJDTB tdkc,
                                    JW_CJ_XSGRJHDTB btdkc,
                                    JW_JH_JXZXJHKCXXB jhkc,
                                    JW_JH_JXZXJHXFYQXXB xfb
                               where tdkc.XH_ID = btdkc.XH_ID
                                 and tdkc.KCTHZH_ID = btdkc.KCTHZH_ID
                                 and tdkc.zszt = '3'
                                 and tdkc.KCTHZBM = 'xnkc'
                                 and btdkc.KCH_ID = jhkc.KCH_ID
                                 and jhkc.XFYQJD_ID = xfb.XFYQJD_ID
                                 and xfb.JXZXJHXX_ID = v_jxzxjhxx_id
                                 and tdkc.XH_ID = v_xh_id) t
                         where t.XFYQJD_ID = a.xfyqjd_id
                           and t.xh_id = a.xh_id)
  where exists((select 1
                from (select distinct tdkc.xh_id, btdkc.KCH_ID btdkcxx, btdkc.xf, jhkc.xfyqjd_id, xfb.XFYQJDMC
                      from JW_CJ_XSGRCJDTB tdkc,
                           JW_CJ_XSGRJHDTB btdkc,
                           JW_JH_JXZXJHKCXXB jhkc,
                           JW_JH_JXZXJHXFYQXXB xfb
                      where tdkc.XH_ID = btdkc.XH_ID
                        and tdkc.KCTHZH_ID = btdkc.KCTHZH_ID
                        and tdkc.zszt = '3'
                        and tdkc.KCTHZBM = 'xnkc'
                        and btdkc.KCH_ID = jhkc.KCH_ID
                        and jhkc.XFYQJD_ID = xfb.XFYQJD_ID
                        and xfb.JXZXJHXX_ID = v_jxzxjhxx_id
                        and tdkc.XH_ID = v_xh_id) t
                where t.XFYQJD_ID = a.xfyqjd_id
                  and t.xh_id = a.xh_id))
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB a
  set a.zgshzt = case
                   when (a.yqzdxf is not null and a.yqzdxf <= a.hdxf) then 'Y'
                   else 'N' end,
      a.sjhdxf = a.hdxf
  where exists(select 'X'
               from jw_cj_xsgrdtzb tt1,
                    jw_cj_xsgrjhjddtb tt2
               where tt1.kcthzh_id = tt2.kcthzh_id
                 and tt1.kcthzbm = 'xnxfjd'
                 and tt1.zszt = '3'
                 and tt2.xh_id = v_xh_id
                 and (a.xfyqjd_id = tt2.xfyqjd_id or a.xfyqjd_id = tt2.xfyqzjd_id))
    and a.xh_id = v_xh_id
    and a.sfmjd = '1'
    and a.xdlx = 'zx';
  for x in reverse 2 .. iMaxjb loop update JW_JH_xsJXZXJHXFYQXXB t
                                    set t.hdxf = nvl((select hdxf
                                                      from (select a.xh_id,
                                                                   a.fxfyqjd_id,
                                                                   a.xfyqzjdgx,
                                                                   case
                                                                     when a.xfyqzjdgx = 1
                                                                             then sum(to_number(nvl(a.hdxf, 0)))
                                                                     when a.xfyqzjdgx = 0
                                                                             then max(to_number(nvl(a.hdxf, 0)))
                                                                     else sum(to_number(nvl(a.hdxf, 0))) end hdxf
                                                            from (select a.xh_id,
                                                                         a.fxfyqjd_id,
                                                                         b.xfyqzjdgx,
                                                                         a.hdxf,
                                                                         row_number() over (partition by a.fxfyqjd_id
                                                                           order by case when nvl(a.hdxf, 0) >=
                                                                                              nvl(a.yqzdxf, 0)
                                                                             then 1
                                                                                    else 0 end desc, case when
                                                                             nvl(a.hdxf, 0) = 0
                                                                             then 0
                                                                                                     else 1 end desc, to_number(
                                                                               nvl(a.hdxf, 0)) desc) rn
                                                                  from JW_JH_xsJXZXJHXFYQXXB a,
                                                                       JW_JH_xsJXZXJHXFYQXXB b
                                                                  where a.fxfyqjd_id is not null
                                                                    and a.fxfyqjd_id = b.xfyqjd_id
                                                                    and b.xh_id = v_xh_id
                                                                    and a.xh_id = v_xh_id) a
                                                            where case
                                                                    when a.xfyqzjdgx in ('1', '0') then a.rn
                                                                    else to_number(a.xfyqzjdgx) end >= a.rn
                                                            group by a.xh_id, a.fxfyqjd_id, a.xfyqzjdgx) t1
                                                      where t.xfyqjd_id = t1.fxfyqjd_id), 0) + nvl((case
                                                                                                      when t.xfyqjd_id = sJhwkcgs_xfyqjd_id
                                                                                                              then (select sum(nvl(hdxf, 0))
                                                                                                                    from JW_JH_xsJXZXJHKCXXB
                                                                                                                    where xfyqjd_id = 'qtkcxfyq'
                                                                                                                      and sfyxqtkc = '1'
                                                                                                                      and xh_id = v_xh_id
                                                                                                                      and bfzcj >= 60)
                                                                                                      else 0 end), 0)
                                    where t.sjhdxf is null
                                      and t.fxfyqjd_id is not null
                                      and t.sfmjd = '0'
                                      and t.xh_id = v_xh_id
                                      and t.jb = x
                                      and t.xdlx = 'zx';
    update JW_JH_xsJXZXJHXFYQXXB t
    set t.hdkcms = nvl((select hdkcms
                        from (select a.xh_id,
                                     a.fxfyqjd_id,
                                     a.xfyqzjdgx,
                                     case
                                       when a.xfyqzjdgx = 1 then sum(to_number(nvl(a.hdkcms, 0)))
                                       when a.xfyqzjdgx = 0 then max(to_number(nvl(a.hdkcms, 0)))
                                       else sum(to_number(nvl(a.hdkcms, 0))) end hdkcms
                              from (select a.xh_id,
                                           a.fxfyqjd_id,
                                           b.xfyqzjdgx,
                                           a.hdkcms,
                                           row_number() over (partition by a.fxfyqjd_id
                                             order by case when nvl(a.hdkcms, 0) >= nvl(a.hdkcms, 0)
                                               then 1
                                                      else 0 end desc, case when nvl(a.hdkcms, 0) = 0
                                               then 0
                                                                       else 1 end desc, to_number(
                                                 nvl(a.hdkcms, 0)) desc) rn
                                    from JW_JH_xsJXZXJHXFYQXXB a,
                                         JW_JH_xsJXZXJHXFYQXXB b
                                    where a.fxfyqjd_id is not null
                                      and a.fxfyqjd_id = b.xfyqjd_id
                                      and b.xh_id = v_xh_id
                                      and a.xh_id = v_xh_id) a
                              where case
                                      when a.xfyqzjdgx in ('1', '0') then a.rn
                                      else to_number(a.xfyqzjdgx) end >= a.rn
                              group by a.xh_id, a.fxfyqjd_id, a.xfyqzjdgx) t1
                        where t.xfyqjd_id = t1.fxfyqjd_id), 0) + nvl((case
                                                                        when t.xfyqjd_id = sJhwkcgs_xfyqjd_id
                                                                                then(select count(1)
                                                                                     from JW_JH_xsJXZXJHKCXXB
                                                                                     where xfyqjd_id = 'qtkcxfyq'
                                                                                       and sfyxqtkc = '1'
                                                                                       and xh_id = v_xh_id
                                                                                       and bfzcj >= 60)
                                                                        else 0 end), 0)
    where t.sjhdxf is null
      and t.fxfyqjd_id is not null
      and t.sfmjd = '0'
      and t.xh_id = v_xh_id
      and t.jb = x
      and t.xdlx = 'zx';
    update JW_JH_xsJXZXJHXFYQXXB t
    set t.syxf = case
                   when (to_number(nvl(t.yqzdxf, 0)) > 0 and to_number(t.yqzdxf) < to_number(t.hdxf))
                           then to_number(t.yqzdxf) - to_number(t.hdxf)
                   else 0 end
    where t.sjhdxf is null
      and t.hdxf is not null
      and t.sfmjd = '0'
      and t.fxfyqjd_id is not null
      and t.xh_id = v_xh_id
      and t.jb = x
      and t.xdlx = 'zx';
    update JW_JH_xsJXZXJHXFYQXXB t
    set t.zgshzt = case
                     when (nvl(t.yqzdxf, 0) >= 0 and t.yqzdxf <= nvl(t.hdxf, 0) and t.kczdms is null) or
                          (nvl(t.yqzdxf, 0) = 0 and t.kczdms is not null and t.kczdms <= nvl(t.hdkcms, 0)) or
                          ((t.yqzdxf is not null and t.yqzdxf <= nvl(t.hdxf, 0)) and
                           (t.kczdms is not null and t.kczdms <= nvl(t.hdkcms, 0))) then 'Y'
                     else 'N' end,
        t.sjhdxf = (select sjhdxf
                    from (select a.xh_id,
                                 a.fxfyqjd_id,
                                 a.xfyqzjdgx,
                                 case
                                   when a.xfyqzjdgx = 1 then sum(to_number(nvl(a.sjhdxf, 0)))
                                   when a.xfyqzjdgx = 0 then max(to_number(nvl(a.sjhdxf, 0)))
                                   else sum(to_number(nvl(a.sjhdxf, 0))) end sjhdxf
                          from (select a.xh_id,
                                       a.fxfyqjd_id,
                                       b.xfyqzjdgx,
                                       a.sjhdxf,
                                       row_number() over (partition by a.fxfyqjd_id
                                         order by case when nvl(a.sjhdxf, 0) >= nvl(a.yqzdxf, 0)
                                           then 1
                                                  else 0 end desc, case when nvl(a.sjhdxf, 0) = 0
                                           then 0
                                                                   else 1 end desc, to_number(nvl(a.sjhdxf, 0)) desc) rn
                                from JW_JH_xsJXZXJHXFYQXXB a,
                                     JW_JH_xsJXZXJHXFYQXXB b
                                where a.fxfyqjd_id is not null
                                  and a.fxfyqjd_id = b.xfyqjd_id
                                  and b.xh_id = v_xh_id
                                  and a.xh_id = v_xh_id) a
                          where case
                                  when a.xfyqzjdgx in ('1', '0') then a.rn
                                  else to_number(a.xfyqzjdgx) end >= a.rn
                          group by a.xh_id, a.fxfyqjd_id, a.xfyqzjdgx) t1
                    where t.xfyqjd_id = t1.fxfyqjd_id)
    where t.sjhdxf is null
      and t.fxfyqjd_id is not null
      and t.sfmjd = '0'
      and t.xh_id = v_xh_id
      and t.jb = x
      and t.xdlx = 'zx';
  end loop;
  update JW_JH_xsJXZXJHXFYQXXB t
  set t.zgshzt = case
                   when (nvl(t.yqzdxf, 0) >= 0 and t.yqzdxf <= nvl(t.hdxf, 0) and t.kczdms is null) or
                        (nvl(t.yqzdxf, 0) = 0 and t.kczdms is not null and t.kczdms <= nvl(t.hdkcms, 0)) or
                        ((t.yqzdxf is not null and t.yqzdxf <= nvl(t.hdxf, 0)) and
                         (t.kczdms is not null and t.kczdms <= nvl(t.hdkcms, 0))) then 'Y'
                   else 'N' end
  where t.fxfyqjd_id is not null
    and t.xh_id = v_xh_id
    and t.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB t
  set t.hdxf = (select hdxf
                from (select a.xh_id,
                             a.fxfyqjd_id,
                             b.xfyqzjdgx,
                             case
                               when nvl(b.xfyqzjdgx, '1') = 1 then sum(to_number(nvl(a.hdxf, 0)))
                               when b.xfyqzjdgx = 0 then max(to_number(nvl(a.hdxf, 0)))
                               else sum(case
                                          when a.zgshzt = 'Y' then to_number(nvl(a.hdxf, 0))
                                          else 0 end) end hdxf
                      from JW_JH_xsJXZXJHXFYQXXB a,
                           JW_JH_xsJXZXJHXFYQXXB b
                      where a.fxfyqjd_id is not null
                        and a.fxfyqjd_id = b.xfyqjd_id
                        and b.xh_id = v_xh_id
                        and a.xh_id = v_xh_id
                      group by a.xh_id, a.fxfyqjd_id, b.xfyqzjdgx) t1
                where t.xfyqjd_id = t1.fxfyqjd_id)
  where t.hdxf is null
    and t.fxfyqjd_id is null
    and t.xh_id = v_xh_id
    and t.jb = 1
    and t.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB t
  set t.zgshzt = case
                   when (t.yqzdxf is not null and t.yqzdxf <= t.hdxf) and ((select min(case
                                                                                         when t2.zgshzt = 'N' then '0'
                                                                                         else '1' end)
                                                                            from JW_JH_xsJXZXJHXFYQXXB t2
                                                                            where t.xfyqjd_id = t2.fxfyqjd_id
                                                                              and t2.xh_id = v_xh_id
                                                                              and t2.xdlx = 'zx') = 1) then 'Y'
                   else 'N' end,
      t.sjhdxf = (select sjhdxf
                  from (select a.xh_id,
                               a.fxfyqjd_id,
                               b.xfyqzjdgx,
                               case
                                 when nvl(b.xfyqzjdgx, '1') = 1 then sum(to_number(nvl(a.sjhdxf, 0)))
                                 when b.xfyqzjdgx = 0 then max(to_number(nvl(a.sjhdxf, 0)))
                                 else sum(case
                                            when a.zgshzt = 'Y' then to_number(nvl(a.sjhdxf, 0))
                                            else 0 end) end sjhdxf
                        from JW_JH_xsJXZXJHXFYQXXB a,
                             JW_JH_xsJXZXJHXFYQXXB b
                        where a.fxfyqjd_id is not null
                          and a.fxfyqjd_id = b.xfyqjd_id
                          and b.xh_id = v_xh_id
                          and a.xh_id = v_xh_id
                        group by a.xh_id, a.fxfyqjd_id, b.xfyqzjdgx) t1
                  where t.xfyqjd_id = t1.fxfyqjd_id)
  where t.sjhdxf is null
    and t.fxfyqjd_id is null
    and t.xh_id = v_xh_id
    and t.jb = 1
    and t.xdlx = 'zx';
  update JW_JH_xsJXZXJHXFYQXXB t
  set t.yxjd = '1'
  where t.xh_id = v_xh_id
    and t.xdlx = 'zx';
  for x in 3 .. iMaxjb + 1 loop update JW_JH_xsJXZXJHXFYQXXB t
                                set t.yxjd = (select case
                                                       when t1.xfyqzjdgx = 1 then '1'
                                                       when (t1.xfyqzjdgx = 0 or t1.xfyqzjdgx > 1) and
                                                            t1.zgshzt = 'Y' and t.zgshzt = 'Y' then '1'
                                                       when (t1.xfyqzjdgx = 0 or t1.xfyqzjdgx > 1) and
                                                            t1.zgshzt = 'Y' and t.zgshzt = 'N' then '0'
                                                       when (t1.xfyqzjdgx = 0 or t1.xfyqzjdgx > 1) and t1.zgshzt = 'N'
                                                               then '1'
                                                       else '1' end
                                              from JW_JH_xsJXZXJHXFYQXXB t1
                                              where t1.xh_id = v_xh_id
                                                and t1.xdlx = 'zx'
                                                and t.fxfyqjd_id = t1.xfyqjd_id
                                                and t1.jb = x - 1)
                                where t.xh_id = v_xh_id
                                  and t.xdlx = 'zx'
                                  and t.jb = x;
  end loop;
  select max(decode(hdxf, 0, 0, case
                                  when nvl(yqzdxf, 0) = 0 then null
                                  else to_char(100 - ((to_number(yqzdxf) - to_number(hdxf)) /
                                                      to_number(decode(yqzdxf, 0, 1, yqzdxf)) * 100),
                                               'FM9990.00') end))                                               xyjd,
         max((to_number(hdxf) - to_number(yqzdxf)))                                                             wc,
         max(case
               when zgshzt = '0' then 1
               else (decode(hdxf, 0, 1, decode(sign(to_number(yqzdxf) - to_number(hdxf)), '1', '1',
                                               '0'))) end)                                                      yj into v_xyjd, v_wc, v_yj
  from (select sum(nvl(yqzdxf, 0))                     yqzdxf,
               sum(case
                     when to_number(nvl(hdxf, 0)) > to_number(nvl(yqzdxf, 0)) then to_number(nvl(yqzdxf, 0))
                     else to_number(nvl(hdxf, 0)) end) hdxf,
               min(case
                     when zgshzt = 'Y' then 1
                     else 0 end) as                    zgshzt
        from JW_JH_xsJXZXJHXFYQXXB t
        where t.sfmjd = '1'
          and t.xh_id = v_xh_id
          and t.xdlx = 'zx');
  select count(1) into sl from JW_BYGL_xsxyyjjgb t where t.xh_id = v_xh_id;
  if to_number(sl) > 0
  then update JW_BYGL_xsxyyjjgb t
       set t.jxzxjhxx_id = v_jxzxjhxx_id,
           t.xyjd        = v_xyjd,
           t.wc          = v_wc,
           t.yj          = v_yj
       where t.xh_id = v_xh_id;
  else insert into JW_BYGL_xsxyyjjgb values (v_xh_id, v_jxzxjhxx_id, v_xyjd, v_wc, nvl(v_yj, 'x')); end if;
  commit;
end;
end;
/

