create procedure p_xk_choose_zykc_quickly(
    in_xkkz_id in varchar2,
    in_xh_id in varchar2,
    out_flag out varchar2,
    out_msg out varchar2
) as
    v_count number;
    v_xnm varchar2(5);
    v_xqm varchar2(5);
    v_xkxnm varchar2(5);
    v_xkxqm varchar2(5);
    v_xxdm varchar2(8);
    v_njdm_id varchar2(32);
    v_jg_id varchar2(32);
    v_zyh_id varchar2(32);
    v_bh_id varchar2(32);
    v_zyfx_id varchar2(32);
    v_xklc varchar2(2);
    v_hbrskz number;
    v_pjkz varchar2(1);
    v_jfkz varchar2(1);
    v_zckz  varchar2(1);
    v_sfkxk varchar2(1);
    v_sfyjxk varchar2(1);
    v_ztbj varchar2(1);
    v_jzxk varchar2(1);
    v_gz_sfzx varchar2(1);
    v_xs_sfzx varchar2(1);
    v_bdzcbj varchar2(1);
    v_xbx varchar2(30);
    v_kcxz varchar2(200);
    v_xsdms varchar2(20);
    v_current_kch_id varchar2(32);
    xsdm_array mytype;

    cursor c_tj_jxb(i_xkxnm varchar2,i_xkxqm varchar2,i_njdm_id varchar2,i_zyh_id varchar2,i_bh_id varchar2,i_zyfx_id varchar2,i_xbx varchar2,i_kcxz varchar2) is
        select
            t1.kch_id,t1.jxb_id,(
                case when
                    nvl(t1.bpkbj,0)='1' or nvl(t1.sfsjk,'0')='1'
                then
                    1
                else
                    (select count(*) from jw_jh_kcdmb t4 where t4.kch_id=t1.kch_id and nvl(t4.sfsjk,0)=1)
                end
            ) sjkbj
        from
            jw_jxrw_jxbxxb t1,jw_jxrw_jxbhbxxb t2,jw_jh_kcxzdmb t3
        where
            t1.jxb_id=t2.jxb_id and t2.kcxzdm=t3.kcxzdm
            and (instr(','||i_xbx||',' , ','||t3.xbx||',') > 0 or instr(','||i_kcxz||',' , ','||t3.kcxzdm||',') > 0)
            and t1.sfxkbj='1' and t1.sfzjxb='1' and t1.kkzt='1' and t1.sfkxk='1' and t1.xnm=i_xkxnm and t1.xqm=i_xkxqm
            and t1.kklxdm='01' and t2.njdm_id=i_njdm_id and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
        order by t1.kch_id;
    cursor c_zh_zijxb_1(i_xkxnm varchar2,i_xkxqm varchar2,i_njdm_id varchar2,i_zyh_id varchar2,i_bh_id varchar2,i_zyfx_id varchar2,i_fjxb_id varchar2,i_xsdm varchar2) is
        select jxb_id jxb_id_1 from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm
            and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
            );
    cursor c_zh_zijxb_2(i_xkxnm varchar2,i_xkxqm varchar2,i_njdm_id varchar2,i_zyh_id varchar2,i_bh_id varchar2,i_zyfx_id varchar2,i_fjxb_id varchar2,i_xsdm_1 varchar2,i_xsdm_2 varchar2) is
        select m1.jxb_id jxb_id_1,m2.jxb_id jxb_id_2 from
            (
                select fjxb_id,jxb_id from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm_1
                and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                    select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                    and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
                )
            ) m1,
            (
                select fjxb_id,jxb_id from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm_2
                and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                    select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                    and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
                )
            ) m2
        where m1.fjxb_id=m2.fjxb_id;

    cursor c_zh_zijxb_3(i_xkxnm varchar2,i_xkxqm varchar2,i_njdm_id varchar2,i_zyh_id varchar2,i_bh_id varchar2,i_zyfx_id varchar2,i_fjxb_id varchar2,i_xsdm_1 varchar2,i_xsdm_2 varchar2,i_xsdm_3 varchar2) is
        select m1.jxb_id jxb_id_1,m2.jxb_id jxb_id_2,m3.jxb_id jxb_id_3 from
            (
                select fjxb_id,jxb_id from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm_1
                and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                    select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                    and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
                )
            ) m1,
            (
                select fjxb_id,jxb_id from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm_2
                and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                    select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                    and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
                )
            ) m2,
            (
                select fjxb_id,jxb_id from jw_jxrw_jxbxxb t1 where xnm=i_xkxnm and xqm=i_xkxqm and fjxb_id=i_fjxb_id and xsdm=i_xsdm_3
                and sfxkbj='1' and kkzt='1' and kklxdm='01' and exists(
                    select 1 from jw_jxrw_jxbhbxxb t2 where t1.jxb_id=t2.jxb_id and t2.njdm_id=i_njdm_id
                    and t2.zyh_id=i_zyh_id and t2.bh_id=i_bh_id and t2.zyfx_id in ('wfx',i_zyfx_id)
                )
            ) m3
        where m1.fjxb_id=m2.fjxb_id and m1.fjxb_id=m3.fjxb_id;

begin
    --判断当前是否在选课时间内
    select count(*) into v_count from JW_XK_XKKZB a where a.xkkz_id=in_xkkz_id and to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') between a.xkkssj and a.xkjssj;
    if v_count='0' then
        out_flag := '0';--不在选课时间内
        out_msg := '对不起，当前时间不可选课！';
        goto EndPoint; --跳出循环
    end if;

    select xnm,xqm,xklc into v_xkxnm,v_xkxqm,v_xklc from JW_XK_XKKZB b where b.xkkz_id=in_xkkz_id;

    select count(*) into v_count from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
    if v_count='0' then
        out_flag := '0';--不在选课时间内
        out_msg := '对不起，您在当前学年学期，不可选课！';
        goto EndPoint; --跳出循环
    end if;

    select
        nvl(sfyjxk,'0'),nvl(sfkxk,'0'),nvl(pjkz,'0'),nvl(jfkz,'0'),nvl(zckz,'0'),nvl(sfzx,'0')
        into
        v_sfyjxk,v_sfkxk,v_pjkz,v_jfkz,v_zckz,v_gz_sfzx
    from jw_xk_xkkzxmb where xkkz_id=in_xkkz_id;

    if v_sfkxk='0' then
        out_flag := '0';--不在选课时间内
        out_msg := '对不起，选课尚未开放！';
        goto EndPoint; --跳出循环
    end if;

    if v_sfyjxk='0' then
        out_flag := '0';--不在选课时间内
        out_msg := '对不起，该功能不可用！';
        goto EndPoint; --跳出循环
    end if;

    if v_pjkz='1' then
        select xxdm into v_xxdm from zftal_xtgl_xxxxszb;
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDPJXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDPJXQM';
        if v_xxdm='10290' then --中国矿业大学
            select count(*) into v_count from jw_pj_xspjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id and ztbj='1';
            if v_count=0 then
                out_flag:='0';
                out_msg := '未完成评价，不可选课！';
                goto EndPoint; --跳出循环
            else
                select count(*) into v_count from jw_pj_xskcwjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id and ztbj='1';
                if v_count=0 then
                    out_flag:='0';
                    out_msg := '未完成评价，不可选课！';
                    goto EndPoint; --跳出循环
                end if;
            end if;
        else --其他学校
            select max(nvl(ztbj,'0')) into v_ztbj from jw_pj_xspjztb where xnm=v_xnm and xqm=v_xqm and xh_id=in_xh_id;
            if nvl(v_ztbj,'w')='w' then --不存在状态记录
                if fn_xspjztbj(v_xnm,v_xqm,in_xh_id)='0' then
                    out_flag:='0';
                    out_msg := '未完成评价，不可选课！';
                    goto EndPoint; --跳出循环
                end if;
            else
                if v_ztbj!='1' then
                    out_flag:='0';
                    out_msg := '未完成评价，不可选课！';
                    goto EndPoint; --跳出循环
                end if;
            end if;
        end if;
    end if;

    if v_jfkz='1' then
        select zdz into v_xnm from zftal_xtgl_xtszb where zdm='XKPDJFXNM';
        select zdz into v_xqm from zftal_xtgl_xtszb where zdm='XKPDJFXQM';
        select count(*) into v_count from jw_xjgl_xsxqjfztb where xh_id=in_xh_id and xnm=v_xnm and decode(xqm,'0',v_xqm,xqm)=v_xqm and jfzt ='1';
        if v_count=0 then
            out_flag:='0';
            out_msg := '未缴费，不可选课！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    select njdm_id,jg_id,zyh_id,bh_id,nvl(zyfx_id,'wfx'),nvl(sfzx,'0'),nvl(bdzcbj,'0') into v_njdm_id,v_jg_id,v_zyh_id,v_bh_id,v_zyfx_id,v_xs_sfzx,v_bdzcbj from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
    if v_gz_sfzx='1' or v_zckz='1' then
        if v_gz_sfzx='1' and v_xs_sfzx='0' then
            out_flag:='0';
            out_msg:='对不起，您当前学籍状态为不在校，不可选此类课程！';
            goto EndPoint;
        end if;
        if v_zckz='1' and v_bdzcbj not in ('2','3') then
            out_flag:='0';
            out_msg:='对不起，您的学籍处于未注册状态，不可选此类课程！';
            goto EndPoint;
        end if;
    end if;

    select count(*) into v_count from JW_XK_QTXKGZB where xnm=v_xkxnm and xqm=v_xkxqm and xh_id in (in_xh_id,'tongyi');
    if v_count>0 then
        select nvl(jzxk,'0') into v_jzxk from (
            select jzxk from JW_XK_QTXKGZB
            where xnm=v_xkxnm and xqm=v_xkxqm and xh_id in (in_xh_id,'tongyi')
            order by case when xh_id='tongyi' then 1 else 0 end
        ) where rownum=1;
        if v_jzxk='1' then
            out_flag := '0';
            out_msg := '对不起，您当前不可选课！';
            goto EndPoint; --跳出循环
        end if;
    end if;

    select count(*) into v_hbrskz from jw_jcdml_xtnzb where zdm='HBRSKZ' and zdz='1' and rownum=1;

    select trim(substr(zdz,1,instr(zdz,'|',1,1)-1)),trim(substr(zdz,instr(zdz,'|',1,1)+1,100)) into v_xbx,v_kcxz from jw_jcdml_xtnzb where zdm='PKKCXZ';
    delete from jw_xk_yjxklsb where xh_id=in_xh_id;
    commit;
    --将学生可选的教学班都查出来作遍历
    for p_jxb in c_tj_jxb(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,v_xbx,v_kcxz) loop
        if nvl(v_current_kch_id,'w') != p_jxb.kch_id then --未给该学生配过此课程
            select count(*) into v_count from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id and kch_id=p_jxb.kch_id;
            if v_count>0 then --该学生之前已选过此课程
                v_current_kch_id := p_jxb.kch_id;
            else --开始为该学生配该课程
                select count(*) into v_count from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and fjxb_id=p_jxb.jxb_id;
                if v_count=0 then --无子教学班
                    if p_jxb.sjkbj=1 then --是实践课时，不判断时间冲突
                        if v_hbrskz=0 then --不按合班人数控制（是实践课、无子教学班）
                            insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb
                            where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id and (jxbrs+nvl(krrl,0))>(
                                (select count(*) from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id)
                                +
                                (select count(*) from jw_xk_yjxklsb where jxb_id=p_jxb.jxb_id)
                            );
                            commit;

                            select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                            if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                v_current_kch_id := p_jxb.kch_id;
                                goto NextPoint;
                            end if;
                        else --按合班人数控制（是实践课、无子教学班）
                            insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,t1.kch_id,t1.jxb_id
                            from
                                jw_jxrw_jxbxxb t1,(
                                    select
                                        count(m1.xh_id) xkrs,
                                        sum(decode(m2.njdm_id||m2.zyh_id||m2.bh_id||m2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                    from
                                        (
                                            select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id
                                            union all
                                            select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id=p_jxb.jxb_id
                                        ) m1,jw_xjgl_xsxjxxb m2
                                    where
                                        m1.xh_id=m2.xh_id and m2.xnm=v_xkxnm and m2.xqm=v_xkxqm
                                ) t2
                            where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.jxb_id=p_jxb.jxb_id and (t1.jxbrs+nvl(t1.krrl,0))>t2.xkrs
                                and nvl((
                                    select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb a where a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id
                                    and a.bh_id=v_bh_id and a.zyfx_id in ('wfx',v_zyfx_id) and a.jxb_id=p_jxb.jxb_id
                                ),0)>nvl(t2.hbxsrs,0);
                            commit;

                            select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                            if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                v_current_kch_id := p_jxb.kch_id;
                                goto NextPoint;
                            end if;
                        end if;
                    else --不是实践课时（无子教学班）
                        select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm and jxb_id=p_jxb.jxb_id and exists (
                            select 1 from (
                                select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                union all
                                select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                            ) t1,jw_pk_kbsjb t2
                            where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                    where t1.jxb_id=sjk.jxb_id
                                    and nvl(sjk.sfsjk,'0')='0'
                                    and  sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                )--排除已选的实践课
                        );
                        if v_count=0 then --选课时间上不冲突
                            if v_hbrskz=0 then --不按合班人数控制（非实践课、无子教学班）
                                insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb
                                where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id
                                    and (jxbrs+nvl(krrl,0))>(
                                        (select count(*) from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id)
                                        +
                                        (select count(*) from jw_xk_yjxklsb where jxb_id=p_jxb.jxb_id)
                                    );
                                commit;
                                select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                    v_current_kch_id := p_jxb.kch_id;
                                    goto NextPoint;
                                end if;
                            else --按合班人数控制（非实践课、无子教学班）
                                insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,t1.kch_id,t1.jxb_id
                                from
                                    jw_jxrw_jxbxxb t1,(
                                        select
                                            count(m1.xh_id) xkrs,
                                            sum(decode(m2.njdm_id||m2.zyh_id||m2.bh_id||m2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                        from
                                            (
                                                select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id=p_jxb.jxb_id
                                                union all
                                                select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id=p_jxb.jxb_id
                                            ) m1,jw_xjgl_xsxjxxb m2
                                        where
                                            m1.xh_id=m2.xh_id and m2.xnm=v_xkxnm and m2.xqm=v_xkxqm
                                    ) t2
                                where t1.xnm=v_xkxnm and t1.xqm=v_xkxqm and t1.jxb_id=p_jxb.jxb_id and (t1.jxbrs+nvl(t1.krrl,0))>t2.xkrs
                                    and nvl((
                                        select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb a where a.njdm_id=v_njdm_id and a.zyh_id=v_zyh_id
                                        and a.bh_id=v_bh_id and a.zyfx_id in ('wfx',v_zyfx_id) and a.jxb_id=p_jxb.jxb_id
                                    ),0)>nvl(t2.hbxsrs,0);
                                commit;

                                select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                    v_current_kch_id := p_jxb.kch_id;
                                    goto NextPoint;
                                end if;
                            end if;
                        end if;
                    end if;
                else --有子教学班
                    select wm_concat(xsdm) into v_xsdms from (select distinct xsdm from jw_jxrw_jxbxxb where xnm=v_xkxnm and xqm=v_xkxqm and fjxb_id=p_jxb.jxb_id and sfxkbj='1' and kkzt='1' and kklxdm='01');
                    xsdm_array := my_split(v_xsdms,','); --子教学班种类串
                    if p_jxb.sjkbj=1 then --是实践课时（有子教学班）
                        if v_hbrskz=0 then --不按合班人数控制（实践课、有子教学班）
                            if xsdm_array.count=1 then
                                for p_zijxb in c_zh_zijxb_1(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and (
                                        select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                        and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                            (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                            +
                                            (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                        )
                                    )=0;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=2 then
                                for p_zijxb in c_zh_zijxb_2(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and (
                                        select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                        and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                            (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                            +
                                            (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                        )
                                    )=0;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=3 then
                                for p_zijxb in c_zh_zijxb_3(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2),xsdm_array(3)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and (
                                        select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                        and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                            (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                            +
                                            (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                        )
                                    )=0;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            else
                                null;
                            end if;
                        else --按合班人数控制（实践课、有子教学班）
                            if xsdm_array.count=1 then --只有一类子教学班
                                for p_zijxb in c_zh_zijxb_1(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and (
                                        select count(*) from (
                                            select
                                                m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                    select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                    and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                ),0) rs
                                            from
                                                jw_jxrw_jxbxxb m1,(
                                                    select
                                                        n1.jxb_id,count(n1.xh_id) xkrs,
                                                        sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                    from
                                                        (
                                                            select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                                            union all
                                                            select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                                        ) n1,jw_xjgl_xsxjxxb n2
                                                    where
                                                        n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                    group by n1.jxb_id
                                                ) m2
                                            where
                                                m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                        ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                    )=2;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=2 then  --有两类子教学班
                                for p_zijxb in c_zh_zijxb_2(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and (
                                        select count(*) from (
                                            select
                                                m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                    select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                    and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                ),0) rs
                                            from
                                                jw_jxrw_jxbxxb m1,(
                                                    select
                                                        n1.jxb_id,count(n1.xh_id) xkrs,
                                                        sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                    from
                                                        (
                                                            select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                                            union all
                                                            select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                                        ) n1,jw_xjgl_xsxjxxb n2
                                                    where
                                                        n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                    group by n1.jxb_id
                                                ) m2
                                            where
                                                m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                        ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                    )=3;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=3 then --有三类子教学班
                                for p_zijxb in c_zh_zijxb_3(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2),xsdm_array(3)) loop
                                    insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                    where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and (
                                        select count(*) from (
                                            select
                                                m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                    select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                    and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                ),0) rs
                                            from
                                                jw_jxrw_jxbxxb m1,(
                                                    select
                                                        n1.jxb_id,count(n1.xh_id) xkrs,
                                                        sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                    from
                                                        (
                                                            select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                                            union all
                                                            select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                                        ) n1,jw_xjgl_xsxjxxb n2
                                                    where
                                                        n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                    group by n1.jxb_id
                                                ) m2
                                            where
                                                m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                        ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                    )=4;
                                    commit;
                                    select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                    if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                        v_current_kch_id := p_jxb.kch_id;
                                        goto NextPoint;
                                    end if;
                                end loop;
                            else
                                null;
                            end if;
                        end if;
                    else --不是实践课时（有子教学班）
                        if v_hbrskz=0 then --不按合班人数控制（非实践课、有子教学班）
                            if xsdm_array.count=1 then --只有一类子教学班
                                for p_zijxb in c_zh_zijxb_1(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and (
                                            select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                            and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                                (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                                +
                                                (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                            )
                                        )=0;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=2 then --有两类子教学班
                                for p_zijxb in c_zh_zijxb_2(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and (
                                            select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                            and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                                (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                                +
                                                (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                            )
                                        )=0;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=3 then --有三类子教学班
                                for p_zijxb in c_zh_zijxb_3(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2),xsdm_array(3)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and (
                                            select count(*) from jw_jxrw_jxbxxb m1 where m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                            and (m1.jxbrs+nvl(m1.krrl,0))<=(
                                                (select count(*) from jw_xk_xsxkb m2 where m2.xnm=v_xkxnm and m2.xqm=v_xkxqm and m2.jxb_id=m1.jxb_id)
                                                +
                                                (select count(*) from jw_xk_yjxklsb m3 where m3.jxb_id=m1.jxb_id)
                                            )
                                        )=0;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            else
                                null;
                            end if;
                        else --按合班人数控制（非实践课，有子教学班）
                            if xsdm_array.count=1 then --只有一类子教学班
                                for p_zijxb in c_zh_zijxb_1(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间上不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1) and (
                                            select count(*) from (
                                                select
                                                    m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                        select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                        and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                    ),0) rs
                                                from
                                                    jw_jxrw_jxbxxb m1,(
                                                        select
                                                            n1.jxb_id,count(n1.xh_id) xkrs,
                                                            sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                        from
                                                            (
                                                                select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                                                union all
                                                                select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                                            ) n1,jw_xjgl_xsxjxxb n2
                                                        where
                                                            n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                        group by n1.jxb_id
                                                    ) m2
                                                where
                                                    m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1)
                                            ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                        )=2;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=2 then --有两类子教学班
                                for p_zijxb in c_zh_zijxb_2(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2) and (
                                            select count(*) from (
                                                select
                                                    m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                        select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                        and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                    ),0) rs
                                                from
                                                    jw_jxrw_jxbxxb m1,(
                                                        select
                                                            n1.jxb_id,count(n1.xh_id) xkrs,
                                                            sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                        from
                                                            (
                                                                select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                                                union all
                                                                select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                                            ) n1,jw_xjgl_xsxjxxb n2
                                                        where
                                                            n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                        group by n1.jxb_id
                                                    ) m2
                                                where
                                                    m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2)
                                            ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                        )=3;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            elsif xsdm_array.count=3 then --有三类子教学班
                                for p_zijxb in c_zh_zijxb_3(v_xkxnm,v_xkxqm,v_njdm_id,v_zyh_id,v_bh_id,v_zyfx_id,p_jxb.jxb_id,xsdm_array(1),xsdm_array(2),xsdm_array(3)) loop
                                    select count(*) into v_count from jw_pk_kbsjb m where m.xnm=v_xkxnm and m.xqm=v_xkxqm
                                    and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and exists (
                                        select 1 from (
                                            select jxb_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id
                                            union all
                                            select jxb_id from jw_xk_yjxklsb where xh_id=in_xh_id
                                        ) t1,jw_pk_kbsjb t2
                                        where t1.jxb_id=t2.jxb_id and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm
                                            and m.xqj=t2.xqj and bitand(m.zcd,t2.zcd)>0 and bitand(m.jc, t2.jc)>0
                                            and exists (select 'X' from jw_jxrw_jxbxxb sjk
                                                where t1.jxb_id=sjk.jxb_id
                                                and nvl(sjk.sfsjk,'0')='0'
                                                and sjk.xnm=v_xkxnm and sjk.xqm=v_xkxqm
                                            )--排除已选的实践课
                                    );
                                    if v_count=0 then --选课时间不冲突
                                        insert into jw_xk_yjxklsb(xh_id,kch_id,jxb_id) select in_xh_id,kch_id,jxb_id from jw_jxrw_jxbxxb t1
                                        where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3) and (
                                            select count(*) from (
                                                select
                                                    m1.jxb_id,m1.jxbrs,nvl(m1.krrl,0) krrl,m2.xkrs,m2.hbxsrs,nvl((
                                                        select sum(nvl(rs,0)) from jw_jxrw_jxbhbxxb m3 where m3.njdm_id=v_njdm_id and m3.zyh_id=v_zyh_id
                                                        and m3.bh_id=v_bh_id and m3.zyfx_id in ('wfx',v_zyfx_id) and m3.jxb_id=m1.jxb_id
                                                    ),0) rs
                                                from
                                                    jw_jxrw_jxbxxb m1,(
                                                        select
                                                            n1.jxb_id,count(n1.xh_id) xkrs,
                                                            sum(decode(n2.njdm_id||n2.zyh_id||n2.bh_id||n2.zyfx_id,v_njdm_id||v_zyh_id||v_bh_id||v_zyfx_id,1,0)) hbxsrs
                                                        from
                                                            (
                                                                select jxb_id,xh_id from jw_xk_xsxkb where xnm=v_xkxnm and xqm=v_xkxqm and jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                                                union all
                                                                select jxb_id,xh_id from jw_xk_yjxklsb where jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                                            ) n1,jw_xjgl_xsxjxxb n2
                                                        where
                                                            n1.xh_id=n2.xh_id and n2.xnm=v_xkxnm and n2.xqm=v_xkxqm
                                                        group by n1.jxb_id
                                                    ) m2
                                                where
                                                    m1.jxb_id=m2.jxb_id(+) and m1.xnm=v_xkxnm and m1.xqm=v_xkxqm and m1.jxb_id in (p_jxb.jxb_id,p_zijxb.jxb_id_1,p_zijxb.jxb_id_2,p_zijxb.jxb_id_3)
                                            ) where (jxbrs+krrl)>nvl(xkrs,0) and rs>nvl(hbxsrs,0)
                                        )=4;
                                        commit;
                                        select count(*) into v_count from jw_xk_yjxklsb where xh_id=in_xh_id and kch_id=p_jxb.kch_id;
                                        if v_count>0 then --配课成功，再往下循环时，将不再配该课程
                                            v_current_kch_id := p_jxb.kch_id;
                                            goto NextPoint;
                                        end if;
                                    end if;
                                end loop;
                            else
                                null;
                            end if;
                        end if;
                    end if;
                end if;
                <<NextPoint>>
                null;
            end if;
        end if;
    end loop;

    insert into jw_xk_xsxkb(xnm,xqm,kch_id,jxb_id,xh_id,xklc,zy,xkbj,sxbj,cxbj,fxbj,jcytbj,xksj,jgh_id)
    select v_xkxnm,v_xkxqm,kch_id,jxb_id,xh_id,v_xklc,1,'10','1','0','0','0',to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),xh_id
    from jw_xk_yjxklsb where xh_id=in_xh_id;
    --更新教学班人数信息
    update jw_jxrw_jxbxxb t1 set yxzrs=(select count(*) from jw_xk_xsxkb t2 where xnm=v_xkxnm and xqm=v_xkxqm and t1.jxb_id=t2.jxb_id)
    where exists(select 1 from jw_xk_yjxklsb t3 where t3.jxb_id=t1.jxb_id and t3.xh_id=in_xh_id);
    delete from jw_xk_yjxklsb where xh_id=in_xh_id;
    commit;
    out_flag := '1';
    <<EndPoint>>
    null;
    exception
        When others then
            Rollback;
            out_flag := '0';
            out_msg := '出现错误！请与管理员联系！';
end;

/

