create view V_JW_XSKBSJ as
  SELECT

  (select t.xh from   JW_XJGL_XSJBXXB t where xk.XH_ID=t.XH_ID) xh,
  (select t.xm from   JW_XJGL_XSJBXXB t where xk.XH_ID=t.XH_ID) xm,
  kc.kcmc,
  kc.kch kcdm,
  jxb.JXB_ID  jxbid,
  jxb.JXBMC bjmc,
  jxb.xf,
  jxb.rwzxs,
  case when kkzt='1' then '0' else '1' end zt,
  (select jgh from   JW_JG_JZGXXB where jgh_id=sj.JGH_ID) jsgh,
  (select xm from   JW_JG_JZGXXB where jgh_id=sj.JGH_ID) jsxm,
  (select xnmc from   JW_JCDM_XNB where xnm=xk.xnm) xn,
  (select mc from   ZFTAL_XTGL_JCSJB where lx='0001' and dm=xk.xqm  ) xq,
    get_jcbinarydesc(nvl(cd.zcd,sj.zcd),'') zc,
  case when    get_weeksdesc(nvl(cd.zcd,sj.zcd)) like '%双%' then '双'
  when    get_weeksdesc(nvl(cd.zcd,sj.zcd)) like '%单%' then '单'
    else '全' end dsz,
  sj.xqj xqj,
    get_jcbinarydesc(nvl(cd.jc,sj.jc),'')  sksj,
  (SELECT xqmc from   ZFTAL_XTGL_XQDMB where xqh_id=jxb.XQH_ID) xqh,
  (select cdmc from   JW_JCDM_CDJBXXB  where cd_id=cd.CD_ID) skdd,
  (select kcxzmc from   JW_JH_KCXZDMB where kcxzdm=kc.KCXZDM) kcxz,
  jxb.JXBRS skrs,
  (select mc from   ZFTAL_XTGL_JCSJB where lx='0037' and dm=jxb.KHFSDM) khfs
  FROM    JW_XK_XSXKB xk, JW_PK_KBSJB sj, JW_PK_KBCDB cd, JW_JXRW_JXBXXB jxb, JW_JH_KCDMB kc
  where  xk.xqm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXQM') and xk.xnm in(
select zdz from zftal_xtgl_xtszb  where zdm='DQXNM'
)and xk.JXB_ID=sj.JXB_ID and sj.KB_ID=cd.KB_ID(+) and xk.JXB_ID=jxb.JXB_ID and xk.KCH_ID=kc.KCH_ID
/

