create view ZFTAL_SJCJ_S_GJ341 as
  (select
  al,
  rownum bh,
  gcdy,
  gqty,
  mzdp,
  hq,
  gat,
  ssmz,
  cjr
from
(select t.mc al,
         sum(case when b.zzmmm='01' then 1 else 0 end) gcdy,
         sum(case when b.zzmmm='03' then 1 else 0 end) gqty,
         sum(case when b.zzmmm not in ('01','03','12','13') then 1 else 0 end) mzdp,
         sum(case when b.gatqwm='11' then 1 else 0 end) hq,
         sum(case when b.gatqwm in ('01','03','05') then 1 else 0 end) gat,
         sum(case when b.mzm!='01' then 1 else 0 end) ssmz,
         null cjr
    from zftal_xtgl_jcsjb t,
         (select t.xh_id,t.zzmmm,t.gatqwm,t.mzm,xj.xslbdm
          from JW_XJGL_XSJBXXB t, jw_xjgl_xsxjxxb xj
          where t.xh_id = xj.xh_id
          and xj.xnm =(select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXNM')
          and xj.xqm =(select t.zdz from zftal_xtgl_xtszb t where t.zdm='XKXQM')
          and xj.sfzx = '1'
         ) b
   where t.lx = '0016'
     and t.dm = b.xslbdm
   group by t.mc
   ))
/

