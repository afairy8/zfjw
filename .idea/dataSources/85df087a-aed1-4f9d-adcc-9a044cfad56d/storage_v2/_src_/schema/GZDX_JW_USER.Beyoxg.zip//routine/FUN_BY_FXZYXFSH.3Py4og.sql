create function fun_by_fxzyxfsh(v_xh_id varchar2,v_tjmc varchar2,v_tjsjcs varchar2,v_tjsjz varchar2,
                                       v_tjsjly varchar2,v_tjsjlymc varchar2,v_tjsjgx varchar2,v_tjsjmc varchar2,v_tjsjz1 varchar2,v_tjsjgx1 varchar2) return varchar2
as
   sJg varchar2(2000);   ---返回审核是否通过描述
   v_hdxf varchar2(10);
   sqlstr VARCHAR2(2000);
begin
    sJg := '合格';
    begin
         sqlstr:=' select nvl('||v_tjsjcs||', 0) '||v_tjsjcs||' from dual  left join '||v_tjsjlymc||' on xh_id='''||v_xh_id||'''';
         execute immediate  sqlstr  into v_hdxf;
         if v_tjsjz is not null then
           sqlstr:=' select (case when '||v_hdxf||v_tjsjgx||v_tjsjz||' then ''合格'' else  '''||v_tjsjmc||v_hdxf||'分，低于要求'||v_tjsjz||'分,不合格！'' end ) from dual';
           execute immediate  sqlstr  into sJg;
         end if;
         if sJg = '合格' then
           if v_tjsjz1 is not null then
             sqlstr:=' select (case when '||v_hdxf||v_tjsjgx1||v_tjsjz1||' then ''合格'' else  '''||v_tjsjmc||v_hdxf||'分，低于要求'||v_tjsjz1||'分,不合格！'' end ) from dual';
             execute immediate  sqlstr  into sJg;
           end if;
         end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_fxzyxfsh;

/

