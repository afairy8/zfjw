create view V_ORDERSYN as
  select t.syn_id,
         t.stuff_no,
         t.order_no,
         t.order_amount,
         t.order_pay,
         t.order_mes,
         t.order_date,
         t.form_data
  from   jw_xtgl_ordersyn t
/

