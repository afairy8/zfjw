create procedure PK_TJKBXSBRS-----推荐课表补学生人数---
(
 vXnm in varchar2,
 vXqm in varchar2,
 vJg_id in varchar2,
 vNjdm_id in varchar2,
 vZyh_id in varchar2,
 vBh_id in varchar2,
 vBj out varchar2)
 as
 sNjdm_id   varchar2(32);
 sZyh_id   varchar2(32);
 sBh_id    varchar2(32);
 sKbgsbj varchar2(8);    ----课表个数标记
 cursor Get_Tjkb is     ----已经生成推荐课表信息。----游标---
      select distinct a.njdm_id,a.zyh_id,a.bh_id from jw_pk_tjxsbrsb a
                      where a.xnm = vXnm
                        and a.xqm = vXqm
                        and nvl(vNjdm_id,a.njdm_id) = a.njdm_id
                        and exists (select 'X' from zftal_xtgl_zydmb b where a.zyh_id = b.zyh_id and b.jg_id = vJg_id)
                        and nvl(vZyh_id,a.zyh_id) = a.zyh_id
                        and nvl(vBh_id,a.bh_id) = a.bh_id;
 Cur_Tjkb Get_Tjkb%rowtype;

begin
  select nvl((select zdz from jw_jcdml_xtnzb  where zdm = 'KBGSBJ'),0) into sKbgsbj from dual;
  if sKbgsbj != '1' then
  vBj := '';
  open Get_Tjkb;
    loop
      fetch Get_Tjkb into Cur_Tjkb;
      exit when Get_Tjkb%notfound;
         sZyh_id   := Cur_Tjkb.zyh_id;
         sNjdm_id  := Cur_Tjkb.njdm_id;
         sBh_id    := Cur_Tjkb.bh_id;
      begin
           update jw_pk_tjkbjgb a set rs = (select rs from
           ( select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,tjkbzdm,tjkbzxsdm,rs+
             case when rn = 1 then trunc((brs)/gs)+ mod(brs,gs) else  trunc((brs)/gs) end rs from
               (select xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,tjkbzdm,tjkbzxsdm,rs,brs,
                       count(1) over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id ) gs,
                       row_number() over (partition by xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id order by rs desc ) rn from
                 (select distinct xnm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,tjkbzdm,tjkbzxsdm,rs,
                    (select rs from jw_pk_tjxsbrsb t2
                                        where t1.xnm = t2.xnm
                                          and bitand(t1.xqm , t2.xqm) > 0
                                          and t1.njdm_id = t2.njdm_id
                                          and t1.zyh_id = t2.zyh_id
                                          and t1.bh_id = t2.bh_id
                                          and t1.zyfx_id = t2.zyfx_id) brs from
                           jw_pk_tjkbjgb t1  where t1.xnm = vXnm
                                               and t1.dxqm = vXqm
                                               and t1.njdm_id = sNjdm_id
                                               and t1.zyh_id = sZyh_id
                                               and t1.bh_id = sBh_id
                   ) where brs is not null
                  )
            ) b where a.xnm = b.xnm
                  and a.xqm = b.xqm
                  and a.njdm_id = b.njdm_id
                  and a.zyh_id = b.zyh_id
                  and a.bh_id = b.bh_id
                  and a.zyfx_id = b.zyfx_id
                  and a.tjkbzdm =  b.tjkbzdm
                  and a.tjkbzxsdm= b.tjkbzxsdm )
          where a.xnm = vXnm
            and a.dxqm = vXqm
            and a.njdm_id = sNjdm_id
            and a.zyh_id = sZyh_id
            and a.bh_id = sBh_id;

       delete from jw_pk_tjxsbrsb where xnm = vXnm
                                    and xqm= vXqm
                                    and njdm_id = sNjdm_id
                                    and zyh_id = sZyh_id
                                    and bh_id = sBh_id;
       commit;
      end;
  end loop;
  close Get_Tjkb;

  <<Exend>>
 null;
 end if;
end PK_TJKBXSBRS;

/

