create procedure p_kjbm_choose
(
  in_xh_id in varchar2,
  in_xnm in varchar2,
  in_xqm in varchar2,
  in_xmbmsz_id in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
    v_xmlbkzmc number; --项目类别已报门次
    v_count number; --项目类别限制门次
begin
    out_flag := '1';
    select count(*) into v_count from jw_xmgl_xmbmszb a,jw_xmgl_xmxsbmqkb b
    where a.xmbmsz_id = b.xmbmsz_id and b.xh_id = in_xh_id
    and a.xnm = in_xnm and a.xqm = in_xqm
    and a.xmkssj = (select xmkssj from jw_xmgl_xmbmszb where xmbmsz_id = in_xmbmsz_id);

    if v_count > 0 then
       out_flag :='0';
       out_msg :='有重复时间的考级项目';
       goto nextOne; --跳出循环
    end if ;

 /*   select count(*) into v_count from jw_xmgl_xmbmszb a,jw_xmgl_xmxsbmqkb b
    where a.xmbmsz_id = b.xmbmsz_id and b.xh_id = in_xh_id
    and a.xnm = in_xnm and a.xqm = in_xqm
    and a.xmdm in (select xmdm from jw_jcdm_xmlbdmb
    where xmlbfl = (select y.xmlbfl from jw_xmgl_xmbmszb x ,jw_jcdm_xmlbdmb y ,jw_jcdm_xmdmb z
    where x.xmdm = z.xmdm and z.xmlbdm =y.xmlbdm and x.xmbmsz_id = in_xmbmsz_id)
     );*/

     select count(*) into v_count
      from jw_xmgl_xmbmszb a, jw_xmgl_xmxsbmqkb b,jw_jcdm_xmlbdmb  c ,jw_jcdm_xmdmb d
     where a.xmbmsz_id = b.xmbmsz_id
       and b.xh_id = in_xh_id
       and a.xnm = in_xnm
       and a.xqm = in_xqm
       and a.xmdm = d.xmdm
       and d.xmlbdm = c.xmlbdm
       and exists
     (select 1
              from jw_jcdm_xmlbdmb x, jw_xmgl_xmbmszb y, jw_jcdm_xmdmb z
             where a.xmdm = z.xmdm
               and z.xmlbdm = x.xmlbdm
               and z.xmdm = y.xmdm
               and x.xmlbfl = c.xmlbfl
               and y.xmbmsz_id = in_xmbmsz_id);

    select y.xmlbkzmc into v_xmlbkzmc from jw_xmgl_xmbmszb x ,jw_jcdm_xmlbdmb y ,jw_jcdm_xmdmb z
    where x.xmdm = z.xmdm and z.xmlbdm =y.xmlbdm and x.xmbmsz_id = in_xmbmsz_id;

    if v_count > v_xmlbkzmc then
       out_flag :='0';
       out_msg :='超过该项目类别限制门'||v_xmlbkzmc||'次';
       goto nextOne; --跳出循环
    end if ;

    <<nextOne>>

     if out_flag = '-1' then
         rollback;
     else
         commit;
     end if;
end;

/

