create function get_kczhzxs(vkch_id varchar2,v_lx varchar2)---取课程周和总学时组合
Return varchar2
as
sKcZhxsZh varchar2(1000);
begin
  if v_lx='py' then
       select replace(wm_concat('<span id="jsxsdm'||xsdm||'">'||xsmc||'(周:'||trim(to_char(zhxs,'990.9'))||'总:'||trim(to_char(zxs,'990.9'))||')</span>'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc from JW_JH_PYFAKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.pyfakcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='jh' then
     select replace(wm_concat('<span id="jsxsdm'||xsdm||'">'||xsmc||'(周:'||trim(to_char(zhxs,'990.9'))||'总:'||trim(to_char(zxs,'990.9'))||')</span>'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc from JW_JH_JXZXJHKCXSDZB t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.jxzxjhkcxx_id= vkch_id order by t1.xsdm );
  elsif v_lx='kcsq' then
     select replace(wm_concat('<span id="jsxsdm'||xsdm||'">'||xsmc||'(周:'||trim(to_char(zhxs,'990.9'))||'总:'||trim(to_char(zxs,'990.9'))||')</span>'),',','-') into sKcZhxsZh from (
     select  t1.xsdm,t1.zhxs,t1.zxs,t3.xsmc from jw_jh_kcdmbbxsdzb t1 , jw_jh_kcdmbbb t2 ,jw_jh_kcxsxxdmb t3
     where t1.kcdmbbb_id = t2.kcdmbbb_id and  t1.xsdm = t3.xsdm AND t2.kcdmbbb_id=vkch_id  order by t1.xsdm );    --主修专业任务落实，教师排课时显示课程周和总学时组合
  elsif v_lx='kcbgsq' then
     select replace(wm_concat(decode(nvl(zxsbj,'0'),'1','[主]','')||xsmc||'(周:'||trim(to_char(zhxs,'990.9'))||'总:'||trim(to_char(zxs,'990.9'))||')'),',','-') into sKcZhxsZh from (
     select  t1.xsdm,t1.zhxs,t1.zxs,t3.xsmc,t1.zxsbj from jw_jh_kcdmbbxsdzb t1 , jw_jh_kcdmbbb t2 ,jw_jh_kcxsxxdmb t3
     where t1.kcdmbbb_id = t2.kcdmbbb_id and  t1.xsdm = t3.xsdm AND t2.kcdmbbb_id=vkch_id  order by t1.xsdm );    --课程变更申请审核时审核页面课程学时的显示
  else
    select replace(wm_concat('<span id="jsxsdm'||xsdm||'">'||xsmc||'(周:'||trim(to_char(zhxs,'990.9'))||'总:'||trim(to_char(zxs,'990.9'))||')</span>'),',','-') into sKcZhxsZh from (
    select t1.xsdm,t1.zhxs,t1.zxs,t2.xsmc from jw_jh_kcxsdzb t1,jw_jh_kcxsxxdmb t2 where
     t1.xsdm = t2.xsdm and t1.kch_id = vkch_id order by t1.xsdm );
   end if;
  return sKcZhxsZh;
end;

/

