create function fn_kcjssj(vJxb_id varchar2) return varchar2 /**---课程结束时间----**/
 as
  sSjxx        varchar2(32); /**---返回的时间信息**/
  sjtzbj       varchar2(2); /**---时间调整标记 **/
  v_xnm        varchar2(32); /**---学年标记**/
  v_xqm        varchar2(32); /**---学年标记**/
  v_section    varchar2(32); /**---节次信息**/
  v_TimePrefix varchar2(32); /*时间前缀*/
  v_TimeSuffix varchar2(32); /*时间后缀 */
  v_xiaoq      varchar2(32);
  sFlag        number;       /*标记 */
  sKcjssj_y    varchar2(32); /*原课程结束时间 */
begin
  sSjxx := '';
  begin

    --获取时间前缀
    select xqh_id, rq,(case when instr(jc,',')>0 then substr(jc,instr(jc,',')+1,length(jc)-instr(jc,',')) else jc end),xnm,xqm
      into v_xiaoq, v_TimePrefix, v_section,v_xnm,v_xqm
      from (select row_number() over(partition by s.jxb_id order by b.rq desc, to_number(replace(substr(fn_bittozc(s.jc*2), -2), ',', '')) desc) rn,
                   jxb.xqh_id,
                   b.rq,
                   fn_bittozc(s.jc * 2)as jc,
                   jxb.xnm,
                   jxb.xqm
              from jw_pk_xlb      a,
                   jw_pk_rcmxb    b,
                   jw_jxrw_jxbxxb jxb,
                   jw_pk_kbsjb    s
             where a.xl_id = b.xl_id
               and a.xnm = jxb.xnm
               and a.xqm = jxb.xqm
               and s.xnm = jxb.xnm
               and s.xqm = jxb.xqm
               and jxb.jxb_id = s.jxb_id
               and s.jxb_id = vJxb_id
               and b.xqj = s.xqj
               and bitand(power(2, b.dxqzc - 1), s.zcd) > 0)
     where rn = '1';

    --获取时间后缀
    select max(t.jssj)
      into v_TimeSuffix
      from jw_pk_rjcszb t, jw_pk_rsdszb b
     where b.rsdsz_id = t.rsdsz_id
       and b.xnm = v_xnm
       and b.xqm = v_xqm
       and b.xqh_id = v_xiaoq
       and jcmc = v_section;

    sSjxx := v_TimePrefix || ' ' || v_TimeSuffix;

    --根据教学班信息来查询时间调整标记
    select sjtzbj into Sjtzbj from jw_jxrw_jxbxxb where jxb_id = vJxb_id;

    if Sjtzbj = '1' then
      --如果已存在的课程结束时间 大于实际系统数据的时间时不做处理（前提有针对时间调整的标记）
      select count(*)
        into sFlag
        from jw_jxrw_jxbxxb b
       where b.jxb_id = vJxb_id
         and b.kcjssj is not null
         and to_date(sSjxx, 'yyyy-mm-dd hh24:mi:ss') < to_date(b.kcjssj, 'yyyy-mm-dd hh24:mi:ss');

      --判断标记>0表示
      if sFlag > 0 then
        --获取原课程结束时间
        select kcjssj
          into sKcjssj_y
          from jw_jxrw_jxbxxb
         where jxb_id = vJxb_id;
        --进行赋值
        sSjxx := sKcjssj_y;
      end if;
    end if;

  exception
    When others then
      sSjxx := '';
  end;
  return sSjxx;
end fn_kcjssj;

/

