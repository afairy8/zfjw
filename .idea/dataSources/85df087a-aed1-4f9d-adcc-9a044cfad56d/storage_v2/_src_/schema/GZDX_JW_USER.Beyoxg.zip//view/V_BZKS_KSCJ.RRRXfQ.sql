create view V_BZKS_KSCJ as
  select t2.xh,t2.xm,
       (select xnmc from jw_jcdm_xnb where xnm = t1.xnm) xn,
       (select mc from zftal_xtgl_jcsjb where lx = '0001' and dm = t1.xqm) xq,
       t3.kch kcdm,t3.kcmc,t1.jxb_id xkkch,
       case when (select count(*) from jw_cj_dzb where dzmc = t1.cj) >0 then t1.cj end bfzkscj,
       case when (select count(*) from jw_cj_dzb where dzmc = t1.cj) =0 then t1.cj end djzkscj,
       case when t1.bfzcj>=60 then '是' else '否' end  SFTG,t1.cj,t1.bfzcj zscj,t1.cjxzm,
       '' cxbj,'' bkcj,'' kcxz,'' cxcj,'' cxxnxq,'' qzcj,'' fxbj,'' bkcj_bz,t1.jd,t3.xf,
       '' SFXWK,t3.KCLBDM,'' KSFSDM,'' KSXZDM,t1.cjbz bz
            from jw_cj_xscjb t1,jw_xjgl_xsjbxxb t2,jw_jh_kcdmb t3
where t1.xh_id = t2.xh_id
  and t1.kch_id = t3.kch_id
/

