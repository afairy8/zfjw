create function fun_spl_sjfwpp(                ------判断数据范围条件值是否符合:符合返回1,不符合返回0
tjfwztj varchar2,
vSjfwztj varchar2,
vSjfwztjqz varchar2,
vWid varchar2
) return varchar2
as
	sqlstr    varchar2(4000);
	sSjfwztjqz    varchar2(2000);
	sSjfwztj    varchar2(2000);
	sFlag    varchar2(1);
	sTjfwztj_arr mytype;     ------分割 tjfwztj 后的值
	sSjfwztj_arr  mytype;    ------分割 vSjfwztj 后的值
	sSjfwztjqz_arr  mytype;  ------分割 vSjfwztjqz 后的值
	sTjfwztjnj  varchar2(2000);
	sTjfwztjjg  varchar2(2000);
	sql1str    varchar2(4000);
	sql2str    varchar2(4000);
	sSjfwztjqz1  varchar2(2000);
	sSjfwztjqz2  varchar2(2000);
	sSfczdynjsjfwz varchar2(200);
	sSfczdyjgsjfwz varchar2(200);
	sJgsjfwz   varchar2(4000);
	sJdsjfwzqz   varchar2(4000);
	--sNjsjfwz   varchar2(4000);
  --sNjsjfwzqz   varchar2(4000);
begin
  begin
    sFlag := '0';
    sTjfwztj_arr := my_split(tjfwztj,';');
    sSjfwztj_arr := my_split(vSjfwztj,';');
    sSjfwztjqz_arr := my_split(vSjfwztjqz,';');
    ------tjfwztj参数带有njdm_id的，获取流程配置中数据范围条件”;”前的值：jg_id=？
   for t in 1..sSjfwztj_arr.count loop
    if t = 1 then
      sJgsjfwz := sSjfwztj_arr(t);
    /*eles
      sNjsjfwz := sSjfwztj_arr(t);*/
    end  if;
  end loop;
  ------tjfwztj参数带有njdm_id或不带njdm_id的，获取流程配置中数据范围值条件取值”;”前的值
  for p in 1..sSjfwztjqz_arr.count loop
    if p = 1 then
      sJdsjfwzqz := sSjfwztjqz_arr(p);
    end  if;
  end loop;

    ------判断 vSjfwztj 是否有njdm_id数据范围
    if sSjfwztj_arr.count = 2 and sSjfwztjqz_arr.count = 2 and sTjfwztj_arr.count = 2 then
      for k in 1..sTjfwztj_arr.count loop
        ------“;”后的是njdm_id
        if k = 2 then
           sTjfwztjnj := sTjfwztj_arr(k);
        else
           sTjfwztjjg := sTjfwztj_arr(k);
        end if;
      end loop;

      for a in 1..sTjfwztj_arr.count loop
        if a = 1 then
          ------执行数据范围取值语句,把替换=?成实际要执行的内容（jg_id）
          sql1str:= replace(sSjfwztjqz_arr(a),'=?','=''' ||vWid|| '''');
          execute immediate sql1str into sSjfwztjqz1;
          ------判断上述执行后的值是否存在于zftal_xtgl_sjfwzb中sjfwztj
          sSfczdyjgsjfwz := replace(sJgsjfwz,'=?','=')||sSjfwztjqz1;
          ------select instr(sTjfwztjjg,sSjfwztjqz1) into sSfczdyjgsjfwz from dual;
        else
          ------执行数据范围取值语句,把替换=?成实际要执行的内容（njdm_id）
          sql2str:= replace(sSjfwztjqz_arr(a),'=?','=''' ||vWid|| '''');
          execute immediate sql2str into sSjfwztjqz2;
          ------判断上述执行后的值是否存在于zftal_xtgl_sjfwzb中sjfwztj
          select instr(sTjfwztjnj,sSjfwztjqz2) into sSfczdynjsjfwz from dual;
          ------sSfczdynjsjfwz := replace(sNjsjfwz,'=?','=')||sSjfwztjqz2;
        end if ;
      end loop;
      if sSfczdynjsjfwz > 0 and sSfczdyjgsjfwz = sTjfwztjjg then
        sFlag := '1';
      else
        sFlag := '0';
      end if;
   else
      -------执行数据范围取值语句,把替换=?成实际要执行的内容
      sqlstr:= replace(sJdsjfwzqz,'=?','=''' ||vWid|| '''');
      execute immediate sqlstr into sSjfwztjqz;
      -------拼装出数据范围条件值,比如:jg_id=04
      sSjfwztj:=replace(sJgsjfwz,'=?','=')||sSjfwztjqz;
      ------目前判断的是zftal_xtgl_sjfwzb中sjfwztj跟拼装出来的结果一样的记录,像:jg_id=04;njdm_id=2019,2018,2017,2016  这种后面还要再处理
      if tjfwztj=sSjfwztj then
        sFlag := '1';
      end if;
    end if;

    return sFlag ;
    exception
      When others then
        return null;
  end;
end fun_spl_sjfwpp;

/

