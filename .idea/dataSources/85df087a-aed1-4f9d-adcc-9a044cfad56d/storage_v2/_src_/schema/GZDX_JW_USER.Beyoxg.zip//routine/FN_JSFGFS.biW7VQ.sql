create function FN_JSFGFS(vStr in varchar2,vFgf in varchar2) return number is
  aStrCd int;
  aDelFgsStrCd int;
begin
  select length(vStr) into aStrCd from dual;
  select length(replace(vStr,vFgf,'')) into aDelFgsStrCd from dual;
  return(aStrCd-aDelFgsStrCd);
end FN_JSFGFS;


/

