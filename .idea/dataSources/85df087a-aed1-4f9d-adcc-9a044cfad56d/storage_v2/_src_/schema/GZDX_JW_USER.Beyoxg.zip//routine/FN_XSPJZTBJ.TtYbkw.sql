create function fn_xspjztbj(vXnm varchar2,vXqm varchar2,vXh_id varchar2) return varchar2
as                          --被限制评价的学生和本学期没有课程的学生，在关联了学生评价的时候，可以直接选课
   sZtbj number;
begin
    begin
       select case when count(*) > 0 then 1 else 0 end into sZtbj from jw_pj_cpxsxzb where xnm = vXnm and xqm = vXqm and xh_id = vXh_id;
       if sZtbj > 0 then
         return sZtbj;
       else
       select case when nvl(max(sfkp),0) = 0 then 1
              else 0 end into sZtbj  from jw_xk_xsxkb where xnm = vXnm and xqm = vXqm and xh_id = vXh_id;
        return sZtbj;
       end if ;
     exception
        When others then
        return 0;
    end;
end fn_xspjztbj;

/

