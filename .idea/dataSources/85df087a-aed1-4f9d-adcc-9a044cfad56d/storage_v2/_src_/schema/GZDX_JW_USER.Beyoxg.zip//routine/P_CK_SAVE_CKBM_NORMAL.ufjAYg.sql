create procedure p_ck_save_ckbm_normal
(
  in_xh_id in varchar2,
  in_kch_id in varchar2,
  in_xqh_id in varchar2,
  in_bmsj in varchar2,
  out_flag out varchar2,
  out_msg out varchar2
)
as
v_kbzgxf varchar2(4);--可报最高学分
v_kbzdmc varchar2(4);
v_count  number;
v_count_bct number;
--v_count_ct number;
--v_count_ct2 number;
v_zi_jxb number;
v_jfdj number;
v_count_zib number;
v_count_2 number;
v_fjxb_id varchar2(32);
v_xkxnm varchar2(5);
v_xkxqm varchar2(2);
v_dkbckctkg varchar2(5);
v_gbckctkg  varchar2(5);
v_ckxkbmxm varchar2(10);
v_zxfs varchar2(10);--当前所选课程总学分
v_xf varchar2(10);
v_kcmc varchar2(100);
v_njdm_id varchar2(32);
v_zyh_id varchar2(32);
v_jxb_ids1 varchar2(4000);
v_jxb_ids2 varchar2(4000);
v_jxb_ids3 varchar2(4000);
jxb_array mytype;
begin
    out_flag := 1;
    /*select count(*) into v_count from jw_bygl_bysfzxxb where xh_id = in_xh_id;
     if v_count=0 then
       out_flag := -1;
       out_msg := '对不起，非毕业班的学生只能跟班报名，不允许重组报名，如有需要，请与管理员联系！';
       goto nextOne;
     end if;*/

    select count(*) into v_count from jw_cj_ckbmszb t where zt = '1' and sysdate between t.kssj and t.jssj;
    if v_count=0 then
        out_flag := -1;
        out_msg := '对不起，当前时间不可报名！';
        goto nextOne;
    end if;

    select xnm,xqm,kbzdmc,kbzgxf into v_xkxnm,v_xkxqm,v_kbzdmc,v_kbzgxf from jw_cj_ckbmszb t where zt = '1' and sysdate between t.kssj and t.jssj;
    if v_kbzdmc is not null then
        select count(distinct kch_id) into v_count from (
            select kch_id from jw_xk_xsxkb where cxbj = '2' and xnm =v_xkxnm and xqm =v_xkxqm and xh_id =in_xh_id
            union all
            select kch_id from jw_cj_ckbmb where xnm =v_xkxnm and xqm =v_xkxqm and xh_id =in_xh_id
        );

        if v_count>=to_number(v_kbzdmc) then
            out_flag := -1;
            out_msg := '对不起，最大报名门次为'||v_kbzdmc;
            goto nextOne;
        end if;
    end if;

    select t1.xf,t1.kcmc into v_xf,v_kcmc from  jw_jh_kcdmb t1 where t1.kch_id = in_kch_id;

    if v_kbzgxf is not null then
        select to_char(nvl(sum(t1.xf), 0), 'FM9990.0') into v_zxfs from jw_jh_kcdmb t1
        where exists(select 1 from jw_xk_xsxkb t2 where t1.kch_id=t2.kch_id and t2.cxbj='2' and t2.xnm=v_xkxnm and t2.xqm=v_xkxqm and t2.xh_id=in_xh_id);
        if v_zxfs*1+v_xf*1 > v_kbzgxf*1 then
            out_flag := -1;
            out_msg := '对不起，最高可报学分为'||v_kbzgxf||'，选课后总学分为'||(v_zxfs*1+v_xf*1)||'，已超过最高学分！';
            goto nextOne;
         end if;
    end if;

    select zdz into v_ckxkbmxm from zftal_xtgl_xtszb where ssmk ='XKMK' and zdm = 'CKXKBMXM';

    select dkbckctkg, gbckctkg  into v_dkbckctkg, v_gbckctkg from jw_cj_ckbmszb t where xnm=v_xkxnm and xqm=v_xkxqm and sysdate between t.kssj and t.jssj and  t.zt = '1';
    if instr(v_ckxkbmxm,'1')>0 then
        select count(*) into v_count from jw_jxrw_jxbxxb t
        where
            --有无任务教学班
            t.kch_id=in_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
            --是否在同一个校区
            and t.xqh_id=in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt,'3') = '3' and t.cxbmkg ='1'
            --有无余量
            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));

         select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
             select rn,wm_concat(jxb_id) as jxb_ids from (
                 select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from (
                     select jxb_id from jw_jxrw_jxbxxb t
                     where
                         --有无任务教学班
                         t.kch_id=in_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
                         --是否在同一个校区
                         and t.xqh_id=in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt,'3') = '3' and t.cxbmkg ='1'
                         --有无余量
                         and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                     minus
                     select jxb_id from (
                         select t2.jxb_id from (
                             select a.jxb_id, b.xqj, b.zcd, b.jc from jw_xk_xsxkb a, jw_pk_kbsjb b
                             where a.jxb_id = b.jxb_id and a.kch_id != in_kch_id and a.xh_id = in_xh_id and b.xnm = v_xkxnm
                                 and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm and a.zxbj != '1'
                         ) t1,
                         (
                              select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                              where exists (
                                  select 'x' from jw_jxrw_jxbxxb t
                                  --有无任务教学班
                                  where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and sjb.jxb_id = t.jxb_id
                                  --是否在同一个校区
                                  and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and t.cxbmkg = '1'
                                  --有无余量
                                  and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0)))
                          ) t2
                     where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                     union
                     select t2.jxb_id from (
                         select sum(zc) zcd, xqj, jc from (
                             select zc, xqj, sum(jcm) jc from (
                                 select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                     select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj from jw_pk_xlb a, jw_pk_rcmxb b
                                     where a.xl_id = b.xl_id and b.dxqzc <> 0
                                 ) t2,
                                 jw_pk_rsdszb a,
                                 jw_pk_rjcszb b,
                                 jw_pk_rsddmb c,
                                 (
                                     --正考学生--
                                     select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                     where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                         and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                         and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                     group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     union all
                                     --补考学生--
                                     select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                     where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                         and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                         and t4.bkqrbj = '1' and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm
                                         and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                     group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                 ) t3
                                 where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and a.xnm = t3.xnm and a.xqm = t3.xqm
                                     and a.xqh_id = in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                     and c.qyzt = '1' and t2.xnm = t3.xnm and t2.xqm = t3.xqm and t2.rq = t3.ksrq
                             )
                             group by zc, xqj
                         )
                         group by jc, xqj
                     ) t1,
                     (
                         select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                         where exists (
                             select 'x' from jw_jxrw_jxbxxb t
                             --有无任务教学班
                             where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and sjb.jxb_id = t.jxb_id
                             --是否在同一个校区
                             and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and t.cxbmkg = '1'
                             --有无余量
                             and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                         )
                     ) t2
                     where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                     union
                     select t2.jxb_id from (
                         select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                         from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                         where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                             and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                             and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                         group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                         union all
                         select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                         from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                         where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                             and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                             and t4.bkqrbj = '1' and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                         group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                     ) t1,
                     (
                         select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                         from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                         where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                             and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                             and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                         group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                     ) t2
                     where t1.ksrq = t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                         and exists (
                             select 'x' from jw_jxrw_jxbxxb t
                             --有无任务教学班
                             where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and t2.jxb_id = t.jxb_id
                             --是否在同一个校区
                             and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and t.cxbmkg = '1'
                             --有无余量
                             and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                         )
                     union
                     select t2.jxb_id from (
                         select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                         where a.jxb_id = b.jxb_id and b.xh_id = in_xh_id and b.xnm = v_xkxnm and b.xqm = v_xkxqm and nvl(b.zxbj, '0') = '0'
                    ) t1,
                    (
                        select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                            select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                    select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                    from jw_pk_xlb a, jw_pk_rcmxb b
                                    where a.xl_id = b.xl_id and b.dxqzc <> 0
                                ) t2,
                                jw_pk_rsdszb a,
                                jw_pk_rjcszb b,
                                jw_pk_rsddmb c,
                                (
                                    select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                    from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb   t4
                                    where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                        and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                        and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                    group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                ) t3
                                where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and a.xnm = t3.xnm and a.xqm = t3.xqm
                                    and a.xqh_id = in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                    and c.qyzt = '1' and t2.xnm = t3.xnm and t2.xqm = t3.xqm and t2.rq = t3.ksrq
                            )
                            group by zc, xqj, kch_id, jxb_id
                        )
                        group by jc, xqj, kch_id, jxb_id
                    ) t2
                    where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                        and exists(
                            select 'x' from jw_jxrw_jxbxxb t
                            --有无任务教学班
                            where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and t2.jxb_id = t.jxb_id
                            --是否在同一个校区
                            and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and t.cxbmkg = '1'
                            --有无余量
                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                        )
                    )
                )
            )
            group by rn
        );

        if v_jxb_ids1 is not null then
            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
            for i in 1..jxb_array.count loop
                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                if v_zi_jxb=1 then
                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                        v_count_bct := 1;
                        goto stepOne;
                    end if;
                else
                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                    if v_count_zib>0 then
                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                        if v_count_2>0 then
                            v_count_bct := 1;
                            goto stepOne;
                        end if;
                    else
                        v_count_bct := 1;
                        goto stepOne;
                    end if;
                end if;
            end loop;
        end if;
        <<stepOne>>
        if v_count>0 then
            if v_gbckctkg = '1' or v_count_bct>0 then
                out_flag := 0;
                out_msg := '该课程有可以选重考的教学班，请在跟班重考页签下选择！';
                goto nextOne;
            end if;
        end if;
    end if;

    if instr(v_ckxkbmxm,'2')>0 then
        select count(*) into v_count from jw_jxrw_jxbxxb t
        --有无任务教学班
        where t.kch_id=in_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
            --是否在同一个校区
            and t.xqh_id=in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt,'3') = '3' and (t.kklxdm = '28')
            --有无余量
            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0));

        select max(decode(rn,1,jxb_ids)),max(decode(rn,2,jxb_ids)),max(decode(rn,3,jxb_ids)) into v_jxb_ids1,v_jxb_ids2,v_jxb_ids3 from (
            select rn,wm_concat(jxb_id) as jxb_ids from (
                select case when rownum <= 100 then 1 when rownum <= 200 and  rownum > 100 then 2 else 3 end rn, jxb_id from  (
                    select jxb_id from jw_jxrw_jxbxxb t
                    --有无任务教学班
                    where t.kch_id=in_kch_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm
                    --是否在同一个校区
                    and t.xqh_id=in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt,'3') = '3' and t.kklxdm = '28'
                    --有无余量
                    and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm=t.xnm and t1.xqm=t.xqm and t1.jxb_id=t.jxb_id)<(nvl(jxbrs,0)+nvl(krrl,0))
                minus
                select jxb_id from (
                    select t2.jxb_id from (
                        select a.jxb_id, b.xqj, b.zcd, b.jc
                        from jw_xk_xsxkb a, jw_pk_kbsjb b
                        where a.jxb_id = b.jxb_id and a.kch_id != in_kch_id and a.xh_id = in_xh_id
                            and b.xnm = v_xkxnm and b.xqm = v_xkxqm and a.xnm = v_xkxnm and a.xqm = v_xkxqm and a.zxbj != '1'
                    ) t1,
                    (
                        select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                        where exists (
                            select 'x' from jw_jxrw_jxbxxb t
                            --有无任务教学班
                            where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and sjb.jxb_id = t.jxb_id
                            --是否在同一个校区
                            and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and (t.kklxdm = '28')
                            --有无余量
                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                        )
                    ) t2
                    where t1.xqj = t2.xqj and bitand(t1.zcd,t2.zcd)>0 and bitand(t1.jc,t2.jc)>0
                    union
                    select t2.jxb_id from (
                        select sum(zc) zcd, xqj, jc from (
                            select zc, xqj, sum(jcm) jc from (
                                select t2.zc,t2.xqj,t3.xh_id,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq from (
                                    select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                    from jw_pk_xlb a,jw_pk_rcmxb b
                                    where a.xl_id = b.xl_id and b.dxqzc <> 0
                                ) t2,
                                jw_pk_rsdszb a,
                                jw_pk_rjcszb b,
                                jw_pk_rsddmb c,
                                (
                                     --正考学生--
                                     select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                                     where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                         and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                         and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                     group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     union all
                                     --补考学生--
                                     select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                     from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                                     where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                         and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                         and t4.bkqrbj = '1' and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                     group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm
                                ) t3
                                where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and a.xnm = t3.xnm and a.xqm = t3.xqm
                                    and a.xqh_id = in_xqh_id and b.qssj < t3.ksjssj || ':00' and b.jssj > t3.kskssj || ':00'
                                    and c.qyzt = '1' and t2.xnm = t3.xnm and t2.xqm = t3.xqm and t2.rq = t3.ksrq
                            )
                            group by zc, xqj
                        )
                        group by jc, xqj
                    ) t1,
                    (
                        select jxb_id, xqj, zcd, jc from jw_pk_kbsjb sjb
                        where exists (
                            select 'x' from jw_jxrw_jxbxxb t
                                --有无任务教学班
                            where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and sjb.jxb_id = t.jxb_id
                                --是否在同一个校区
                                and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and (t.kklxdm = '28')
                                --有无余量
                                and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id)<(nvl(jxbrs, 0) + nvl(krrl, 0))
                        )
                    ) t2
                    where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0
                    union
                    select t2.jxb_id from (
                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
                        where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                            and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                            and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                        union all
                        select t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
                        where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                            and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                            and t4.bkqrbj = '1' and t4.xh_id = in_xh_id and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm
                            and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t4.xh_id,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                    ) t1,
                    (
                        select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                        from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                        where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                            and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                            and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                        group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                    ) t2
                    where t1.ksrq = t2.ksrq and t2.kskssj < t1.ksjssj and t2.ksjssj > t1.kskssj and t1.jxb_id != t2.jxb_id
                    and exists (
                        select 'x' from jw_jxrw_jxbxxb t
                        --有无任务教学班
                        where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and t2.jxb_id = t.jxb_id
                        --是否在同一个校区
                        and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and (t.kklxdm = '28')
                        --有无余量
                        and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                    )
                    union
                    select t2.jxb_id from (
                        select a.jxb_id, xqj, zcd, jc from jw_pk_kbsjb a, jw_xk_xsxkb b
                        where a.jxb_id = b.jxb_id and b.xh_id = in_xh_id and b.xnm = v_xkxnm and b.xqm = v_xkxqm and nvl(b.zxbj, '0') = '0'
                    ) t1,
                    (
                        select sum(zc) zcd, xqj, jc, kch_id, jxb_id from (
                            select zc, xqj, sum(jcm) jc, kch_id, jxb_id from (
                                select t2.zc,t2.xqj,b.jcm,t3.xnm,t3.xqm,a.xqh_id,t3.kskssj,t3.ksjssj,t3.ksrq,t3.kch_id,t3.jxb_id from (
                                    select a.xnm,b.dxqm xqm,power(2, b.dxqzc - 1) zc,b.rq,b.xqj
                                    from jw_pk_xlb a, jw_pk_rcmxb b
                                    where a.xl_id = b.xl_id and b.dxqzc <> 0
                                ) t2,
                                jw_pk_rsdszb a,
                                jw_pk_rjcszb b,
                                jw_pk_rsddmb c,
                                (
                                    select t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                    from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbxxb t4
                                    where t1.xnm = t2.xnm and t1.xqm = t2.xqm and t1.xnm = t3.xnm and t1.xqm = t3.xqm
                                        and t1.sjbh_id = t3.sjbh_id and t1.ksccb_id = t2.ksccb_id and t3.jxb_id = t4.jxb_id
                                        and t1.xnm = v_xkxnm and t1.xqm = v_xkxqm and t4.xnm = v_xkxnm and t4.xqm = v_xkxqm
                                    group by t2.ksrq,t2.kskssj,t2.ksjssj,t1.xnm,t1.xqm,t4.kch_id,t4.jxb_id
                                ) t3
                                where a.rsdsz_id = b.rsdsz_id and a.rsd_id = c.rsd_id and a.xnm = t3.xnm
                                    and a.xqm = t3.xqm and a.xqh_id = in_xqh_id and b.qssj < t3.ksjssj || ':00'
                                    and b.jssj > t3.kskssj || ':00' and c.qyzt = '1' and t2.xnm = t3.xnm
                                    and t2.xqm = t3.xqm and t2.rq = t3.ksrq
                            )
                            group by zc, xqj, kch_id, jxb_id
                        )
                        group by jc, xqj, kch_id, jxb_id
                    ) t2
                    where t1.xqj = t2.xqj and bitand(t1.zcd, t2.zcd) > 0 and bitand(t1.jc, t2.jc) > 0 and t1.jxb_id != t2.jxb_id
                        and exists (
                            select 'x' from jw_jxrw_jxbxxb t
                            --有无任务教学班
                            where t.kch_id = in_kch_id and t.xnm = v_xkxnm and t.xqm = v_xkxqm and t2.jxb_id = t.jxb_id
                            --是否在同一个校区
                            and t.xqh_id = in_xqh_id and t.sfkxk = '1' and t.kkzt = '1' and nvl(t.shzt, '3') = '3' and (t.kklxdm = '28')
                            --有无余量
                            and (select count(jxb_id) from jw_xk_xsxkb t1 where t1.xnm = t.xnm and t1.xqm = t.xqm and t1.jxb_id = t.jxb_id) < (nvl(jxbrs, 0) + nvl(krrl, 0))
                        )

                    )
                )
            )
            group by rn
        );

        if v_jxb_ids1 is not null then
            jxb_array:=my_split(v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,''),',');
            for i in 1..jxb_array.count loop
                select count(*) into v_zi_jxb from jw_jxrw_jxbxxb where jxb_id=jxb_array(i) and fjxb_id is not null;
                if v_zi_jxb=1 then
                    select fjxb_id into v_fjxb_id from jw_jxrw_jxbxxb where jxb_id=jxb_array(i);
                    if instr(','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',',','||v_fjxb_id||',')>0 then
                        v_count_bct := 1;
                        goto stepTwo;
                    end if;
                else
                    select count(*) into v_count_zib from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i);
                    if v_count_zib>0 then
                        select count(*) into v_count_2 from jw_jxrw_jxbxxb where fjxb_id=jxb_array(i) and ','||v_jxb_ids1||','||nvl(v_jxb_ids2,'')||','||nvl(v_jxb_ids3,'')||',' like ','||jxb_id||',';
                        if v_count_2>0 then
                            v_count_bct := 1;
                            goto stepTwo;
                        end if;
                    else
                        v_count_bct := 1;
                        goto stepTwo;
                    end if;
                end if;
            end loop;
        end if;
        <<stepTwo>>

        if v_count>0 then
            if v_dkbckctkg = '1' or v_count_bct>0 then
                out_flag := 0;
                out_msg := '该课程有可以选重考的教学班，请在跟单开班重考页签下选择！';
                goto nextOne;
            end if;
        end if;
    end if;

    /*if v_count>0 and instr(v_ckxkbmxm,'2')>0  then
    if v_dkbckctkg = '1' or v_count_ct2  != v_count then
      out_flag := 0;
      out_msg := '该课程有可以选重修的教学班，请在跟单开班重修页签下选择！';
      goto nextOne;
    end if;
    end if;*/

    insert into jw_cj_ckbmb(xnm,xqm,kch_id,xh_id,bmsj,jfzt) values (v_xkxnm,v_xkxqm,in_kch_id,in_xh_id,in_bmsj,'0');
    --判断是否从资格库报名,并更新数据
    select count(*) into v_count from zftal_xtgl_xtszb where zdm='CKBMZGKG' and zdz='1';
    if v_count > 0 then
        update jw_cj_ckbmb t set
            (xf,kclbdm,kcxzdm,kcgsdm,cj,cjbz,bfzcj)=(select xf,kclbdm,kcxzdm,kcgsdm,cj,cjbz,bfzcj from jw_cj_ckmdtjb where ckxnm=t.xnm and ckxqm=t.xqm and xh_id=t.xh_id and kch_id=t.kch_id and rownum=1)
        where t.xh_id=in_xh_id and t.xnm=v_xkxnm and t.xqm=v_xkxqm and t.kch_id=in_kch_id ;
    end if;
    select count(*) into v_count from jw_jcdml_xtnzb where zdm='CKBMJFXXXS' and zdz='1';
    if v_count>0 then
        select njdm_id,zyh_id into v_njdm_id,v_zyh_id from jw_xjgl_xsxjxxb where xnm=v_xkxnm and xqm=v_xkxqm and xh_id=in_xh_id;
        v_jfdj := fn_cx_jfdj(v_njdm_id,v_zyh_id,in_kch_id,'',in_xh_id,'2');
        insert into zftal_xtgl_zfywsjb(ywdm,ywsjb,ywsjb_id,order_amount,order_men,order_name)
        values
        ('06','jw_cj_ckbmb',v_xkxnm||lpad(v_xkxqm,2,'0')||in_kch_id||in_xh_id,v_xf*v_jfdj*100,in_xh_id,v_kcmc);
    end if;
    <<nextOne>>
    if out_flag = '-1' then
        rollback;
    else
        commit;
    end if;
end;

/

