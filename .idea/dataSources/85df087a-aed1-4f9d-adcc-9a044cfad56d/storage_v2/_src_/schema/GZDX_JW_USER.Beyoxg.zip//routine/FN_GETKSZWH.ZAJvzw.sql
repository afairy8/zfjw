create function fn_getKszwh(
  v_xnm  varchar2,
  v_xqm  varchar2,
  v_ksmcdmb_id  varchar2,
  v_sjbh_id  varchar2,
  v_cd_id  varchar2,
  v_jxb_id  varchar2,
  v_kch_id  varchar2,
  v_xh_id  varchar2,
  v_zwh  varchar2,
  vBj varchar2)return varchar2
is
  vKszwh varchar2(3);
  icount number;
  sscd_id varchar2(32);
  cdmc varchar2(50);
  begin
    vKszwh:='';
    select count(*) into icount from zftal_xtgl_xxxxszb where xxdm = '10434';
    if vBj = '1' then
      vKszwh := v_zwh;
    end if;
    if icount=1 then
      select SSCD_ID into sscd_id from JW_JCDM_CDJBXXB where cd_id=v_cd_id;
      select cdmc into cdmc from JW_JCDM_CDJBXXB where cd_id=v_cd_id;
      vKszwh :=(case when sscd_id is not null then substr(cdmc,-1,1) else  '' end)||v_zwh;
    end if ;
    return vKszwh;
  end fn_getKszwh;

/

