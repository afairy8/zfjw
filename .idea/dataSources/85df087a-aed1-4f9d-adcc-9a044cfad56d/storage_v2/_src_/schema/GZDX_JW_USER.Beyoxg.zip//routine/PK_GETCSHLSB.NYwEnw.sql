create Procedure Pk_GetCshlsb(
    vXnm      in varchar2,
    vXqm      in varchar2,
    vJg_id    in varchar2,
    vNjdm_id  in varchar2,
    vZyh_id   in varchar2,
    vBh_id    in varchar2,
    vTj       in varchar2,
    vLx       in varchar2,
    vJgh_id   in varchar2,
    vClbj     in varchar2,
    vBj       out varchar2)
as
  v_jls number; ----记录数
  sSql varchar2(10000);
  i number;

  cursor Get_Cshxx is     ----取异常教学任务信息。----游标---
  select count(a.xnm) jls From jw_pk_jxrwlsb a, JW_PK_CSHLSB c
                                   where a.xnm = vXnm
                                     and a.xqm = vXqm
                                     and a.jxb_id = c.jxb_id
                                     and c.xnm = vXnm
                                     and c.dxqm = vXqm
                                     and c.jgh_id = vJgh_id
                                     and c.lx = vLx
                                     and c.clbj = vClbj
                                     and not exists(select 'X' from JW_PK_CSHZTLSB b
                                                         where a.njdm_id = b.njdm_id
                                                           and a.zyh_id = b.zyh_id
                                                           and a.bh_id = b.bh_id
                                                           and b.xnm = vXnm
                                                           and b.dxqm =vXqm
                                                           and b.jgh_id = vJgh_id
                                                           and b.lx = vLx
                                                           and b.clbj = vClbj
                                                           and b.zt = '0')
                                     and a.xnm=vXnm and a.dxqm = vXqm and rownum = 1;

  Cur_Cshxx Get_Cshxx%rowtype;
 --------------------------------------------------------------------------------
begin

  vBj := '0';
  i := 0;
  delete from JW_PK_CSHLSB   where xnm = vXnm and dxqm = vXqm and lx = vLx and jgh_id = vJgh_id;
  delete from JW_PK_CSHZTLSB where xnm = vXnm and dxqm = vXqm and lx = vLx and jgh_id = vJgh_id;
  if vTj is not null then
    sSql := 'insert into JW_PK_CSHLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,lx,jgh_id,clbj)
    select a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.rs, '''||vLx||''','''||vJgh_id||''','''||vClbj||''' from
                       jw_pk_jxrwlsb a where a.xnm  = '''||vXnm||'''
                                         and a.dxqm = '''||vXqm||'''
                                         and '''||vTj||''' like ''%''||a.njdm_id||a.zyh_id||a.bh_id||''%'' ';
  else
  sSql := 'insert into JW_PK_CSHLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,lx,jgh_id,clbj)
    select a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.rs, '''||vLx||''','''||vJgh_id||''','''||vClbj||''' from
                       jw_pk_jxrwlsb a where xnm= '''||vXnm||'''
                                       and a.dxqm = '''||vXqm||''' ';
      if vJg_id is not null then
         sSql := sSql || ' and exists(select ''X'' from zftal_xtgl_zydmb b where a.zyh_id = b.zyh_id and b.jg_id = '''||vJg_id||''')';
      end if;

      if vNjdm_id is not null then
         sSql := sSql || ' and a.njdm_id = '''||vNjdm_id||'''';
      end if;

      if vZyh_id is not null then
         sSql := sSql || ' and a.zyh_id = '''||vZyh_id||'''';
      end if;

      if vBh_id is not null then
         sSql := sSql || ' and a.bh_id = '''||vBh_id||'''';
      end if;

  end if;
  Execute Immediate sSql;
  commit;
  insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,clbj,zt)
        select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_id,clbj,'0' zt from JW_PK_CSHLSB a    -----已初始化状态
                   where a.xnm = vXnm
                     and a.dxqm = vXqm
                     and a.lx = vLx
                     and a.jgh_id = vJgh_id
                     and a.clbj = vClbj;
  commit;
  -------------------------------------------------------------------------------
  <<NextReCord>>
  v_jls:=0;
  open Get_Cshxx;
  loop
    fetch Get_Cshxx into Cur_Cshxx;
     exit when Get_Cshxx%notfound;
     v_jls:=Cur_Cshxx.jls;
     if v_jls > 0 then
       begin
         i:=i+1;
         if i >10 then
           Goto Exend;
         end if;
       -------------------------------------------------------
       insert into JW_PK_CSHLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,zyfx_id,kch_id,jxb_id,fjxb_id,xsdm,rs,lx,jgh_id,clbj)
                select a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.zyfx_id,a.kch_id,a.jxb_id,a.fjxb_id,a.xsdm,a.rs,
                       vLx,vJgh_id,vClbj From jw_pk_jxrwlsb a,JW_PK_CSHLSB c
                                                 where a.xnm    = vXnm
                                                   and a.xqm    = vXqm
                                                   and a.jxb_id = c.jxb_id
                                                   and c.xnm    = vXnm
                                                   and c.dxqm   = vXqm
                                                   and c.jgh_id = vJgh_id
                                                   and c.lx     = vLx
                                                   and c.clbj   = vClbj
                                                   and not exists(select 'X' from JW_PK_CSHLSB b
                                                                                  where a.njdm_id   = b.njdm_id
                                                                                    and a.zyh_id    = b.zyh_id
                                                                                    and a.bh_id     = b.bh_id
                                                                                    and b.xnm       = vXnm
                                                                                    and b.dxqm      = vXqm
                                                                                    and b.jgh_id    = vJgh_id
                                                                                    and b.lx        = vLx
                                                                                    and b.clbj      = vClbj )
                                                   and a.xnm = vXnm
                                                   and a.dxqm = vXqm ;
       -------------------------------------------------------

        insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,clbj,zt)
        select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_id,clbj,'0' zt from JW_PK_CSHLSB a    -----已初始化状态
                   where a.xnm = vXnm
                     and a.dxqm = vXqm
                     and a.lx = vLx
                     and a.jgh_id = vJgh_id
                     and a.clbj = vClbj
                     and exists( select 'X' from JW_PK_CSHZTLSB b
                                            where b.xnm  = vXnm
                                              and b.dxqm = vXqm
                                              and a.lx = b.lx
                                              and a.jgh_id = b.jgh_id
                                              and a.clbj = b.clbj
                                              and a.njdm_id = b.njdm_id
                                              and a.zyh_id = b.zyh_id
                                              and a.bh_id = b.bh_id );

       commit;
      exception
        When others then
          Rollback;
          Goto Exend;
      end;
     else
       Goto Exend;
     end if;
  end loop;
  close Get_Cshxx;
  Goto NextReCord;
  <<Exend>>
  begin

  if vLx = '0' then ----待初始化数据（没有生成排课矩阵的数据）
    -----已初始化状态(zt 1 表示正常使用 0 表示临时内部使用)
  insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,zt,clbj)
    select distinct xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_id,'1' zt,clbj from JW_PK_CSHLSB a
               where a.xnm = vXnm
                 and a.xqm = vXqm
                 and a.lx = vLx
                 and a.jgh_id = vJgh_id
                 and a.clbj = vClbj
                 and not exists(select 'X' from jw_pk_cshztb c
                                          where c.bj = '0'
                                            and a.njdm_id = c.njdm_id
                                            and a.zyh_id = c.zyh_id
                                            and a.bh_id = c.bh_id
                                            and c.xnm = vXnm
                                            and c.xqm = vXqm )
                 and not exists(select 'X' from jw_pk_tjkbjgb b
                                              where b.xnm = vXnm
                                                and b.xqm = vXqm
                                                and a.njdm_id = b.njdm_id
                                                and a.zyh_id = b.zyh_id
                                                and a.bh_id = b.bh_id);
  end if;

  if vLx = '1' then  ---待清空初始化数据（没有排课的数据）
  insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,zt,clbj)
    select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.lx,a.jgh_id,'1' zt,a.clbj from JW_PK_CSHLSB a,jw_pk_cshztb b    -----已初始化状态
               where a.xnm = vXnm
                 and a.dxqm = vXqm
                 and b.xnm = vXnm
                 and b.dxqm = vXqm
                 and a.lx = vLx
                 and a.jgh_id = vJgh_id
                 and a.clbj = vClbj
                 and a.njdm_id = b.njdm_id
                 and a.zyh_id = b.zyh_id
                 and a.bh_id = b.bh_id
                 and b.bj = '1'
                 and not exists(select 'X' from jw_pk_jxrwlsb t1,jw_pk_kbsjb t2
                                              where t1.xnm = vXnm
                                                and t1.dxqm = vXqm
                                                and t2.xnm = vXnm
                                                and t2.xqm =vXqm
                                                and t1.jxb_id = t2.jxb_id
                                                and a.njdm_id = t1.njdm_id
                                                and a.zyh_id = t1.zyh_id
                                                and a.bh_id = t1.bh_id );
  end if;

  if vLx = '2' then  ---待课表刷新
  insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,zt,clbj)
    select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.lx,a.jgh_id,'1' zt,a.clbj from JW_PK_CSHLSB a,jw_pk_cshztb b    -----已初始化状态
               where a.xnm = vXnm
                 and a.dxqm = vXqm
                 and b.xnm = vXnm
                 and b.dxqm = vXqm
                 and a.lx = vLx
                 and a.jgh_id = vJgh_id
                 and a.clbj = vClbj
                 and a.njdm_id = b.njdm_id
                 and a.zyh_id = b.zyh_id
                 and a.bh_id = b.bh_id
                 and b.bj = '2'
                 and not exists(select 'X' from jw_pk_cshztb t
                                          where t.bj = '0'
                                            and t.xnm = a.xnm
                                            and t.dxqm = a.dxqm
                                            and bitand(t.xqm, a.xqm) >0
                                            and t.njdm_id = a.njdm_id
                                            and t.zyh_id = a.zyh_id
                                            and t.bh_id = a.bh_id)
                 and exists(select 'X' from jw_pk_jxrwlsb t1,jw_pk_kbsjb t2
                                              where a.xnm = t1.xnm
                                                and a.xqm = t1.xqm
                                                and a.xnm = t2.xnm
                                                and a.xqm = t2.xqm
                                                and t1.xnm = vXnm
                                                and t1.dxqm = vXqm
                                                and t2.xnm = vXnm
                                                and bitand(t2.xqm ,vXqm)>0
                                                and t1.jxb_id = t2.jxb_id
                                                and a.njdm_id = t1.njdm_id
                                                and a.zyh_id = t1.zyh_id
                                                and a.bh_id = t1.bh_id );
  end if;

  if vLx = '3' then  ---待人数刷新
  insert into JW_PK_CSHZTLSB(xnm,dxqm,xqm,njdm_id,zyh_id,bh_id,lx,jgh_Id,zt,clbj)
    select distinct a.xnm,a.dxqm,a.xqm,a.njdm_id,a.zyh_id,a.bh_id,a.lx,a.jgh_id,'1' zt,a.clbj from JW_PK_CSHLSB a,jw_pk_tjxsbrsb b    -----已初始化状态
               where a.xnm = vXnm
                 and a.dxqm = vXqm
                 and b.xnm = vXnm
                 and b.xqm = vXqm
                 and a.lx = vLx
                 and a.jgh_id = vJgh_id
                 and a.clbj = vClbj
                 and a.njdm_id = b.njdm_id
                 and a.zyh_id = b.zyh_id
                 and a.bh_id = b.bh_id;
  end if;
  commit;
  end;
  null;
-----------------------------------------------------------------------------------------------------------------------
end;

/

