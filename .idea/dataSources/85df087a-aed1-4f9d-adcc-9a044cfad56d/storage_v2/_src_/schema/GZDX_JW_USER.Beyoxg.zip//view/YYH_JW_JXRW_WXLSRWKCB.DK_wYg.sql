create view YYH_JW_JXRW_WXLSRWKCB as
  select jyxdxnm||jyxdxnm+1||'1'||yy bls,zyh_id,kch_id, jyxdxnm,jyxdxqm ,v.jxzxjhkcxx_id  from  jw_jxrw_wxlsrwkcb v where v.zzshjg='1'
/

