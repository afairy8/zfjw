create function fn_jxbypcdxs(fn_jxbid varchar2) return number  ---教学班已排场地学时
as
   v_ypcdxs number;
begin
   select count(1) into v_ypcdxs from
   (select b.rn zc,a.xqj,c.rn jc from
     (select m.zcd ,n.xqj,m.jc from jw_pk_kbcdb m,jw_pk_kbsjb n where m.kb_id=n.kb_id and n.jxb_id=fn_jxbid) a ,
     (select power(2,rownum-1) rn from zftal_xtgl_jcsjlxb where rownum<=40) b,
     (select power(2,rownum-1) rn from zftal_xtgl_jcsjlxb where rownum<=40) c
     where bitand(a.zcd,b.rn) > 0 and bitand(a.jc,c.rn)>0
     group by b.rn,a.xqj,c.rn
   );
   return v_ypcdxs;
end fn_jxbypcdxs;

/

