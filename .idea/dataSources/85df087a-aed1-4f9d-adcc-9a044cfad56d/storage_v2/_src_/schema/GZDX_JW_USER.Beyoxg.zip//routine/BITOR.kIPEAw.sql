create function bitor(x IN NUMBER,y IN NUMBER)
return number is
begin
return (x + y) - BITAND(x, y);
end;


/

