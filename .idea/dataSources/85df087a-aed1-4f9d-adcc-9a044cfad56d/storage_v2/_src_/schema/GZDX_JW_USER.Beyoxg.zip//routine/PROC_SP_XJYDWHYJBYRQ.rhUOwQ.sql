create procedure proc_sp_xjydwhyjbyrq(
                        xxdm varchar2,
                        yxzd varchar2,
                        ydfxxnm varchar2,
                        ydfxxqm varchar2,
                        xh_ids varchar2,
                        ydlbms varchar2,
                        ydsxxnm varchar2,
                        ydsxxqm varchar2,
                        xxjssj varchar2,
                        xxqssj varchar2,
                        ydhnjdm_id varchar2,
                        ydhjg_id varchar2,
                        out_ydhyjbyrq out varchar2) as
    v_yjbyrq varchar2(5);/*预计毕业日期，只有日期*/
    v_ydqyjbyrq varchar2(10);/*异动前预计毕业日期*/
    v_ydhyjbyrq varchar2(10);/*异动后预计毕业日期*/
    v_sfgdxjxx varchar2(2);/*是否改动学籍，1:改动，0:不改动*/
    v_xjydxxfs varchar(2);/*学籍异动休学方式*/

    num_ydhxz number;
    num_yjbyn number;/*预计毕业年，只有年*/
    num_ydqxz number;/*异动前学制*/

    v_xxxzjsgzz varchar2(20);  /*休学学制计算规则的值*/
    v_ydxqs   number;    /*休学的学期数（休学方式按学期）*/
    v_xxxzjsz varchar2(20);    /*休学的学期数（休学方式按日期）*/
    v_ydsjb   varchar2(20);   /*休学学制计算规则的值*/
    v_ydfxxqmmc varchar2(32); /*异动复学学期名称*/
    v_ydsxxqmc varchar2(32); /*异动生效学期名称*/
    num_ydhyjbyrq number;
begin
    /*判断预计毕业日期是否是影响学籍字段*/
    select countSplit('yjbyrq',yxzd) into num_ydhyjbyrq from dual;

    select xs.yjbyrq into v_ydqyjbyrq from jw_xjgl_xsjbxxb xs where xs.xh_id=xh_ids;
    select xs.xz into num_ydqxz from jw_xjgl_xsjbxxb xs where xs.xh_id=xh_ids;
    select sfgdxjxx into v_sfgdxjxx from jw_xjgl_xjydlbdmb where ydlbm = ydlbms;
    select x.zdz into v_xjydxxfs from jw_jcdml_xtnzb x where x.zdm = 'XJYDXXFS';/*休学方式*/
    if ydlbms = '11' then
    if v_xjydxxfs = '2' then
      select jcsj.mc into v_ydfxxqmmc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and dm = ydfxxqm;
    end if;
    select jcsj.mc into v_ydsxxqmc from zftal_xtgl_jcsjb jcsj where jcsj.lx = '0001' and dm = ydsxxqm;
    end if;
    /*计算异动前预计毕业日期*/
    if xxdm = '10248' then
        if v_ydqyjbyrq is null then
            /*预计毕业日期（只有日期）*/
            select max(t.yjbyrq) into v_yjbyrq from JW_XJGL_YJBYRQJGDZB t where t.jg_id = (select jg_id from jw_xjgl_xsjbxxb where xh_id = xh_ids);
            /*计算异动前预计毕业年*/
            select (to_number(xs.njdm_id) + to_number(xs.xz)) into num_yjbyn from jw_xjgl_xsjbxxb xs where xs.xh_id=xh_ids;
              v_ydqyjbyrq := num_yjbyn || '-' || v_yjbyrq;
        end if;
        /*获取预计毕业日期（只有日期）*/
        select substr(v_ydqyjbyrq,6) into v_yjbyrq from dual;

        /*计算异动后预计毕业日期*/
        if v_sfgdxjxx = 1 then
            /*预计毕业年，默认取异动前的年*/
            select to_number(substr(v_ydqyjbyrq,1,4)) into num_yjbyn from dual;
            if ydlbms = '11' then
                /*休学*/
                if v_xjydxxfs = '2' then
                    num_yjbyn := num_yjbyn + (ydfxxnm - ydsxxnm);
                else
                    select num_yjbyn + round(to_number((to_date(xxjssj,'yyyy-MM-dd') - to_date(xxqssj,'yyyy-MM-dd')))/365,0) into num_yjbyn from dual;
                end if;
                /*保持学制不变，因为后面要更新学生基本信息表的学制*/
                num_ydhxz := num_ydqxz;
            else
                /*休学以外的学籍异动*/
                if ydhnjdm_id is not null and ydhnjdm_id != '' then
                   num_yjbyn := ydhnjdm_id;/*页面传年级，以页面取值为准*/
                end if;
                if num_ydhxz is null then
                   num_ydhxz := num_ydqxz;
                end if;
                num_yjbyn := num_yjbyn + (num_ydhxz - num_ydqxz);
             end if;
             /*如果学院发生变化需要重新获取预计毕业日期（只有日期）*/
             if ydhjg_id is not null and ydhjg_id != '' then
                 select t.yjbyrq into v_yjbyrq from JW_XJGL_YJBYRQJGDZB t where t.jg_id = ydhjg_id;
             end if;
             /*计算获得移动后预计毕业日期*/
             v_ydhyjbyrq := num_yjbyn || '-' || v_yjbyrq;

        end if;
    else
        if num_ydhyjbyrq = 1 then
            if v_ydqyjbyrq is null then
                /*只有日期*/
                select max(t.yjbyrq) into v_yjbyrq from JW_XJGL_YJBYRQJGDZB t where t.jg_id = (select jg_id from jw_xjgl_xsjbxxb where xh_id = xh_ids);
                if v_yjbyrq is null then
                /*结束，异动后预计毕业日期为空*/
                v_ydhyjbyrq := '';
                /*这种情景只插入学籍异动表数据，不更新学生基本信息表*/

                      else
                /*获取学生原来的年级和学制计算移动前预计毕业年*/
                select (to_number(xs.njdm_id) + to_number(xs.xz)) into num_yjbyn from jw_xjgl_xsjbxxb xs where xs.xh_id=xh_ids;
                /*计算移动前预计毕业日期*/
                v_ydqyjbyrq := num_yjbyn || '-' || v_yjbyrq;
                if ydlbms = '11' then   /*休学*/
                  if v_xjydxxfs = '2' then
                    /*休学方式为2:获取休学学制计算规则的后半部分的值*/
                    select fn_jqzd(zdz,',',2) into v_xxxzjsgzz from jw_jcdml_xtnzb where zdm = 'XXXZJSGZ';
                    v_ydxqs := (to_number(ydfxxnm) - to_number(ydsxxnm))*2 + (to_number(v_ydfxxqmmc) - to_number(v_ydsxxqmc));
                    if v_xxxzjsgzz = '0' then
                      /*值为0:一个学期不算一年*/
                      num_yjbyn := num_yjbyn + nvl(fn_jqzd(round(v_ydxqs/2,1),'.', 1),'0');
                    else
                      /*值为1:一个学期算一年*/
                      num_yjbyn := num_yjbyn + (round(v_ydxqs/2));
                    end if;
                   else
                    /*休学方式为1:获取休学学制计算规则的前半部分的区间值*/
                    select fn_jqzd(zdz,',',1) into v_xxxzjsz from jw_jcdml_xtnzb where zdm = 'XXXZJSGZ';
                    v_ydsjb := to_char(((to_number((to_date(xxjssj,'yyyy-MM-dd') - to_date(xxqssj,'yyyy-MM-dd')))/365)),'fm9990.0');
                    /*休学结束时间-休学开始时间的值除以365,在四舍五入一位小数点,小数点的值在区间值内算一年，不在的不算一年*/
                    if v_ydsjb < 1 then
                      if fn_jqzd(v_xxxzjsz,'-',1) < v_ydsjb and v_ydsjb < fn_jqzd(v_xxxzjsz,'-',2) then
                        num_yjbyn := num_yjbyn + 1;
                      end if;
                    else
                      if fn_jqzd(v_xxxzjsz,'-',1) < (v_ydsjb - fn_jqzd(v_ydsjb,'.',1)) and (v_ydsjb - fn_jqzd(v_ydsjb,'.',1)) < fn_jqzd(v_xxxzjsz,'-',2) then
                        num_yjbyn := num_yjbyn + fn_jqzd(v_ydsjb,'.',1) + 1;
                      else
                        num_yjbyn := num_yjbyn + fn_jqzd(v_ydsjb,'.',1);
                      end if;
                    end if;
                   end if;
                   /*保持学制不变，因为后面要更新学生基本信息表的学制*/
                   num_ydhxz := num_ydqxz;
                else   /*休学以外的学籍异动*/
                  if ydhnjdm_id is not null  then
                    num_yjbyn := ydhnjdm_id;/*页面传年级，以页面取值为准*/
                  end if;
                  if num_ydhxz is null then
                    num_ydhxz := num_ydqxz;
                  end if;
                    num_yjbyn := num_yjbyn + (num_ydhxz - num_ydqxz);
                end if;
                /*如果学院发生变化需要重新获取预计毕业日期（只有日期）*/
                if ydhjg_id is not null and ydhjg_id != '' then
                   select t.yjbyrq into v_yjbyrq from JW_XJGL_YJBYRQJGDZB t where t.jg_id = ydhjg_id;
                end if;
                /*计算获得异动后预计毕业日期*/
                v_ydhyjbyrq := num_yjbyn || '-' || v_yjbyrq;

              end if;
           else
                /*学生基本信息表有预计毕业日期*/
              if ydlbms = '11' then   /*休学*/
                    select substr(v_ydqyjbyrq, 6) into v_yjbyrq from dual; /*计算异动后预计毕业日期*/
                    select to_number(substr(v_ydqyjbyrq, 1, 4)) into num_yjbyn from dual;
                    select x.zdz into v_xjydxxfs from jw_jcdml_xtnzb x where x.zdm = 'XJYDXXFS';/*休学方式*/
                    if v_xjydxxfs = '2' then
                        /*休学方式为2:获取休学学制计算规则的后半部分的值*/
                        select fn_jqzd(zdz,',',2) into v_xxxzjsgzz from jw_jcdml_xtnzb where zdm = 'XXXZJSGZ';
                        v_ydxqs := (to_number(ydfxxnm) - to_number(ydsxxnm))*2 + (to_number(v_ydfxxqmmc) - to_number(v_ydsxxqmc));
                        if v_xxxzjsgzz = '0' then
                            /*值为0:一个学期不算一年*/
                            num_yjbyn := num_yjbyn + nvl(fn_jqzd(round(v_ydxqs/2,1),'.', 1),'0');
                        else
                            /*值为1:一个学期算一年*/
                            num_yjbyn := num_yjbyn + (round(v_ydxqs/2) );
                        end if;
                    else
                        /*休学方式为1:获取休学学制计算规则的前半部分的区间值*/
                        select fn_jqzd(zdz,',',1) into v_xxxzjsz from jw_jcdml_xtnzb where zdm = 'XXXZJSGZ';
                        v_ydsjb := to_char(((to_number((to_date(xxjssj,'yyyy-MM-dd') - to_date(xxqssj,'yyyy-MM-dd')))/365)),'fm9990.0');
                        /*休学结束时间-休学开始时间的值除以365,在四舍五入一位小数点,小数点的值在区间值内算一年，不在的不算一年*/
                        if v_ydsjb < 1 then
                            if fn_jqzd(v_xxxzjsz,'-',1) < v_ydsjb and v_ydsjb < fn_jqzd(v_xxxzjsz,'-',2) then
                                num_yjbyn := num_yjbyn + 1;
                            end if;
                        else
                            if fn_jqzd(v_xxxzjsz,'-',1) < (v_ydsjb - fn_jqzd(v_ydsjb,'.',1)) and (v_ydsjb - fn_jqzd(v_ydsjb,'.',1)) < fn_jqzd(v_xxxzjsz,'-',2) then
                                num_yjbyn := num_yjbyn + fn_jqzd(v_ydsjb,'.',1) + 1;
                            else
                                num_yjbyn := num_yjbyn + fn_jqzd(v_ydsjb,'.',1);
                            end if;
                        end if;
                    end if;
                    /*保持学制不变，因为后面要更新学生基本信息表的学制*/
                    num_ydhxz := num_ydqxz;
              else   /*休学以外的学籍异动*/
                    if ydhnjdm_id is not null  then
                        num_yjbyn := ydhnjdm_id;/*页面传年级，以页面取值为准*/
                    end if;
                    if num_ydhxz is null then
                        num_ydhxz := num_ydqxz;
                    end if;
                    num_yjbyn := num_yjbyn + (num_ydhxz - num_ydqxz);
              end if;
                /*如果学院发生变化需要重新获取预计毕业日期（只有日期）*/
                if ydhjg_id is not null and ydhjg_id != '' then
                  select t.yjbyrq into v_yjbyrq from JW_XJGL_YJBYRQJGDZB t where t.jg_id = ydhjg_id;
                end if;
                /*计算获得异动后预计毕业日期*/
                v_ydhyjbyrq := num_yjbyn || '-' || v_yjbyrq;
          end if;

      else
           select xs.yjbyrq into v_ydqyjbyrq from jw_xjgl_xsjbxxb xs where xs.xh_id=xh_ids;
           v_ydhyjbyrq := v_ydqyjbyrq;
      end if;

    end if;
    out_ydhyjbyrq := v_ydhyjbyrq;

  exception
      When others then
      out_ydhyjbyrq := '';
end proc_sp_xjydwhyjbyrq;

/

