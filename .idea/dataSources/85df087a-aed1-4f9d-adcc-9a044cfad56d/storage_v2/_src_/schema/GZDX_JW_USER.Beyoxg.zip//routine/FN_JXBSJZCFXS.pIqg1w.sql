create function fn_jxbsjzcfxs(v_xnm varchar2,v_xqm varchar2,v_jgh_id varchar2,v_sjz varchar2) return number  ---教学班实践周重复学时
as
   v_sjzcfjxbxs number;--时间周重复教学班学时
begin
   select count(*) into v_sjzcfjxbxs from (
      select distinct a.xnm,a.xqm,a.jgh_id,xl.dxqzc,a.xqj,b.rn as jc from
      (select t1.xnm,t1.xqm,t1.jxb_id,t1.jgh_id,
      bitand(t1.zcd,v_sjz) as zcd,
      t1.xqj,
      t1.jc
       from jw_pk_kbsjb t1 where xnm = v_xnm and xqm =v_xqm and jgh_id = v_jgh_id and bitand(t1.zcd,v_sjz) > 0
      ) a,
     (select t1.xnm,t1.xqm,t2.dxqzc,t2.xqj,t2.rq from jw_pk_xlb t1,jw_pk_rcmxb t2
                        where t1.xl_id = t2.xl_id) xl,
     (select rownum rn from zftal_xtgl_jcsjlxb where rownum <20) b
    where a.xnm = xl.xnm
      and a.xqm = xl.xqm
      and a.xqj = xl.xqj
      and bitand(a.zcd,power(2,xl.dxqzc-1)) > 0
      and bitand(a.jc,power(2,b.rn-1)) > 0
    );
   return v_sjzcfjxbxs;
end fn_jxbsjzcfxs;

/

