create function get_Jxbmc(v_kch_id  in varchar2,
                                         v_xnm in varchar2,
                                         v_xqm in varchar2)
Return varchar2
as
  v_kch varchar2(120);
  v_kcmc varchar2(140);
  v_xnmc varchar2(120);
  v_xqmc varchar2(120);
  v_scfs varchar2(12);
  out_jxbmc varchar2(4000);
  out_ycbj varchar2(112);
begin
select kch,kcmc into v_kch,v_kcmc from jw_jh_kcdmb where kch_id=v_kch_id;
  select xnmc into v_xnmc from jw_jcdm_xnb where xnm=v_xnm;
  select mc into v_xqmc from zftal_xtgl_jcsjb where lx='0001' and dm=v_xqm;
  select zdz into v_scfs from jw_jcdml_xtnzb where zdm='JXBSCFS';
  out_ycbj:='0';
  if v_scfs=1 then
  ----教学班生成方式：1，课程名称-流水号
    begin
    select v_kcmc||'-'||nvl(lpad(max(substr(jxbmc,instr(jxbmc,'-',-1)+1,4))+1,4,'0'),'0001') jxbmc into out_jxbmc
    from jw_jxrw_jxbxxb where xnm = v_xnm and xqm = v_xqm and jxbmc like '%'||v_kcmc||'-%' and lpad(substr(jxbmc,instr(jxbmc,'-',-1)+1,4),4,'9') <'9999';
    exception
      When others then
      out_ycbj:='1';
    end;
  elsif v_scfs=2 then
  ----教学班生成方式：2，流水号
    begin
    select nvl(max(jxbmc)+1,1) jxbmc into out_jxbmc
    from jw_jxrw_jxbxxb where xnm = v_xnm and xqm = v_xqm and jxbmc not like '%-%' and kch_id = v_kch_id and '9'||lpad(jxbmc,4,'9')<'99999';
    exception
      When others then
      out_ycbj:='1';
    end;
  elsif v_scfs=3 then
  ----教学班生成方式：3，(学年名称-学期名称)-课程号-流水号
     begin
    select '('||v_xnmc||'-'||v_xqmc||')-'||v_kch||'-'||nvl(max(substr(jxbmc,instr(jxbmc,'-',-1)+1,4))+1,1) jxbmc into out_jxbmc
    from jw_jxrw_jxbxxb where xnm = v_xnm and xqm = v_xqm and jxbmc like '%('||v_xnmc||'-'||v_xqmc||')-'||v_kch||'-%' and lpad(substr(jxbmc,instr(jxbmc,'-',-1)+1,4),4,'9') <'9999';
    exception
      When others then
      out_ycbj:='1';
    end;
  else
    select '' into out_jxbmc from dual;
  end if;
  return out_jxbmc;
end;

/

