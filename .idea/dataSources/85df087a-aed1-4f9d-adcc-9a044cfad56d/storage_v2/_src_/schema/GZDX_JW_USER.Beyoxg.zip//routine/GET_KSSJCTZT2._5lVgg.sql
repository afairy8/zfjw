create function get_kssjctzt2(
    vXnm varchar2,--学年
    vXqm varchar2,--学期
    vKsmcdmb_id varchar2,--考试名称代码表ID
    vSjbh_ids varchar2,--试卷编号IDS
    vKsrq varchar2,--考试日期
    vKskssj varchar2,--考试开始时间
    vKsjssj varchar2,--考试结束时间
    vPkfs varchar2,--排考方式(1先排考后选课，只判断学生考试冲突到年级专业维度,2先选课后排考)
    vSfbkbj varchar2,--是否补考标记
    vSfpdxsskct varchar2,--是否判断学生上课冲突
    vXzbpkszt varchar2,--行政班一天只排一场考试
    vSfjzkslp varchar2,--是否禁止考试连排
    vYtzdyxksms varchar2--一天最多允许考试门数
)
    return number
as
    sCtzt number := 0;--返回的冲突状态
    sXqh_id varchar2(32);--校区号ID
    sZcd number;--周次段
    sXqj number;--星期几
    sJcd number;--节次段
    iCount number;
begin
    if vPkfs = '1' then --先排考后选课
        select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbhbxxb t4,jw_jxrw_bkzybjdzb t5
        where t1.xnm = t2.xnm
          and t1.xqm = t2.xqm
          and t1.xnm = t3.xnm
          and t1.xqm = t3.xqm
          and t1.sjbh_id = t3.sjbh_id
          and t1.ksccb_id = t2.ksccb_id
          and t2.ksmcdmb_id = t3.ksmcdmb_id
          and t3.jxb_id = t4.jxb_id
          and t1.xnm = vXnm
          and t1.xqm = vXqm
          and t3.xnm = vXnm
          and t3.xqm = vXqm
          and t2.ksrq = vKsrq
          and t2.ksjssj >= vKskssj
          and t2.kskssj <= vKsjssj
          and t4.bkxxb_id=t5.bkxxb_id(+)
          and nvl(t5.zyh_id,t4.zyh_id) != 'wzy'
          and exists(
                select 'X' from jw_jxrw_jxbhbxxb hb, jw_kw_ksmcjxbdzb dzb,jw_jxrw_bkzybjdzb bk
                where instr(vSjbh_ids,dzb.sjbh_id)>0
                  and dzb.xnm = vXnm
                  and dzb.xqm = vXqm
                  and dzb.ksmcdmb_id = vKsmcdmb_id
                  and dzb.jxb_id = hb.jxb_id
                  and hb.bkxxb_id = bk.bkxxb_id(+)
                  and nvl(bk.njdm_id,hb.njdm_id) = nvl(t5.njdm_id,t4.njdm_id)
                  and nvl(bk.zyh_id,hb.zyh_id) = nvl(t5.zyh_id,t4.zyh_id)
            );
        if iCount > 0 then
            sCtzt := 1;
            return sCtzt;
        end if;
    else --先选课后排考
        if vSfbkbj = '1' then --学生考试与考试冲突(正考学生)
            select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
            where t1.xnm = t2.xnm
              and t1.xqm = t2.xqm
              and t1.xnm = t3.xnm
              and t1.xqm = t3.xqm
              and t1.sjbh_id = t3.sjbh_id
              and t1.ksccb_id = t2.ksccb_id
              and t2.ksmcdmb_id = t3.ksmcdmb_id
              and t3.jxb_id = t4.jxb_id
              and t1.xnm = vXnm
              and t1.xqm = vXqm
              and t3.xnm = vXnm
              and t3.xqm = vXqm
              and t4.xnm = vXnm
              and t4.xqm = vXqm
              and t2.ksrq = vKsrq
              and t2.ksjssj >= vKskssj
              and t2.kskssj <= vKsjssj
              and exists(
                    select bk.xh_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb
                    where instr(vSjbh_ids,dzb.sjbh_id)>0
                      and dzb.xnm=vXnm and dzb.xqm=vXqm
                      and dzb.ksmcdmb_id = vKsmcdmb_id
                      and dzb.jxb_id=bk.jxb_id
                      and bk.bkqrbj = '1'
                      and t4.xh_id = bk.xh_id
                );
        else
            select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_xk_xsxkb t4
            where t1.xnm = t2.xnm
              and t1.xqm = t2.xqm
              and t1.xnm = t3.xnm
              and t1.xqm = t3.xqm
              and t1.sjbh_id = t3.sjbh_id
              and t1.ksccb_id = t2.ksccb_id
              and t2.ksmcdmb_id = t3.ksmcdmb_id
              and t3.jxb_id = t4.jxb_id
              and t1.xnm = vXnm
              and t1.xqm = vXqm
              and t3.xnm = vXnm
              and t3.xqm = vXqm
              and t4.xnm = vXnm
              and t4.xqm = vXqm
              and t2.ksrq = vKsrq
              and t2.ksjssj >= vKskssj
              and t2.kskssj <= vKsjssj
              and exists(
                    select xk.xh_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_cj_bzdmb bz
                    where instr(vSjbh_ids,dzb.sjbh_id)>0
                      and xk.xnm=vXnm and xk.xqm=vXqm
                      and dzb.xnm=vXnm and dzb.xqm=vXqm
                      and dzb.ksmcdmb_id = vKsmcdmb_id
                      and dzb.jxb_id=xk.jxb_id
                      and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                      and t4.xh_id = xk.xh_id
                );
        end if;
        if iCount > 0 then
            sCtzt := 1;
            return sCtzt;
        end if;

        if vSfbkbj = '1' then --学生考试与考试冲突(补考学生)
            select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
            where t1.xnm = t2.xnm
              and t1.xqm = t2.xqm
              and t1.xnm = t3.xnm
              and t1.xqm = t3.xqm
              and t1.sjbh_id = t3.sjbh_id
              and t1.ksccb_id = t2.ksccb_id
              and t2.ksmcdmb_id = t3.ksmcdmb_id
              and t3.jxb_id = t4.jxb_id
              and t4.bkqrbj = '1'
              and t1.xnm = vXnm
              and t1.xqm = vXqm
              and t3.xnm = vXnm
              and t3.xqm = vXqm
              and t4.xnm = vXnm
              and t4.xqm = vXqm
              and t2.ksrq = vKsrq
              and t2.ksjssj >= vKskssj
              and t2.kskssj <= vKsjssj
              and exists(
                    select bk.xh_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb
                    where instr(vSjbh_ids,dzb.sjbh_id)>0
                      and dzb.xnm=vXnm and dzb.xqm=vXqm
                      and dzb.ksmcdmb_id = vKsmcdmb_id
                      and dzb.jxb_id=bk.jxb_id
                      and bk.bkqrbj = '1'
                      and t4.xh_id = bk.xh_id
                );
        else
            select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_kw_bkmdb t4
            where t1.xnm = t2.xnm
              and t1.xqm = t2.xqm
              and t1.xnm = t3.xnm
              and t1.xqm = t3.xqm
              and t1.sjbh_id = t3.sjbh_id
              and t1.ksccb_id = t2.ksccb_id
              and t2.ksmcdmb_id = t3.ksmcdmb_id
              and t3.jxb_id = t4.jxb_id
              and t4.bkqrbj = '1'
              and t1.xnm = vXnm
              and t1.xqm = vXqm
              and t3.xnm = vXnm
              and t3.xqm = vXqm
              and t4.xnm = vXnm
              and t4.xqm = vXqm
              and t2.ksrq = vKsrq
              and t2.ksjssj >= vKskssj
              and t2.kskssj <= vKsjssj
              and exists(
                    select xk.xh_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_cj_bzdmb bz
                    where instr(vSjbh_ids,dzb.sjbh_id)>0
                      and xk.xnm=vXnm and xk.xqm=vXqm
                      and dzb.xnm=vXnm and dzb.xqm=vXqm
                      and dzb.ksmcdmb_id = vKsmcdmb_id
                      and dzb.jxb_id=xk.jxb_id
                      and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                      and t4.xh_id = xk.xh_id
                );
        end if;
        if iCount > 0 then
            sCtzt := 1;
            return sCtzt;
        end if;

        if vSfpdxsskct = '1' then --判断学生上课冲突
            select min(ksxq.xqh_id) into sXqh_id from jw_kw_ksmcxqb ksxq where ksxq.ksmcdmb_id=vKsmcdmb_id and exists(select 'X' from jw_pk_rsdszb where xqh_id=ksxq.xqh_id);
            select nvl(sum(t2.jcm),0) into sJcd from jw_pk_rsdszb t1,jw_pk_rjcszb t2
            where t1.rsdsz_id = t2.rsdsz_id
              and t1.xnm = vXnm
              and t1.xqm = vXqm
              and substr(t2.jssj,1,5) >= to_char(to_date(vKskssj,'hh24:mi')-(select zdz from JW_JCDML_XTNZB where XTNZ_ID='KSCTJCSJ')/1440,'hh24:mi')
              and substr(t2.qssj,1,5) <= to_char(to_date(vKsjssj,'hh24:mi')+(select zdz from JW_JCDML_XTNZB where XTNZ_ID='KSCTJCSJ')/1440,'hh24:mi')
              and t1.xqh_id = sXqh_id;
            select nvl(max(power(2,t2.dxqzc-1)),0) zcd,nvl(max(t2.xqj),0) xqj into sZcd,sXqj
            from jw_pk_xlb t1,jw_pk_rcmxb t2 where t1.xl_id = t2.xl_id and t1.xnm = vXnm and t1.xqm = vXqm and t2.rq = vKsrq;

            if sZcd>0 and sXqj>0 and sJcd>0 then --对应到上课周次
                if vSfbkbj = '1' then
                    select count(1) into iCount from jw_xk_xsxkb t1,jw_pk_kbsjb t2
                    where t1.xnm = t2.xnm
                      and t1.xqm = t2.xqm
                      and t1.jxb_id = t2.jxb_id
                      and t1.xnm = vXnm
                      and t1.xqm = vXqm
                      and bitand(t2.zcd,sZcd) > 0
                      and t2.xqj = sXqj
                      and bitand(t2.jc,sJcd) > 0
                      and nvl(t1.zxbj,'0')='0'
                      and exists(
                            select bk.xh_id from jw_kw_bkmdb bk,jw_kw_ksmcjxbdzb dzb
                            where instr(vSjbh_ids,dzb.sjbh_id)>0
                              and dzb.xnm=vXnm and dzb.xqm=vXqm
                              and dzb.ksmcdmb_id = vKsmcdmb_id
                              and dzb.jxb_id=bk.jxb_id
                              and bk.bkqrbj = '1'
                              and t1.xh_id = bk.xh_id
                        );
                else
                    select count(1) into iCount from jw_xk_xsxkb t1,jw_pk_kbsjb t2
                    where t1.xnm = t2.xnm
                      and t1.xqm = t2.xqm
                      and t1.jxb_id = t2.jxb_id
                      and t1.xnm = vXnm
                      and t1.xqm = vXqm
                      and bitand(t2.zcd,sZcd) > 0
                      and t2.xqj = sXqj
                      and bitand(t2.jc,sJcd) > 0
                      and nvl(t1.zxbj,'0')='0'
                      and exists(
                            select xk.xh_id from jw_xk_xsxkb xk,jw_kw_ksmcjxbdzb dzb,jw_cj_bzdmb bz
                            where instr(vSjbh_ids,dzb.sjbh_id)>0
                              and xk.xnm=vXnm and xk.xqm=vXqm
                              and dzb.xnm=vXnm and dzb.xqm=vXqm
                              and dzb.ksmcdmb_id = vKsmcdmb_id
                              and dzb.jxb_id=xk.jxb_id
                              and bz.cjbzmc(+)=xk.ksbz and nvl(bz.ksxs,'2') != '0'
                              and t1.xh_id = xk.xh_id
                        );
                end if;
                if iCount > 0 then
                    sCtzt := 1;
                    return sCtzt;
                end if;
            end if;
        end if; --判断学生上课冲突end

        if vYtzdyxksms != '0' then--一天最多允许考试门数
            if vSfbkbj != '1' then
                select max(cc) into iCount from
                    (select count(1) cc
                     from JW_KW_KSMCJXBDZB dz,JW_KW_KSSJB sj,JW_XK_XSXKB xk,JW_KW_KSCCB cc,JW_JXRW_JXBXXB jxb
                     where dz.SJBH_ID=sj.SJBH_ID and sj.KSMCDMB_ID=dz.KSMCDMB_ID
                       and cc.KSCCB_ID=sj.KSCCB_ID
                       and jxb.JXB_ID=dz.JXB_ID
                       and xk.JXB_ID=jxb.JXB_ID
                       and xk.XH_ID in (select xk.XH_ID from JW_KW_KSMCJXBDZB dz,JW_JXRW_JXBXXB jxb,JW_XK_XSXKB xk
                                        where dz.JXB_ID=jxb.JXB_ID and dz.KSMCDMB_ID=vKsmcdmb_id and xk.JXB_Id=jxb.JXB_ID
                                          and instr(vSjbh_ids,dz.sjbh_id)>0)
                       and cc.KSMCDMB_ID=vKsmcdmb_id
                       and cc.KSRQ=vKsrq
                     group by xk.XH_ID);
            else
                select max(cc) into iCount from
                    (select count(1) cc
                     from JW_KW_KSMCJXBDZB dz,JW_KW_KSSJB sj,JW_KW_BKMDB xk,JW_KW_KSCCB cc,JW_JXRW_JXBXXB jxb
                     where dz.SJBH_ID=sj.SJBH_ID and sj.KSMCDMB_ID=dz.KSMCDMB_ID
                       and cc.KSCCB_ID=sj.KSCCB_ID
                       and jxb.JXB_ID=dz.JXB_ID
                       and xk.JXB_ID=jxb.JXB_ID
                       and xk.XH_ID in (select bk.XH_ID from JW_KW_KSMCJXBDZB dz,JW_JXRW_JXBXXB jxb,JW_KW_BKMDB bk
                                        where dz.JXB_ID=jxb.JXB_ID and dz.KSMCDMB_ID=vKsmcdmb_id and bk.JXB_Id=jxb.JXB_ID
                                          and instr(vSjbh_ids,dz.sjbh_id)>0)
                       and cc.KSMCDMB_ID=vKsmcdmb_id
                       and cc.KSRQ=vKsrq
                     group by xk.XH_ID);
            end if;
            if iCount >= to_number(vYtzdyxksms) then
                sCtzt := 1;
                return sCtzt;
            end if;
        end if;--一天最多允许考试门数end
    end if;
    if vXzbpkszt = '1' and vSfbkbj != '1' then --行政班一天只排一场考试
        select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbhbxxb t4
        where t1.xnm = t2.xnm
          and t1.xqm = t2.xqm
          and t3.xnm = t2.xnm
          and t3.xqm = t2.xqm
          and t1.sjbh_id = t3.sjbh_id
          and t1.ksccb_id = t2.ksccb_id
          and t2.ksmcdmb_id = t3.ksmcdmb_id
          and t3.jxb_id = t4.jxb_id
          and t2.xnm = vXnm
          and t2.xqm = vXqm
          and t3.xnm = vXnm
          and t3.xqm = vXqm
          and t2.ksrq = vKsrq
          and exists(
                select hb.bh_id from jw_jxrw_jxbhbxxb hb, jw_kw_ksmcjxbdzb dzb
                where instr(vSjbh_ids,dzb.sjbh_id)>0
                  and dzb.xnm = vXnm
                  and dzb.xqm = vXqm
                  and dzb.ksmcdmb_id = vKsmcdmb_id
                  and dzb.jxb_id = hb.jxb_id
                  and hb.bh_id != 'wbj'
                  and t4.bh_id = hb.bh_id
            );
        if iCount > 0 then
            sCtzt := 1;
            return sCtzt;
        end if;
    end if; --行政班一天只排一场考试end

    if vSfjzkslp = '1' and vSfbkbj != '1' then --禁止连排
        select count(1) into iCount from jw_kw_kssjb t1,jw_kw_ksccb t2,jw_kw_ksmcjxbdzb t3,jw_jxrw_jxbhbxxb t4
        where t1.xnm = t2.xnm
          and t1.xqm = t2.xqm
          and t3.xnm = t2.xnm
          and t3.xqm = t2.xqm
          and t1.sjbh_id = t3.sjbh_id
          and t1.ksccb_id = t2.ksccb_id
          and t2.ksmcdmb_id = t3.ksmcdmb_id
          and t3.jxb_id = t4.jxb_id
          and t2.xnm = vXnm
          and t2.xqm = vXqm
          and t3.xnm = vXnm
          and t3.xqm = vXqm
          and t2.ksrq = vKsrq
          and t2.ksjssj >= to_char(to_date(vKskssj,'hh24:mi')-120/1440,'hh24:mi')--前后加2小时
          and t2.kskssj <= to_char(to_date(vKsjssj,'hh24:mi')+120/1440,'hh24:mi')
          and exists(
                select hb.bh_id from jw_jxrw_jxbhbxxb hb, jw_kw_ksmcjxbdzb dzb
                where instr(vSjbh_ids,dzb.sjbh_id)>0
                  and dzb.xnm = vXnm
                  and dzb.xqm = vXqm
                  and dzb.ksmcdmb_id = vKsmcdmb_id
                  and dzb.jxb_id = hb.jxb_id
                  and hb.bh_id != 'wbj'
                  and t4.bh_id = hb.bh_id
            );
        if iCount > 0 then
            sCtzt := 1;
            return sCtzt;
        end if;
    end if; --禁止连排end
    return sCtzt;
end get_kssjctzt2;


/

