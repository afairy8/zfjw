create procedure PROC_SC_BYXSSH(
   V_NJDM_ID in VARCHAR2,
   V_ZYH_ID in VARCHAR2,
   V_TJ_ID in VARCHAR2,
   V_XH_ID in VARCHAR2,
   out_shjg out varchar2,
   out_shyy out varchar2) as

   v_tjsjz varchar2(10);
   v_count varchar2(10);
------学生毕业自审核
begin

   v_tjsjz:= '';

      select count(1) into v_count
          from jw_bygl_shtjb       t,
               jw_bygl_shtjsjsyzyb t1,
               jw_bygl_shtjsjb     t2,
               jw_bygl_shtjsjsyb   t3
         where t1.tjsjsy_id = t3.tjsjsy_id
           and t3.tjsj_id = t2.tjsj_id
           and t2.tj_id = t.tj_id
           and t.tjlx = '3'
           and t1.tjsy = '1'
           and exists (select 1
                  from jw_jh_jxzxjhxxb jh
                 where jh.jxzxjhxx_id = t1.jxzxjhxx_id
                   and jh.njdm_id = V_NJDM_ID
                   and jh.zyh_id = V_ZYH_ID)
           and t.tj_id=V_TJ_ID;

if v_count>0 then
   select t1.tjsjz into v_tjsjz

          from jw_bygl_shtjb       t,
               jw_bygl_shtjsjsyzyb t1,
               jw_bygl_shtjsjb     t2,
               jw_bygl_shtjsjsyb   t3
         where t1.tjsjsy_id = t3.tjsjsy_id
           and t3.tjsj_id = t2.tjsj_id
           and t2.tj_id = t.tj_id
           and t.tjlx = '3'
           and t1.tjsy = '1'
           and exists (select 1
                  from jw_jh_jxzxjhxxb jh
                 where jh.jxzxjhxx_id = t1.jxzxjhxx_id
                   and jh.njdm_id = V_NJDM_ID
                   and jh.zyh_id = V_ZYH_ID)
           and t.tj_id=V_TJ_ID;
  end if;

  if V_TJ_ID='30000001' and v_tjsjz is not null  then
  ----学生获得学分/本专业要求最低毕业学分

   out_shyy := fun_byysh_hdxfbl(V_XH_ID,v_tjsjz);
    if instr(out_shyy, '不合格') > 0 then
      out_shjg:= '2';--不通过
    else
      out_shjg:= '1';--通过
    end if;
  else
    select '' into out_shyy from dual;
  end if;
end PROC_SC_BYXSSH;

/

