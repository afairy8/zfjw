create Function Get_LXJCGS(vBinary in integer,vGs in integer)
  Return integer as
  aJc integer; ---节次变量
  rst integer;
begin
  if nvl(vBinary, 0) = 0 then
    return 0;
  else
    rst := 0;
    for aJc in 0 .. log(2, vBinary) loop
      ---log(2,vBinary)取整
      if bitand(vBinary, power(2, aJc)) = power(2, aJc) then
        ---利用位运算取出二进制数对应的第几节次
        rst := rst + 1;
      else
        rst := 0;
      end if;
      if rst >= vGs then
        RETURN rst;
       END IF;
    end loop;
    return rst;
  end if;
end;

/

