create function fun_by_gjwysjsh_bak(v_xh_id varchar2) return varchar2
as
   sJg varchar2(2000);   ---通过国家外语四级考试
   v_wysjcount number;  --外语四级个数
   v_wysjcj number;     --外语四级成绩
   v_yypjcj number;     --英语平均成绩
begin
    sJg := '合格';
    begin
    select count(1),nvl(max(a.xmbfzcj),0) into v_wysjcount,v_wysjcj  from view_by_cetcjb a where xh_id = ''||v_xh_id||'' and xmdm='CET-4' ;
    if v_wysjcount =  0 or v_wysjcj<425 then
       sJg :='无外语四级考试成绩或低于425不及格！';

      ---查询英语平均成绩
        select avg(e.bfzcj) into v_yypjcj
         from (select a.kcxzdm,
                a.xh_id,
                a.jd,
                a.xf,
                a.jxb_id,
                a.kch_id,
                a.bfzcj,
                row_number() over(partition by a.xh_id, a.kch_id order by nvl(a.bfzcj,0) desc) rn
           from jw_cj_xscjb a
          where 1 = 1
          and a.kcmc like '%大学英语%'
            and not exists (select 'X'
                   from jw_cj_cjjglxsqb zfb
                  where zfb.cjjglx = '01'
                    and zfb.shzt = '3'
                    and zfb.xh_id = a.xh_id
                    and zfb.kch_id = a.kch_id)
            and a.xh_id = ''||v_xh_id||'') e
           where rn = 1;

        if v_yypjcj >=70 then
           sJg :=sJg||'大学英语平均成绩'||v_yypjcj||',合格！';
        else
            sJg :=sJg||'大学英语平均成绩'||v_yypjcj||'低于70,不合格！';
        end if;

    else
      sJg := '四级成绩为'||v_wysjcj||',合格！';
    end if;
     exception
        When others then
          sJg := '查询出错，不合格！';
    end;

    if sJg is null then
     return '系统无数据，不合格！' ;
    else
    return sJg ;
    end if ;
end fun_by_gjwysjsh_bak;
/

